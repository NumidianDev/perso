using System;
using System.Collections.Generic;
using AutoMapper;
using FormuleSrv.Helpers;
using FormuleSrv.Models.BA;
using FormuleSrv.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;

namespace FormuleSrv.Controllers {

    [ApiController]
    [Route ("[controller]")]
    public class DeclarationsController : BaseController {
        private readonly IDeclarationService _declarationService;
        private readonly IMapper _mapper;

        public DeclarationsController (
            IDeclarationService declarationService,
            IMapper mapper,
            DataContext context) {
            _declarationService = declarationService;
            _mapper = mapper;
        }

        [Authorize]
        [HttpGet ("formules")]
        public ActionResult<IEnumerable<FormuleDTO>> GetAllFormules () {
            var formules = _declarationService.GetAllFormules ();
            return Ok (formules);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<FormuleDTO> GetFormuleById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var formule = _declarationService.GetFormuleById (id);
            return Ok (formule);
        }

        [Authorize]
        [HttpGet ("declarations")]
        public ActionResult<DeclarationDTO> GetAllDeclarations () {
            var response = _declarationService.GetAllDeclarations ();
            return Ok (response);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<DeclarationDTO> GetDeclarationById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var declaration = _declarationService.GetDeclarationById (id);
            return Ok (declaration);
        }

        [Authorize]
        [HttpGet ("fichiersXml")]
        public ActionResult<FichierXmlDTO> GetAllXML () {
            var response = _declarationService.GetAllXML ();
            return Ok (response);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<FichierXmlDTO> GetXmlById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var fichierXml = _declarationService.GetXMLById (id);
            return Ok (fichierXml);
        }

        [Authorize]
        [HttpGet ("generateXMLDeclaration")]
        public ActionResult generateXMLDeclaration (int id) {

            var outPutFile = _declarationService.generateXMLDeclaration (id);

            var memory = new System.IO.MemoryStream ();
            using (var stream = new System.IO.FileStream (outPutFile, System.IO.FileMode.Open)) {
                stream.CopyTo (memory);
            }
            memory.Position = 0;

            return File (memory, GetContentType (outPutFile), outPutFile);

            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var fichierXml = _declarationService.GetXMLById (id);
            return Ok (fichierXml);
        }

        private string GetContentType (string outPutFile) {
            var provider = new FileExtensionContentTypeProvider ();
            string contentType;

            if (!provider.TryGetContentType (outPutFile, out contentType)) {
                contentType = "application/octet-stream";
            }

            return contentType;
        }

        [Authorize]
        [HttpGet ("bordereaux")]
        public ActionResult<BordereauDTO> GetAllBordreaux () {
            var response = _declarationService.GetAllBordreaux ();
            return Ok (response);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<BordereauDTO> GetBordereauById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var bordereaux = _declarationService.GetBordereauById (id);
            return Ok (bordereaux);
        }
    }
}