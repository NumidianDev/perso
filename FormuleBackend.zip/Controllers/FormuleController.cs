using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Net.Mime;
using System.Reflection;
using AutoMapper;
using FormuleSrv.Entities;
using FormuleSrv.Helpers;
using FormuleSrv.Models.BA;
using FormuleSrv.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;


namespace FormuleSrv.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class FormuleController : BaseController
    {
        private readonly IDeclarationService _declarationService;
        private readonly IMapper _mapper;
        private ILogger<FormuleController> logger;
        private readonly ConnectionStrings _connectionStrings;
        public DataContext _context;

        public FormuleController(
            IDeclarationService declarationService,
            IMapper mapper,
            IOptions<ConnectionStrings> appSettings,
            DataContext context)
        {
            _declarationService = declarationService;
            _mapper = mapper;
            _connectionStrings = appSettings.Value;
             _context = context;
        }

    


        [Authorize]
        [HttpGet("formules")]
        public ActionResult<IEnumerable<FormuleDTO>> GetAllFormules()
        {
            var formules = _declarationService.GetAllFormules();
            return Ok(formules);
        }

        [Authorize]
        [HttpGet("{id:int}")]
        public ActionResult<FormuleDTO> GetFormuleById(int id)
        {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var formule = _declarationService.GetFormuleById(id);
            return Ok(formule);
        }

         [HttpGet]
        [Route("GetFormule4")]
        public System.Object GetFormule4()

        {   IEnumerable<Formule4> list;

             list = _context.F04Source.ToList();
             if (list!=null) return list ;
             else return null ; 

        }

        [HttpGet]
        [Route("GetFormule4FromDelta")]
        public List<Formule4> GetFormule4FromDelta()
        {
            List<Formule4> formuleListe = new List<Formule4>();
            var requete = System.IO.File.ReadAllText(@"D:\QueryFolder\F4Quey.sql");
            using (var con = new OleDbConnection(_connectionStrings.sga))
            {
                con.Open();
                OleDbCommand command = con.CreateCommand();
                command.CommandTimeout = 1000000000;
                command.CommandType = CommandType.Text;
                command.CommandText = requete;
                var da = new OleDbDataAdapter(command);
                OleDbDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {

                    while (reader.Read())

                    {
                        var formule = new Formule4();
                        formule.age = (string)reader[1].ToString();
                        formule.ndos = (string)reader[3].ToString();
                        formule.dev = (string)reader[4].ToString();
                        formule.designation_pays = (string)reader[12].ToString();
                        formule.tarif_douanier = (string)reader[13].ToString();
                        formule.num_domiciliation = (string)reader[16].ToString();
                        // formule.code_operation = (string)reader[15].ToString();
                        formule.montant_ba = (string)reader[21].ToString();
                        formule.cours_f = (string)reader[22].ToString();
                        formuleListe.Add(formule);
                    }

                    return formuleListe;
                }


                else return null;


            }
        }















    }
}