﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
using AutoMapper;
using FormuleSrv.Entities;
using FormuleSrv.Helpers;
using FormuleSrv.Models.Accounts;
using FormuleSrv.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FormuleSrv.Controllers {
    [ApiController]
    [Route ("[controller]")]
    public class AccountsController : BaseController {
        private readonly IAccountService _accountService;
        private readonly IMapper _mapper;

        private readonly DataContext _context;

        public AccountsController (
            IAccountService accountService,
            IMapper mapper,
            DataContext context) {
            _accountService = accountService;
            _mapper = mapper;
            _context = context;
            
        }

    //      [HttpPost ("Authenticate")]
            [HttpPost]
            [Route ("Authenticate")]
                public ActionResult<AuthenticateResponse> Authenticate (AuthenticateRequest model) {
            var response = _accountService.Authenticate (model, ipAddress ());
            setTokenCookie (response.RefreshToken);
            return Ok (response);
        }

        [HttpPost ("refresh-token")]
        public ActionResult<AuthenticateResponse> RefreshToken () {
            var refreshToken = Request.Cookies["refreshToken"];
            var response = _accountService.RefreshToken (refreshToken, ipAddress ());
            setTokenCookie (response.RefreshToken);
            return Ok (response);
        }

        [Authorize]
        [HttpPost ("revoke-token")]
        public IActionResult RevokeToken (RevokeTokenRequest model) {
            // accept token from request body or cookie
            var token = model.Token ?? Request.Cookies["refreshToken"];

            if (string.IsNullOrEmpty (token))
                return BadRequest (new { message = "Token is required" });

            // users can revoke their own tokens and admins can revoke any tokens
            if (!Account.OwnsToken (token) && Account.Role != Role.Admin)
                return Unauthorized ();

            _accountService.RevokeToken (token, ipAddress ());
            return Ok (new { message = "Token revoked" });
        }

        [Authorize (Role.Admin)]
        [HttpGet]
        public ActionResult<IEnumerable<AccountResponse>> GetAll () {
            var accounts = _accountService.GetAll ();
            /*FichierXml fdb = null;
            var xmls = _context.FichiersXml
                .Include (f => f.declarations)
                .ThenInclude (d => d.bordereau)
                .Include (f => f.declarations)
                .ThenInclude (d => d.formules)
                .Where (f => f.Id == 1);
            fdb = xmls.First ();

            var fichierBA = _mapper.Map<FormuleSrv.Models.BA.FichierXmlDTO> (fdb);

            using (XmlWriter writer = XmlWriter.Create ("declaration.xml")) {
                writer.WriteStartDocument (false);
                writer.WriteDocType ("fichier_xml", null, "declaration.dtd", null);

                var ns = new XmlSerializerNamespaces (new [] { XmlQualifiedName.Empty });
                XmlSerializer serializer = new XmlSerializer (fichierBA.GetType ());
                //DataContractSerializer serializer = new DataContractSerializer (fichierBA.GetType ());
                serializer.Serialize (writer, fichierBA, ns);
            }*/
            return Ok (accounts);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<AccountResponse> GetById (int id) {
            // users can get their own account and admins can get any account
            if (id != Account.Id && Account.Role != Role.Admin)
                return Unauthorized ();

            var account = _accountService.GetById (id);
            return Ok (account);
        }

        // helper methods

        private void setTokenCookie (string token) {
            var cookieOptions = new CookieOptions {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays (7)
            };
            Response.Cookies.Append ("refreshToken", token, cookieOptions);
        }

        private string ipAddress () {
            if (Request.Headers.ContainsKey ("X-Forwarded-For"))
                return Request.Headers["X-Forwarded-For"];
            else
                return HttpContext.Connection.RemoteIpAddress.MapToIPv4 ().ToString ();
        }
    }
}