namespace FormuleSrv.Models.Accounts
{
    public class RevokeTokenRequest
    {
        public string Token { get; set; }
    }
}