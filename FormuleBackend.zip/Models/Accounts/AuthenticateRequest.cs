using System.ComponentModel.DataAnnotations;

namespace FormuleSrv.Models.Accounts
{
    public class AuthenticateRequest
    {
        [Required]
        public string Matricule { get; set; }

        [Required]
        public string Password { get; set; }
    }
}