using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace FormuleSrv.Models.BA {

    [XmlType]
    public class DeclarationDTO {
        [XmlIgnore]
        public int Id { get; set; }

        [XmlElement]
        public BordereauDTO bordereau { get; set; }

        [XmlElement]
        public List<FormuleDTO> formules { get; set; }
    }
}