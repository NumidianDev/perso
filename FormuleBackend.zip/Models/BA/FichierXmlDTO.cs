using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace FormuleSrv.Models.BA {

    [XmlType ("fichier_xml")]
    public class FichierXmlDTO {

        [XmlIgnore]
        public int Id { get; set; }

        [XmlElement]
        public List<DeclarationDTO> declarations { get; set; }
    }
}