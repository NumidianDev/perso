using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Xml;
using System.Xml.Serialization;
using AutoMapper;
using FormuleSrv.Entities;
using FormuleSrv.Helpers;
using FormuleSrv.Models.BA;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FormuleSrv.Services {

    public interface IDeclarationService {
        IEnumerable<FichierXmlDTO> GetAllXML ();
        IEnumerable<DeclarationDTO> GetAllDeclarations ();
        IEnumerable<BordereauDTO> GetAllBordreaux ();
        IEnumerable<FormuleDTO> GetAllFormules ();
        FichierXmlDTO GetXMLById (int id);
        string generateXMLDeclaration (int id);
        FichierXmlDTO CreateXML (FichierXmlDTO model);
        FichierXmlDTO UpdateXML (int id, FichierXmlDTO model);
        DeclarationDTO GetDeclarationById (int id);
        DeclarationDTO CreateDeclaration (DeclarationDTO model);
        DeclarationDTO UpdateDeclaration (int id, DeclarationDTO model);
        BordereauDTO GetBordereauById (int id);
        BordereauDTO CreateBordereau (BordereauDTO model);
        BordereauDTO UpdateBordereau (int id, BordereauDTO model);
        FormuleDTO GetFormuleById (int id);
        FormuleDTO CreateFormule (FormuleDTO model);
        FormuleDTO UpdateFormule (int id, FormuleDTO model);

    }

    public class DeclarationService : IDeclarationService {
        private readonly IMapper _mapper;

        private readonly DataContext _context;
        private readonly AppSettings _appSettings;
        //private readonly IEmailService _emailService;

        public DeclarationService (
            DataContext context,
            IMapper mapper,
            IOptions<AppSettings> appSettings
            /*,IEmailService emailService*/
        ) {
            _context = context;
            _mapper = mapper;
            _appSettings = appSettings.Value;
            //_emailService = emailService;
        }

        public BordereauDTO CreateBordereau (BordereauDTO model) {
            // validate
            if (_context.Bordereaux.Any (b => (b.DATE_VALEUR.Value.Date == model.DATE_VALEUR.Value.Date) &&
                    (b.MONNAIE.ToLower ().Equals (model.MONNAIE, StringComparison.CurrentCultureIgnoreCase))))
                throw new AppException ($"Bordereau '{model.DATE_VALEUR}' est déjà enregistré pour la monaie '{model.MONNAIE}'");
            var bordereau = _mapper.Map<Bordereau> (model);
            _context.Bordereaux.Add (bordereau);
            _context.SaveChanges ();
            return _mapper.Map<BordereauDTO> (bordereau);
        }

        public DeclarationDTO CreateDeclaration (DeclarationDTO model) {
            // validate

            var declaration = _mapper.Map<Declaration> (model);
            _context.Declarations.Add (declaration);
            _context.SaveChanges ();
            return _mapper.Map<DeclarationDTO> (declaration);
        }

        public FormuleDTO CreateFormule (FormuleDTO model) {
            // validate
            if (_context.Formules.Any (f => (!String.IsNullOrEmpty (model.NUM_DOMICILIATION) &&
                        f.NUM_DOMICILIATION.Equals (model.NUM_DOMICILIATION, StringComparison.CurrentCultureIgnoreCase)) &&
                    (f.MONTANT == model.MONTANT) &&
                    (f.TARIF_DOUANIER.Equals (model.TARIF_DOUANIER, StringComparison.CurrentCultureIgnoreCase))))
                throw new AppException ($"Formule '{model.TARIF_DOUANIER}' - '{model.TARIF_DOUANIER}' est déjà enregistrée'");
            var formule = _mapper.Map<Formule> (model);
            _context.Formules.Add (formule);
            _context.SaveChanges ();
            return _mapper.Map<FormuleDTO> (formule);
        }

        public FichierXmlDTO CreateXML (FichierXmlDTO model) {
            var fichierXml = _mapper.Map<FichierXml> (model);
            _context.FichiersXml.Add (fichierXml);
            _context.SaveChanges ();
            return _mapper.Map<FichierXmlDTO> (fichierXml);
        }

        public IEnumerable<FormuleDTO> GetAllFormules () {
            var formules = _context.Formules;
            return _mapper.Map<IEnumerable<FormuleDTO>> (formules);
        }

        public IEnumerable<FichierXmlDTO> GetAllXML () {
            var xmls = _context.FichiersXml
                .Include (f => f.declarations)
                .ThenInclude (d => d.bordereau)
                .Include (f => f.declarations)
                .ThenInclude (d => d.formules);
            return _mapper.Map<IEnumerable<FichierXmlDTO>> (xmls);
        }

        public BordereauDTO GetBordereauById (int id) {
            var bordereau = _context.Bordereaux.Find (id);
            return _mapper.Map<BordereauDTO> (bordereau);
        }

        public DeclarationDTO GetDeclarationById (int id) {
            var declaration = _context.Declarations.Find (id);
            return _mapper.Map<DeclarationDTO> (declaration);
        }

        public FormuleDTO GetFormuleById (int id) {
            var formule = _context.Formules.Find (id);
            return _mapper.Map<FormuleDTO> (formule);
        }

        public FichierXmlDTO GetXMLById (int id) {
            var fichierXml = _context.FichiersXml.Find (id);
            return _mapper.Map<FichierXmlDTO> (fichierXml);
        }

        public string generateXMLDeclaration (int id) {

            FichierXml fdb = null;
            var xmls = _context.FichiersXml
                .Include (f => f.declarations)
                .ThenInclude (d => d.bordereau)
                .Include (f => f.declarations)
                .ThenInclude (d => d.formules)
                .Where (f => f.Id == id);
            fdb = xmls.First ();

            if (null == fdb) {
                throw new AppException ("La déclaration portant identifiant système : " + id + " est introuvable dans la base");
            }

            var fichierBA = _mapper.Map<FormuleSrv.Models.BA.FichierXmlDTO> (fdb);
            var outPutFileName = _appSettings.FilePath + "declaration_" + id + ".xml";

            using (XmlWriter writer = XmlWriter.Create (outPutFileName)) {
                writer.WriteStartDocument (false);
                writer.WriteDocType ("fichier_xml", null, "declaration.dtd", null);
                var ns = new XmlSerializerNamespaces (new [] { XmlQualifiedName.Empty });
                XmlSerializer serializer = new XmlSerializer (fichierBA.GetType ());
                //DataContractSerializer serializer = new DataContractSerializer (fichierBA.GetType ());
                serializer.Serialize (writer, fichierBA, ns);
            }

            return outPutFileName;
            //return _mapper.Map<FichierXmlDTO> (fichierXml);
        }

        public BordereauDTO UpdateBordereau (int id, BordereauDTO model) {
            throw new System.NotImplementedException ();
        }

        public DeclarationDTO UpdateDeclaration (int id, DeclarationDTO model) {
            throw new System.NotImplementedException ();
        }

        public FormuleDTO UpdateFormule (int id, FormuleDTO model) {
            throw new System.NotImplementedException ();
        }

        public FichierXmlDTO UpdateXML (int id, FichierXmlDTO model) {
            throw new System.NotImplementedException ();
        }

        IEnumerable<BordereauDTO> IDeclarationService.GetAllBordreaux () {
            var bordereaux = _context.Bordereaux;
            return _mapper.Map<IEnumerable<BordereauDTO>> (bordereaux);
        }

        IEnumerable<DeclarationDTO> IDeclarationService.GetAllDeclarations () {
            var declarations = _context.Declarations.Include (d => d.formules).Include (d => d.bordereau);
            return _mapper.Map<IEnumerable<DeclarationDTO>> (declarations);
        }
    }
}