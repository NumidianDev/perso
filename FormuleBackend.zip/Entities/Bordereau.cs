using System;

namespace FormuleSrv.Entities {
    public class Bordereau {
        public int Id { get; set; }
        public string TYPE_DECLARATION { get; set; }

        public string SENS_FLUX { get; set; }

        public string BANQUE { get; set; }

        public string MONNAIE { get; set; }

        public decimal MONTANT_GLOBAL { get; set; }

        public int NBR_ENREGISTREMENT { get; set; }

        public DateTime? DATE_VALEUR { get; set; }

        public decimal COURS { get; set; }

        public decimal CONTRE_VALEUR { get; set; }
    }
}