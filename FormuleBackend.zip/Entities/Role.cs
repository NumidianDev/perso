namespace FormuleSrv.Entities {
    public enum Role {
        Admin,
        UserF4,
        UserF104,
        UserF5,
        DeclarantBA
    }
}