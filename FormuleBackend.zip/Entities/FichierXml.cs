using System.Collections.Generic;

namespace FormuleSrv.Entities {
    public class FichierXml {
        public int Id { get; set; }
        public int NBR_ENREGISTREMENT { get; set; }
        public virtual List<Declaration> declarations { get; set; }
    }
}