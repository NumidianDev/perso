using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormuleSrv.Entities {
    public class Declaration {
        public int Id { get; set; }

        [ForeignKey ("Bordereau")]
        public int bordereauId { get; set; }
        public Bordereau bordereau { get; set; }
        public List<Formule> formules { get; set; }
    }
}