using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormuleSrv.Entities

{
    public class Formule4
    {
 [Key]
        public string cli { get; set; }

        public string age { get; set; }

        public string eve { get; set; }

        public string ndos { get; set; }

        public string dev { get; set; }

        public string datint { get; set; }

        public bool resident { get; set; }

        public bool  morale { get; set; }

        public string date_valeur { get; set; }

        public string code_pays { get; set; }

        public string rubrique { get; set; }

        public string designation_pays { get; set; }

        public string tarif_douanier { get; set; }

        public string designation_operation { get; set; }

        public string code_operation { get; set; }
        public string num_domiciliation { get; set; }
        public string designation_operateur { get; set; }
        public string montant_ba { get; set; }
        public string cours_f { get; set; }
        public string CODE_OPERATION  { get; set; }
        // public string FORMULE { get; set; }

        // public string MODE_REGLEMENT { get; set; }

    }
}