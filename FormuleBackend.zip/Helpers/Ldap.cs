using System;
using System.DirectoryServices;

namespace FormuleSrv.Helpers {
    public static class Ldap {

        private static string LdapPath = "LDAP://sga-dcpm001";

        public static bool isInDomain (string login, string password) {
            //return true;
            try {
                DirectoryEntry entry = new DirectoryEntry (LdapPath, login, password);
                object nativeObject = entry.NativeObject;
                DirectorySearcher ds = new DirectorySearcher (entry);

            } catch (Exception ) {
                return false;
                // Log de l'exception 
                //response = ex.Message;
                //throw new AppException (ex.Message);
            }

            return true;
        }
    }
}