using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using FormuleSrv.Entities;

namespace FormuleSrv.Helpers {
    public class DataContext : DbContext {
        public DbSet<Account> Accounts { get; set; }
        public DbSet<FichierXml> FichiersXml { get; set; }
        public DbSet<Formule> Formules { get; set; }
        public DbSet<Declaration> Declarations { get; set; }
        public DbSet<Bordereau> Bordereaux { get; set; }

        public DbSet<Formule4> F04Source { get; set; }

        private readonly IConfiguration Configuration;

        public DataContext (IConfiguration configuration) {
            Configuration = configuration;
        }

        protected override void OnConfiguring (DbContextOptionsBuilder options) {
            // connect to sqlite database
            //options.UseSqlite (Configuration.GetConnectionString ("WebApiDatabase"));
            options.UseSqlServer (Configuration.GetConnectionString ("WebApiDatabase"));
        }
    }
}