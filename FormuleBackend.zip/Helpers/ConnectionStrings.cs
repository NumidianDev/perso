using Microsoft.EntityFrameworkCore;

namespace FormuleSrv.Helpers


{
    public class ConnectionStrings 
    {
        

        public string Dev { get; set; }
        public string sga { get; set; }


 

    }
}