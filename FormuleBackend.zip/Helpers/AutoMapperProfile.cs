using AutoMapper;
using FormuleSrv.Entities;
using FormuleSrv.Models.Accounts;
using FormuleSrv.Models.BA;

namespace FormuleSrv.Helpers {
    public class AutoMapperProfile : Profile {
        // mappings between model and entity objects
        public AutoMapperProfile () {
            CreateMap<Account, AccountResponse> ();
            CreateMap<Account, AuthenticateResponse> ();
            CreateMap<FichierXml, FichierXmlDTO> ();
            CreateMap<Declaration, DeclarationDTO> ();
            CreateMap<Bordereau, BordereauDTO> ();
            CreateMap<Formule, FormuleDTO> ();
        }
    }
}