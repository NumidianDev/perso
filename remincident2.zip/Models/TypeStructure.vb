﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
<Table("RI_TypeStructure")>
Public Class TypeStructure

    <Key()>
    Public Property Id() As String
        Get
            Return m_id
        End Get
        Set(value As String)
            m_id = value
        End Set
    End Property
    Private m_id As String

    Public Property Libelle() As String
        Get
            Return m_nom
        End Get
        Set(value As String)
            m_nom = value
        End Set
    End Property
    Private m_nom As String

End Class