﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_StatutHis")>
Public Class StatutHis

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property Id_Inc_Act() As Int32
        Get
            Return m_Id_Inc_Act
        End Get
        Set(value As Int32)
            m_Id_Inc_Act = value
        End Set
    End Property
    Private m_Id_Inc_Act As Int32
    Public Property Commentaire() As String
        Get
            Return m_Commentaire
        End Get
        Set(value As String)
            m_Commentaire = value
        End Set
    End Property
    Private m_Commentaire As String
   
    Public Property Date_heure() As DateTime
        Get
            Return m_date_heure
        End Get
        Set(value As DateTime)
            m_date_heure = value
        End Set
    End Property
    Private m_date_heure As DateTime
    Public Property Id_Statut() As Int32
        Get
            Return m_Id_Statut
        End Get
        Set(value As Int32)
            m_Id_Statut = value
        End Set
    End Property
    Private m_Id_Statut As Int32

    <ForeignKey("Id_Statut")>
    Public Overridable Property Statut() As Statut
        Get
            Return m_statut
        End Get
        Set(value As Statut)
            m_statut = value
        End Set
    End Property
    Private m_statut As Statut

End Class
