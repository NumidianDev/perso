﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_Sous_Process")>
Public Class SousProcess

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32
    <Required(ErrorMessage:="Veuillez compléter ce champ.")>
    Public Property Libelle() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String

    Public Property Id_Process() As Int32
        Get
            Return m_Id_Process
        End Get
        Set(value As Int32)
            m_Id_Process = value
        End Set
    End Property
    Private m_Id_Process As Int32
    <ForeignKey("Id_Process")>
    Public Overridable Property Process() As Process
        Get
            Return m_Process
        End Get
        Set(value As Process)
            m_Process = value
        End Set
    End Property
    Private m_Process As Process

End Class