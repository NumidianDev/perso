﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_Parametres")>
Public Class Parametres
    <Key()>
    Public Property Cle() As String
        Get
            Return m_cle
        End Get
        Set(value As String)
            m_cle = value
        End Set
    End Property
    Private m_cle As String

    Public Property Value() As String
        Get
            Return m_value
        End Get
        Set(value As String)
            m_value = value
        End Set
    End Property
    Private m_value As String

End Class
