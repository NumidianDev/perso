﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_RoleUtilisateur")>
Public Class RoleUtilisateur

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property UtilisateurId() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String
    <ForeignKey("UtilisateurId")>
    Public Overridable Property Utilisateur() As Utilisateur
        Get
            Return m_Utilisateur
        End Get
        Set(value As Utilisateur)
            m_Utilisateur = value
        End Set
    End Property
    Private m_Utilisateur As Utilisateur
    Public Property RoleId() As String
        Get
            Return m_roleID
        End Get
        Set(value As String)
            m_roleID = value
        End Set
    End Property
    Private m_roleID As String
    <ForeignKey("RoleId")>
    Public Overridable Property Role() As Role
        Get
            Return m_Role
        End Get
        Set(value As Role)
            m_Role = value
        End Set
    End Property
    Private m_Role As Role
End Class
