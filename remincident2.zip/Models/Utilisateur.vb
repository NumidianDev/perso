﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_Utilisateur")>
Public Class Utilisateur

    <Key()> _
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    <StringLength(4, ErrorMessage:=" Ce champ contient 04 positions alphanumérique")> _
    Public Property Matricule() As String
        Get
            Return m_matricule
        End Get
        Set(value As String)
            m_matricule = value
        End Set
    End Property
    Private m_matricule As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Nom() As String
        Get
            Return m_nom
        End Get
        Set(value As String)
            m_nom = value
        End Set
    End Property
    Private m_nom As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Prenom() As String
        Get
            Return m_prenom
        End Get
        Set(value As String)
            m_prenom = value
        End Set
    End Property
    Private m_prenom As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Email() As String
        Get
            Return m_email
        End Get
        Set(value As String)
            m_email = value
        End Set
    End Property
    Private m_email As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Fonction() As String
        Get
            Return m_fonction
        End Get
        Set(value As String)
            m_fonction = value
        End Set
    End Property
    Private m_fonction As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Tel() As String
        Get
            Return m_tel
        End Get
        Set(value As String)
            m_tel = value
        End Set
    End Property
    Private m_tel As String

    Public Property Code_Str() As String
        Get
            Return m_Code_Str
        End Get
        Set(value As String)
            m_Code_Str = value
        End Set
    End Property
    Private m_Code_Str As String

    <ForeignKey("Code_Str")>
    Public Overridable Property str() As Structures
        Get
            Return m_Structure
        End Get
        Set(value As Structures)
            m_Structure = value
        End Set
    End Property
    Private m_Structure As Structures
    <NotMapped()> _
     Public ReadOnly Property Fullname As String
        Get
            Return Nom + " " + Prenom
        End Get
    End Property
    <NotMapped()> _
    Public ReadOnly Property getRole As String
        Get
            Using db As New DB
                Dim dm = db.RoleUtilisateur.Where(Function(u) u.UtilisateurId.Equals(Matricule)).Select(Function(r) r.Role.Libelle).Distinct().ToArray()
                m_s = Join(dm, ", ")
            End Using
            Return m_s
        End Get
    End Property
    Private m_s As String
    <NotMapped()> _
    Public ReadOnly Property getRoleDesc As String
        Get
            Using db As New DB
                Dim dm = db.RoleUtilisateur.Where(Function(u) u.UtilisateurId.Equals(Matricule)).Select(Function(r) r.Role.Description).Distinct().ToArray()
                m_rd = Join(dm, ", ")
            End Using
            Return m_rd
        End Get
    End Property
    Private m_rd As String
   
End Class
