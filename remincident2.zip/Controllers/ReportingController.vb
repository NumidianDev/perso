﻿Imports System.Data.Entity
Imports System.Data
Imports System.IO
Imports System.Web.UI
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Threading
Imports System.Net

Public Class ReportingController
    Inherits BaseController

    Private gvDetails As GridView = New GridView
    <Authorize(Roles:="GRO,Consultation")>
    Function Reporting() As ActionResult
        Dim inc As List(Of Etat)
        inc = inList()
        Return View(inc)

    End Function

    Function inList() As IList
        Dim r As List(Of Etat) = New List(Of Etat)
        Dim conn As New SqlConnection
        If conn.State = ConnectionState.Closed Then
            conn.ConnectionString = Fct.getConnectionString
        End If
        ' Lister les pole
        Dim Q1 As String = "if object_id('tempdb..#orga_pole') is not null " &
                            "drop table #orga_pole ; " &
                            "select * " &
                            "into #orga_pole " &
                            "from " &
                            "(select t.Code ,t.Nom,p.Code as CPole,p.Nom as Pole,'' as CDir,'' as Direction,'' as CDep,'' as Departement,'' as CSer, '' as [Service],'' as CCel ,'' as Cellule " &
                            "from RI_Structure t " &
                            "left join RI_Structure p on p.Code=t.Code " &
                            "where t.Type='1') tpole;"
        ' Lister les direction
        Dim Q2 As String = "if object_id('tempdb..#orga_dir') is not null " &
                             "drop table #orga_dir ; " &
                             "select * " &
                             "into #orga_dir " &
                             "from " &
                             "(select t.Code ,t.Nom,pol.Code as CPole,pol.Nom as Pole ,dir.Code as CDir,dir.Nom as Direction,'' as CDep,'' as Departement,'' as CSer,'' as [Service],'' as CCel,'' as Cellule " &
                             "from RI_Structure t " &
                             "left join RI_Structure dir on dir.Code=t.Code " &
                             "left join RI_Structure pol on pol.Code=dir.Code_STR_Mere " &
                             "where t.Type='2') tdir;"
        ' Lister les departement
        Dim Q3 As String = "if object_id('tempdb..#orga_dep') is not null " &
                            "drop table #orga_dep ; " &
                            "select * " &
                            "into #orga_dep " &
                            "from " &
                            "( " &
                            "select dep.Code ,dep.Nom, " &
                            "case when pol.Code is null then dir.Code else pol.Code end as CPole, " &
                            "case when pol.Code is null then dir.Nom else pol.Nom end as Pole, " &
                            "case when pol.Code is null then '' else dir.Code end as CDir, " &
                            "case when pol.Code is null then '' else dir.Nom end as Direction, " &
                            "Dep.Code as CDep,Dep.Nom as Departement,'' as CSer,'' as [Service],'' as CCel ,'' as Cellule " &
                            "from RI_Structure dep " &
                            "left join RI_Structure dir on dir.Code=dep.Code_STR_Mere " &
                            "left join RI_Structure pol on pol.Code=dir.Code_STR_Mere " &
                            "where dep.Type='3' ) tdep;"
        ' Lister les service
        Dim Q4 As String = "if object_id('tempdb..#orga_ser') is not null " &
                            "drop table #orga_ser ; " &
                            "select * " &
                            "into #orga_ser " &
                            "from " &
                            "( " &
                            "select ser.Code ,ser.Nom, " &
                            "case when dep.Code is not null then dep.cpole else " &
                            "case when dir.Code is not null then dir.cpole else pol.cpole end " &
                            "end as cpole, " &
                            "case when dep.Code is not null then dep.pole else " &
                            "case when dir.Code is not null then dir.pole else pol.pole end " &
                            "end as Pole, " &
                            "case when dep.Code is not null then dep.cdir else " &
                            "case when dir.Code is not null then dir.cdir else pol.cdir end " &
                            "end as cdir, " &
                            "case when dep.Code is not null then dep.Direction else " &
                            "case when dir.Code is not null then dir.Direction else pol.Direction end " &
                            "end as Direction, " &
                            "case when dep.Code is not null then dep.cdep else '' end as cdep, " &
                            "case when dep.Code is not null then dep.Departement else '' end as Departement, " &
                            "ser.Code as CSer,ser.Nom as [Service],'' as CCel,'' as Cellule " &
                            "from RI_Structure ser " &
                            "left join #orga_dep dep on dep.Code=ser.Code_STR_Mere " &
                            "left join #orga_dir dir on dir.Code=ser.Code_STR_Mere " &
                            "left join #orga_pole pol on pol.Code=ser.Code_STR_Mere " &
                            "where ser.Type='4' ) tser;"
        ' jointure
        Dim Q5 As String = "if object_id('tempdb..#gtt_orga') is not null " &
                            "drop table #gtt_orga ; " &
                            "select * " &
                            "into #gtt_orga " &
                            "from " &
                            "( " &
                            "select * from #orga_pole  " &
                            "union " &
                            "select * from #orga_dir  " &
                            "union " &
                            "select * from #orga_dep  " &
                            "union " &
                            "select * from #orga_ser " &
                            ") torga;"

        Dim command = New SqlCommand()
        Try
            conn.Open()
            command.Connection = conn
            command.CommandText = Q1 + Q2 + Q3 + Q4 + Q5
            command.ExecuteNonQuery()
            ' " LEFT JOIN RI_Utilisateur u ON u.Matricule = i.Matricule_Creation  " 
            Dim _q As String = "SELECT DISTINCT o.Pole,o.Direction,o.Departement,o.Service, i.Id Numero,i.Date_declaration,i.Date_debut,i.Date_decouverte, i.Montant_declarer brut,i.Montant_estime recuperation,i.Montant_effectif perte,  " &
"  r.Libelle as Origine,  " &
" (select (nom+' '+prenom) As NomComplet from RI_Utilisateur where Matricule in ( SELECT TOP 1 s.Correcspondant_principal FROM RI_Utilisateur u, RI_Structure s WHERE Code_Str = i.Code_Str and s.Code = Code_Str )) NomComplet  " &
" , ni.Libelle AS Nature_Impact,  " &
" CASE WHEN i.Impact_financier = 0 THEN 'Non' ELSE 'Oui' END AS Impact_financier,  " &
" i.ref_caroline,  " &
" c.Libelle categorie, sc.Libelle sous_categorie,  " &
" s.Description Statut,  " &
" (SELECT top 1 STUFF((SELECT ' - '+ Action FROM RI_Act WHERE RI_Act.Id_Incident = i.Id FOR XML PATH('')) , 1 , 1 , '' ) AS Actions FROM RI_Act A ) As Actions,  " &
" (SELECT top 1 STUFF((SELECT ' | '+ CAST(CONVERT(VARCHAR(24),date_realisation,103) as varchar) FROM RI_Act WHERE RI_Act.Id_Incident = i.Id FOR XML PATH('')) , 1 , 1 , '' ) AS dr FROM RI_Act A ) As dr  " &
" , i.Detail,  " &
" Case WHEN i.RORC = 1 THEN 'Oui'ELSE 'Non' END AS RORC," &
" Case When i.RORM = 1 Then 'Oui'ELSE 'Non' END AS RORM," &
" Case When i.Conformite = '1' THEN 'Oui' ELSE 'Non' END AS Conformite, " &
" p.Libelle as Process,  sp.Libelle as SousProcess, sr.Libelle as SourceRemonte, CAST(CONVERT(VARCHAR(24),i.Date_Validation,103) as varchar) as Date_Validation " &
" FROM RI_Incident i  " &
" LEFT JOIN RI_Utilisateur u ON u.Code_Str = i.Code_Str  " &
" LEFT JOIN RI_Origine r on r.Id = i.Id_origine   " &
" LEFT JOIN RI_NatureImpact ni on ni.Id = i.Nature_Impact  " &
" LEFT JOIN RI_Statut s on s.Id = i.Statut_Final  " &
" LEFT JOIN RI_Sous_Categorie sc on sc.Id = i.Id_sous_Cat  " &
" LEFT JOIN RI_Categorie c on c.Id = sc.Id_cat  " &
" LEFT JOIN RI_Sous_Process sp on sp.Id = i.Id_Sous_Process  " &
" LEFT JOIN RI_Process p on p.Id = sp.Id_Process  " &
" LEFT JOIN RI_SourceRemonte sr on sr.Id = i.Id_SourceRemonte " &
" LEFT JOIN #gtt_orga o On o.Code = i.Code_Str  " &
" WHERE CPole Is Not null  " &
" ORDER BY i.Date_declaration desc ;"
            Dim cmd As SqlCommand = New SqlCommand(_q, conn)
            Dim data As SqlDataReader = cmd.ExecuteReader()
            While data.Read()
                r.Add(New Etat With {
                                        .col1 = data("Pole").ToString(),
                                        .col2 = data("Direction").ToString(),
                                        .col3 = data("Departement").ToString(),
                                        .col4 = data("Service").ToString(),
                                        .col5 = data("Numero").ToString(),
                                        .col6 = data("Date_declaration").ToString(),
                                        .col7 = data("Date_debut").ToString(),
                                        .col8 = data("Date_decouverte").ToString(),
                                        .col9 = data("Origine").ToString(),
                                        .col10 = data("NomComplet").ToString(),
                                        .col11 = data("Nature_Impact").ToString(),
                                        .col12 = data("Impact_financier").ToString(),
                                        .col13 = data("ref_caroline").ToString(),
                                        .col14 = data("categorie").ToString(),
                                        .col15 = data("sous_categorie").ToString(),
                                        .col16 = data("Statut").ToString(),
                                        .col17 = WebUtility.HtmlDecode(data("Actions").ToString()),
                                        .col18 = WebUtility.HtmlDecode(data("dr").ToString()),
                                        .col19 = data("brut").ToString(),
                                        .col20 = data("recuperation").ToString(),
                                        .col21 = data("perte").ToString(),
                                        .col22 = data("Detail").ToString(),
                                        .col23 = data("RORC").ToString(),
                                        .col29 = data("RORM").ToString(),
                                        .col24 = data("Conformite").ToString(),
                                        .col25 = data("SourceRemonte").ToString(),
                                        .col26 = data("Process").ToString(),
                                        .col27 = data("SousProcess").ToString(),
                                        .col28 = data("Date_Validation").ToString()
                                   })
            End While
            data.Close()
        Catch ex As Exception
            Console.Out.WriteLine(ex.Message)
        Finally
            conn.Close()
        End Try
        Return r.ToList()
    End Function
    '
    ' GET: /Test/
    'Sub cmd(ByVal Query As String)
    '    Dim conn As New SqlConnection
    '    If conn.State = ConnectionState.Closed Then
    '        conn.ConnectionString = Fct.getConnectionString
    '    End If
    '    Dim command = New SqlCommand()
    '    Try
    '        conn.Open()
    '        command.Connection = conn
    '        command.CommandText = Query
    '        command.ExecuteNonQuery()
    '    Finally
    '        conn.Close()
    '    End Try

    'End Sub
    Sub inTemp()
        Dim conn As New SqlConnection
        If conn.State = ConnectionState.Closed Then
            conn.ConnectionString = Fct.getConnectionString
        End If
        ' Lister les pole
        Dim Q1 As String = "if object_id('tempdb..#orga_pole') is not null " & _
                            "drop table #orga_pole ; " & _
                            "select * " & _
                            "into #orga_pole " & _
                            "from " & _
                            "(select t.Code ,t.Nom,p.Code as CPole,p.Nom as Pole,'' as CDir,'' as Direction,'' as CDep,'' as Departement,'' as CSer, '' as [Service],'' as CCel ,'' as Cellule " & _
                            "from RI_Structure t " & _
                            "left join RI_Structure p on p.Code=t.Code " & _
                            "where t.Type='1') tpole;"
        ' Lister les direction
        Dim Q2 As String = "if object_id('tempdb..#orga_dir') is not null " & _
                             "drop table #orga_dir ; " & _
                             "select * " & _
                             "into #orga_dir " & _
                             "from " & _
                             "(select t.Code ,t.Nom,pol.Code as CPole,pol.Nom as Pole ,dir.Code as CDir,dir.Nom as Direction,'' as CDep,'' as Departement,'' as CSer,'' as [Service],'' as CCel,'' as Cellule " & _
                             "from RI_Structure t " & _
                             "left join RI_Structure dir on dir.Code=t.Code " & _
                             "left join RI_Structure pol on pol.Code=dir.Code_STR_Mere " & _
                             "where t.Type='2') tdir;"
        ' Lister les departement
        Dim Q3 As String = "if object_id('tempdb..#orga_dep') is not null " & _
                            "drop table #orga_dep ; " & _
                            "select * " & _
                            "into #orga_dep " & _
                            "from " & _
                            "( " & _
                            "select dep.Code ,dep.Nom, " & _
                            "case when pol.Code is null then dir.Code else pol.Code end as CPole, " & _
                            "case when pol.Code is null then dir.Nom else pol.Nom end as Pole, " & _
                            "case when pol.Code is null then '' else dir.Code end as CDir, " & _
                            "case when pol.Code is null then '' else dir.Nom end as Direction, " & _
                            "Dep.Code as CDep,Dep.Nom as Departement,'' as CSer,'' as [Service],'' as CCel ,'' as Cellule " & _
                            "from RI_Structure dep " & _
                            "left join RI_Structure dir on dir.Code=dep.Code_STR_Mere " & _
                            "left join RI_Structure pol on pol.Code=dir.Code_STR_Mere " & _
                            "where dep.Type='3' ) tdep;"
        ' Lister les service
        Dim Q4 As String = "if object_id('tempdb..#orga_ser') is not null " & _
                            "drop table #orga_ser ; " & _
                            "select * " & _
                            "into #orga_ser " & _
                            "from " & _
                            "( " & _
                            "select ser.Code ,ser.Nom, " & _
                            "case when dep.Code is not null then dep.cpole else " & _
                            "case when dir.Code is not null then dir.cpole else pol.cpole end " & _
                            "end as cpole, " & _
                            "case when dep.Code is not null then dep.pole else " & _
                            "case when dir.Code is not null then dir.pole else pol.pole end " & _
                            "end as Pole, " & _
                            "case when dep.Code is not null then dep.cdir else " & _
                            "case when dir.Code is not null then dir.cdir else pol.cdir end " & _
                            "end as cdir, " & _
                            "case when dep.Code is not null then dep.Direction else " & _
                            "case when dir.Code is not null then dir.Direction else pol.Direction end " & _
                            "end as Direction, " & _
                            "case when dep.Code is not null then dep.cdep else '' end as cdep, " & _
                            "case when dep.Code is not null then dep.Departement else '' end as Departement, " & _
                            "ser.Code as CSer,ser.Nom as [Service],'' as CCel,'' as Cellule " & _
                            "from RI_Structure ser " & _
                            "left join #orga_dep dep on dep.Code=ser.Code_STR_Mere " & _
                            "left join #orga_dir dir on dir.Code=ser.Code_STR_Mere " & _
                            "left join #orga_pole pol on pol.Code=ser.Code_STR_Mere " & _
                            "where ser.Type='4' ) tser;"
        ' jointure
        Dim Q5 As String = "if object_id('tempdb..#gtt_orga') is not null " & _
                            "drop table #gtt_orga ; " & _
                            "select * " & _
                            "into #gtt_orga " & _
                            "from " & _
                            "( " & _
                            "select * from #orga_pole  " & _
                            "union " & _
                            "select * from #orga_dir  " & _
                            "union " & _
                            "select * from #orga_dep  " & _
                            "union " & _
                            "select * from #orga_ser " & _
                            ") torga;"

        Dim command = New SqlCommand()
        Try
            conn.Open()
            command.Connection = conn
            command.CommandText = Q1 + Q2 + Q3 + Q4 + Q5
            command.ExecuteNonQuery()
            'Dim _q As String = "SELECT o.Pole,o.Direction,o.Departement,o.Service, i.Date_declaration,i.Date_debut,i.Date_decouverte,a.Libelle as Typologie, r.Libelle as Origine,i.Detail,(u.Nom+' '+u.Prenom) as NomComplet " & _
            '                    " FROM RI_Incident i" & _
            '                    " LEFT JOIN RI_Utilisateur u ON u.Matricule = i.Matricule_Creation " & _
            '                    " LEFT JOIN RI_Origine r on r.Id = i.Id_origine " & _
            '                    " LEFT JOIN RI_Activite a on a.Id = i.Id_Process " & _
            '                    " LEFT JOIN #gtt_orga o On o.Code = u.Code_Str " & _
            '                    " WHERE CPole Is Not null " & _
            '                    " ORDER BY i.Date_declaration desc ;"
            Dim _q As String = "SELECT DISTINCT o.Pole,o.Direction,o.Departement,o.Service, i.Id Numero,i.Date_declaration,i.Date_debut,i.Date_decouverte, i.Montant_declarer brut,i.Montant_estime recuperation,i.Montant_effectif perte,  " &
"  r.Libelle as Origine,  " &
" (select (nom+' '+prenom) As NomComplet from RI_Utilisateur where Matricule in ( SELECT TOP 1 s.Correcspondant_principal FROM RI_Utilisateur u, RI_Structure s WHERE Code_Str = i.Code_Str and s.Code = Code_Str )) NomComplet  " &
" , ni.Libelle AS Nature_Impact,  " &
" CASE WHEN i.Impact_financier = 0 THEN 'Non' ELSE 'Oui' END AS Impact_financier,  " &
" i.ref_caroline,  " &
" c.Libelle categorie, sc.Libelle sous_categorie,  " &
" s.Description Statut,  " &
" (SELECT top 1 STUFF((SELECT ' - '+ Action FROM RI_Act WHERE RI_Act.Id_Incident = i.Id FOR XML PATH('')) , 1 , 1 , '' ) AS Actions FROM RI_Act A ) As Actions,  " &
" (SELECT top 1 STUFF((SELECT ' | '+ CAST(CONVERT(VARCHAR(24),date_realisation,103) as varchar) FROM RI_Act WHERE RI_Act.Id_Incident = i.Id FOR XML PATH('')) , 1 , 1 , '' ) AS dr FROM RI_Act A ) As dr  " &
" , i.Detail,  " &
" Case WHEN i.RORC = 1 THEN 'Oui'ELSE 'Non' END AS RORC," &
" Case When i.RORM = 1 Then 'Oui'ELSE 'Non' END AS RORM," &
" Case WHEN i.Conformite = '1' THEN 'Oui' ELSE 'Non' END AS Conformite, " &
" p.Libelle as Process,  sp.Libelle as SousProcess, sr.Libelle as SourceRemonte, CAST(CONVERT(VARCHAR(24),Date_Validation,103) as varchar) as Date_Validation " &
" FROM RI_Incident i  " &
" LEFT JOIN RI_Utilisateur u ON u.Code_Str = i.Code_Str  " &
" LEFT JOIN RI_Origine r on r.Id = i.Id_origine   " &
" LEFT JOIN RI_NatureImpact ni on ni.Id = i.Nature_Impact  " &
" LEFT JOIN RI_Statut s on s.Id = i.Statut_Final  " &
" LEFT JOIN RI_Sous_Categorie sc on sc.Id = i.Id_sous_Cat  " &
" LEFT JOIN RI_Categorie c on c.Id = sc.Id_cat  " &
" LEFT JOIN RI_Sous_Process sp on sp.Id = i.Id_Sous_Process  " &
" LEFT JOIN RI_Process p on p.Id = sp.Id_Process  " &
" LEFT JOIN RI_SourceRemonte sr on sr.Id = i.Id_SourceRemonte " &
" LEFT JOIN #gtt_orga o On o.Code = i.Code_Str  " &
" WHERE CPole Is Not null  " &
" ORDER BY i.Date_declaration desc ;"

            Dim cmd As SqlDataAdapter = New SqlDataAdapter(_q, conn)
            Dim ds As DataSet = New DataSet()
            cmd.Fill(ds)
            gvDetails.DataSource = ds
            gvDetails.DataBind()
        Catch ex As Exception
            Console.Out.WriteLine(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    'Private Sub Data()
    '    Dim conn As New SqlConnection
    '    If conn.State = ConnectionState.Closed Then
    '        conn.ConnectionString = Fct.getConnectionString
    '    End If
    '    Dim _q As String = "SELECT Code,Pole,Direction,Departement,Service " & _
    '                        " FROM  #gtt_orga " & _
    '                        " WHERE CPole Is Not null " & _
    '                        " ORDER BY Pole,Direction,Departement,Service;"
    '    Dim cmd As SqlDataAdapter = New SqlDataAdapter(_q, conn)
    '    Dim ds As DataSet = New DataSet()
    '    cmd.Fill(ds)
    '    gvDetails.DataSource = ds
    '    gvDetails.DataBind()
    'End Sub
    <Authorize(Roles:="GRO,Consultation")>
    Sub Export()
        Try
            Response.ClearContent()
            Response.Buffer = True
            Dim dnow As String = String.Format("{0:yyyyMMddHHmmss}", DateTime.Now)
            Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "Incidents_" + dnow + ".xls"))
            Response.ContentType = "application/ms-excel"
            Response.ContentType.ToString()
            Dim sw As New StringWriter()
            Dim htw As New HtmlTextWriter(sw)
            gvDetails.AllowPaging = False
            gvDetails.RowStyle.ToString()
            inTemp()
            'Data()
            'Change the Header Row back to white color
            gvDetails.HeaderRow.Style.Add("background-color", "#FFFFFF")
            Dim H As Array = getColomns()
            For i As Integer = 0 To gvDetails.HeaderRow.Cells.Count - 1
                gvDetails.HeaderRow.Cells(i).Text = H(i).ToUpper()
                gvDetails.HeaderRow.Cells(i).Style.Add("background-color", "#333333")
                gvDetails.HeaderRow.Cells(i).Style.Add("color", "#ffffff")
            Next
            gvDetails.RenderControl(htw)
            Dim style As String = "<style>.textmode{mso-number-format:\@;}</style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.End()
        Catch ex As Exception

        End Try
    End Sub

    Function getColomns() As Array
        Return {"Pole", "Direction", "Departement", "Service", "Numero evenement", "Date declaration", "Date debut", "Date decouverte", "Montant brut", "Montant recuperation", "Montant perte", " Origine", "correspondant RO ", "Nature Impact", "Impact financier", "Ref. caroline", "categorie", "sous categorie", "statut", "actions", "Date previsionnelle", "Description", "RORC", "RORM", "Conformite", "Processus", "Sous processus", "Source de Remontee", "Date Validation"}
    End Function


    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class