﻿Public Class TestController
    Inherits System.Web.Mvc.Controller

    '
    ' GET: /Test

    Function Index(Optional id As Boolean = True) As ActionResult
        Dim _r = If(1, "Oui", "Non")
        Return View()
    End Function

End Class