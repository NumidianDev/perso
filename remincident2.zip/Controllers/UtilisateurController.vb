﻿Imports System.Data.Entity
Imports System.DirectoryServices

<RoleFilter()> _
Public Class UtilisateurController
    Inherits BaseController
    'Private db As New DB
    '
    ' GET: /Utilisateur/
    Function Index() As ActionResult
        Dim user = db.Utilisateur.Include(Function(u) u.str)
        Return PartialView(user.ToList())
    End Function

    '
    ' GET: /Utilisateur/Details/5
    <HttpGet()> _
    <AllowAnonymous> _
    Function Details(ByVal id As String) As ActionResult
        If Not String.IsNullOrEmpty(id) Then
            Dim users = (From u In db.Utilisateur Where u.Matricule.Equals(id)).FirstOrDefault()
            ViewBag.Code_str = New SelectList(db.Structures, "code", "Nom")
            Return PartialView(users)
        End If
        Return PartialView()
    End Function

    '
    ' GET: /Utilisateur/Create

    Function Create() As ActionResult
        ViewBag.getRole = New SelectList(db.Roles, "Id", "Description")
        ViewBag.Code_str = New SelectList(db.Structures, "code", "Nom")

        Return PartialView()
    End Function
    '
    ' POST: /Utilisateur/Create _ ' 
    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Create(ByVal utilisateur As Utilisateur, roles As String) As ActionResult


        Dim tab(6) As String
        If ModelState.IsValid Then
            If (String.IsNullOrEmpty(roles)) Then
                Return Json(New With {.result = "no", .message = "Aucun rôle n'est sélectionné."}, JsonRequestBehavior.AllowGet)
            End If
            db.Utilisateur.Add(utilisateur)
            db.SaveChanges()
            tab = Split(Trim(roles), ",")
            Dim ur As New RoleUtilisateur
            For Each i In tab
                ur.RoleId = i.ToString()
                ur.UtilisateurId = utilisateur.Matricule
                db.RoleUtilisateur.Add(ur)
                db.SaveChanges()
            Next
            Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        End If
        'Catch ex As Exception
        '    Dim Cu = db.Utilisateur.Where(Function(u) u.Matricule.Equals(utilisateur.Matricule)).ToList()
        '    If (Cu.Count > 0) Then
        '        ModelState.AddModelError("", "l'utlisateur " & utilisateur.Matricule & " existe déjà dans la liste des utilisateur !")
        '    Else
        '        ModelState.AddModelError("", ex.Message)
        '    End If
        'End Try
        ViewBag.getRole = New SelectList(db.Roles, "Id", "Libelle")
        ViewBag.Code_Str = New SelectList(db.Structures, "code", "Nom", utilisateur.Code_Str)

        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function
    '
    ' GET: /Utilisateur/Edit/5
    Function Edit(Optional ByVal id As String = Nothing) As ActionResult
        Dim utilisateur As Utilisateur = db.Utilisateur.Find(id)
        Dim lr = (From ru In db.RoleUtilisateur Join r In db.Roles On r.Id Equals ru.RoleId Where ru.UtilisateurId.Equals(id)).ToList()
        If IsNothing(utilisateur) Then
            Return HttpNotFound()
        End If
        Dim ListruRole As List(Of String) = New List(Of String)
        Dim ListrRole As List(Of String) = New List(Of String)
        Dim rRole = lr.Select(Function(r) r.ru.RoleId)
        Dim ruRole = lr.Select(Function(r) r.r.Libelle)
        If (lr.Count > 0) Then
            For Each i In ruRole
                ListruRole.Add(i)
            Next
            For Each i In rRole
                ListrRole.Add(i)
            Next
            ViewBag.getRoleID = String.Join(",", ListrRole)
            ViewBag.getRoles = String.Join(",", ListruRole)
        Else
            ViewBag.getRoleID = Nothing
            ViewBag.getRoles = Nothing
        End If
        ViewBag.getRole = New SelectList(db.Roles, "Id", "Description", utilisateur.getRole)
        ViewBag.Code_str = New SelectList(db.Structures, "code", "Nom", utilisateur.Code_Str)
        Return PartialView(utilisateur)
    End Function
    '
    ' POST: /Utilisateur/Edit/5
    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal utilisateur As Utilisateur, roles As String) As ActionResult
        Try
            Dim tab(6) As String
            If ModelState.IsValid Then
                If (String.IsNullOrEmpty(roles) = True) Then
                    Return Json(New With {.result = "no", .message = "Aucun rôle n'est sélectionné."}, JsonRequestBehavior.AllowGet)
                End If
                db.Entry(utilisateur).State = EntityState.Modified
                db.SaveChanges()
                'traitemeent des role
                DeleteRole(utilisateur.Matricule)
                tab = Split(Trim(roles), ",")
                Dim ur As New RoleUtilisateur
                For Each i In tab
                    ur.RoleId = i.ToString()
                    ur.UtilisateurId = utilisateur.Matricule
                    db.RoleUtilisateur.Add(ur)
                    db.SaveChanges()
                Next
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            End If
        Catch ex As Exception
            Console.Write(ex.Message)
        End Try
        ViewBag.getRole = New SelectList(db.Roles, "Id", "Libelle")
        ViewBag.Code_Str = New SelectList(db.Structures, "code", "Nom", utilisateur.Code_Str)
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function
    '
    ' GET: /Utilisateur/Delete/5
    Function Delete(Optional ByVal id As String = Nothing) As ActionResult
        Dim utilisateur As Utilisateur = db.Utilisateur.Find(id)
        If IsNothing(utilisateur) Then
            Return HttpNotFound()
        End If
        Return View(utilisateur)
    End Function
    '
    ' POST: /Utilisateur/Delete/5
    <HttpPost()> _
    <ActionName("Delete")> _
    <ValidateAntiForgeryToken()> _
    Function DeleteConfirmed(ByVal id As String) As RedirectToRouteResult
        Dim utilisateur As Utilisateur = db.Utilisateur.Find(id)
        db.Utilisateur.Remove(utilisateur)
        db.SaveChanges()
        Return RedirectToAction("Index")
    End Function

    <ActionName("Delete")> _
    Sub DeleteRole(ByVal mat As String)
        Dim ur As List(Of RoleUtilisateur) = (From u In db.RoleUtilisateur Where u.UtilisateurId.Equals(mat)).ToList()
        For Each e In ur
            db.RoleUtilisateur.Remove(e)
            db.SaveChanges()
        Next
    End Sub

    '
    <HttpGet>
    Function getUser(ByVal id As String) As JsonResult
        Dim _path As String = "LDAP://sga-dcpm001"
        Dim login As String = "SGA\sgaappadm"
        Dim pwd As String = "echo99"
        Dim Ldap As DirectoryEntry = New DirectoryEntry(_path, login, pwd)
        Try
            Dim obj As Object = Ldap.NativeObject
            Dim search As DirectorySearcher = New DirectorySearcher(Ldap)
            '
            search.Filter = "(samaccountname=" & id & ")"
            search.PropertiesToLoad.Add("ou")
            search.PropertiesToLoad.Add("samaccountname")
            search.PropertiesToLoad.Add("sn")
            search.PropertiesToLoad.Add("givenname")
            search.PropertiesToLoad.Add("mail")
            Dim result As SearchResult = search.FindOne()
            Dim objJSON As StringBuilder = New StringBuilder()
            'Dim result As SearchResult
            'For Each result In results
            objJSON.Append("{")
            objJSON.Append("""mat""")
            objJSON.Append(":")
            objJSON.Append("""" & result.Properties("samaccountname").Item(0) & """")
            objJSON.Append(",")
            objJSON.Append("""nom""")
            objJSON.Append(":")
            objJSON.Append("""" & result.Properties("sn").Item(0) & """")
            objJSON.Append(",")
            objJSON.Append("""prenom""")
            objJSON.Append(":")
            objJSON.Append("""" & result.Properties("givenname").Item(0) & """")
            objJSON.Append(",")
            objJSON.Append("""mail""")
            objJSON.Append(":")
            objJSON.Append("""" & result.Properties("mail").Item(0) & """")
            objJSON.Append("}")
            'Next result
            If (objJSON IsNot Nothing) Then
                Return Json(New With {.data = result, .message = "OK"}, JsonRequestBehavior.AllowGet)
            End If
            Return Json(Nothing, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(Nothing, JsonRequestBehavior.AllowGet)
        End Try

    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class