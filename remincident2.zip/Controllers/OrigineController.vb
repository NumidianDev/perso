﻿Imports System.Data.Entity
<RoleFilter()> _
Public Class OrigineController
    Inherits BaseController
    '
    ' GET: /Origine/

    Function Index() As ActionResult
        Return View(db.Origine.ToList())
    End Function

    '
    ' GET: /Origine/Details/5

    Function Details(ByVal id As String) As ActionResult
        Dim Origine As Origine = db.Origine.Find(id)
        If IsNothing(Origine) Then
            Return HttpNotFound()
        End If
        Return View(Origine)
    End Function

    '
    ' GET: /Origine/Create

    Function Create() As ActionResult

        Return PartialView()
    End Function

    '
    ' POST: /Origine/Create

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Create(ByVal Origine As Origine) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Origine.Add(Origine)
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Origine/Edit/5

    Function Edit(ByVal id As Int32) As ActionResult
        Dim Origine As Origine = db.Origine.Find(id)
        If IsNothing(Origine) Then
            Return HttpNotFound()
        End If

        Return PartialView(Origine)
    End Function

    '
    ' POST: /Metier/Edit/5

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal Origine As Origine) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Entry(Origine).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Metier/Delete/5

    Function Delete(ByVal id As Int32) As ActionResult
        Dim Origine As Origine = db.Origine.Find(id)
        If IsNothing(Origine) Then
            Return HttpNotFound()
        End If
        Return PartialView(Origine)
    End Function

    '
    ' POST: /Metier/Delete/5

    <HttpPost()> _
    <ActionName("Delete")> _
    <ValidateAntiForgeryToken()> _
    Function DeleteConfirmed(ByVal id As Int32) As JsonResult
        Try
            Dim catégories As Origine = db.Origine.Find(id)
            db.Origine.Remove(catégories)
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La suppression est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "no", .message = "Echec de suppression."}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(Nothing, JsonRequestBehavior.AllowGet)
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class