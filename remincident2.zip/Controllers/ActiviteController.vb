﻿Imports System.Data.Entity
<RoleFilter()> _
Public Class ActiviteController
    Inherits BaseController
    '
    ' GET: /Activite/

    Function Index() As ActionResult
        Return View(db.Activite.ToList())
    End Function

    '
    ' GET: /Activite/Details/5

    Function Details(ByVal id As String) As ActionResult
        Dim Activite As Activite = db.Activite.Find(id)
        If IsNothing(Activite) Then
            Return HttpNotFound()
        End If
        Return View(Activite)
    End Function

    '
    ' GET: /Activite/Create

    Function Create() As ActionResult

        Return PartialView()
    End Function

    '
    ' POST: /Activite/Create

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Create(ByVal Activite As Activite) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Activite.Add(Activite)
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Activite/Edit/5

    Function Edit(ByVal id As Int32) As ActionResult
        Dim Activite As Activite = db.Activite.Find(id)
        If IsNothing(Activite) Then
            Return HttpNotFound()
        End If

        Return PartialView(Activite)
    End Function

    '
    ' POST: /Metier/Edit/5

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal Activite As Activite) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Entry(Activite).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Metier/Delete/5

    Function Delete(ByVal id As String) As ActionResult
        Dim Activite As Activite = db.Activite.Find(id)
        If IsNothing(Activite) Then
            Return HttpNotFound()
        End If
        Return PartialView(Activite)
    End Function

    '
    ' POST: /Metier/Delete/5

    <HttpPost()> _
    <ActionName("Delete")> _
    <ValidateAntiForgeryToken()> _
    Function DeleteConfirmed(ByVal id As String) As JsonResult
        Try
            Dim catégories As Activite = db.Activite.Find(id)
            db.Activite.Remove(catégories)
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La suppression est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "no", .message = "Echec de suppression."}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(Nothing, JsonRequestBehavior.AllowGet)
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class