﻿Imports System.Data.Entity
<RoleFilter()>
Public Class SousProcessController
    Inherits BaseController
    '
    ' GET: /SousProcess/

    Function Index() As ActionResult
        Return View(db.SousProcess.ToList())
    End Function

    '
    ' GET: /SousProcess/Details/5

    Function Details(Optional ByVal id As Integer = Nothing) As ActionResult
        Dim SousProcess As SousProcess = db.SousProcess.Find(id)
        If IsNothing(SousProcess) Then
            Return HttpNotFound()
        End If
        ViewBag.ProcessId = New SelectList(db.Process, "Id", "Libelle")
        Return View(SousProcess)
    End Function

    '
    ' GET: /SousProcess/Create

    Function Create() As ActionResult
        ViewBag.Id_Process = New SelectList(db.Process, "Id", "Libelle")
        Return PartialView()
    End Function

    '
    ' POST: /SousProcess/Create

    <HttpPost()>
    <ValidateAntiForgeryToken()>
    Function Create(ByVal SousProcess As SousProcess) As JsonResult
        If ModelState.IsValid Then
            Try
                db.SousProcess.Add(SousProcess)
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /SousProcess/Edit/5

    Function Edit(ByVal id As Int32) As ActionResult
        Dim SousProcess As SousProcess = db.SousProcess.Find(id)
        If IsNothing(SousProcess) Then
            Return HttpNotFound()
        End If
        ViewBag.Id_Process = New SelectList(db.Process, "Id", "Libelle", SousProcess.Id_Process)
        Return PartialView(SousProcess)
    End Function

    '
    ' POST: /SousProcess/Edit/5

    <HttpPost()>
    <ValidateAntiForgeryToken()>
    Function Edit(ByVal SousProcess As SousProcess) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Entry(SousProcess).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /SousProcess/Delete/5

    Function Delete(ByVal id As Int32) As ActionResult
        Dim SousProcess As SousProcess = db.SousProcess.Find(id)
        If IsNothing(SousProcess) Then
            Return HttpNotFound()
        End If
        Return PartialView(SousProcess)
    End Function

    '
    ' POST: /SousProcess/Delete/5

    <HttpPost()>
    <ActionName("Delete")>
    <ValidateAntiForgeryToken()>
    Function DeleteConfirmed(ByVal id As Int32) As JsonResult
        Try
            Dim SousProcess As SousProcess = db.SousProcess.Find(id)
            db.SousProcess.Remove(SousProcess)
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La suppression est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "no", .message = "Echec de suppression."}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(Nothing, JsonRequestBehavior.AllowGet)
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class