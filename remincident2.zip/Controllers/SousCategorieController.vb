﻿Imports System.Data.Entity
<RoleFilter()> _
Public Class SousCategorieController
    Inherits BaseController
    '
    ' GET: /SousCategorie/

    Function Index() As ActionResult
        Return View(db.Sous_Categorie.ToList())
    End Function

    '
    ' GET: /SousCategorie/Details/5

    Function Details(Optional ByVal id As Integer = Nothing) As ActionResult
        Dim SousCategorie As Sous_Categorie = db.Sous_Categorie.Find(id)
        If IsNothing(SousCategorie) Then
            Return HttpNotFound()
        End If
        ViewBag.CategorieId = New SelectList(db.Categorie, "Id", "Libelle")
        Return View(SousCategorie)
    End Function

    '
    ' GET: /SousCategorie/Create

    Function Create() As ActionResult
        ViewBag.Id_cat = New SelectList(db.Categorie, "Id", "Libelle")
        Return PartialView()
    End Function

    '
    ' POST: /SousCategorie/Create

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Create(ByVal SousCategorie As Sous_Categorie) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Sous_Categorie.Add(SousCategorie)
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /SousCategorie/Edit/5

    Function Edit(ByVal id As Int32) As ActionResult
        Dim SousCategorie As Sous_Categorie = db.Sous_Categorie.Find(id)
        If IsNothing(SousCategorie) Then
            Return HttpNotFound()
        End If
        ViewBag.Id_cat = New SelectList(db.Categorie, "Id", "Libelle", SousCategorie.Id_cat)
        Return PartialView(SousCategorie)
    End Function

    '
    ' POST: /SousCategorie/Edit/5

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal SousCategorie As Sous_Categorie) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Entry(SousCategorie).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /SousCategorie/Delete/5

    Function Delete(ByVal id As Int32) As ActionResult
        Dim SousCategorie As Sous_Categorie = db.Sous_Categorie.Find(id)
        If IsNothing(SousCategorie) Then
            Return HttpNotFound()
        End If
        Return PartialView(SousCategorie)
    End Function

    '
    ' POST: /SousCategorie/Delete/5

    <HttpPost()> _
    <ActionName("Delete")> _
    <ValidateAntiForgeryToken()> _
    Function DeleteConfirmed(ByVal id As Int32) As JsonResult
        Try
            Dim SousCategorie As Sous_Categorie = db.Sous_Categorie.Find(id)
            db.Sous_Categorie.Remove(SousCategorie)
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La suppression est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "no", .message = "Echec de suppression."}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(Nothing, JsonRequestBehavior.AllowGet)
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class