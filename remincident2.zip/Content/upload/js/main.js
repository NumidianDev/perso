$(function () {
    'use strict';
   /* alert("ok");*/
    $('#fileupload').fileupload({
        url: 'UploadFile'
    });
    //----------
    $.ajax({

        url: $('#fileupload').fileupload('option', {
            maxFileSize: 30000000, //30mo
            acceptFileTypes: /(\.|\/)(gif|jpe?g|png|mp4|xls|xlsx|doc|docx|xls|xlsx|txt|rtf)$/i
        }),
        dataType: 'json',
        context: $('#fileupload')[0]
    }).done(function (result) {
        /*alert(result);*/
        $(this).fileupload('option', 'done')
        .call(this, null, { files: result });
    });

  
});