﻿Imports System.Web
Imports System.Web.Optimization

Public Class BundleConfig
    ' For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
    Public Shared Sub RegisterBundles(ByVal bundles As BundleCollection)
        bundles.Add(New ScriptBundle("~/bundles/jquery").Include("~/Scripts/jquery-{version}.js", "~/Scripts/html5.js", "~/Scripts/dsi.js"))
        bundles.Add(New ScriptBundle("~/Content/bootstrap/js").Include("~/Content/bootstrap/js/bootstrap.js"))
        bundles.Add(New ScriptBundle("~/Scripts/wizard").Include("~/Scripts/wizard/jquery.bootstrap.wizard.js", "~/Scripts/wizard/prettify.js"))
        ' bundles.Add(New ScriptBundle("~/bundles/jqueryui").Include("~/Scripts/jquery-ui-{version}.js"))
        bundles.Add(New ScriptBundle("~/bundles/jqueryval").Include("~/Scripts/jquery.unobtrusive*", "~/Scripts/jquery.validate*"))

        ' Use the development version of Modernizr to develop with and learn from. Then, when you're
        ' ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
        bundles.Add(New ScriptBundle("~/bundles/modernizr").Include("~/Scripts/modernizr-*"))

        bundles.Add(New StyleBundle("~/bundles/Gridcss").Include("~/Content/Gridmvc.css"))
        bundles.Add(New ScriptBundle("~/bundles/Gridjs").Include("~/Scripts/gridmvc.js"))

        bundles.Add(New StyleBundle("~/Content/bootstrap/css/").Include("~/Content/bootstrap/css/bootstrap.css", "~/Content/bootstrap/css/bootstrap-responsive.css", "~/Content/assets/styles.css"))
        bundles.Add(New StyleBundle("~/Content/wizard").Include("~/Content/wizard/prettify.css"))

        bundles.Add(New ScriptBundle("~/Content/datepicker/js").Include("~/Content/datepicker/js/bootstrap-datepicker.js"))
        bundles.Add(New StyleBundle("~/Content/datepicker/css").Include("~/Content/datepicker/css/datepicker.css"))
        BundleTable.EnableOptimizations = False
    End Sub
End Class