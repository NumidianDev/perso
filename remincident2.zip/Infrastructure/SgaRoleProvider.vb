﻿Imports System.Web.Security
Imports System.Data.SqlClient

Namespace Providers
    Public Class SgaRoleProvider
        Inherits SqlRoleProvider

        Protected Friend userInRoleQuery As String = "SELECT count(*) nb FROM RI_roles r, RI_Utilisateur u where r.Id = u.Role_Id and u.Matricule = '{0}' and r.Libelle = {1}"

        Protected Friend GetRolesForUserQuery As String = "SELECT  r.Libelle role from RI_RoleUtilisateur ru,RI_Roles r WHERE ru.RoleId = R.Id and ru.UtilisateurId = '{0}' "


        Public Overrides Function IsUserInRole(username As String, roleName As String) As Boolean

            Dim roleArray As String() = roleName.Split(",")
            Dim rolesValue As String = "'" & String.Join("','", roleArray) & "'"

            Dim connectionString As String = Fct.getConnectionString()

            Try

                Using conn As SqlConnection = New SqlConnection(connectionString)

                    conn.Open()

                    Dim cmd As SqlCommand = conn.CreateCommand()

                    cmd.CommandType = CommandType.Text
                    cmd.CommandTimeout = 1000
                    cmd.CommandText = String.Format(userInRoleQuery, username, rolesValue)

                    Dim count As Integer = cmd.ExecuteScalar

                    Return count > 0

                End Using

            Catch ex As Exception
                Return False
            End Try

        End Function

        Public Overrides Function GetRolesForUser(username As String) As String()

            Dim result As List(Of String) = New List(Of String)

            Dim connectionString As String = Fct.getConnectionString()

            Try

                Using conn As SqlConnection = New SqlConnection(connectionString)

                    conn.Open()

                    Dim cmd As SqlCommand = conn.CreateCommand()

                    cmd.CommandType = CommandType.Text
                    cmd.CommandTimeout = 1000
                    cmd.CommandText = String.Format(GetRolesForUserQuery, username)

                    Using dr As SqlDataReader = cmd.ExecuteReader()

                        While dr.Read

                            result.Add(dr("role"))

                        End While

                    End Using

                End Using

            Catch ex As Exception

            End Try

            Return result.ToArray

        End Function

        Public Overrides Function RoleExists(uid As String) As Boolean
            Dim db = New DB
            Dim adm = db.Parametres.Where(Function(u) u.Cle.Equals("Administrateur")).FirstOrDefault()
            Dim role = adm.Value.Split(",").ToArray()
            Dim r = Array.IndexOf(role, uid)
            If r = -1 Then
                Return False
            End If
            Return True
        End Function

#Region "Helper Method"


#End Region

    End Class
End Namespace
