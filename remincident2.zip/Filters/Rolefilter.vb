﻿Imports System.Web.Security

Public Class RoleFilter
    Inherits ActionFilterAttribute
    Implements IActionFilter

    Public Overrides Sub OnActionExecuting(filterContext As System.Web.Mvc.ActionExecutingContext)
        Dim db = New DB
        Dim uid As String = HttpContext.Current.User.Identity.Name
        Dim adm = db.Parametres.Where(Function(u) u.Cle.Equals("Administrateur")).FirstOrDefault()
        Dim role = adm.Value.Split(",").ToArray()
        Dim rvd As RouteValueDictionary = New RouteValueDictionary()
        rvd.Add("controller", "Incident")
        rvd.Add("action", "Index")
        rvd.Add("returnUrl", filterContext.HttpContext.Request.RawUrl)
        Dim r = Array.IndexOf(role, uid)
        If r = -1 Then
            filterContext.Result = New RedirectToRouteResult(rvd)
        Else
            MyBase.OnActionExecuting(filterContext)
        End If

    End Sub

End Class

Public Class NoCache
    Inherits ActionFilterAttribute
    Implements IActionFilter

    Public Overloads Sub OnActionExecuting(CacheContext As System.Web.Mvc.ActionExecutingContext)
        CacheContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1))
        CacheContext.HttpContext.Response.Cache.SetValidUntilExpires(False)
        CacheContext.HttpContext.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches)
        CacheContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache)
        CacheContext.HttpContext.Response.Cache.SetNoStore()
        MyBase.OnActionExecuting(CacheContext)
    End Sub

End Class
