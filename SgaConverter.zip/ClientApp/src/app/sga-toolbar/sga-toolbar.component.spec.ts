import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SgaToolbarComponent } from './sga-toolbar.component';

describe('SgaToolbarComponent', () => {
  let component: SgaToolbarComponent;
  let fixture: ComponentFixture<SgaToolbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SgaToolbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SgaToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
