﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApi.Migrations
{
    public partial class addUserCaracteristics : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Departement",
                table: "Users",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Direction",
                table: "Users",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "N1",
                table: "Users",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "N2",
                table: "Users",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Pole",
                table: "Users",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Service",
                table: "Users",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "SousDirection",
                table: "Users",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Departement",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Direction",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "N1",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "N2",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Pole",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Service",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "SousDirection",
                table: "Users");
        }
    }
}
