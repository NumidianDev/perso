namespace WebApi.Entities
{
    public class Structure
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Designation { get; set; }
        public string Matricule { get; set; }
    }
}