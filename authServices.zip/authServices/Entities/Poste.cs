namespace WebApi.Entities
{
    public class Poste
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Designation { get; set; }
    }
}