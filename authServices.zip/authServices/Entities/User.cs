namespace WebApi.Entities
{
    public class User
    {
        public int Id { get; set; }
        public string Matricule { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string N1 { get; set; }
        public string N2 { get; set; }
        public int Service { get; set; }
        public int Departement { get; set; }
        public int SousDirection { get; set; }
        public int Direction { get; set; }
        public int Pole { get; set; }
        public string Username { get; set; }
        public byte[] PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }
    }
}