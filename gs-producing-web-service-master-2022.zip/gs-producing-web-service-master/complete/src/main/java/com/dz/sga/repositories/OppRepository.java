package com.dz.sga.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.dz.sga.dao.OppCom;
import com.dz.sga.dao.OppComKey;

public interface OppRepository extends CrudRepository<OppCom, OppComKey> {

	@Query("SELECT opp FROM OppCom opp where opp.age = :age and opp.dev = :dev and opp.ncp = :ncp and opp.opp = :opp and opp.eta = 'V'")
	OppCom getStoppage(String age, String dev, String ncp, String opp);
	
	
	//@Query("update OppCom opp set opp.eta = :eta, opp.motifl = :motifl, opp.dlev = CURRENT_DATE WHERE opp.age = :age and opp.dev = :dev and opp.ncp = :ncp and opp.opp = :opp")
	//void updateStoppage(String age, String dev, String ncp, String opp, String motifl, String eta);
}
