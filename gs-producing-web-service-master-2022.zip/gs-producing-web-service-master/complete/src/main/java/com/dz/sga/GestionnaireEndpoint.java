package com.dz.sga;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.dz.sga.amplitude.Gestionnaire;
import com.dz.sga.amplitude.GetGestionnaireRequest;
import com.dz.sga.amplitude.GetGestionnaireResponse;
import com.dz.sga.amplitude.GetGestionnairesRequest;
import com.dz.sga.amplitude.GetGestionnairesResponse;
import com.dz.sga.repositories.GestionnaireRepository;
import com.dz.sga.utils.mappers.OrikaBeanMapper;

@Endpoint
public class GestionnaireEndpoint {
	private static final String NAMESPACE_URI = "http://sga.dz.com/amplitude";

	@Autowired
	private GestionnaireRepository gestionnaireRepository;

	@Autowired
	OrikaBeanMapper mapper;
	
	@Autowired
	public GestionnaireEndpoint(GestionnaireRepository gestionnaireRepository) {
		this.gestionnaireRepository = gestionnaireRepository;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getGestionnaireRequest")
	@ResponsePayload
	public GetGestionnaireResponse getCountry(@RequestPayload GetGestionnaireRequest request) {
		GetGestionnaireResponse response = new GetGestionnaireResponse();
		response.setGestionnaire(mapper.map(gestionnaireRepository.getGestionnaireByMatricule(request.getCuti()), Gestionnaire.class));
		
		return response;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getGestionnairesRequest")
	@ResponsePayload
	public GetGestionnairesResponse getCountry(@RequestPayload GetGestionnairesRequest request) {
		GetGestionnairesResponse response = new GetGestionnairesResponse();
		gestionnaireRepository.getGestionnairesAll().forEach(gestionnaire -> {
			response.getGestionnaire().add(mapper.map(gestionnaire, Gestionnaire.class));
		});
		return response;
	}
}
