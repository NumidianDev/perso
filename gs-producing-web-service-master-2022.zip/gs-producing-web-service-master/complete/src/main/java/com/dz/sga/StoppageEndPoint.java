package com.dz.sga;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.dz.sga.amplitude.CancelStoppageRequest;
import com.dz.sga.amplitude.CancelStoppageResponse;
import com.dz.sga.amplitude.StoppageResponse;
import com.dz.sga.dao.OppCom;
import com.dz.sga.repositories.OppRepository;

@Endpoint
public class StoppageEndPoint {

	private static final String NAMESPACE_URI = "http://sga.dz.com/amplitude";
	
	@Autowired
	private OppRepository oppRepository;
	
	@Autowired
	public StoppageEndPoint(OppRepository oppRepository) {
		this.oppRepository = oppRepository;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "cancelStoppageRequest")
	@ResponsePayload
	public CancelStoppageResponse cancelStoppage(@RequestPayload CancelStoppageRequest request) {
		CancelStoppageResponse cancelResponse = new CancelStoppageResponse();
		StoppageResponse response = new StoppageResponse();
		
		OppCom saved = oppRepository.getStoppage(request.getStoppage().getBranch(), 
									request.getStoppage().getCurrency(), 
									request.getStoppage().getAccount(), 
									request.getStoppage().getStoppageCode());
		if(saved != null) {
			
			saved.setEta("L");
			saved.setMotifl(request.getStoppage().getStoppageEndReason());
			saved.setDlev(new Date());
			saved.setUtl("SMG");
			
			OppCom aftersaved = oppRepository.save(saved);
			
			if(null != aftersaved && aftersaved.getEta().equals("L")) {
				response.setStatusCode(0);
				response
					.setResponse("Opposition d'ouverture levée pour le compte " + 
							request.getStoppage().getBranch() + " - "	+
							request.getStoppage().getCurrency() + " - "	+ 
							request.getStoppage().getAccount());
			}else {
				response.setStatusCode(-1);
				response
					.setResponse("L'opposition d'ouverture pour le compte " + 
							request.getStoppage().getBranch() + " - "	+
							request.getStoppage().getCurrency() + " - "	+ 
							request.getStoppage().getAccount() + " n'as pas pu être levée ");
			}
			
		}else {
			response.setStatusCode(-1);
			response
				.setResponse("Aucune opposition valide n'est trouvée pour le compte " + 
						request.getStoppage().getBranch() + " - "	+
						request.getStoppage().getCurrency() + " - "	+ 
						request.getStoppage().getAccount());
		}
		cancelResponse.setStoppageResponse(response);
		return cancelResponse;
	}
}
