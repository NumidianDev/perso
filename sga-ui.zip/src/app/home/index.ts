﻿export * from './home.component';
