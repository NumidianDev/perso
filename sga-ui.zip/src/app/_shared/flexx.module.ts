import { NgModule } from '@angular/core';
import { FlexModule } from '@angular/flex-layout/flex';
import { GridModule } from '@angular/flex-layout/grid';
import { FlexLayoutModule } from '@angular/flex-layout';

const flexModules = [FlexModule, GridModule, FlexLayoutModule];

@NgModule({
  imports: [...flexModules],
  exports: [...flexModules],
})
export class FlexxModule {}
