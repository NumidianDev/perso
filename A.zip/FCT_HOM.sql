USE [SGABUDGET_DEBUG]
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTRealiseElementBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetHTRealiseElementBudget] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select ISNULL(SUM((A.Montant - A.Remise) * B.Taux),0) CVDZD From Depenses A
							Join Depenses B on A.EngagementId = B.Id
							Where A.ElementBudgetId = @ELEMENTBUDGETID
							And A.TypeId = 1)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetRS]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetRS] 
(
	-- Add the parameters for the function here
	@TAXEID int,
	@Montant decimal(18, 2),
	@Remise decimal(18, 2)
)
RETURNS decimal(18, 2)
AS
BEGIN
	DECLARE @Resultat decimal(18, 2)
	DECLARE @RS bit
	SET @RS = (Select RetenuSource From Taxes Where Id = @TAXEID)
	IF @RS = 0
	BEGIN 
		SET @Resultat = 0
	END
	ELSE
	BEGIN
		SET @Resultat = (@Montant - @Remise) * ((Select Taux From Taxes Where Id = @TAXEID)/100)
	END
	RETURN @Resultat
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTVA]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTVA] 
(
	-- Add the parameters for the function here
	@TAXEID int,
	@Montant decimal(18, 2),
	@Remise decimal(18, 2)
)
RETURNS decimal(18, 2)
AS
BEGIN
	DECLARE @Resultat decimal(18, 2)
	DECLARE @RS bit
	SET @RS = (Select RetenuSource From Taxes Where Id = @TAXEID)
	IF @RS = 1
	BEGIN 
		SET @Resultat = 0
	END
	ELSE
	BEGIN
		SET @Resultat = (@Montant - @Remise) * ((Select Taux From Taxes Where Id = @TAXEID)/100)
	END
	RETURN @Resultat
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTTC]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTTC] 
(
	-- Add the parameters for the function here
	@TAXEID int,
	@Montant decimal(18, 2),
	@Remise decimal(18, 2)
)
RETURNS decimal(18, 2)
AS
BEGIN
	DECLARE @Resultat decimal(18, 2)
	DECLARE @ISRS bit
	SET @ISRS = (Select RetenuSource From Taxes Where Id = @TAXEID)
	IF @ISRS = 0
		SET @Resultat = (@Montant - @Remise) * ( 1 + (Select Taux From Taxes Where Id = @TAXEID)/100)
	ELSE
		SET @Resultat = (@Montant - @Remise) * ( 1 - (Select Taux From Taxes Where Id = @TAXEID)/100)
	RETURN @Resultat
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetDepenseDisplay]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetDepenseDisplay] 
(
	@DEPENSEID int
)
RETURNS varchar(250)
AS
BEGIN
	DECLARE @NUMERO varchar(150)
	DECLARE @AVENANT varchar(150)
	DECLARE @TYPEDEP int
	DECLARE @RESULT varchar(250)
	
	SET @NUMERO = (Select ISNULL(Numero,'') From Depenses where Id = @DEPENSEID)
	SET @AVENANT = (Select ISNULL(Avenant,'') From Depenses where Id = @DEPENSEID)
	SET @TYPEDEP = (Select ISNULL(TypeId,0) From Depenses where Id = @DEPENSEID)
	
	IF (@TYPEDEP = 1) 
		SET @RESULT = 'Facture N� ' + @NUMERO
	ELSE
		BEGIN
			IF (@TYPEDEP = 2) 
				SET @RESULT = 'BDC N� ' + @NUMERO
			ELSE
				BEGIN
					IF @AVENANT <> ''
						SET @RESULT = 'Contrat N� ' + @NUMERO + ' # Avenant N� ' + @AVENANT
					ELSE
						SET @RESULT = 'Contrat N� ' + @NUMERO
				END
		END
	RETURN @RESULT
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTDepense]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetHTDepense] 
(
	-- Add the parameters for the function here
	@DEPENSEID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select T.Materiels + T.Logiciels + T.FraisInformatiques + T.FraisTelecoms + T.FgInvests From
			(Select
				(Select ISNULL(SUM(Montant),0) From Materiels Where DepenseId = A.Id) as Materiels,
				(Select ISNULL(SUM(Montant),0) From Logiciels Where DepenseId = A.Id) as Logiciels,
				(Select ISNULL(SUM(Montant),0) From FraisInformatiques Where DepenseId = A.Id) as FraisInformatiques,
				(Select ISNULL(SUM(Montant),0) From FraisTelecoms Where DepenseId = A.Id) as FraisTelecoms,
				(Select ISNULL(SUM(Montant),0) From FG_Invest Where DepenseId = A.Id) as FgInvests
			From Depenses A
			Where A.Id = @DEPENSEID) T)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetRemiseDepense]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetRemiseDepense] 
(
	-- Add the parameters for the function here
	@DEPENSEID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select T.Materiels + T.Logiciels + T.FraisInformatiques + T.FraisTelecoms + T.FgInvests From
			(Select
				(Select ISNULL(SUM(Remise),0) From Materiels Where DepenseId = A.Id) as Materiels,
				(Select ISNULL(SUM(Remise),0) From Logiciels Where DepenseId = A.Id) as Logiciels,
				(Select ISNULL(SUM(Remise),0) From FraisInformatiques Where DepenseId = A.Id) as FraisInformatiques,
				(Select ISNULL(SUM(Remise),0) From FraisTelecoms Where DepenseId = A.Id) as FraisTelecoms,
				(Select ISNULL(SUM(Remise),0) From FG_Invest Where DepenseId = A.Id) as FgInvests
			From Depenses A
			Where A.Id = @DEPENSEID) T)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTTCDepense]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetTTCDepense] 
(
	-- Add the parameters for the function here
	@DEPENSEID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select T.Materiels + T.Logiciels + T.FraisInformatiques + T.FraisTelecoms + T.FgInvests From
			(Select
				(Select ISNULL(SUM(TTC),0) From Materiels Where DepenseId = A.Id) as Materiels,
				(Select ISNULL(SUM(TTC),0) From Logiciels Where DepenseId = A.Id) as Logiciels,
				(Select ISNULL(SUM(TTC),0) From FraisInformatiques Where DepenseId = A.Id) as FraisInformatiques,
				(Select ISNULL(SUM(TTC),0) From FraisTelecoms Where DepenseId = A.Id) as FraisTelecoms,
				(Select ISNULL(SUM(TTC),0) From FG_Invest Where DepenseId = A.Id) as FgInvests
			From Depenses A
			Where A.Id = @DEPENSEID) T)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTVADepense]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetTVADepense] 
(
	-- Add the parameters for the function here
	@DEPENSEID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select T.Materiels + T.Logiciels + T.FraisInformatiques + T.FraisTelecoms + T.FgInvests From
			(Select
				(Select ISNULL(SUM(TVA),0) From Materiels Where DepenseId = A.Id) as Materiels,
				(Select ISNULL(SUM(TVA),0) From Logiciels Where DepenseId = A.Id) as Logiciels,
				(Select ISNULL(SUM(TVA),0) From FraisInformatiques Where DepenseId = A.Id) as FraisInformatiques,
				(Select ISNULL(SUM(TVA),0) From FraisTelecoms Where DepenseId = A.Id) as FraisTelecoms,
				(Select ISNULL(SUM(TVA),0) From FG_Invest Where DepenseId = A.Id) as FgInvests
			From Depenses A
			Where A.Id = @DEPENSEID) T)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetRSDepense]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetRSDepense] 
(
	-- Add the parameters for the function here
	@DEPENSEID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select T.Materiels + T.Logiciels + T.FraisInformatiques + T.FraisTelecoms + T.FgInvests From
			(Select
				(Select ISNULL(SUM(RS),0) From Materiels Where DepenseId = A.Id) as Materiels,
				(Select ISNULL(SUM(RS),0) From Logiciels Where DepenseId = A.Id) as Logiciels,
				(Select ISNULL(SUM(RS),0) From FraisInformatiques Where DepenseId = A.Id) as FraisInformatiques,
				(Select ISNULL(SUM(RS),0) From FraisTelecoms Where DepenseId = A.Id) as FraisTelecoms,
				(Select ISNULL(SUM(RS),0) From FG_Invest Where DepenseId = A.Id) as FgInvests
			From Depenses A
			Where A.Id = @DEPENSEID) T)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTLicencesRea]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTLicencesRea] 
(
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant - A.Remise,0) * C.Taux) From Logiciels A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Join Depenses C on B.EngagementId = C.Id
			Where B.TypeId in (1)
			And B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTLicencesEng]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTLicencesEng] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant - A.Remise,0) * B.Taux) From Logiciels A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Where B.TypeId in (2,3)
			And B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTLicences]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTLicences] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select ISNULL(SUM(A.Montant),0) From Logiciels A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Where B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTEngagesElementBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetHTEngagesElementBudget] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	DECLARE @Resultat decimal(18, 2)
	DECLARE @ISFG Bit
	SET @ISFG = (Select CAST(CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END AS BIT) From dbo.ElementsBudget_FraisGeneraux Where Id = @ELEMENTBUDGETID)
	
	IF (@ISFG <> 0)
		SET @Resultat = (Select ISNULL(SUM(dbo.GetMontantProrataFG(A.Id,@ELEMENTBUDGETID) * A.Taux),0) CVDZD From Depenses A
							Where (A.TypeId = 2 Or A.TypeId = 3))
	Else
		SET @Resultat = (Select ISNULL(SUM(dbo.GetMontantProrata(A.Id) * A.Taux),0) CVDZD From Depenses A
							Where A.ElementBudgetId = @ELEMENTBUDGETID
							And (A.TypeId = 2 Or A.TypeId = 3))
	Return @Resultat
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetBudgetAmount]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetBudgetAmount] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(Montant,0)) From ElementsBudget
			Where BudgetId = @BUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalEngageFraisByBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTotalEngageFraisByBudget] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Engage,0)) 
			From ElementsBudget A
			Join ElementsBudget_FraisGeneraux B on A.Id = B.Id
			Where BudgetId = @BUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTAquisitions]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTAquisitions] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select ISNULL(SUM(A.Montant),0) From Materiels A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Where B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTAquisitionsEng]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTAquisitionsEng] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant,0) * B.Taux) From Materiels A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Where B.TypeId in (2,3)
			And B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTAquisitionsRea]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTAquisitionsRea] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant,0) * C.Taux) From Materiels A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Join Depenses C on B.EngagementId = C.Id
			Where B.TypeId in (1)
			And B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTPrestations]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTPrestations] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select ISNULL(SUM(A.Montant),0) From FraisInformatiques A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Where B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTPrestationsEng]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTPrestationsEng] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant - A.Remise,0) * B.Taux) From FraisInformatiques A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Where B.TypeId in (2,3)
			And B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTPrestationsRea]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTPrestationsRea] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant - A.Remise,0) * C.Taux) From FraisInformatiques A
			JOIN Depenses B on (A.DepenseId = B.Id)
			Join Depenses C on B.EngagementId = C.Id
			Where B.TypeId in (1)
			And B.ElementBudgetId = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalEngageInvestByBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTotalEngageInvestByBudget] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Engage,0)) 
			From ElementsBudget A
			Join ElementsBudget_Investissement B on A.Id = B.Id
			Where BudgetId = @BUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalFraisByBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTotalFraisByBudget] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant,0)) 
			From ElementsBudget A
			Join ElementsBudget_FraisGeneraux B on A.Id = B.Id
			Where BudgetId = @BUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalInvestByBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTotalInvestByBudget] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Montant,0)) 
			From ElementsBudget A
			Join ElementsBudget_Investissement B on A.Id = B.Id
			Where BudgetId = @BUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalRealiseFraisByBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTotalRealiseFraisByBudget] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Realise,0)) 
			From ElementsBudget A
			Join ElementsBudget_FraisGeneraux B on A.Id = B.Id
			Where BudgetId = @BUDGETID)	
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalRealiseInvestByBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetTotalRealiseInvestByBudget] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Realise,0)) 
			From ElementsBudget A
			Join ElementsBudget_Investissement B on A.Id = B.Id
			Where BudgetId = @BUDGETID)	
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetMontantProrata]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetMontantProrata]
(
	@DEPENSEID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	DECLARE @Resultat decimal(18, 2)
	DECLARE @Exercice int
	DECLARE @Debut DateTime
	DECLARE @Fin DateTime
	DECLARE @DebutExercice DateTime
	DECLARE @FinExercice DateTime
	
	
	SET @Resultat = 0
	
	SET @Debut = (Select DateDebut From dbo.Depenses Where Id = @DEPENSEID)
	SET @Fin = (Select DateFin From dbo.Depenses Where Id = @DEPENSEID)
	SET @Exercice = (Select C.Exercice From dbo.Depenses A
					Join ElementsBudget B on A.ElementBudgetId = B.Id
					Join Budgets C on B.BudgetId = C.Id
					Where A.Id = @DEPENSEID)
					
	SET @DebutExercice = (SELECT CONVERT(datetime, '01.01.' + CONVERT(varchar(12), @Exercice, 101) , 103) AS DateTime)
	SET @FinExercice = (SELECT CONVERT(datetime, '31.12.' + CONVERT(varchar(12), @Exercice, 101) , 103) AS DateTime)
	
	IF ((@Debut Is Null) Or (@Fin Is Null))
		SET @Resultat = (Select Montant - Remise From dbo.Depenses Where Id = @DEPENSEID)
	Else
		Begin
			Declare @TotalDays int
			Declare @ProrataDays int
			Set @TotalDays = DATEDIFF(day,@Debut,@Fin)
			
			If (@Exercice < YEAR(@Debut)) Or (@Exercice > YEAR(@Fin))
				SET @Resultat = 0
			Else
				Begin
					If DATEDIFF(day,@DebutExercice,@Debut) < 0
						Begin
							Set @Debut = @DebutExercice
						End
					If DATEDIFF(day,@FinExercice,@Fin) > 0
						Begin
							Set @Fin = @FinExercice
						End
					/* Calcul au prorata */
					SET @ProrataDays = DATEDIFF(day,@Debut,@Fin)
					SET @Resultat = (Select ((Montant - Remise) * @ProrataDays) / @TotalDays From dbo.Depenses Where Id = @DEPENSEID)
					
				End
		End
	Return @Resultat
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTEngagesElementBudget1]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetHTEngagesElementBudget1] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select ISNULL(SUM(dbo.GetMontantProrata(A.Id) * A.Taux),0) CVDZD From Depenses A
							Where A.ElementBudgetId = @ELEMENTBUDGETID
							And (A.TypeId = 2 Or A.TypeId = 3))
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTElementBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTElementBudget] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select ISNULL(SUM(Montant),0) From Depenses
			Where ElementBudgetId = @ELEMENTBUDGETID
			And TypeId = 1)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetMontantProrataFG]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetMontantProrataFG]
(
	@DEPENSEID int,
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	DECLARE @Resultat decimal(18, 2)
	DECLARE @Exercice int
	DECLARE @Debut DateTime
	DECLARE @Fin DateTime
	DECLARE @DebutExercice DateTime
	DECLARE @FinExercice DateTime
	DECLARE @ProrataFG decimal(18, 2)
	
	SET @Resultat = 0
	
	SET @Debut = (Select DateDebut From dbo.Depenses Where Id = @DEPENSEID)
	SET @Fin = (Select DateFin From dbo.Depenses Where Id = @DEPENSEID)
	SET @Exercice = (Select C.Exercice From dbo.Depenses A
					Join ElementsBudget B on A.ElementBudgetId = B.Id
					Join Budgets C on B.BudgetId = C.Id
					Where A.Id = @DEPENSEID)
					
	SET @DebutExercice = (SELECT CONVERT(datetime, '01.01.' + CONVERT(varchar(12), @Exercice, 101) , 103) AS DateTime)
	SET @FinExercice = (SELECT CONVERT(datetime, '31.12.' + CONVERT(varchar(12), @Exercice, 101) , 103) AS DateTime)
	
	IF ((@Debut Is Null) Or (@Fin Is Null))
		SET @Resultat = (Select SUM(FI) + SUM(FT) From 
							(Select ISNULL((A.Montant - A.Remise),0) As FI, 0 As FT From dbo.FraisInformatiques A
							Join dbo.Depenses B on A.DepenseId = B.Id
							Where B.Id = @DEPENSEID
							And A.PosteId = @ELEMENTBUDGETID
							Union
							Select 0 as FI,ISNULL((A.Montant - A.Remise),0) As FT From dbo.FraisTelecoms A
							Join dbo.Depenses B on A.DepenseId = B.Id
							Where B.Id = @DEPENSEID
							And A.PosteId = @ELEMENTBUDGETID) T)
	Else
		Begin
			Declare @TotalDays int
			Declare @ProrataDays int
			Set @TotalDays = DATEDIFF(day,@Debut,@Fin)
			
			If (@Exercice < YEAR(@Debut)) Or (@Exercice > YEAR(@Fin))
				SET @Resultat = 0
			Else
				Begin
					If DATEDIFF(day,@DebutExercice,@Debut) < 0
						Begin
							Set @Debut = @DebutExercice
						End
					If DATEDIFF(day,@FinExercice,@Fin) > 0
						Begin
							Set @Fin = @FinExercice
						End
					/* Calcul au prorata */
					SET @ProrataDays = DATEDIFF(day,@Debut,@Fin)
					SET @ProrataFG = (Select SUM(FI) + SUM(FT) From 
										(Select ISNULL((A.Montant - A.Remise),0) As FI, 0 As FT From dbo.FraisInformatiques A
										Join dbo.Depenses B on A.DepenseId = B.Id
										Where B.Id = @DEPENSEID
										And A.PosteId = @ELEMENTBUDGETID
										Union
										Select 0 as FI,ISNULL((A.Montant - A.Remise),0) As FT From dbo.FraisTelecoms A
										Join dbo.Depenses B on A.DepenseId = B.Id
										Where B.Id = @DEPENSEID
										And A.PosteId = @ELEMENTBUDGETID) T)
					SET @Resultat = @ProrataFG * @ProrataDays / @TotalDays /*(Select ((Montant - Remise) * @ProrataDays) / @TotalDays From dbo.Depenses Where Id = @DEPENSEID)*/
					
				End
		End
	Return @Resultat
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTEngageBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTEngageBudget]
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(Engage,0)) From ElementsBudget
			Where BudgetId = @BUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetHTBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetHTBudget] 
(
	-- Add the parameters for the function here
	@BUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(Realise,0)) From ElementsBudget
			Where BudgetId = @BUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetCharge]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetCharge] 
(
	-- Add the parameters for the function here
	@ELEMENTBUDGETID int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select SUM(ISNULL(A.Charge,0)) Charge From dbo.ElementsBudget_Investissement A
			Where A.Id = @ELEMENTBUDGETID)
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetMonthFGBudget]    Script Date: 03/05/2017 10:19:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetMonthFGBudget] 
(
	-- Add the parameters for the function here
	@BudgetId int,
	@PosteId int,
	@MonthNumber int
)
RETURNS decimal(18, 2)
AS
BEGIN
	RETURN (Select ((SUM(A.Montant) * @MonthNumber)/12)
			From SGABUDGET.dbo.ElementsBudget A
			Join SGABUDGET.dbo.ElementsBudget_FraisGeneraux B on A.Id = B.Id
			Join SGABUDGET.dbo.Postes C on C.Id = B.PosteId
			Join SGABUDGET.dbo.Budgets E on A.BudgetId = E.Id
			Where E.Exercice = (Select Exercice From Budgets Where Id = @BudgetId)
			And C.Id = @PosteId)
END
GO