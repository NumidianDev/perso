﻿Imports log4net
Imports Sga.Settings
Imports System.Data.SqlClient

Namespace data
    Public Class MSSQLUtils

        Private Shared instance As MSSQLUtils
        Private Shared connectionString As String
        Private Shared pleaseCStr As String

        Private Shared ReadOnly logger As ILog = log4net.LogManager.GetLogger(GetType(MSSQLUtils))

        Private Shared queryUpdateRadical As String = "Update SgaReporting_PleaseData " & _
                                                        "SET Radical = (Select cli From SgaReporting_TempBkcom  " & _
                                                        "				Where (CAST(Code_agence AS INT) = age and Substring([Numero_de_compte],0,11) = ncp)) " & _
                                                        "Where Date_arrete = '{0}'"
        Private queryLeasing As String = "SELECT " & _
                                    "	[Third_Party_Index].[Name] AS Nom_du_client,  " & _
                                    "	[Third_Party_Index].[LP_Form_Of_Business] AS Raison_sociale,  " & _
                                    "	[_Local_List].[Code] AS Code_segment,  " & _
                                    "	[_Dictionary].[FR_Word] AS Segmentation_clientele,  " & _
                                    "	[Third_Party_Index].[Third_Party_ID] AS Numéro_du_client,  " & _
                                    "	[Files].[Contract_Code] AS Numéro_du_contrat,  " & _
                                    "	[Files].[File_Status_Code] AS Statut_contrat,  " & _
                                    "	[Financial_Institution].[Branch_Code] AS Code_agence,  " & _
                                    "	[Financial_Institution].[Branch] AS Agence,  " & _
                                    "	[Bank_Account].[Bank_Account_No] AS Numéro_de_compte,  " & _
                                    "	[Files].[Ending_Date] AS Date_de_fin_de_contrat,  " & _
                                    "	[Authorizations].[Authorized_Amount] AS Montant_Approbation,  " & _
                                    "	[Authorizations].[Expiry_Date] AS Date_Expiration_Approbation,  " & _
                                    "	[Files].[Gross_Asset] AS Montant_du_décaissement,  " & _
                                    "	[Files].[Contract_Outstanding] AS Montant_des_encours,  " & _
                                    "	[Financial_Condition].[Nominal_Rate] AS Taux_appliqué,  " & _
                                    "	[Financial_Condition].[RV_Amount] AS Montant_Valeur_Résiduelle,  " & _
                                    "	(SELECT Sum(Client_Invoice.Remaining_Amount_IOT) AS SommeDeRemaining_Amount_IOT  " & _
                                    "	 FROM Client_Invoice  " & _
                                    "	 INNER JOIN Files As Files1 ON Client_Invoice.File_ID = Files1.File_ID  " & _
                                    "	 WHERE Files1.Contract_Code=Files.Contract_Code) AS Montant_des_impayés,  " & _
                                    "	(SELECT Count(Client_Invoice.Remaining_Amount_IOT) AS CompteDeContract_Code  " & _
                                    "	 FROM Client_Invoice  " & _
                                    "	 INNER JOIN Files As Files1 ON Client_Invoice.File_ID = Files1.File_ID  " & _
                                    "	 WHERE  Files1.Contract_Code=Files.Contract_Code  " & _
                                    "	 AND ((Client_Invoice.Remaining_Amount_IOT)>0)) AS Nombre_Impayés_Contrat,  " & _
                                    "	[Internal_Index].[Name] AS Créateur_du_contrat, " & _
                                    "	'' as Radical " & _
                                    "FROM _Dictionary  " & _
                                    "	 RIGHT JOIN ( " & _
                                    "				 ( " & _
                                    "				  Client INNER JOIN ( " & _
                                    "					( " & _
                                    "					 ( " & _
                                    "					  ( " & _
                                    "					   ( " & _
                                    "						( " & _
                                    "							Files LEFT JOIN Bank_Account ON [Files].[Bank_Account_ID]=[Bank_Account].[Bank_Account_ID] " & _
                                    "						)  " & _
                                    "							INNER JOIN Authorizations ON [Files].[Authorization_ID]=[Authorizations].[Authorization_ID] " & _
                                    "					   )  " & _
                                    "							INNER JOIN Financial_Condition ON [Files].[File_ID]=[Financial_Condition].[File_ID] " & _
                                    "					  )  " & _
                                    "							INNER JOIN Third_Party_Index ON [Files].[Client_ID]=[Third_Party_Index].[Third_Party_ID] " & _
                                    "					 )  " & _
                                    "							INNER JOIN Internal_Index ON [Files].[CD_Internal_Index_ID]=[Internal_Index].[Internal_Index_ID] " & _
                                    "					)  " & _
                                    "							LEFT JOIN Financial_Institution ON [Bank_Account].[Financial_Institution_ID]=[Financial_Institution].[Financial_Institution_ID]) ON [Client].[Third_Party_ID]=[Third_Party_Index].[Third_Party_ID] " & _
                                    "				)  " & _
                                    "							LEFT JOIN _Local_List ON [Client].[Group_Customer_Segment]=[_Local_List].[List_Value_Id]) ON [_Dictionary].[Mnemo]=[_Local_List].[Mnemo] " & _
                                    "WHERE ((([Files].[File_Status_Code])=210 Or ([Files].[File_Status_Code])=200 Or ([Files].[File_Status_Code])=300) And (([Financial_Condition].[Active])=-1)) " & _
                                    "ORDER BY [Third_Party_Index].[Third_Party_ID], [Files].[Contract_Code]"

        Private Sub New()
#If DEBUG Then
        connectionString = ApplicationSettings.GetInstance.getConnectionStringByName("SgaReportingCS")
        pleaseCStr = ApplicationSettings.GetInstance.getConnectionStringByName("Please")
        If logger.IsDebugEnabled Then
            logger.Debug("Connection string setted on debug mode")
        End If
#Else
            pleaseCStr = ApplicationSettings.GetInstance.getConnectionStringByName("Please")
            connectionString = ApplicationSettings.GetInstance.getConnectionStringByName("SgaReportingCS")
            If logger.IsDebugEnabled Then
                logger.Debug("Connection string setted on production mode")
            End If
#End If
        End Sub

        Public Shared Function getInstance() As MSSQLUtils
            If instance Is Nothing Then
                instance = New MSSQLUtils()
            End If
            Return instance
        End Function

        Public Function getPleaseData(ByVal datearrete As Date) As DataTable
            logger.Debug("getPleaseData - Begin -")

            Try
                logger.Debug(pleaseCStr)
                Using pleaseCon As SqlConnection = New SqlConnection(pleaseCStr)
                    Dim command As SqlCommand = pleaseCon.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text

                    command.CommandText = queryLeasing

                    Dim result = New DataTable()
                    Dim da As SqlDataAdapter = New SqlDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("getPleaseData - End -")

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                              .DataType = GetType(DateTime),
                                                              .DefaultValue = datearrete}

                    result.Columns.Add(dc)

                    result.AcceptChanges()

                    Return result

                End Using
            Catch ex As Exception
                logger.Debug("getPleaseData - End Exception - " & ex.Message)
                Return Nothing
            End Try
        End Function

        Public Function getTypesComptesFromPlease() As String
            logger.Debug("getTypesComptesFromPlease - Begin -")

            Try

                Using pleaseCon As SqlConnection = New SqlConnection(pleaseCStr)
                    Dim command As SqlCommand = pleaseCon.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text

                    command.CommandText = "Select Distinct Substring([Bank_Account_No],1,3)  As Typ  From [Bank_Account]"

                    Dim result = New DataTable()
                    Dim da As SqlDataAdapter = New SqlDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("exportSoldeToSqlServer - End -")

                    logger.Debug("'" & String.Join("','", (From row As DataRow In result Select row("Typ")).ToArray) & "'")

                    Return "'" & String.Join("','", (From row As DataRow In result Select row("Typ")).ToArray) & "'"

                End Using
            Catch ex As Exception
                logger.Debug("exportSoldeToSqlServer - End Exception - " & ex.Message)
                Return ""
            End Try
        End Function

        Public Sub exportPleaseDataToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportPleaseDataToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_PleaseData " _
                                            & "Where Date_arrete = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 1)
                            copy.ColumnMappings.Add(1, 2)
                            copy.ColumnMappings.Add(2, 3)
                            copy.ColumnMappings.Add(3, 4)
                            copy.ColumnMappings.Add(4, 5)
                            copy.ColumnMappings.Add(5, 6)
                            copy.ColumnMappings.Add(6, 7)
                            copy.ColumnMappings.Add(7, 8)
                            copy.ColumnMappings.Add(8, 9)
                            copy.ColumnMappings.Add(9, 10)
                            copy.ColumnMappings.Add(10, 11)
                            copy.ColumnMappings.Add(11, 12)
                            copy.ColumnMappings.Add(12, 13)
                            copy.ColumnMappings.Add(13, 14)
                            copy.ColumnMappings.Add(14, 15)
                            copy.ColumnMappings.Add(15, 16)
                            copy.ColumnMappings.Add(16, 17)
                            copy.ColumnMappings.Add(17, 18)
                            copy.ColumnMappings.Add(18, 19)
                            copy.ColumnMappings.Add(19, 20)
                            copy.ColumnMappings.Add(20, 21)
                            copy.ColumnMappings.Add(21, 0)
                            copy.DestinationTableName = "SgaReporting_PleaseData"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportPleaseDataToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des comptes leasing")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportPleaseDataToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        Public Sub exportTempBkComToSqlServer(ByVal dt As DataTable, ByVal datearrete As Date)

            logger.Debug("exportTempBkComToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next


                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text

                        command.CommandText = "Truncate Table SgaReporting_TempBkcom"

                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 0)
                            copy.ColumnMappings.Add(1, 1)
                            copy.ColumnMappings.Add(2, 2)
                            copy.ColumnMappings.Add(3, 3)
                            copy.DestinationTableName = "SgaReporting_TempBkcom"
                            copy.WriteToServer(dt)
                        End Using

                        command.CommandText = String.Format(queryUpdateRadical, datearrete)

                        command.ExecuteNonQuery()

                    End Using
                End If

                logger.Debug("exportTempBkComToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des comptes ")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportTempBkComToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        Public Sub exportSoldeToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportSoldeToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_Soldes " _
                                            & "Where dco = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 0)
                            copy.ColumnMappings.Add(1, 1)
                            copy.ColumnMappings.Add(2, 2)
                            copy.ColumnMappings.Add(3, 3)
                            copy.ColumnMappings.Add(4, 4)
                            copy.ColumnMappings.Add(5, 5)
                            copy.ColumnMappings.Add(6, 6)
                            copy.ColumnMappings.Add(7, 7)
                            copy.ColumnMappings.Add(8, 8)
                            copy.ColumnMappings.Add(9, 9)
                            copy.ColumnMappings.Add(10, 10)
                            copy.ColumnMappings.Add(11, 11)
                            copy.ColumnMappings.Add(12, 12)
                            copy.ColumnMappings.Add(13, 13)
                            copy.ColumnMappings.Add(14, 14)
                            copy.ColumnMappings.Add(15, 15)
                            copy.ColumnMappings.Add(16, 16)
                            copy.ColumnMappings.Add(17, 17)
                            copy.ColumnMappings.Add(18, 18)
                            copy.ColumnMappings.Add(19, 19)
                            copy.ColumnMappings.Add(20, 20)
                            copy.ColumnMappings.Add(21, 21)
                            copy.DestinationTableName = "SgaReporting_Soldes"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportSoldeToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des soldes ")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportSoldeToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        Public Sub exportAllClientsToSqlServer(ByVal dt As DataTable)

            logger.Debug("exportAllClientsToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Truncate Table SgaReporting_All_Clients"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 36000
                            copy.ColumnMappings.Add(0, 0)
                            copy.ColumnMappings.Add(1, 1)
                            copy.ColumnMappings.Add(2, 2)
                            copy.ColumnMappings.Add(3, 3)
                            copy.ColumnMappings.Add(4, 4)
                            copy.ColumnMappings.Add(5, 5)
                            copy.ColumnMappings.Add(6, 6)
                            copy.ColumnMappings.Add(7, 7)
                            copy.ColumnMappings.Add(8, 8)
                            copy.ColumnMappings.Add(9, 9)
                            copy.ColumnMappings.Add(10, 10)
                            copy.ColumnMappings.Add(11, 11)
                            copy.ColumnMappings.Add(12, 12)
                            copy.ColumnMappings.Add(13, 13)
                            copy.ColumnMappings.Add(14, 14)
                            copy.ColumnMappings.Add(15, 15)
                            copy.ColumnMappings.Add(16, 16)
                            copy.ColumnMappings.Add(17, 17)
                            copy.ColumnMappings.Add(18, 18)
                            copy.ColumnMappings.Add(19, 19)
                            copy.ColumnMappings.Add(20, 20)
                            copy.ColumnMappings.Add(21, 21)
                            copy.ColumnMappings.Add(22, 22)
                            copy.ColumnMappings.Add(23, 23)
                            copy.ColumnMappings.Add(24, 24)
                            copy.ColumnMappings.Add(25, 25)
                            copy.ColumnMappings.Add(26, 26)
                            copy.ColumnMappings.Add(27, 27)
                            copy.ColumnMappings.Add(28, 28)
                            copy.ColumnMappings.Add(29, 29)
                            copy.ColumnMappings.Add(30, 30)
                            copy.DestinationTableName = "SgaReporting_All_Clients"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportAllClientsToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de la table des clients")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportAllClientsToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        Public Sub exportBkComTempToSqlServer(ByVal dt As DataTable)

            logger.Debug("exportBkComTempToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Truncate Table SgaReporting_TempComptes"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 36000
                            copy.ColumnMappings.Add(0, 0)
                            copy.ColumnMappings.Add(1, 1)
                            copy.DestinationTableName = "SgaReporting_TempComptes"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportBkComTempToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de la table des comptes")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportBkComTempToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        Public Sub exportBkCliToSqlServer(ByVal dt As DataTable)

            logger.Debug("exportBkCliToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Truncate Table SgaReporting_Clients"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 36000
                            copy.ColumnMappings.Add(0, 0)
                            copy.ColumnMappings.Add(1, 1)
                            copy.ColumnMappings.Add(2, 2)
                            copy.ColumnMappings.Add(3, 3)
                            copy.ColumnMappings.Add(4, 4)
                            copy.ColumnMappings.Add(5, 5)
                            copy.DestinationTableName = "SgaReporting_Clients"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportBkCliToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de la table des clients")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportComptesCreditsToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        Public Sub exportComptesCreditsToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportComptesCreditsToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_ComptesCredits " _
                                            & "Where Date_arrete = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 36000
                            copy.ColumnMappings.Add(0, 2)
                            copy.ColumnMappings.Add(1, 3)
                            copy.ColumnMappings.Add(2, 4)
                            copy.ColumnMappings.Add(3, 5)
                            copy.ColumnMappings.Add(4, 6)
                            copy.ColumnMappings.Add(5, 7)
                            copy.ColumnMappings.Add(6, 1)
                            copy.DestinationTableName = "SgaReporting_ComptesCredits"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportComptesCreditsToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des Comptes de Credits")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportComptesCreditsToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        ' Effait
        Public Sub exportEffaitsToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportEffaitsToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_Effaits " _
                                            & "Where Date_arrete = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 2)
                            copy.ColumnMappings.Add(1, 3)
                            copy.ColumnMappings.Add(2, 4)
                            copy.ColumnMappings.Add(3, 5)
                            copy.ColumnMappings.Add(4, 6)
                            copy.ColumnMappings.Add(5, 7)
                            copy.ColumnMappings.Add(6, 8)
                            copy.ColumnMappings.Add(7, 9)
                            copy.ColumnMappings.Add(8, 10)
                            copy.ColumnMappings.Add(9, 11)
                            copy.ColumnMappings.Add(10, 12)
                            copy.ColumnMappings.Add(11, 13)
                            copy.ColumnMappings.Add(12, 14)
                            copy.ColumnMappings.Add(13, 15)
                            copy.ColumnMappings.Add(14, 16)
                            copy.ColumnMappings.Add(15, 17)
                            copy.ColumnMappings.Add(16, 18)
                            copy.ColumnMappings.Add(17, 19)
                            copy.ColumnMappings.Add(18, 20)
                            copy.ColumnMappings.Add(19, 21)
                            copy.ColumnMappings.Add(20, 22)
                            copy.ColumnMappings.Add(21, 23)
                            copy.ColumnMappings.Add(22, 24)
                            copy.ColumnMappings.Add(23, 25)
                            copy.ColumnMappings.Add(24, 26)
                            copy.ColumnMappings.Add(25, 1)
                            copy.DestinationTableName = "SgaReporting_Effaits"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportEffaitsToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des effaits")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportEffaitsToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        'SgaReporting_DAT
        Public Sub exportDATToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportDATToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)


            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_DAT " _
                                            & "Where Date_arrete = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)

                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 2)
                            copy.ColumnMappings.Add(1, 3)
                            copy.ColumnMappings.Add(2, 4)
                            copy.ColumnMappings.Add(3, 5)
                            copy.ColumnMappings.Add(4, 6)
                            copy.ColumnMappings.Add(5, 7)
                            copy.ColumnMappings.Add(6, 8)
                            copy.ColumnMappings.Add(7, 9)
                            copy.ColumnMappings.Add(8, 10)
                            copy.ColumnMappings.Add(9, 11)
                            copy.ColumnMappings.Add(10, 12)
                            copy.ColumnMappings.Add(11, 13)
                            copy.ColumnMappings.Add(12, 14)
                            copy.ColumnMappings.Add(13, 15)
                            copy.ColumnMappings.Add(14, 16)
                            copy.ColumnMappings.Add(15, 17)
                            copy.ColumnMappings.Add(16, 18)
                            copy.ColumnMappings.Add(17, 19)
                            copy.ColumnMappings.Add(18, 20)
                            copy.ColumnMappings.Add(19, 21)
                            copy.ColumnMappings.Add(20, 22)
                            copy.ColumnMappings.Add(21, 23)
                            copy.ColumnMappings.Add(22, 24)
                            copy.ColumnMappings.Add(23, 25)
                            copy.ColumnMappings.Add(24, 26)
                            copy.ColumnMappings.Add(25, 1)

                            copy.DestinationTableName = "SgaReporting_DAT"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportDATToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des DAT ")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportDATToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub

        'SgaReporting_BDC
        Public Sub exportBDCToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportBDCToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try
                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)
                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_BDC " _
                                            & "Where Date_arrete = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)

                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 2)
                            copy.ColumnMappings.Add(1, 3)
                            copy.ColumnMappings.Add(2, 4)
                            copy.ColumnMappings.Add(3, 5)
                            copy.ColumnMappings.Add(4, 6)
                            copy.ColumnMappings.Add(5, 7)
                            copy.ColumnMappings.Add(6, 8)
                            copy.ColumnMappings.Add(7, 9)
                            copy.ColumnMappings.Add(8, 10)
                            copy.ColumnMappings.Add(9, 11)
                            copy.ColumnMappings.Add(10, 12)
                            copy.ColumnMappings.Add(11, 13)
                            copy.ColumnMappings.Add(12, 14)
                            copy.ColumnMappings.Add(13, 15)
                            copy.ColumnMappings.Add(14, 16)
                            copy.ColumnMappings.Add(15, 17)
                            copy.ColumnMappings.Add(16, 18)
                            copy.ColumnMappings.Add(17, 19)
                            copy.ColumnMappings.Add(18, 20)
                            copy.ColumnMappings.Add(19, 21)
                            copy.ColumnMappings.Add(20, 22)
                            copy.ColumnMappings.Add(21, 23)
                            copy.ColumnMappings.Add(22, 24)
                            copy.ColumnMappings.Add(23, 25)
                            copy.ColumnMappings.Add(24, 26)
                            copy.ColumnMappings.Add(25, 27)
                            copy.ColumnMappings.Add(26, 28)
                            copy.ColumnMappings.Add(27, 29)
                            copy.ColumnMappings.Add(28, 30)
                            copy.ColumnMappings.Add(29, 31)
                            copy.ColumnMappings.Add(30, 1)

                            copy.DestinationTableName = "SgaReporting_BDC"
                            copy.WriteToServer(dt)
                        End Using
                    End Using
                End If

                logger.Debug("exportBDCToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des Bons de caisse ")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Debug("exportBDCToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try

        End Sub


        Public Sub exportArreteToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportAgiosToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try

                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next
                    logger.Debug("Date arrete in dt : " & dt.Rows(0)("Date_arrete").ToString)
                    Using con As SqlConnection = New SqlConnection(connectionString)

                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_Arretes " _
                                            & "Where Date_arrete = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)

                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 2)
                            copy.ColumnMappings.Add(1, 3)
                            copy.ColumnMappings.Add(2, 4)
                            copy.ColumnMappings.Add(3, 5)
                            copy.ColumnMappings.Add(4, 6)
                            copy.ColumnMappings.Add(5, 7)
                            copy.ColumnMappings.Add(6, 8)
                            copy.ColumnMappings.Add(7, 9)
                            copy.ColumnMappings.Add(8, 10)
                            copy.ColumnMappings.Add(9, 11)
                            copy.ColumnMappings.Add(10, 12)
                            copy.ColumnMappings.Add(11, 13)
                            copy.ColumnMappings.Add(12, 14)
                            copy.ColumnMappings.Add(13, 15)
                            copy.ColumnMappings.Add(14, 16)
                            copy.ColumnMappings.Add(15, 17)
                            copy.ColumnMappings.Add(16, 18)
                            copy.ColumnMappings.Add(17, 19)
                            copy.ColumnMappings.Add(18, 20)
                            copy.ColumnMappings.Add(19, 1)

                            copy.DestinationTableName = "SgaReporting_Arretes"
                            copy.WriteToServer(dt)

                        End Using

                    End Using

                End If

                logger.Debug("exportAgiosToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des Arretes ")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Warn("exportArreteToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try
        End Sub


        Public Sub exportConditionsBanques(ByVal dt As DataTable)

            logger.Debug("exportConditionsBanques - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)

            Try

                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    For i As Int32 = 0 To dt.Columns.Count - 1
                        logger.Debug(" index : " & i & " = " & dt.Columns(i).ColumnName)
                    Next

                    Using con As SqlConnection = New SqlConnection(connectionString)

                        con.Open()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)

                            copy.BulkCopyTimeout = 3600
                            copy.ColumnMappings.Add(0, 1)
                            copy.ColumnMappings.Add(1, 2)
                            copy.ColumnMappings.Add(2, 3)
                            copy.ColumnMappings.Add(3, 4)
                            copy.ColumnMappings.Add(4, 5)
                            copy.ColumnMappings.Add(5, 6)
                            copy.ColumnMappings.Add(6, 7)
                            copy.ColumnMappings.Add(7, 8)
                            copy.ColumnMappings.Add(8, 9)
                            copy.ColumnMappings.Add(9, 10)
                            copy.ColumnMappings.Add(10, 11)
                            copy.ColumnMappings.Add(11, 12)
                            copy.ColumnMappings.Add(12, 13)
                            copy.ColumnMappings.Add(13, 14)
                            copy.ColumnMappings.Add(14, 0)
                            
                            copy.DestinationTableName = "SgaReporting_ConditionsBanque"
                            copy.WriteToServer(dt)

                        End Using

                    End Using

                End If

                logger.Debug("exportConditionsBanques - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des Arretes ")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Warn("exportArreteToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try
        End Sub

        Public Sub exportRisqueGlobalToSqlServer(ByVal dt As DataTable, ByVal dateArrete As Date)

            logger.Debug("exportRisqueGlobalToSqlServer - Begin -")
            logger.Debug("exportsize " & dt.Rows.Count)


            Try

                If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then

                    Using con As SqlConnection = New SqlConnection(connectionString)

                        con.Open()

                        Dim command As SqlCommand = con.CreateCommand()
                        command.CommandTimeout = 10000
                        command.CommandType = CommandType.Text
                        command.CommandText = "Delete From SgaReporting_RisqueGlobale " _
                                            & "Where Date_arrete = '" & dateArrete.ToString("yyyyMMdd") & "'"
                        command.ExecuteNonQuery()

                        Using copy As SqlBulkCopy = New SqlBulkCopy(con)
                            copy.BulkCopyTimeout = 36000
                            copy.ColumnMappings.Add(0, 1)
                            copy.ColumnMappings.Add(1, 2)
                            copy.ColumnMappings.Add(2, 3)
                            copy.ColumnMappings.Add(3, 4)
                            copy.ColumnMappings.Add(4, 5)
                            copy.ColumnMappings.Add(5, 6)
                            copy.ColumnMappings.Add(6, 7)
                            copy.ColumnMappings.Add(7, 8)
                            copy.ColumnMappings.Add(8, 9)
                            copy.ColumnMappings.Add(9, 10)
                            copy.ColumnMappings.Add(10, 11)
                            copy.ColumnMappings.Add(11, 12)
                            copy.ColumnMappings.Add(12, 13)
                            copy.ColumnMappings.Add(13, 14)
                            copy.ColumnMappings.Add(14, 15)
                            copy.ColumnMappings.Add(15, 16)
                            copy.ColumnMappings.Add(16, 17)
                            copy.ColumnMappings.Add(17, 18)
                            copy.ColumnMappings.Add(18, 19)
                            copy.ColumnMappings.Add(19, 20)
                            copy.ColumnMappings.Add(20, 21)
                            copy.ColumnMappings.Add(21, 22)
                            copy.ColumnMappings.Add(22, 23)
                            copy.ColumnMappings.Add(23, 24)
                            copy.ColumnMappings.Add(24, 25)
                            copy.ColumnMappings.Add(25, 26)
                            copy.ColumnMappings.Add(26, 27)
                            copy.ColumnMappings.Add(27, 28)
                            copy.ColumnMappings.Add(28, 29)
                            copy.ColumnMappings.Add(29, 30)
                            copy.ColumnMappings.Add(30, 31)
                            copy.ColumnMappings.Add(31, 32)
                            copy.ColumnMappings.Add(32, 33)
                            copy.ColumnMappings.Add(33, 34)
                            copy.ColumnMappings.Add(34, 35)
                            copy.ColumnMappings.Add(35, 36)
                            copy.ColumnMappings.Add(36, 37)
                            copy.ColumnMappings.Add(37, 38)
                            copy.ColumnMappings.Add(38, 39)
                            copy.ColumnMappings.Add(39, 40)
                            copy.ColumnMappings.Add(40, 41)
                            copy.ColumnMappings.Add(41, 42)
                            copy.ColumnMappings.Add(42, 43)
                            copy.ColumnMappings.Add(43, 44)
                            copy.ColumnMappings.Add(44, 0)
                            copy.DestinationTableName = "SgaReporting_RisqueGlobale"
                            copy.WriteToServer(dt)
                        End Using

                    End Using

                End If

                logger.Debug("exportRisqueGlobalToSqlServer - End -")

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de la sauvegarde de l'extraction des risques ")
                logger.Warn(ex.Message)
                If ex.StackTrace IsNot Nothing Then
                    logger.Warn(ex.StackTrace)
                End If
                If ex.InnerException IsNot Nothing Then
                    logger.Warn(ex.InnerException.Message)
                End If
                logger.Warn("exportRisqueGlobalToSqlServer - End with exception -")
                Throw New Exception("Une erreur est survenu lors de la sauvegarde de l'extraction", ex)
            End Try
        End Sub

        Public Sub GenerateDataForDate(ByVal datearrete As Date)

            logger.Debug("GenerateDataForDate - Begin")

            Try
                exportDATToSqlServer(IDSUtils.getInstance.extractDATEnCours(datearrete), datearrete)
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try

            Try
                exportBDCToSqlServer(IDSUtils.getInstance.extractBDCEnCours(datearrete), datearrete)
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try

            Try
                exportEffaitsToSqlServer(IDSUtils.getInstance.extractEffaits(datearrete), datearrete)
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try



            Try
                exportComptesCreditsToSqlServer(IDSUtils.getInstance.extractComptesCredits(datearrete), datearrete)
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try


            Try
                exportPleaseDataToSqlServer(getPleaseData(datearrete), datearrete)
                exportTempBkComToSqlServer(IDSUtils.getInstance.extractComptesRadicalsPlease(), datearrete)
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try

            Try
                exportBkCliToSqlServer(IDSUtils.getInstance.extractBkCli())
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try
            
            Try
                exportAllClientsToSqlServer(IDSUtils.getInstance.extractAllClients())
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try

            'exportArreteToSqlServer(IDSUtils.getInstance.extractArretesBySecteur(datearrete), datearrete)
            'exportSoldeToSqlServer(IDSUtils.getInstance.extractSoldeMensuel(datearrete))
            'exportRisqueGlobalToSqlServer(IDSUtils.getInstance.GetGlobal(datearrete))

            ' Obsolètes
            'exportBkComTempToSqlServer(IDSUtils.getInstance.extractTempBkCom())
            'exportConditionsBanques(IDSUtils.getInstance.extractCoditionsDeBanque(datearrete))

            logger.Debug("GenerateDataForDate - End")
        End Sub


        Public Function GetFaciliteCaisseCha() As String

            logger.Debug("GetFaciliteCaisseCha - Begin - ")
            Dim param As String = String.Empty

            'Dim sqlConnectionString As String = ApplicationSettings.GetInstance.getConnectionStringByName("SgaReportingCS")

            logger.Debug("GetFaciliteCaisseCha - connectionString - " & connectionString)

            Try
                Using con As SqlConnection = New SqlConnection(connectionString)

                    con.Open()

                    Dim query As String = "select Chapitre from dbo.SgaReporting_GlobalSettings " & _
                                            "where EtatComptable = 'M20R' and Annexe03 in ('FACICAISA3','FACCAIDTA3')"
                    Dim command As SqlCommand = con.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text
                    command.CommandText = query

                    Dim dt As DataTable = New DataTable()
                    dt.TableName = "Param"
                    Dim da As SqlDataAdapter = New SqlDataAdapter(command)
                    da.Fill(dt)

                    For Each dr As DataRow In dt.Rows
                        Dim part As String = "'" & dr("Chapitre") & "',"
                        param = param & part
                    Next

                    param = param.Substring(0, param.Length - 1)

                End Using
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try

            Return param
        End Function

        Public Function GetRisqueParams(ByVal nomParam As String) As String

            logger.Debug("GetRisqueParams - Begin - " & nomParam)
            Dim param As String = String.Empty

            'Dim sqlConnectionString As String = ApplicationSettings.GetInstance.getConnectionStringByName("SgaReportingCS")

            logger.Debug("GetRisqueParams - connectionString - " & connectionString)

            Try
                Using con As SqlConnection = New SqlConnection(connectionString)

                    con.Open()

                    Dim query As String = "select chapitre from dbo.SgaReporting_DefilementsRisque where nom = '{0}'"
                    Dim command As SqlCommand = con.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text
                    command.CommandText = String.Format(query, nomParam)

                    Dim dt As DataTable = New DataTable()
                    dt.TableName = "Param"
                    Dim da As SqlDataAdapter = New SqlDataAdapter(command)
                    da.Fill(dt)

                    For Each dr As DataRow In dt.Rows
                        Dim part As String = "'" & dr("chapitre") & "',"
                        param = param & part
                    Next

                    param = param.Substring(0, param.Length - 1)

                End Using
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try

            Return param
        End Function

    End Class
End Namespace

