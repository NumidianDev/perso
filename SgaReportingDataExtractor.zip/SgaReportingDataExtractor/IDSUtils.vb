﻿Imports log4net
Imports Sga.Settings
Imports System.Data.OleDb
Imports Sga.Tools

Namespace data

    Public Class IDSUtils

        Private Shared instance As IDSUtils
        Private Shared connectionString As String

        Private queryCotMaxDate As String = "select cli s_cli, max(ddef) datemax from bkhdefcli " & _
                                            "group by cli " & _
                                            "into temp bkhdefmaxdate"

        Private queryCotTab As String = "select cli, cot||ddef cotation " & _
                                        "from bkhdefcli,bkhdefmaxdate " & _
                                        "where bkhdefcli.cli=bkhdefmaxdate.s_cli and bkhdefcli.ddef=bkhdefmaxdate.datemax " & _
                                        "and eta = 'V' " & _
                                        "into temp cotation_tab"

        Private queryAllClients As String = "select   " & _
                                            "	   a.cli  " & _
                                            "	   ,a.tcli  " & _
                                            "	   ,'021' banque  " & _
                                            "	   ,substr(a.age,3,3) as age  " & _
                                            "	   ,trim(nvl(a.nicr,'')) nicr  " & _
                                            "	   ,trim(nvl(a.sig,'')) sig  " & _
                                            "	   ,trim(nvl(a.nidf,'')) nidf  " & _
                                            "	   ,trim(nvl(a.rso,'')) rso  " & _
                                            "	   ,trim(nvl(a.nomrest,'')) nomrest  " & _
                                            "	   ,trim(nvl(a.nom,'')) nom  " & _
                                            "	   ,trim(nvl(a.pre,'')) pre  " & _
                                            "	   ,trim(nvl(a.njf,'')) njf  " & _
                                            "	   ,trim(nvl(a.fju,'')) fju  " & _
                                            "	   ,trim(nvl(c.lib1,'')) libelleFju  " & _
                                            "	   ,trim(nvl(a.nrc,'')) nrc  " & _
                                            "	   ,substr(trim(sec) || '000',2,2) as sec  " & _
                                            "	   ,CASE WHEN a.dna < DATE('1755-01-01') THEN CAST(NULL as DATE)  " & _
                                            "	   		 ELSE a.dna END dna  " & _
                                            "	   ,CASE WHEN a.datc < DATE('1755-01-01') THEN CAST(NULL as DATE)  " & _
                                            "	   		 ELSE a.datc END datc  " & _
                                            "	   ,trim(nvl(a.viln,'')) viln  " & _
                                            "	   ,trim(nvl(a.nchc,'')) nchc  " & _
                                            "	   ,(Select trim(nvl(cpos,'')) From bkadcli where cli=a.cli and typ='D') as cpos " & _
                                            "	   ,(Select trim(nvl(cpos,'')) From bkadcli where cli=a.cli and typ='C') as cposCourrier " & _
                                            "	   ,trim(nvl(d.lib1,'')) wilaya_Creation  " & _
                                            "	   ,f.cotation cotddef  " & _
                                            "	   ,getadr(a.cli) adresse " & _
                                            "	   ,(Select trim(nvl(adr1,'')) From bkadcli where cli=a.cli and typ='D') as adr1 " & _
                                            "	   ,(Select trim(nvl(adr1,'')) From bkadcli where cli=a.cli and typ='C') as adrCourrier " & _
                                            "	   ,(Select trim(nvl(ville,'')) From bkadcli where cli=a.cli and typ='D') as ville   " & _
                                            "	   ,CASE WHEN b.dmep < DATE('1755-01-01') THEN CAST(NULL as DATE)  " & _
                                            "	   		 ELSE b.dmep END dmep  " & _
                                            "      ,a.grp " & _
                                            "      ,e.nom as nomgrp " & _
                                            "From bkcli a  " & _
                                            "left join (  " & _
                                            "	 SELECT cli,max(dmep) dmep   " & _
                                            "            FROM bkdosprt   " & _
                                            "           WHERE eta in ('VA','VD')   " & _
                                            "		   and ctr = '1'  " & _
                                            "		   group by cli  " & _
                                            ") b on (a.cli = b.cli)  " & _
                                            "left join (  " & _
                                            "	 	  select   " & _
                                            "	 		cacc,lib1   " & _
                                            "	 	  from bknom  " & _
                                            "		  where bknom.ctab = '049' and age='99999'  " & _
                                            ") c on (c.cacc = a.fju)  " & _
                                            "left join (  " & _
                                            "	 	  select   " & _
                                            "	 		cacc,lib1   " & _
                                            "	 	  from bknom  " & _
                                            "		  where bknom.ctab = '077' and age='99999'  " & _
                                            ") d on (d.cacc = a.nchc)  " & _
                                            " left join bkgrp e on a.grp = e.grp " & _
                                            " LEFT JOIN cotation_tab f ON a.cli = f.cli "

        

        Private queryTauxDateDescriptive As String = "select dco,dev,tind from bktau " & _
                                        "where dco in (Select max(dag) from bkhis) " & _
                                        "order by dco " & _
                                        "into temp bktauDay"

        Private _tempBkcomQuery As String = "select cli,sum(y.sde*x.tind) as somme   " & _
                                            "from bkcom y  " & _
                                            "join bktauDay x on (y.dev = x.dev) " & _
                                            "where (y.ncp[1,3] in ('113', '017', '018', '116', '117', '121', '124') and y.sde < 0)  " & _
                                            "Or (y.ncp[1,3] in ('014', '016', '600','602', '604', '605', '203', '204', '206', '208', '213','274', '214', '300', '301', '314', '321', '324', '325','326', '327', '385', '305', '308', '311', '312', '313') and y.cli <> '' and y.cli is not null and y.sde <> 0)  " & _
                                            "group by 1 "


        Private queryBkCli As String = "select  " & _
                                        "cli " & _
                                        ",substr(age,3,3) as age " & _
                                        ",'021' banque " & _
                                        ",nicr " & _
                                        ",substr(trim(sec) || '000',2,2) as sec " & _
                                        ",nidf as nif " & _
                                        "from bkcli "


        Private dirtyQuery As String = "set isolation to dirty read "

        Private queryTauxDate As String = "select * from bktau " _
                                      & "where dco = DATETIME({0}) YEAR TO DAY " _
                                      & "into temp bktauDA "

        Private queryTauxDarrete As String = "select    " & _
                                                "	   A.ban   " & _
                                                "	   ,trim(nvl(A.pro,'')) as pro   " & _
                                                "	   ,trim(nvl(A.cha,'')) as cha   " & _
                                                "	   ,trim(nvl(A.cli,'')) as cli   " & _
                                                "	   ,trim(nvl(A.typ,'')) as typ    " & _
                                                "	   ,trim(nvl(A.ncp,'')) as ncp     " & _
                                                "	   ,trim(nvl(A.clc,'')) as clc    " & _
                                                "	   ,trim(nvl(A.age,'')) as age    " & _
                                                "	   ,trim(nvl(A.dev,'')) as dev    " & _
                                                "	   ,A.txb    " & _
                                                "	   ,A.ttxb    " & _
                                                "	   ,B.tau    " & _
                                                "	   ,trim(nvl(C.lib2,'')) as lib2   " & _
                                                "	   ,C.tau1  " & _
                                                "	   ,(CASE WHEN trim(nvl(C.lib2,'')) = '+' THEN tau + tau1   " & _
                                                "								WHEN trim(nvl(C.lib2,'')) = '-' THEN tau - tau1  " & _
                                                "								WHEN trim(nvl(C.lib2,'')) = '' and tau <> 0 THEN tau    " & _
                                                "								ELSE 0 END) as taux_final     " & _
                                                "from bkaco A   " & _
                                                "left join bktxb B    " & _
                                                "	 on (Cast(B.cod AS int) = Cast(A.txb AS int)    " & _
                                                "	 				and B.dat = (select max(dat) from bktxb where cod = B.cod))   " & _
                                                "left join bkacod D   " & _
                                                "	 on (A.lien = D.lien and A.age = D.age and  D.datr = (select max(datr) from bkacod where lien = A.lien))   " & _
                                                "left join bknom C    " & _
                                                "	 on (C.ctab = '021' and Cast(C.cacc AS int) = Cast(D.cnr1 AS int)) " & _
                                                "into temp tabTaux "
        

        Private queryTempSldM20RByDateArrete As String = "select " & _
                                                            "a.age  " & _
                                                            ",a.dev  " & _
                                                            ",a.ncp  " & _
                                                            ",a.dco  " & _
                                                            ",a.mon  " & _
                                                            ",a.mvtd  " & _
                                                            ",a.mvtc  " & _
                                                            ",a.cha  " & _
                                                            ",a.cli  " & _
                                                            ",a.sde  " & _
                                                            ",b.tind  " & _
                                                            ",c.tcli  " & _
                                                            ",getpro(c.cli) as pro  " & _
                                                            ",trim(c.sec) sec  " & _
                                                            "from bksld a  " & _
                                                            "inner join bktauDA b on (a.dev = b.dev and a.dco = b.dco)  " & _
                                                            "left join bkcli c on a.cli = c.cli  " & _
                                                            "where a.dco = DATETIME({0}) YEAR TO DAY " & _
                                                            "and a.sde <> 0  " & _
                                                            "into temp sld0 "

        Private queryTempSldFaciliteDeCaisse As String = "select * from sld0 " & _
                                                            " where cha in ({0}) " & _
                                                            "into temp facilitecaisse "

        Private queryTempTauxComptes As String = "select A.*,B.taux_final as TauxCompte from facilitecaisse A,tabTaux B " & _
                                                    "where A.age||A.dev||A.ncp = B.age||B.dev||B.ncp " & _
                                                    "into temp TauxCompteT "

        Private queryTempTauxTyp As String = "select A.*,B.taux_final as TauxTyp from facilitecaisse A,tabTaux B " & _
                                                    "where B.typ = A.tcli  " & _
                                                    "	  and B.dev = A.dev  " & _
                                                    "	  and trim(nvl(B.typ,'')) <> '' " & _
                                                    "into temp TauxTypT "

        Private queryTempTauxCli As String = "select A.*,B.taux_final as TauxCli from facilitecaisse A,tabTaux B " & _
                                                    "where A.cli||A.age||A.dev = B.cli||B.age||B.dev  " & _
                                                    "	  and trim(nvl(B.cli,'')) <> '' " & _
                                                    "into temp TauxCliT "

        Private queryTempTauxCha As String = "select A.*,B.taux_final as TauxCha from facilitecaisse A,tabTaux B " & _
                                                "where A.cha||A.dev = B.cha||B.dev  " & _
                                                "	  and B.age = '99999'  " & _
                                                "	  and trim(nvl(B.cha,'')) <> '' " & _
                                                "into temp TauxChaT " & _
                                                ""
        Private queryTempTauxPro As String = "select A.*,B.taux_final as TauxPro from facilitecaisse A,tabTaux B " & _
                                                    "where A.pro||A.dev = B.pro||B.dev  " & _
                                                    "	  and B.age = '99999'  " & _
                                                    "	  and trim(nvl(B.pro,'')) <> ''  " & _
                                                    "	  and trim(nvl(A.pro,'')) <> ''  " & _
                                                    "	  and trim(nvl(B.lib2,'')) <> '' " & _
                                                    "into temp TauxProT "

        Private queryTempTauxAgence As String = "select A.*,B.taux_final as TauxAgence from facilitecaisse A,tabTaux B " & _
                                                    "where B.ban = 'O'  " & _
                                                    "	  and B.age = A.age  " & _
                                                    "	  and trim(nvl(B.age,'')) <> '' " & _
                                                    "into temp TauxAgenceT"
        Private queryTempTauxBanque As String = "select A.*,B.taux_final as TauxBanque from facilitecaisse A,tabTaux B " & _
                                                "where B.ban = 'O'  " & _
                                                "	  and B.age = '99999' " & _
                                                "into temp TauxBanqueT "

        Private queryTempJoinAll As String = "select  " & _
                                                "	   A.* " & _
                                                "	   ,B.TauxCompte as TauxCompte " & _
                                                "   	   ,C.TauxTyp as TauxTyp " & _
                                                "   	   ,D.TauxCli as TauxCli " & _
                                                "	   ,E.TauxCha as TauxCha " & _
                                                "   	   ,F.TauxPro as TauxPro " & _
                                                "	   ,G.TauxAgence as TauxAgence " & _
                                                "   	   ,H.TauxBanque as TauxBanque " & _
                                                "From facilitecaisse A " & _
                                                "LEFT JOIN TauxCompteT B on (A.age = B.age and A.dev = B.dev and A.ncp = B.ncp) " & _
                                                "LEFT JOIN TauxTypT C on (A.age = C.age and A.dev = C.dev and A.ncp = C.ncp) " & _
                                                "LEFT JOIN TauxCliT D on (A.age = D.age and A.dev = D.dev and A.ncp = D.ncp) " & _
                                                "LEFT JOIN TauxChaT E on (A.age = E.age and A.dev = E.dev and A.ncp = E.ncp) " & _
                                                "LEFT JOIN TauxProT F on (A.age = F.age and A.dev = F.dev and A.ncp = F.ncp) " & _
                                                "LEFT JOIN TauxAgenceT G on (A.age = G.age and A.dev = G.dev and A.ncp = G.ncp) " & _
                                                "LEFT JOIN TauxBanqueT H on (A.age = H.age and A.dev = H.dev and A.ncp = H.ncp)  " & _
                                                "into temp sld_taux"

        Private queryTempSoldeFinal As String = "select  " & _
                                                "       A.* " & _
                                                "       ,B.TauxCompte as TauxCompte " & _
                                                "       ,B.TauxTyp as TauxTyp " & _
                                                "       ,B.TauxCli as TauxCli " & _
                                                "       ,B.TauxCha as TauxCha " & _
                                                "       ,B.TauxPro as TauxPro " & _
                                                "       ,B.TauxAgence as TauxAgence " & _
                                                "       ,B.TauxBanque as TauxBanque " & _
                                                "       ,(CASE WHEN trim(nvl(B.TauxCompte,'')) <> '' THEN B.TauxCompte " & _
                                                "			   		  WHEN trim(nvl(B.TauxTyp,'')) <> '' THEN B.TauxTyp 								 " & _
                                                "					  WHEN trim(nvl(B.TauxCli,'')) <> '' THEN B.TauxCli " & _
                                                "					  WHEN trim(nvl(B.TauxCha,'')) <> '' THEN B.TauxCha " & _
                                                "					  WHEN trim(nvl(B.TauxPro,'')) <> '' THEN B.TauxPro " & _
                                                "					  ELSE B.TauxBanque END) as taux_final " & _
                                                "From sld0 A " & _
                                                "Left join sld_taux B on (A.age = B.age and A.dev = B.dev and A.ncp = B.ncp)"




       

        Private queryDosCred As String = "select age,eve,ave,tau_int,(ddec-DATE('{0}'))/365 as mat  from bkdosprt " _
                                     & "into temp doscred "

        Private queryCptCred As String = "select A.age,A.ncp,A.dev,A.eve,B.cha " _
                                         & "from bkcptprt A, bkcom B " _
                                         & "where exists (select * from doscred where A.age = doscred.age and A.eve = doscred.eve and A.ave = doscred.ave) " _
                                         & "and A.age=B.age and A.ncp=B.ncp and A.dev=B.dev " _
                                         & "into temp cptcred "

        Private queryResultatCred As String = "select A.age,A.dev,A.ncp,A.cha,B.mat,B.tau_int " _
                                              & "from cptcred A,doscred B " _
                                              & "where A.eve=B.eve and A.age=B.age "

        Private queryEffaitPourAnnexe03 As String = "select age,etab,guib,neff,dpre,cli,ope,ncpc,devc,dval,dind,ncpe,dev,mnat,mdev,aged,clid,ncpd,clcd,nom,sor,tint,dou,dech,dechp from bkefr " _
                                                    & "where ncpe[1,3] in ('014') " _
                                                    & "and bkefr.dou < DATE('{0}')  " _
                                                    & "and bkefr.dech > DATE('{0}') "

        Private queryEffaitHistoriquePourAnnexe03 As String = "select age,etab,guib,neff,dpre,cli,ope,ncpc,devc,dval,dind,ncpe,dev,mnat,mdev,aged,clid,ncpd,clcd,nom,sor,tint,dou,dech,dechp from bkhisefr " _
                                                              & "where ncpe[1,3] in ('014') " _
                                                              & "and dou < DATE('{0}')   " _
                                                              & "and dech > DATE('{0}')   "

        'ncpd,ddc,ddp,dmo,ncpprov,taun
        Private queryDAT As String = "select age,eve,ncp,ncpd,ncpprov,dco,ddc,ddp,dva,dmo,mon,tau,taun,terme,ctr,eta,dou,cli,dech,ope,dev,mont,dechs,typ,txb from bkdat "
        ' & "where ctr in ('2','8') "

        Private queryBDC As String = "select age,nsou,eve,dev,typ,ncpd,sufd,ncpc,sufc,dco,dva,mon,mnat,tau,nom,dvi,ctr,eta,dou,dmo,cli,dech,dechs,ope,ncp,suf,remb,ncpr,agec,opp from bkbdc " _
                                     & "where ctr in ('2','8') " _
                                     & "and typ in ('101','121','111','131') "

        Private queryChapitre220000 As String = "select age,dev,ncp from bksld " & _
                                                "where dco = DATETIME({0}) YEAR TO DAY " & _
                                                "and cha = '220000' " & _
                                                "and sde <> 0 " & _
                                                "into temp t220000 "

        Private queryArreteCompte As String = "select a.pie,a.pieo,a.age,a.dev,a.ncp,a.dco,a.ope,a.mvt,a.dva,a.mon,a.sen,a.lib,a.dag,a.ncc,a.dech,a.agsa,a.devc,a.mctv from bkhis a " & _
                                            "inner join t220000 b on (a.age = b.age and a.dev = b.dev and a.ncp = b.ncp) " & _
                                            "and a.dco between DATETIME({0}) YEAR TO DAY  and DATETIME({1}) YEAR TO DAY  " & _
                                            "into temp tarretecompte "

        Private queryArreteSecteur As String = "select a.*,b.sec from tarretecompte a " & _
                                                "left join bkcom c on (a.agsa = c.age and a.devc = c.dev and a.ncc = c.ncp) " & _
                                                "left join bkcli b on (c.cli = b.cli) "

        Private queryFiltreBkComPlease As String = "select trim(age) as age,trim(ncp) as ncp,trim(clc) as clc,trim(cli) as cli from bkcom " & _
                                                    "where ncp[1,3] in ({0}) " & _
                                                    "and dev = '208' " & _
                                                    "and trim(nvl(cli,'')) <> ''"


        ' Requêtes Global Cotation_Encours

        Private Shared ReadOnly logger As ILog = log4net.LogManager.GetLogger(GetType(IDSUtils))

        Private Sub New()
#If DEBUG Then
            connectionString = ApplicationSettings.GetInstance.getConnectionStringByName("Delta")
        If logger.IsDebugEnabled Then
            logger.Debug("Connection string setted on debug mode")
            logger.Debug(connectionString)
        End If
#Else
            connectionString = ApplicationSettings.GetInstance.getConnectionStringByName("Delta")
            If logger.IsDebugEnabled Then
                logger.Debug("Connection string setted on production mode")
                logger.Debug(connectionString)
            End If
#End If
        End Sub

        Public Shared Function getInstance() As IDSUtils
            If instance Is Nothing Then
                instance = New IDSUtils()
            End If
            Return instance
        End Function

        Public Sub historiqueEvent()

            Try

                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 100000
                    command.CommandType = CommandType.Text

                    command.CommandText = queryAllClients

                End Using

            Catch ex As Exception
                logger.Warn("Excepion")
                logger.Warn(ex.Message)
            End Try

        End Sub

        Private Sub createTempTaux(deltaConnexion As OleDbConnection, ByVal datearrete As Date)

            If IsNothing(datearrete) Then
                Throw New Exception("Impossible de créer la base temporaire please avec une date d'arrêtée null ")
            End If

            If deltaConnexion Is Nothing OrElse Not deltaConnexion.State = ConnectionState.Open Then
                Throw New Exception("La connection à la base de donnée ne doit pas être null et doit être ouverte ")
            End If

            Try
                Dim command As OleDbCommand = deltaConnexion.CreateCommand()
                command.CommandTimeout = 100000
                command.CommandType = CommandType.Text

                command.CommandText = String.Format(queryTauxDate, datearrete.ToString("yyyy-MM-dd"))

                command.ExecuteNonQuery()

            Catch ex As Exception
                logger.Warn(ex.Message)
                Throw New Exception("Une erreur est survenu lors de la creation de la base temporaire des taux devises")
            End Try

        End Sub

        Public Function extractAllClients() As DataTable

            logger.Debug("extractAllClients - BEGIN - ")

            Dim result As DataTable = Nothing

            Try

                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 100000
                    command.CommandType = CommandType.Text

                    command.CommandText = queryCotMaxDate
                    logger.Debug("0 : " & command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryCotTab
                    logger.Debug("0.1 : " & command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryAllClients
                    logger.Debug("1 : " & command.CommandText)

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    Return result

                End Using

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction de la table des clients ")
                logger.Warn(ex.Message)
                logger.Warn(ex.StackTrace)

            End Try

        End Function

        Public Function extractTempBkCom() As DataTable

            logger.Debug("extractTempBkCom - BEGIN - ")

            Dim result As DataTable = Nothing

            Try

                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 100000
                    command.CommandType = CommandType.Text

                    command.CommandText = queryTauxDateDescriptive
                    command.ExecuteNonQuery()

                    command.CommandText = _tempBkcomQuery

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    Return result

                End Using

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction de la table des comptes ")
                logger.Warn(ex.Message)
                logger.Warn(ex.StackTrace)

            End Try

        End Function

        Public Function extractComptesRadicalsPlease() As DataTable

            logger.Debug("extractComptesRadicalsPlease - BEGIN - ")

            Dim result As DataTable = Nothing

            Dim typeComptes As String = MSSQLUtils.getInstance.getTypesComptesFromPlease()

            Try

                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 100000
                    command.CommandType = CommandType.Text

                    command.CommandText = String.Format(queryFiltreBkComPlease, typeComptes)

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    Return result

                End Using

            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction des comptes ")
                logger.Warn(ex.Message)
            End Try
        End Function

        Public Function extractCoditionsDeBanque(ByVal datearrete As Date) As DataTable

            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 100000
                    command.CommandType = CommandType.Text

                    command.CommandText = queryTauxDarrete

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                              .DataType = GetType(DateTime),
                                                              .DefaultValue = datearrete}

                    result.Columns.Add(dc)

                    result.AcceptChanges()

                    Return result
                End Using
            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction des conditions d'arrêtés : " & datearrete.ToString("dd/MM/yyyy"))
                logger.Warn(ex.Message)
            End Try
        End Function


        Public Function extractBkCli() As DataTable

            logger.Debug("extractBkCli - Begin")
            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 100000
                    command.CommandType = CommandType.Text

                    command.CommandText = queryBkCli
                    logger.Debug(command.CommandText)

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("extractBkCli - End")

                    Return result

                End Using
            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction de la table des clients ")
                logger.Warn(ex.Message)
            End Try

        End Function

        Public Function extractSoldeMensuel(ByVal datearrete As Date) As DataTable

            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    createTempTaux(con, datearrete)

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 100000
                    command.CommandType = CommandType.Text

                    command.CommandText = queryTauxDarrete
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = String.Format(queryTempSldM20RByDateArrete, datearrete.ToString("yyyy-MM-dd"))
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = String.Format(queryTempSldFaciliteDeCaisse, MSSQLUtils.getInstance.GetFaciliteCaisseCha())
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempTauxComptes
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempTauxTyp
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempTauxCli
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempTauxCha
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempTauxPro
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempTauxAgence
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempTauxBanque
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempJoinAll
                    logger.Debug(command.CommandText)
                    command.ExecuteNonQuery()

                    command.CommandText = queryTempSoldeFinal
                    logger.Debug(command.CommandText)
                    logger.Debug(command.CommandText)
                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    Return result
                End Using
            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction des soldes : " & datearrete.ToString("dd/MM/yyyy"))
                logger.Warn(ex.Message)
            End Try

        End Function

        Public Function extractComptesCredits(ByVal datearrete As Date) As DataTable

            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text

                    command.CommandText = "set isolation to dirty read"
                    command.ExecuteNonQuery()

#If DEBUG Then
                    command.CommandText = String.Format(queryDosCred, datearrete.ToString("dd/MM/yyyy"))
#Else
                    '' en local
                    'command.CommandText = String.Format(queryDosCred, datearrete.ToString("dd/MM/yyyy"))

                    '' pour le serveur 
                    command.CommandText = String.Format(queryDosCred, datearrete.ToString("yyyy-MM-dd"))
#End If

                    Dim nbDossier As Integer = command.ExecuteNonQuery()
                    logger.Debug("Nombre de dossiers credits : " & nbDossier)

                    command.CommandText = queryCptCred
                    Dim nbCptDossiers As Integer = command.ExecuteNonQuery()

                    logger.Debug("Nombre de comptes des dossiers credits : " & nbCptDossiers)

                    command.CommandText = "set isolation to dirty read"
                    command.ExecuteNonQuery()

                    command.CommandText = queryResultatCred

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("Nombre de comptes des dossiers credits : " & result.Rows.Count)

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                              .DataType = GetType(DateTime),
                                                              .DefaultValue = datearrete}

                    result.Columns.Add(dc)

                    result.AcceptChanges()

                    Return result
                End Using
            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction des dossiers credits : " & datearrete.ToString("dd/MM/yyyy"))
                logger.Warn(ex.Message)
            End Try
        End Function

        Public Function extractEffaits(ByVal datearrete As Date) As DataTable

            logger.Debug("extractEffaits - BEGIN - ")

            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text

                    command.CommandText = "set isolation to dirty read"
                    command.ExecuteNonQuery()

#If DEBUG Then
                    command.CommandText = String.Format(queryEffaitPourAnnexe03, datearrete.ToString("dd/MM/yyyy"))
#Else
                    '' en local
                    'command.CommandText = String.Format(queryEffaitPourAnnexe03, datearrete.ToString("dd/MM/yyyy"))

                    '' sur serveur 
                    command.CommandText = String.Format(queryEffaitPourAnnexe03, datearrete.ToString("yyyy-MM-dd"))
#End If


                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("Nombre effaits : " & result.Rows.Count)

                    ' Effait historiques

#If DEBUG Then
                    command.CommandText = String.Format(queryEffaitHistoriquePourAnnexe03, datearrete.ToString("dd/MM/yyyy"))
#Else
                    '' en local
                    'command.CommandText = String.Format(queryEffaitHistoriquePourAnnexe03, datearrete.ToString("dd/MM/yyyy"))


                    '' sur serveur 
                    command.CommandText = String.Format(queryEffaitHistoriquePourAnnexe03, datearrete.ToString("yyyy-MM-dd"))
#End If

                    Dim resultHis = New DataTable()
                    Dim daHis As OleDbDataAdapter = New OleDbDataAdapter(command)
                    daHis.Fill(resultHis)

                    If resultHis.Rows.Count > 0 Then
                        For Each dr As DataRow In resultHis.Rows
                            result.ImportRow(dr)
                            result.AcceptChanges()
                        Next
                    End If

                    logger.Debug("Nombre d'effaits dans l'historique : " & resultHis.Rows.Count)

                    logger.Debug("Nombre d'effaits total : " & result.Rows.Count)

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                              .DataType = GetType(DateTime),
                                                              .DefaultValue = datearrete}

                    result.Columns.Add(dc)

                    result.AcceptChanges()

                    logger.Debug("extractEffaits - END - " & datearrete.ToString("dd-MM-yyyy"))

                    Return result
                End Using
            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction des dossiers credits : " & datearrete.ToString("dd/MM/yyyy"))
                logger.Warn(ex.Message)
            End Try
        End Function

        Public Function extractDATEnCours(ByVal dateArrete As Date) As DataTable

            logger.Debug("extractDATEnCours - Begin - " & dateArrete.ToString("dd-MM-yyyy"))

            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)
                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text

                    command.CommandText = "set isolation to dirty read"
                    command.ExecuteNonQuery()

                    command.CommandText = queryDAT

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("Nombre de DAT en cours : " & result.Rows.Count)

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                              .DataType = GetType(DateTime),
                                                              .DefaultValue = dateArrete}

                    result.Columns.Add(dc)

                    result.AcceptChanges()

                    logger.Debug("extractDATEnCours - END - " & dateArrete.ToString("dd-MM-yyyy"))

                    Return result

                End Using
            Catch ex As Exception

                logger.Warn("Une erreur est survenu lors de l'extraction des DAT")

                logger.Warn(ex.Message)

                logger.Debug("extractDATEnCours - END WITH Exception - " & dateArrete.ToString("dd-MM-yyyy"))
            End Try
        End Function

        Public Function extractBDCEnCours(ByVal dateArrete As Date) As DataTable

            logger.Debug("extractBDCEnCours - Begin - " & dateArrete.ToString("dd-MM-yyyy"))

            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)
                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text

                    command.CommandText = "set isolation to dirty read"
                    command.ExecuteNonQuery()

                    command.CommandText = queryBDC

                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("Nombre de bons de caisse en cours : " & result.Rows.Count)

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                              .DataType = GetType(DateTime),
                                                              .DefaultValue = dateArrete}

                    result.Columns.Add(dc)


                    result.AcceptChanges()

                    logger.Debug("extractBDCEnCours - END - " & dateArrete.ToString("dd-MM-yyyy"))

                    Return result

                End Using
            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction des Bon de caisse")
                logger.Warn(ex.Message)
                logger.Debug("extractBDCEnCours - END WITH Exception - " & dateArrete.ToString("dd-MM-yyyy"))
            End Try
        End Function

        Public Function extractArretesBySecteur(ByVal dateArrete As Date) As DataTable

            logger.Debug("extractArretesBySecteur - Begin - " & dateArrete.ToString("dd-MM-yyyy"))

            Dim result As DataTable = Nothing
            Try
                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()

                    Dim command As OleDbCommand = con.CreateCommand()
                    command.CommandTimeout = 10000
                    command.CommandType = CommandType.Text

                    command.CommandText = "set isolation to dirty read"
                    command.ExecuteNonQuery()

                    'command.CommandText = String.Format(queryTempSldM20RByDateArrete, dateArrete.ToString("dd/MM/yyyy"))
                    command.CommandText = String.Format(queryChapitre220000, dateArrete.ToString("yyyy-MM-dd"))
                    command.ExecuteNonQuery()

                    Dim firstDayNextMonth As Date = dateArrete.AddDays(1)



                    'Dim firstDayNextMonth As Date = DateUtils.GetFirstDayOfMonth(dateArrete.Month + 1, dateArrete.Year)

                    'If dateArrete.Month = 12 Then
                    '    firstDayNextMonth = DateUtils.GetFirstDayOfMonth(dateArrete.Month + 1, dateArrete.Year + 1)
                    'End If

                    Dim tenDayNextMonth As Date = firstDayNextMonth.AddDays(12)



                    logger.Debug(dateArrete.ToString())
                    logger.Debug(firstDayNextMonth.ToString())
                    logger.Debug(tenDayNextMonth.ToString())

                    'command.CommandText = String.Format(queryTempSldM20RByDateArrete, dateArrete.ToString("dd/MM/yyyy"))
                    command.CommandText = String.Format(queryArreteCompte, firstDayNextMonth.ToString("yyyy-MM-dd"), tenDayNextMonth.ToString("yyyy-MM-dd"))
                    command.ExecuteNonQuery()

                    command.CommandText = queryArreteSecteur
                    result = New DataTable()
                    Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                    da.Fill(result)

                    logger.Debug("Nombre d'arrete de fin du mois : " & result.Rows.Count)

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                              .DataType = GetType(DateTime),
                                                              .DefaultValue = dateArrete}

                    result.Columns.Add(dc)


                    result.AcceptChanges()

                    logger.Debug("extractArretesBySecteur - END - " & dateArrete.ToString("dd-MM-yyyy"))

                    Return result

                End Using
                Return result
            Catch ex As Exception
                logger.Warn("Une erreur est survenu lors de l'extraction des Arrete de comptes")
                logger.Warn(ex.Message)
                logger.Debug("extractArretesBySecteur - END WITH Exception - " & dateArrete.ToString("dd-MM-yyyy"))
            End Try
        End Function

        Public Sub SupprimerTable(ByVal MaTable As String, ByRef Connexion As OleDb.OleDbConnection)
            Try
                Dim SuppCommand As OleDb.OleDbCommand = New OleDb.OleDbCommand("Drop table " & MaTable, Connexion)
                SuppCommand.ExecuteNonQuery()
            Catch ex As Exception

            End Try
        End Sub

        Public Function GetGlobal(ByVal dateArrete As Date) As DataTable

            logger.Debug("GetGlobal - Begin ")
            Dim dtResultat = New DataTable
            dtResultat.TableName = "Cotations"

            Dim SqlCommand As OleDb.OleDbCommand
            Dim MyReader As OleDb.OleDbDataReader
            Dim SqlStr As String

            Dim ESCOMPTE As String = MSSQLUtils.getInstance.GetRisqueParams("ESCOMPTE")
            Dim COD As String = MSSQLUtils.getInstance.GetRisqueParams("COD")
            Dim CREDIT_SPOT As String = MSSQLUtils.getInstance.GetRisqueParams("CREDIT_SPOT")
            Dim IMP_SPOT As String = MSSQLUtils.getInstance.GetRisqueParams("IMP_SPOT")
            Dim ASF As String = MSSQLUtils.getInstance.GetRisqueParams("ASF")
            Dim ASM As String = MSSQLUtils.getInstance.GetRisqueParams("ASM")
            Dim CMT As String = MSSQLUtils.getInstance.GetRisqueParams("CMT")
            Dim IMP_CMT As String = MSSQLUtils.getInstance.GetRisqueParams("IMP_CMT")
            Dim ENG_FIN_CMT_CLICOM As String = MSSQLUtils.getInstance.GetRisqueParams("ENG_FIN_CMT_CLICOM")
            Dim CREDIT_CONSO As String = MSSQLUtils.getInstance.GetRisqueParams("CREDIT_CONSO")
            Dim IMP_CREDIT_CONSO As String = MSSQLUtils.getInstance.GetRisqueParams("IMP_CREDIT_CONSO")
            Dim CMT_DCC As String = MSSQLUtils.getInstance.GetRisqueParams("CMT_DCC")
            Dim IMP_CMT_DCC As String = MSSQLUtils.getInstance.GetRisqueParams("IMP_CMT_DCC")
            Dim PPI As String = MSSQLUtils.getInstance.GetRisqueParams("PPI")
            Dim IMP_PPI As String = MSSQLUtils.getInstance.GetRisqueParams("IMP_PPI")
            Dim CAUTIONS_MARCHES As String = MSSQLUtils.getInstance.GetRisqueParams("CAUTIONS_MARCHES")
            Dim CRA As String = MSSQLUtils.getInstance.GetRisqueParams("CRA")
            Dim OCD As String = MSSQLUtils.getInstance.GetRisqueParams("OCD")
            Dim AVAL As String = MSSQLUtils.getInstance.GetRisqueParams("AVAL")
            Dim CDI_SBLC As String = MSSQLUtils.getInstance.GetRisqueParams("CDI_SBLC")
            Dim ENCOURS_LEASING As String = MSSQLUtils.getInstance.GetRisqueParams("ENCOURS_LEASING")
            Dim IMPAYES_LEASING As String = MSSQLUtils.getInstance.GetRisqueParams("IMPAYES_LEASING")
            Dim CREANCES_CLASSEES_B As String = MSSQLUtils.getInstance.GetRisqueParams("CREANCES_CLASSEES_B")
            Dim CREANCES_CLASSEES_HB As String = MSSQLUtils.getInstance.GetRisqueParams("CREANCES_CLASSEES_HB")
            Dim PROV_CAUTIONS As String = MSSQLUtils.getInstance.GetRisqueParams("PROV_CAUTIONS")
            Dim PROV_CDI As String = MSSQLUtils.getInstance.GetRisqueParams("PROV_CDI")
            Dim GARANTIE_BANCAIRE_RECUE As String = MSSQLUtils.getInstance.GetRisqueParams("GARANTIE_BANCAIRE_RECUE")
            Dim TITRE_RECU_NANTISSEMENT As String = MSSQLUtils.getInstance.GetRisqueParams("TITRE_RECU_NANTISSEMENT")
            Dim PROV_CTX_BILAN As String = MSSQLUtils.getInstance.GetRisqueParams("PROV_CTX_BILAN")
            Dim PROV_CTX_HORS_BILAN As String = MSSQLUtils.getInstance.GetRisqueParams("PROV_CTX_HORS_BILAN")
            Dim DEPOTS As String = MSSQLUtils.getInstance.GetRisqueParams("DEPOTS")

            Try

                logger.Debug("GetGlobal - connectionString  " & connectionString)
                Using con As OleDbConnection = New OleDbConnection(connectionString)

                    con.Open()
                    logger.Debug("Delta connection opened")
                    SqlCommand = New OleDb.OleDbCommand("set isolation to dirty read", con)
                    SqlCommand.ExecuteNonQuery()

                    SupprimerTable("tsld", con)
                    SupprimerTable("tsld0", con)
                    SupprimerTable("tsld1", con)
                    SupprimerTable("tcli", con)
                    SupprimerTable("Tresultat1", con)
                    SupprimerTable("Tresultat2", con)
                    SupprimerTable("tab_autc", con)
                    SupprimerTable("tab_gar_mon", con)
                    SupprimerTable("tab_gar_nat", con)
                    SupprimerTable("tab_gar_nat1", con)
                    SupprimerTable("tab_gar", con)

                    Dim query As String = "select age, cli, cha, sde, dev " & _
                    "from bksld where dco = DATETIME({0}) YEAR TO DAY " & _
                    "into temp tsld0 "

                    '"select age, cli, cha, sde, dev " & _
                    '"from bksld where dco = '" & dateArrete.ToString("yyyy-MM-dd") & "' " & _
                    '"into temp tsld0 ""

                    SqlStr = String.Format(query, dateArrete.ToString("yyyy-MM-dd"))
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    query = _
                    "select tsld0.age, tsld0.cli, tsld0.cha, (tsld0.sde * bktau.tind) as sde  " & _
                    "from tsld0, bktau  " & _
                    "where tsld0.sde <> 0  " & _
                    "and tsld0.dev = bktau.dev and bktau.dco = DATETIME({0}) YEAR TO DAY   " & _
                    "into temp tsld1"
                    logger.Debug("tsld query done")
                    SqlStr = String.Format(query, dateArrete.ToString("yyyy-MM-dd"))
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SupprimerTable("tsld0", con)



                    SqlStr = _
                    "select a.age, a.cli, a.nom, a.pre, a.qua, b.vala, a.nicr, a.grp, c.nom as nomgrp, a.nidf, a.sec  " & _
                    "from bkcli a left join bkicli b on a.cli = b.cli and b.iden = 'SEG' " & _
                    "left join bkgrp c on a.grp = c.grp " & _
                    "into temp tcli"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()
                    logger.Debug("tcli query done")
                    SqlStr = _
                    "select cli, sum(sde) as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & ESCOMPTE & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, sum(sde) as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & COD & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, sum(sde) as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CREDIT_SPOT & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, sum(sde) as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & IMP_SPOT & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, sum(sde) as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & ASF & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, sum(sde) as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & ASM & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "sum(sde) as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CMT & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, sum(sde) as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & IMP_CMT & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, sum(sde) as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & ENG_FIN_CMT_CLICOM & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, sum(sde) as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CREDIT_CONSO & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, sum(sde) as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & IMP_CREDIT_CONSO & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, sum(sde) as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CMT_DCC & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "sum(sde) as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & IMP_CMT_DCC & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, sum(sde) as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & PPI & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, sum(sde) as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & IMP_PPI & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, sum(sde) as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CAUTIONS_MARCHES & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, sum(sde) as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CRA & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, sum(sde) as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & OCD & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "sum(sde) as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & AVAL & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, sum(sde) as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CDI_SBLC & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, sum(sde) as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & ENCOURS_LEASING & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, sum(sde) as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & IMPAYES_LEASING & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, sum(sde) as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CREANCES_CLASSEES_B & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, sum(sde) as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & CREANCES_CLASSEES_HB & ") and sde < 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "sum(sde) as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & PROV_CAUTIONS & ") and sde > 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, sum(sde) as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & PROV_CDI & ") and sde > 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, sum(sde) as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & GARANTIE_BANCAIRE_RECUE & ") and sde > 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, sum(sde) as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & TITRE_RECU_NANTISSEMENT & ") and sde > 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, sum(sde) as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & PROV_CTX_BILAN & ") and sde > 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, sum(sde) as PROV_CTX_HORS_BILAN, 0 as DEPOTS " & _
                    "from tsld1 where cha in (" & PROV_CTX_HORS_BILAN & ") and sde > 0 " & _
                    "group by cli " & _
                    "union " & _
                    "select cli, 0 as ESCOMPTE, 0 as COD, 0 as CREDIT_SPOT, 0 as IMP_SPOT, 0 as ASF, 0 as ASM, " & _
                    "0 as CMT, 0 as IMP_CMT, 0 as ENG_FIN_CMT_CLICOM, 0 as CREDIT_CONSO, 0 as IMP_CREDIT_CONSO, 0 as CMT_DCC, " & _
                    "0 as IMP_CMT_DCC, 0 as PPI, 0 as IMP_PPI, 0 as CAUTIONS_MARCHES, 0 as CRA, 0 as OCD, " & _
                    "0 as AVAL, 0 as CDI_SBLC, 0 as ENCOURS_LEASING, 0 as IMPAYES_LEASING, 0 as CREANCES_CLASSEES_B, 0 as CREANCES_CLASSEES_HB, " & _
                    "0 as PROV_CAUTIONS, 0 as PROV_CDI, 0 as GARANTIE_BANCAIRE_RECUE, 0 as TITRE_RECU_NANTISSEMENT, 0 as PROV_CTX_BILAN, 0 as PROV_CTX_HORS_BILAN, sum(sde) as DEPOTS " & _
                    "from tsld1 where cha in (" & DEPOTS & ") and sde > 0 " & _
                    "group by cli " & _
                    "into temp Tresultat1"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()
                    logger.Debug("Tresultat1 query done")
                    SqlStr = _
                    "select a.age, a.cli, a.nom, a.pre, a.qua, a.vala, a.nicr, a.grp, a.nomgrp, a.nidf, a.sec, " & _
                    "sum(b.ESCOMPTE) as ESCOMPTE, sum(b.COD) as COD, sum(b.CREDIT_SPOT) as CREDIT_SPOT, sum(b.IMP_SPOT) as IMP_SPOT, sum(b.ASF) as ASF, sum(b.ASM) as ASM, " & _
                    "sum(b.CMT) as CMT, sum(b.IMP_CMT) as IMP_CMT, sum(b.ENG_FIN_CMT_CLICOM) as ENG_FIN_CMT_CLICOM, sum(b.CREDIT_CONSO) as CREDIT_CONSO, sum(b.IMP_CREDIT_CONSO) as IMP_CREDIT_CONSO, sum(b.CMT_DCC) as CMT_DCC, " & _
                    "sum(b.IMP_CMT_DCC) as IMP_CMT_DCC, sum(b.PPI) as PPI, sum(b.IMP_PPI) as IMP_PPI, sum(b.CAUTIONS_MARCHES) as CAUTIONS_MARCHES, sum(b.CRA) as CRA, sum(b.OCD) as OCD, " & _
                    "sum(b.AVAL) as AVAL, sum(b.CDI_SBLC) as CDI_SBLC, sum(b.ENCOURS_LEASING) as ENCOURS_LEASING, sum(b.IMPAYES_LEASING) as IMPAYES_LEASING, sum(b.CREANCES_CLASSEES_B) as CREANCES_CLASSEES_B, sum(b.CREANCES_CLASSEES_HB) as CREANCES_CLASSEES_HB, " & _
                    "sum(b.PROV_CAUTIONS) as PROV_CAUTIONS, sum(b.PROV_CDI) as PROV_CDI, sum(b.GARANTIE_BANCAIRE_RECUE) as GARANTIE_BANCAIRE_RECUE, sum(b.TITRE_RECU_NANTISSEMENT) as TITRE_RECU_NANTISSEMENT, sum(b.PROV_CTX_BILAN) as PROV_CTX_BILAN, sum(b.PROV_CTX_HORS_BILAN) as PROV_CTX_HORS_BILAN, sum(b.DEPOTS) as DEPOTS " & _
                    "from tcli a, Tresultat1 b " & _
                    "where a.cli = b.cli " & _
                    "group by a.age, a.cli, a.nom, a.pre, a.qua, a.vala, a.nicr, a.grp, a.nomgrp, a.nidf, a.sec " & _
                    "into temp Tresultat2"
                    logger.Debug("Tresultat2 query done")
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    ' autorisations

                    query = "select bkcom.cli, sum(bkautc.maut * bktau.tind) as maut  " & _
                    "from bkcom, bkautc, bktau  " & _
                    "where bkcom.age = bkautc.age and bkcom.ncp = bkautc.ncp and bkcom.dev = bkautc.dev  " & _
                    "and bkautc.ech >= DATETIME({0}) YEAR TO DAY  and bkautc.fin >= DATETIME({0}) YEAR TO DAY  and bkautc.eta in ('VA','VF')  " & _
                    "and bkautc.dev = bktau.dev and bkautc.dou = bktau.dco  " & _
                    "group by bkcom.cli  " & _
                    "into temp tab_autc"
                    logger.Debug("tab_autc query done")
                    SqlStr = String.Format(query, dateArrete.ToString("yyyy-MM-dd"))
                    
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    ' garanties

                    query = _
                    "select cli, sum(mont) as mont " & _
                    "from bkgar " & _
                    "where ddm <= DATETIME({0}) YEAR TO DAY  and dech >= DATETIME({0}) YEAR TO DAY  " & _
                    "group by 1 " & _
                    "into temp tab_gar_mon"
                    logger.Debug("tab_gar_mon query done")
                    SqlStr = String.Format(query, dateArrete.ToString("yyyy-MM-dd"))
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    query = _
                    "select distinct cli, cnat, 0 as nat " & _
                    "from bkgar " & _
                    "where ddm <= DATETIME({0}) YEAR TO DAY  and dech >= DATETIME({0}) YEAR TO DAY  " & _
                    "into temp tab_gar_nat"
                    logger.Debug("tab_gar_nat query done")
                    SqlStr = String.Format(query, dateArrete.ToString("yyyy-MM-dd"))
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()




                    SqlStr = "update tab_gar_nat set nat=1 where cnat='ASS'"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SqlStr = "update tab_gar_nat set nat=20 where cnat='CAT'"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SqlStr = "update tab_gar_nat set nat=300 where cnat='HYP'"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SqlStr = "update tab_gar_nat set nat=4000 where cnat='NAT'"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SqlStr = "update tab_gar_nat set nat=50000 where cnat='NTD'"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SqlStr = "update tab_gar_nat set nat=600000 where cnat='VEH'"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SqlStr = _
                    "select cli, sum(nat) as nat " & _
                    "from tab_gar_nat " & _
                    "group by 1 " & _
                    "into temp tab_gar_nat1"
                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()

                    SqlStr = _
                    "select a.cli, a.mont, b.nat " & _
                    "from tab_gar_mon a, tab_gar_nat1 b " & _
                    "where a.cli=b.cli " & _
                    "into temp tab_gar"

                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 10000
                    SqlCommand.ExecuteNonQuery()
                    logger.Debug("tab_gar query done")

                    SqlStr = _
                    "select a.age as agence, a.cli as radical, a.nom, a.pre as prenom, a.nomgrp as nom_groupe, a.nidf, a.sec,  " & _
                    "a.qua as cotation, a.vala as segment, a.nicr as CLE_BA, b.maut as autorisation,  " & _
                    "a.ESCOMPTE, a.COD, a.CREDIT_SPOT, a.IMP_SPOT, a.ASF, a.ASM, " & _
                    "a.CMT, a.IMP_CMT, a.ENG_FIN_CMT_CLICOM, a.CREDIT_CONSO, a.IMP_CREDIT_CONSO, a.CMT_DCC, " & _
                    "a.IMP_CMT_DCC, a.PPI, a.IMP_PPI, a.CAUTIONS_MARCHES, a.CRA, a.OCD, " & _
                    "a.AVAL, a.CDI_SBLC, a.ENCOURS_LEASING, a.IMPAYES_LEASING, a.CREANCES_CLASSEES_B, a.CREANCES_CLASSEES_HB, " & _
                    "a.PROV_CAUTIONS, a.PROV_CDI, a.GARANTIE_BANCAIRE_RECUE, a.TITRE_RECU_NANTISSEMENT, a.PROV_CTX_BILAN, a.PROV_CTX_HORS_BILAN, a.DEPOTS, " & _
                    "c.nat as GARANTIES, c.mont as MONTANT_GARANTIES " & _
                    "from Tresultat2 a left join tab_autc b on a.cli = b.cli " & _
                    "left join tab_gar c on a.cli = c.cli  " & _
                    "order by a.age, a.cli"

                    SqlCommand = New OleDb.OleDbCommand(SqlStr, con)
                    SqlCommand.CommandTimeout = 1000000

                    Dim cotationAdapter As OleDbDataAdapter = New OleDbDataAdapter(SqlCommand)
                    cotationAdapter.Fill(dtResultat)
                    logger.Debug("dtResultat query done")
                    SupprimerTable("tsld", con)
                    SupprimerTable("tsld0", con)
                    SupprimerTable("tsld1", con)
                    SupprimerTable("tcli", con)
                    SupprimerTable("Tresultat", con)
                    SupprimerTable("Tresultat1", con)
                    SupprimerTable("Tresultat2", con)
                    SupprimerTable("tab_autc", con)
                    SupprimerTable("tab_gar_mon", con)
                    SupprimerTable("tab_gar_nat", con)
                    SupprimerTable("tab_gar_nat1", con)
                    SupprimerTable("tab_gar", con)
                    logger.Debug("clean temps done")

                    Dim dc As DataColumn = New DataColumn() With {.ColumnName = "Date_arrete",
                                                      .DataType = GetType(DateTime),
                                                      .DefaultValue = dateArrete}

                    dtResultat.Columns.Add(dc)

                    dtResultat.AcceptChanges()

                    logger.Debug("date arreté " & dateArrete.ToString("dd-MM-yyyy"))

                    logger.Debug("result count " & dtResultat.Rows.Count)
                End Using

                Return dtResultat
            Catch ex As Exception
                logger.Warn(ex.Message)
            End Try

        End Function


    End Class
End Namespace

