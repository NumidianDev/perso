﻿Imports log4net
Imports SgaReportingDataExtractor.data
Imports Sga.Tools

Module MainModule

    Private currentDir As String = AppDomain.CurrentDomain.BaseDirectory
    Private logger As ILog

    Sub Main(ByVal sArgs() As String)

        log4net.Config.XmlConfigurator.ConfigureAndWatch(configFile:=New System.IO.FileInfo(AppDomain.CurrentDomain.BaseDirectory & "SgaReportingDataExtractor.log.config"))

        logger = LogManager.GetLogger(GetType(MainModule))
        Dim datearrete As DateTime

        datearrete = Date.Parse(Now.AddDays(-1 * Now.Day).ToString("dd/MM/yyyy"))

        Console.WriteLine("Date d'arrêté par défaut : " & datearrete)

        IDSUtils.getInstance()

        Dim argc As Integer
        Dim argv As System.Collections.ObjectModel.ReadOnlyCollection(Of String)

        logger.Debug("Arguments de la ligne de commande : ")
        logger.Debug(My.Application.CommandLineArgs)

        argv = My.Application.CommandLineArgs
        argc = argv.Count

        If argc > 0 AndAlso (argv(0) = "/?" OrElse argv(0) = "\?" OrElse argv(0) = "-?") Then

            Console.WriteLine("Utilisation :")
            Console.WriteLine(" SgaReportingDataExtractor [/DAT | /BDC | /EFF | /GES | /PLZ | /CLI | /SLD]")
            Console.WriteLine("Où :")
            Console.WriteLine(" Options :")
            Console.WriteLine("     /DAT        Extrait les dépôts à terme ")
            Console.WriteLine("     /BDC        Extrait les bons de caisse ")
            Console.WriteLine("     /EFF        Extrait les effets ")
            Console.WriteLine("     /GES        Extrait les comptes & dossiers de crédits")
            Console.WriteLine("     /PLZ        Extrait les données du leasing")
            Console.WriteLine("     /CLI        Extrait les données des clients")
            Console.WriteLine("     /SLD        Extrait les soldes & les agios (cette options existe uniquement en manuelle car elle est dépendante de la période d'ajustement comptable!)")


        ElseIf argc > 0 AndAlso argv(0) <> "/?" Then

            For Each arg As String In argv

                arg = arg.Substring(1)

                Select Case arg

                    Case "DAT"
                        Try
                            MSSQLUtils.getInstance().exportDATToSqlServer(IDSUtils.getInstance.extractDATEnCours(datearrete), datearrete)
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try
                    Case "BDC"
                        Try
                            MSSQLUtils.getInstance().exportBDCToSqlServer(IDSUtils.getInstance.extractBDCEnCours(datearrete), datearrete)
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try
                    Case "EFF"
                        Try
                            MSSQLUtils.getInstance().exportEffaitsToSqlServer(IDSUtils.getInstance.extractEffaits(datearrete), datearrete)
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try
                    Case "GES"
                        Try
                            MSSQLUtils.getInstance().exportComptesCreditsToSqlServer(IDSUtils.getInstance.extractComptesCredits(datearrete), datearrete)
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try
                    Case "PLZ"
                        Try
                            MSSQLUtils.getInstance().exportPleaseDataToSqlServer(MSSQLUtils.getInstance().getPleaseData(datearrete), datearrete)
                            MSSQLUtils.getInstance().exportTempBkComToSqlServer(IDSUtils.getInstance.extractComptesRadicalsPlease(), datearrete)
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try
                    Case "CLI"
                        Try
                            MSSQLUtils.getInstance().exportBkCliToSqlServer(IDSUtils.getInstance.extractBkCli())
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try

                        Try
                            MSSQLUtils.getInstance().exportAllClientsToSqlServer(IDSUtils.getInstance.extractAllClients())
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try
                    Case "SLD"
                        Try
                            MSSQLUtils.getInstance().exportArreteToSqlServer(IDSUtils.getInstance.extractArretesBySecteur(datearrete), datearrete)
                            MSSQLUtils.getInstance().exportSoldeToSqlServer(IDSUtils.getInstance.extractSoldeMensuel(datearrete), datearrete)
                            MSSQLUtils.getInstance().exportRisqueGlobalToSqlServer(IDSUtils.getInstance.GetGlobal(datearrete), datearrete)
                        Catch ex As Exception
                            logger.Warn(ex.Message)
                            Console.WriteLine(ex.Message)
                        End Try
                End Select
            Next
        Else
            MSSQLUtils.getInstance.GenerateDataForDate(datearrete)
        End If
        
    End Sub

    Public Function CommandLineArgs() As System.Collections.ObjectModel.ReadOnlyCollection(Of String)
        Dim value As String = Environment.CommandLine
        Dim bInsideQuote As Boolean
        Dim iCnt As Integer
        If value = "" Then Return New System.Collections.ObjectModel.ReadOnlyCollection(Of String)(Nothing)
        For Each c As Char In value.ToCharArray
            iCnt += 1
            If c = """"c Then
                bInsideQuote = Not bInsideQuote
                Continue For
            End If
            If c = " " Then
                If bInsideQuote Then
                    Continue For
                Else
                    Mid$(value, iCnt, 1) = "§"
                End If
            End If
        Next
        'Replace multiple separators
        While value.IndexOf("§§") > 0
            value = value.Replace("§§", "§")
        End While
        Dim CmdArgs As New List(Of String)
        Dim FirstArg As Boolean = True
        For Each sArg As String In value.Split("§".ToCharArray)
            If FirstArg Then
                FirstArg = False
                Continue For
            End If
            CmdArgs.Add(sArg)
        Next
        Return New System.Collections.ObjectModel.ReadOnlyCollection(Of String)(CmdArgs)
    End Function

End Module
