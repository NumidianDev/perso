﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('searchCtrl', function ($scope, budgetService, searchService, $http, $q, $window, $location, $mdToast, $timeout, $mdDialog, viewModelHelper) {

        $scope.paginationLimit = 10;

        $scope.paginationPage = 1;

        $scope.resultPageUrl = SgaApp.rootPath + 'App/Budget/Depenses/list/depenseList.html';
        
        $scope.searchQuery = null;

        $scope.inSearch = false;

        $scope.selectedCategorie = null;

        $scope.selectedBDCs = [];
        $scope.selectedFactures = [];
        $scope.selectedContrats = [];
        $scope.selectedFournisseurs = [];
        $scope.selectedProjets = [];


        $scope.SearchModel = {
            query: '',
            result: {
                factures: [],
                bdcs: [],
                contrats: [],
                fournisseurs: [],
                fgs: [],
                projets: []
            },
            resultCategories : [
            { name: "Factures", count: 0},
            { name: "BDCs", count: 0 },
            { name: "Contrats", count: 0 },
            { name: "Projets", count: 0 },
            { name: "Fournisseurs", count: 0 }
            ]
        }

        $scope.total = $scope.SearchModel.result.bdcs.length;

        $scope.limitOptions = [5, 10, 15, {
            label: 'All',
            value: function () {
                return $scope.SearchModel.result.bdcs.length;
            }
        }];

        $scope.selectCategory = function (category) {
            $scope.selectedCategorie = category;
        }

        $scope.selectItem = function (item) {
            if (item.Numero != null && item.TypeId != null) {
                switch (item.TypeId) {
                    case 1:
                        console.log("Facture N° : " + item.Numero);
                        break;
                    case 2:
                        console.log("BDC N° : " + item.Numero);
                        break;
                    default:
                        console.log("Contrat N° : " + item.Numero);
                        break;
                }
            } else {
                console.log(item.Nom);
            }
            
        }

        var deferred = null;

        $scope.toggleSearch = function () {
            viewModelHelper.toggleSearch();
        }

        $scope.showSearch = function () {
            return viewModelHelper.showSearch;
        }

        $scope.fireSearch = function () {
            deferred = $q.defer();
            $scope.inSearch = !$scope.inSearch;
            searchService.search($scope.SearchModel);
        }

        var initialize = function () {
            searchService.searchSuccess = function success(result) {
                deferred.resolve();
                $scope.inSearch = !$scope.inSearch;
                $scope.SearchModel = result.data;
            }

            
        }

        initialize();

    });
}());
