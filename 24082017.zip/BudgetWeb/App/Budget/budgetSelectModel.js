﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('budgetSelectModel', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.budgetService = budgetService;
        $scope.viewModelHelper = viewModelHelper;
        
        $scope.selected = [];

        //$scope.deferred = ($scope.deferred != null) ? $scope.deferred : null;

        $scope.budget = null;

        $scope.autoSelect = true;

        $scope.initState = true;

        budgetService.selectedBudget = $scope.budget;

        $scope.budgets = [];

        $scope.query = {
            order: '',
            limit: 0,
            page: 1,
            total: 0
        };

        budgetService.success = function success(budgets) {
            $scope.budgets = budgets.data.pagedBudgets;
            $scope.query = budgets.data.sortParam;
            if ($scope.autoSelect && $scope.initState && $scope.budgets && $scope.budgets.length > 0) {
                $scope.initState = false;
                $scope.budget = $scope.budgets[0];
                budgetService.selectedBudget = $scope.budget;
                angular.forEach(budgetService.onBudgetSelected, function (handler) {
                    handler();
                });
            }
            //$scope.deferred.resolve();
        }

        budgetService.onBudgetSelected.push(function () {
            $scope.budget = budgetService.selectedBudget;
            $scope.selected = [];
            $scope.selected.push($scope.budget);
        })

        var initialize = function () {
            $scope.refreshBudgets();
        }

        $scope.selectItem = function () {
            $scope.selected = [];
            $scope.selected.push($scope.budget);
            budgetService.selectedBudget = $scope.budget;
            angular.forEach(budgetService.onBudgetSelected, function (handler) {
                handler();
            });
        }

        $scope.refreshBudgets = function () {
            //$scope.deferred = $q.defer();
            //$scope.promiseList = $scope.deferred.promise;
            return budgetService.getAllBudgets($scope.query);
        }

        initialize();

    });
}());
