﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('budgetEditCtrl', function ($scope, budgetService, $filter, $http, $q, $window, $location, $mdToast, $mdDialog, $mdEditDialog, $timeout, viewModelHelper) {

        $scope.Title = "Nouveau budget"

        $scope.budget = null;

        //$scope.userDirection = null;

        $scope.priorities = null;

        var posteDeferred = null;
        var priorityDeferred = null;

        budgetService.budgetAddSuccess = function success(budget) {
            alert('Le budget ' + budget.data.Exercice + ' a été créer');
        }

        budgetService.PostesSuccess = function success(postes) {
            $scope.postes = postes.data;
            posteDeferred.resolve();
            angular.forEach($scope.postes, function (poste) {
                $scope.fgs.push({
                    Id: 0,
                    Description: (poste.Intitule) ? poste.Intitule : '',
                    BudgetId: 0,
                    PosteId: (poste.Id) ? poste.Id : -1,
                    Montant: 0
                });
            });
        }

        budgetService.PrioritySuccess = function success(priorities) {
            $scope.priorities = priorities.data;
            priorityDeferred.resolve();
        }

        $scope.fgs = [];
        $scope.investissements = [];

        $scope.TotalFrais = 0;
        $scope.TotalInvest = 0;

        $scope.AllQuery = {
            order: '',
            limit: 0,
            page: 1
        };

        var refreshEditForm = function () {
            $scope.budget = budgetService.selectedBudget;
            //$scope.userDirection = budgetService.currentDirection;
            budgetService.getReducedFraisByBudget($scope.AllQuery);
            budgetService.getReducedInvestByBudget($scope.AllQuery);
        }

        var initialize = function () {

            $scope.dirName = $scope.currentDirection.Nom;
            budgetService.fraisSuccess = function success(frais) {
                $scope.fgs = frais.data.pagedFrais;
                $scope.refreshMontants();
            }

            budgetService.investSuccess = function success(invests) {
                $scope.investissements = invests.data.pagedInvest;
                $scope.refreshMontants();
            }

            budgetService.onBudgetSelected.push(function () {
                refreshEditForm();
            });

            if (budgetService.selectedBudget != null) {
                refreshEditForm();
            }

            posteDeferred = $q.defer();
            priorityDeferred = $q.defer();

            budgetService.GetInvestPriority();

        }

        $scope.refreshMontants = function () {

            $scope.budget.Montant = 0;
            $scope.TotalFrais = 0;
            $scope.TotalInvest = 0;

            angular.forEach($scope.fgs, function (fg) {
                $scope.budget.Montant += parseFloat(fg.Montant);
                $scope.TotalFrais += parseFloat(fg.Montant);
            });
            angular.forEach($scope.investissements, function (invest) {
                $scope.budget.Montant += parseFloat(invest.Montant);
                $scope.TotalInvest += parseFloat(invest.Montant);
            });
        }

        var getById = function (id, objArr) {
            if (id) {
                var single_object = $filter('filter')(objArr, function (o) { return o.Id === id; })[0];
                return single_object
            } else return null;
        }

        $scope.budgetEdit = function (budget) {
            budget.DirectionId = budgetService.currentDirection.Id;
            var budgetVM = {
                budget: budget,
                investissements: $scope.investissements,
                frais: $scope.fgs
            }
            budgetService.UpdateBudget(budgetVM);
        }

        var parent = $scope;

        $scope.addInvest = function (ev) {
            $mdDialog.show({
                controller: NewInvestDialogController,
                templateUrl: '../App/Budget/InvestCreateDialog.tmpl.html',
                parent: angular.element(document.body),
                targetEvent: ev,
                clickOutsideToClose: true,
                fullscreen: true // Only for -xs, -sm breakpoints.
            })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
        }

        function NewInvestDialogController($scope, $mdDialog) {

            $scope.parent = parent;

            $scope.currentDirection = budgetService.currentDirection;

            $scope.investissement = {
                Id: 0,
                DepartementId: $scope.currentDirection.Id,
            }
            $scope.cancel = function () {
                $mdDialog.cancel();
            };

            $scope.Add = function () {
                parent.investissements.push($scope.investissement);
                parent.refreshMontants();
                $mdDialog.hide();
            }

        }

        $scope.editNom = function (event, formModel) {
            event.stopPropagation(); // in case autoselect is enabled

            var editDialog = {
                modelValue: formModel.Nom,
                placeholder: 'Nom',
                save: function (input) {
                    formModel.Nom = input.$modelValue;
                },
                targetEvent: event,
                title: 'Nom',
                validators: {
                    'md-maxlength': 255
                }
            };

            var promise;

            promise = $mdEditDialog.large(editDialog);

            promise.then(function (ctrl) {
                var input = ctrl.getInput();

                input.$viewChangeListeners.push(function () {
                    input.$setValidity('test', input.$modelValue !== 'test');
                });
            });
        };

        $scope.editDescription = function (event, formModel) {
            event.stopPropagation(); // in case autoselect is enabled

            var editDialog = {
                modelValue: formModel.Description,
                placeholder: 'Description',
                save: function (input) {
                    formModel.Description = input.$modelValue;
                },
                targetEvent: event,
                title: 'Description',
                validators: {
                    'md-maxlength': 255
                }
            };

            var promise;

            promise = $mdEditDialog.large(editDialog);

            promise.then(function (ctrl) {
                var input = ctrl.getInput();

                input.$viewChangeListeners.push(function () {
                    input.$setValidity('test', input.$modelValue !== 'test');
                });
            });
        };

        $scope.editMontant = function (event, formModel) {
            event.stopPropagation(); // in case autoselect is enabled
            var editDialog = {
                modelValue: formModel.Montant,
                placeholder: 'Montant',
                save: function (input) {
                    formModel.Montant = input.$modelValue;
                    $scope.refreshMontants();
                },
                targetEvent: event,
                title: 'Montant',
                validators: {
                    'md-maxlength': 255
                }
            };

            var promise;

            promise = $mdEditDialog.large(editDialog);

            promise.then(function (ctrl) {
                var input = ctrl.getInput();

                input.$viewChangeListeners.push(function () {
                    input.$setValidity('test', input.$modelValue !== 0);
                });
            });
        };

        initialize();

    });
}());
