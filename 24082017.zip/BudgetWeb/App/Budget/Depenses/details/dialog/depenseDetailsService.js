﻿(function (SgaApp) {
    var depenseDetailsService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.selectedDepense = null;

        self.onDepenseSelected = [];

        return this;

    };

    SgaApp.depenseDetailsService = depenseDetailsService;

}(window.SgaApp));

