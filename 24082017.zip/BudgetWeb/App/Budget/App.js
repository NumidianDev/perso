﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.factory('budgetService', function ($rootScope, $http, $q, $location, viewModelHelper) {
        return SgaApp.budgetService($rootScope, $http, $q, $location, viewModelHelper);
    });
}());
