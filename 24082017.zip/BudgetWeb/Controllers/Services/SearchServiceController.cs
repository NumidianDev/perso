﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using BudgetData.Models;
using BudgetWeb.Models;

namespace BudgetWeb.Controllers.Services
{
    public class SearchServiceController : ApiController
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        [ResponseType(typeof(SearchModel))]
        [Route("Search/All")]
        public IHttpActionResult PostBudget(SearchModel queryObject)
        {
            
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SearchModel _searchModel = new SearchModel();

            _searchModel.query = queryObject.query;

            if (!String.IsNullOrEmpty(queryObject.query)) {

                var depenses = db.Depenses.Where(d => ((d.Numero.ToUpper().Contains(_searchModel.query.ToUpper())) ||
                                                        (!String.IsNullOrEmpty(d.Avenant) && (d.Avenant.ToUpper().Contains(_searchModel.query.ToUpper()))) ||
                                                         (!String.IsNullOrEmpty(d.Observation) && d.Observation.ToUpper().Contains(_searchModel.query.ToUpper())) ||
                                                         (d.Fournisseur.Nom.ToUpper().Contains(_searchModel.query.ToUpper()))
                                                        )).ToArray();

                _searchModel.result.factures = depenses.Where(d => d.TypeId == 1).ToArray();

                _searchModel.result.bdcs = depenses.Where(d => d.TypeId == 2).ToArray();

                _searchModel.result.contrats = depenses.Where(d => d.TypeId == 3).ToArray();

                _searchModel.result.projets = db.ElementsBudget.OfType<Investissement>().Where(I => (I.Nom.ToUpper().Contains(_searchModel.query.ToUpper()) ||
                                                                                   (!String.IsNullOrEmpty(I.Description) && I.Description.ToUpper().Contains(_searchModel.query.ToUpper())) ||
                                                                                   (!String.IsNullOrEmpty(I.Objectif) && I.Objectif.ToUpper().Contains(_searchModel.query.ToUpper())))).ToArray();

                _searchModel.result.fournisseurs = db.Organisations.Where(o => o.TypeId == 1 && (o.Nom.ToUpper().Contains(_searchModel.query.ToUpper()))).ToArray();
            }

            _searchModel.resultCategories.Where(rc => rc.name.ToUpper().Equals("Factures".ToUpper())).First().count = _searchModel.result.factures.Count();
            _searchModel.resultCategories.Where(rc => rc.name.ToUpper().Equals("BDCs".ToUpper())).First().count = _searchModel.result.bdcs.Count();
            _searchModel.resultCategories.Where(rc => rc.name.ToUpper().Equals("Contrats".ToUpper())).First().count = _searchModel.result.contrats.Count();
            _searchModel.resultCategories.Where(rc => rc.name.ToUpper().Equals("Fournisseurs".ToUpper())).First().count = _searchModel.result.fournisseurs.Count();
            _searchModel.resultCategories.Where(rc => rc.name.ToUpper().Equals("Investissements".ToUpper())).First().count = _searchModel.result.projets.Count();

            return Ok(_searchModel);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}