﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BudgetWeb.Models {
    public class SearchModel {

        private IList<Category> _resultCategories = new List<Category>();
        public SearchModel() {
            IList<String> catNames = new List<String>() { "Factures", "BDCs", "Contrats", "Fournisseurs", "Investissements" };
            foreach (string catName in catNames) {
                _resultCategories.Add(new Category() { name = catName, count = 0 });    
            }
            result = new SearchResult();
        }
        public String query { get; set; }

        public SearchResult result { get; set; }

        public Category[] resultCategories { get { return _resultCategories.ToArray(); } }

    }
}