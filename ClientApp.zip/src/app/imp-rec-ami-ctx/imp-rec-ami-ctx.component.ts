import { Component, OnInit, Inject } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FormGroup } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-imp-rec-ami-ctx',
  templateUrl: './imp-rec-ami-ctx.component.html',
  styleUrls: ['./imp-rec-ami-ctx.component.scss']
})
export class ImpRecAmiCtxComponent implements OnInit {

  formData: FormGroup;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({});
  }

  traitement(): void {
    this.extractService.impRecCTX().subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }

}
