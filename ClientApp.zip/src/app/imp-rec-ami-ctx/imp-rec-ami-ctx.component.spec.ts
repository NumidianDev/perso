import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImpRecAmiCtxComponent } from './imp-rec-ami-ctx.component';

describe('ImpRecAmiCtxComponent', () => {
  let component: ImpRecAmiCtxComponent;
  let fixture: ComponentFixture<ImpRecAmiCtxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImpRecAmiCtxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImpRecAmiCtxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
