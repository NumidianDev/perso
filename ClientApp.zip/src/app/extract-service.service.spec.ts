import { TestBed } from '@angular/core/testing';

import { ExtractServiceService } from './extract-service.service';

describe('ExtractServiceService', () => {
  let service: ExtractServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExtractServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
