import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentieuxPreContentieuxComponent } from './contentieux-pre-contentieux.component';

describe('ContentieuxPreContentieuxComponent', () => {
  let component: ContentieuxPreContentieuxComponent;
  let fixture: ComponentFixture<ContentieuxPreContentieuxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentieuxPreContentieuxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentieuxPreContentieuxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
