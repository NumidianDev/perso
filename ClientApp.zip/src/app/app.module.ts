import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AngularMaterialModule } from './angular-material/angular-material.module';
import { EncoursImpayesComponent } from './encours-impayes/encours-impayes.component';
import { ContentieuxPreContentieuxComponent } from './contentieux-pre-contentieux/contentieux-pre-contentieux.component';
import { CotesMouvementsComponent } from './cotes-mouvements/cotes-mouvements.component';
import { DotationsRepriseComponent } from './dotations-reprise/dotations-reprise.component';
import { EngagementsComponent } from './engagements/engagements.component';
import { EngagementsGlobaleComponent } from './engagements-globale/engagements-globale.component';
import { EngagementsGroupesComponent } from './engagements-groupes/engagements-groupes.component';
import { DefaultClientComponent } from './default-client/default-client.component';
import { ClientsComponent } from './clients/clients.component';
import { PpiMarhabaComponent } from './ppi-marhaba/ppi-marhaba.component';
import { ImpRecAmiCtxComponent } from './imp-rec-ami-ctx/imp-rec-ami-ctx.component';
import { EtatDebiteursComponent } from './etat-debiteurs/etat-debiteurs.component';
import { SoldeFinMoisComponent } from './solde-fin-mois/solde-fin-mois.component';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';

export const periods = ['Etat mensuel', 'Etat journalier'];

@NgModule({
  declarations: [
    AppComponent,
    EncoursImpayesComponent,
    ContentieuxPreContentieuxComponent,
    CotesMouvementsComponent,
    DotationsRepriseComponent,
    EngagementsComponent,
    EngagementsGlobaleComponent,
    EngagementsGroupesComponent,
    DefaultClientComponent,
    ClientsComponent,
    PpiMarhabaComponent,
    ImpRecAmiCtxComponent,
    EtatDebiteursComponent,
    SoldeFinMoisComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AngularMaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
