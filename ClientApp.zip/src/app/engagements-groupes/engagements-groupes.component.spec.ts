import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EngagementsGroupesComponent } from './engagements-groupes.component';

describe('EngagementsGroupesComponent', () => {
  let component: EngagementsGroupesComponent;
  let fixture: ComponentFixture<EngagementsGroupesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EngagementsGroupesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EngagementsGroupesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
