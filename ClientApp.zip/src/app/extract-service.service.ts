import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExtractServiceService {

  httpClient: HttpClient;
  baseUrl: string;

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.httpClient = http;
    this.baseUrl = baseUrl;
  }

  encoursImpayes(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/encoursImpayes', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  nonCotes(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/nonCotes', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  cotesMvtsCpts(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/cotesMvtsCpts', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  dotationsReprises(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/dotationsReprises', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  engagements(formData: FormData): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/engagements', formData , {
      reportProgress: true,
      observe: 'events'
    });
  }

  engagementsGlobale(formData: FormData): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/engagementsGlobale', formData , {
      reportProgress: true,
      observe: 'events'
    });
  }

  engagementsGroupes(formData: FormData): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/engagementsGroupes', formData , {
      reportProgress: true,
      observe: 'events'
    });
  }

  defaut(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/defaut', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  clients(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/clients', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  ppiMarhaba(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/ppiMarhaba', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  impRecCTX(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/impRecCTX', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  debiteurs(): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/debiteurs', [] , {
      reportProgress: true,
      observe: 'events'
    });
  }

  soldesFinMois(formData: FormData): Observable<any> {
    return this.httpClient.post<any>(this.baseUrl + 'Cotation/soldesFinMois', formData , {
      reportProgress: true,
      observe: 'events'
    });
  }

  errorHandler(error: HttpErrorResponse): void {
    console.log(error.message);
  }

}
