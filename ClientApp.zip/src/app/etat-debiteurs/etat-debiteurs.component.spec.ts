import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EtatDebiteursComponent } from './etat-debiteurs.component';

describe('EtatDebiteursComponent', () => {
  let component: EtatDebiteursComponent;
  let fixture: ComponentFixture<EtatDebiteursComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EtatDebiteursComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EtatDebiteursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
