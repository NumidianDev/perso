import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PpiMarhabaComponent } from './ppi-marhaba.component';

describe('PpiMarhabaComponent', () => {
  let component: PpiMarhabaComponent;
  let fixture: ComponentFixture<PpiMarhabaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PpiMarhabaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PpiMarhabaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
