import { Component, OnInit, Inject } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FormGroup } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-ppi-marhaba',
  templateUrl: './ppi-marhaba.component.html',
  styleUrls: ['./ppi-marhaba.component.scss']
})
export class PpiMarhabaComponent implements OnInit {

  formData: FormGroup;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({});
  }

  traitement(): void {
    this.extractService.ppiMarhaba().subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }

}
