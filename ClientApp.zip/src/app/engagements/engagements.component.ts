import { Component, OnInit, Inject } from '@angular/core';
import { periods } from '../app.module';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-engagements',
  templateUrl: './engagements.component.html',
  styleUrls: ['./engagements.component.scss']
})
export class EngagementsComponent implements OnInit {

  formData: FormGroup;

  periods = periods;

  selectedPeriod: string;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({
      choosedPeriod: new FormControl(periods[1])
    });
    this.selectedPeriod = periods[1];
  }

  traitement(formData): void {
    this.extractService.engagements(formData).subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }
}
