import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EngagementsGlobaleComponent } from './engagements-globale.component';

describe('EngagementsGlobaleComponent', () => {
  let component: EngagementsGlobaleComponent;
  let fixture: ComponentFixture<EngagementsGlobaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EngagementsGlobaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EngagementsGlobaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
