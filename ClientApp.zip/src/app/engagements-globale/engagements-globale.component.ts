import { Component, OnInit, Inject } from '@angular/core';
import { periods } from '../app.module';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-engagements-globale',
  templateUrl: './engagements-globale.component.html',
  styleUrls: ['./engagements-globale.component.scss']
})
export class EngagementsGlobaleComponent implements OnInit {

  formData: FormGroup;

  periods = periods;

  selectedPeriod: string;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({
      choosedPeriod: new FormControl()
    });
    this.selectedPeriod = periods[1];
  }

  traitement(formData): void {
    this.extractService.engagementsGlobale(formData).subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }

}
