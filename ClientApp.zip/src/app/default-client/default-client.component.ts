import { Component, OnInit, Inject } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FormGroup } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-default-client',
  templateUrl: './default-client.component.html',
  styleUrls: ['./default-client.component.scss']
})
export class DefaultClientComponent implements OnInit {

  formData: FormGroup;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({});
  }

  traitement(): void {
    this.extractService.defaut().subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }

}
