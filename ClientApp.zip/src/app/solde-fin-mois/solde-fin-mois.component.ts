import { Component, OnInit, Inject } from '@angular/core';
import { periods } from '../app.module';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-solde-fin-mois',
  templateUrl: './solde-fin-mois.component.html',
  styleUrls: ['./solde-fin-mois.component.scss']
})
export class SoldeFinMoisComponent implements OnInit {

  formData: FormGroup;

  periods = periods;

  selectedPeriod: string;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({
      choosedPeriod: new FormControl()
    });
    this.selectedPeriod = periods[1];
  }

  traitement(formData): void {
    this.extractService.soldesFinMois(formData).subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }

}
