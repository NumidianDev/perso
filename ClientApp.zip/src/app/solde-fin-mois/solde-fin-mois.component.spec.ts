import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SoldeFinMoisComponent } from './solde-fin-mois.component';

describe('SoldeFinMoisComponent', () => {
  let component: SoldeFinMoisComponent;
  let fixture: ComponentFixture<SoldeFinMoisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SoldeFinMoisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SoldeFinMoisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
