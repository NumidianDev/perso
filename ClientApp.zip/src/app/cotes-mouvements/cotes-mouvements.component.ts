import { Component, OnInit, Inject } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { FormGroup } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-cotes-mouvements',
  templateUrl: './cotes-mouvements.component.html',
  styleUrls: ['./cotes-mouvements.component.scss']
})
export class CotesMouvementsComponent implements OnInit {

  formData: FormGroup;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({});
  }

  traitement(): void {
    this.extractService.cotesMvtsCpts().subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }

}
