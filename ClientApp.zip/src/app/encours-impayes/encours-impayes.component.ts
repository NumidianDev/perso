import { Component, OnInit, Inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { Observable, PartialObserver, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { FormGroup } from '@angular/forms';
import { ExtractServiceService } from '../extract-service.service';

@Component({
  selector: 'app-encours-impayes',
  templateUrl: './encours-impayes.component.html',
  styleUrls: ['./encours-impayes.component.scss']
})
export class EncoursImpayesComponent implements OnInit {

  formData: FormGroup;

  constructor(private extractService: ExtractServiceService) {
  }

  ngOnInit(): void {
    this.formData = new FormGroup({});
  }

  traitement(): void {
    this.extractService.encoursImpayes().subscribe((event: any) => {
        if (event.type === HttpEventType.Response) {
          console.log(event.body);
        }
      });
  }

}


