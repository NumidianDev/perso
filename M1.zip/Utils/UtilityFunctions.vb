﻿Imports System.Net.Mail
Imports System.IO
Imports System.ComponentModel

Public Class UtilityFunctions

    Public Enum OperationType
        CDI
        RDI
    End Enum

    Public Enum DocumentReglementaire
        ALL
        DOUV
        ENGA
        DDOM
    End Enum

    Protected Shared Sub LogUtilException(ByVal message As String)
        log4net.LogManager.GetLogger(GetType(UtilityFunctions)).Warn("Messages | " & message & " | " & HttpContext.Current.Request.LogonUserIdentity.Name)
    End Sub

    Protected Shared Sub LogUtilInfo(ByVal message As String)
        log4net.LogManager.GetLogger(GetType(UtilityFunctions)).Info("Messages | " & message & " | " & HttpContext.Current.Request.LogonUserIdentity.Name) ' & " | " & sessionCOAB.Nom & " " & sessionCOAB.Prenom & " | " & sessionCOAB.Souscription.Client.RC)
    End Sub

    Public Shared Sub SendMailMultipleAttachments(ByVal aFrom As String, ByVal sendTo As String, ByVal Subject As String, _
    ByVal Body As String, _
    Optional ByVal dnFrom As String = "", _
    Optional ByVal AttachmentFiles As IList(Of String) = Nothing, _
    Optional ByVal CC As String = "", _
    Optional ByVal BCC As String = "", _
    Optional ByVal SMTPServer As String = "172.31.2.1")

        Dim Mail As MailMessage

        Try
            Mail = New MailMessage()
            Mail.To.Add(sendTo)
            Mail.From = New MailAddress(aFrom, IIf(String.IsNullOrEmpty(dnFrom), aFrom, dnFrom), System.Text.Encoding.UTF8)
            Mail.Subject = Subject
            Mail.SubjectEncoding = System.Text.Encoding.UTF8
            Mail.Body = Body
            Mail.BodyEncoding = System.Text.Encoding.UTF8
            Mail.IsBodyHtml = True

            If CC <> "" Then Mail.CC.Add(CC)
            If BCC <> "" Then Mail.Bcc.Add(BCC)

            If Not AttachmentFiles Is Nothing Then
                For Each Attach As String In AttachmentFiles
                    If File.Exists(Attach) Then
                        Dim attachFile As New System.Net.Mail.Attachment(Attach)
                        Mail.Attachments.Add(attachFile)
                    End If
                Next
            End If

            Dim client As SmtpClient = New SmtpClient(SMTPServer)

            Dim userState As Object = Mail
            AddHandler client.SendCompleted, AddressOf SmtpClient_OnCompleted
            client.SendAsync(Mail, userState)
            'client.Send(Mail)

        Catch myexp As Exception
            Throw myexp
        End Try
    End Sub

    Public Shared Sub SendMailMultipleAttachments(ByVal aFrom As String, ByVal sendTo As String(), ByVal Subject As String, _
    ByVal Body As String, _
    Optional ByVal dnFrom As String = "", _
    Optional ByVal AttachmentFiles As IList(Of String) = Nothing, _
    Optional ByVal CC As String() = Nothing, _
    Optional ByVal BCC As String() = Nothing, _
    Optional ByVal SMTPServer As String = "172.31.2.1")

        Dim Mail As MailMessage

        Try
            Mail = New MailMessage()
            For Each st In sendTo
                LogUtilInfo(st)
                If Not String.IsNullOrEmpty(st) Then
                    Mail.To.Add(st)
                End If
            Next

            Mail.From = New MailAddress(aFrom, IIf(String.IsNullOrEmpty(dnFrom), aFrom, dnFrom), System.Text.Encoding.UTF8)
            Mail.Subject = Subject
            Mail.SubjectEncoding = System.Text.Encoding.UTF8
            Mail.Body = Body
            Mail.BodyEncoding = System.Text.Encoding.UTF8
            Mail.IsBodyHtml = True
            If Not IsNothing(CC) Then
                For Each c In CC
                    Mail.CC.Add(c)
                Next
            End If
            If Not IsNothing(BCC) Then
                For Each bc In BCC
                    Mail.Bcc.Add(bc)
                Next
            End If

            If Not AttachmentFiles Is Nothing Then
                For Each Attach As String In AttachmentFiles
                    If File.Exists(Attach) Then
                        Dim attachFile As New System.Net.Mail.Attachment(Attach)
                        Mail.Attachments.Add(attachFile)
                    End If
                Next
            End If

            Dim client As SmtpClient = New SmtpClient(SMTPServer)

            Dim userState As Object = Mail
            AddHandler client.SendCompleted, AddressOf SmtpClient_OnCompleted
            client.SendAsync(Mail, userState)

        Catch myexp As Exception
            Throw myexp
        End Try
    End Sub

    Public Shared Sub SmtpClient_OnCompleted(ByVal sender As Object, ByVal e As AsyncCompletedEventArgs)
        'Get the Original MailMessage object
        Dim mail As MailMessage = CType(e.UserState, MailMessage)

        'write out the subject
        Dim subject As String = mail.Subject

        If e.Cancelled Then
            LogUtilException("Envoie Annulé du mail avec l'objet : " & subject)
        End If
        If Not (e.Error Is Nothing) Then
            LogUtilException("L'erreur " & e.Error.ToString() & " est survenue lors de l'envoie du mail : " & subject)
        Else
            LogUtilInfo("Message " & subject & " envoyé.")
        End If
    End Sub 'SmtpClient_OnCompleted

    Public Shared Function GetFilesRoot() As String

        Dim db As Data.DB = New Data.DB()

        Dim sourceDirectory = db.Parametres.First(Function(p) p.Param.Equals("FilesRoot", StringComparison.CurrentCultureIgnoreCase))
        If sourceDirectory Is Nothing OrElse String.IsNullOrEmpty(sourceDirectory.Value) Then
            'Throw New Exception("Le répértoire racine des fichiers n'est pas paramètré ou introuvable !")
            'Logging erreur fatale
        End If

        'logger.Warn(sourceDirectory.Value)

        Dim root As String = sourceDirectory.Value

        If sourceDirectory.Value.StartsWith("~") Then
            root = HttpContext.Current.Server.MapPath(sourceDirectory.Value)
        End If

        If Not (root.EndsWith("\") OrElse root.EndsWith("/")) Then
            root = root & "\"
        End If

        If Not Directory.Exists(root) Then
            Directory.CreateDirectory(root)
        End If

        Return root

    End Function

    Public Shared Function GetClientFileRoot(ByVal radical As String) As String

        Dim clientRoot As String = GetFilesRoot() & radical & "\"

        If Not Directory.Exists(clientRoot) Then
            Directory.CreateDirectory(clientRoot)
        End If

        Return clientRoot

    End Function

    Public Shared Function GetClientOperationFileRoot(ByVal radical As String, ByVal ope As OperationType) As String

        Dim clientoperationRoot As String = GetClientFileRoot(radical) & ope.ToString & "\"

        If Not Directory.Exists(clientoperationRoot) Then
            Directory.CreateDirectory(clientoperationRoot)
        End If

        Return clientoperationRoot

    End Function

    Public Shared Function GetDossierFileRoot(ByVal radical As String, ByVal ope As OperationType, ByVal id As Int32) As String

        Dim operationRoot As String = GetClientOperationFileRoot(radical, ope) & id.ToString & "\"

        If Not Directory.Exists(operationRoot) Then
            Directory.CreateDirectory(operationRoot)
        End If

        Return operationRoot

    End Function

    Protected Friend Function ChiffresEnLettres(ByVal inD As Double) As String
        Dim outString As String = String.Empty
        Dim centaine, dizaine, unite, y As Double
        Dim dix As Boolean = False
        Dim reste As Double = inD
        Dim i As Int32 = 1000000000

        Do While i >= 1

            y = (reste - reste Mod i) / i

            If y <> 0 Then
                centaine = (y - y Mod 100) / 100
                dizaine = ((y - centaine * 100) - (y - centaine * 100) Mod 10) / 10
                unite = y - (centaine * 100) - (dizaine * 10)

                Select Case centaine
                    Case 0
                        Exit Select
                    Case 1
                        outString = outString & "Cent"
                    Case 2
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Deux cents"
                        Else
                            outString = outString & "Deux cent"
                        End If
                    Case 3
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Trois cents"
                        Else
                            outString = outString & "Trois cent"
                        End If
                    Case 4
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Quatre cents"
                        Else
                            outString = outString & "Quatre cent"
                        End If
                    Case 5
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Cinq cents"
                        Else
                            outString = outString & "Cinq cent"
                        End If
                    Case 6
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Six cents"
                        Else
                            outString = outString & "Six cent"
                        End If
                    Case 7
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Sept cents"
                        Else
                            outString = outString & "Sept cent"
                        End If
                    Case 8
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Huit cents"
                        Else
                            outString = outString & "Huit cent"
                        End If
                    Case 9
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Neuf cents"
                        Else
                            outString = outString & "Neuf cent"
                        End If
                End Select
                Select Case dizaine
                    Case 0
                        Exit Select
                    Case 1
                        dix = True
                    Case 2
                        outString = outString & "Vingt "
                    Case 3
                        outString = outString & "Trente "
                    Case 4
                        outString = outString & "Quarante "
                    Case 5
                        outString = outString & "Cinquante "
                    Case 6
                        outString = outString & "Soixante "
                    Case 7
                        dix = True
                        outString = outString & "Soixante "
                    Case 8
                        outString = outString & "Quatre-Vingt "
                    Case 9
                        dix = True
                        outString = outString & "Quatre-Vingt "
                End Select
                Select Case unite
                    Case 0
                        If dix Then
                            outString = outString & "Dix "
                        End If
                    Case 1
                        If dix Then
                            outString = outString & "Onze "
                        Else
                            outString = outString & "Un "
                        End If
                    Case 2
                        If dix Then
                            outString = outString & "Douze "
                        Else
                            outString = outString & "Deux "
                        End If
                    Case 3
                        If dix Then
                            outString = outString & "Treize "
                        Else
                            outString = outString & "Trois "
                        End If
                    Case 4
                        If dix Then
                            outString = outString & "Quatorze "
                        Else
                            outString = outString & "Quatre "
                        End If
                    Case 5
                        If dix Then
                            outString = outString & "Quinze "
                        Else
                            outString = outString & "Cinq "
                        End If
                    Case 6
                        If dix Then
                            outString = outString & "Seize "
                        Else
                            outString = outString & "Six "
                        End If
                    Case 7
                        If dix Then
                            outString = outString & "Dix-Sept "
                        Else
                            outString = outString & "Sept "
                        End If
                    Case 8
                        If dix Then
                            outString = outString & "Dix-Huit "
                        Else
                            outString = outString & "Huit "
                        End If
                    Case 9
                        If dix Then
                            outString = outString & "Dix-Neuf "
                        Else
                            outString = outString & "Neuf "
                        End If
                End Select

                Select Case i
                    Case 1000000000
                        If y > 1 Then
                            outString = outString & "Milliards "
                        Else
                            outString = outString & "Milliard "
                        End If
                    Case 1000000
                        If y > 1 Then
                            outString = outString & "Millions "
                        Else
                            outString = outString & "Million "
                        End If
                    Case 1000
                        outString = outString & "Milliards "
                End Select
            End If

            reste = reste - y * i
            dix = False
            Console.Write(i)
            i = i / 1000
        Loop

        Return outString

    End Function

    Public Shared Function TryGetFiles(ByVal radical As String, ByVal Ope As OperationType, ByVal IdCible As String, ByVal filesPath As IList(Of String)) As IList(Of String)

        Dim result As IList(Of String) = New List(Of String)

        Try
            Dim dossierRoot As String = GetDossierFileRoot(radical, Ope, IdCible)

            For Each pathString As String In filesPath
                If IO.File.Exists(Path.Combine(dossierRoot, pathString)) Then
                    result.Add(Path.Combine(dossierRoot, pathString))
                End If
            Next
        Catch ex As Exception

        End Try

        Return result

    End Function



    Public Shared Function GetIconPath(ByVal contentType As String) As String
        If String.IsNullOrEmpty(contentType) Then
            Return "/Images/content-types/24/File.png"
        ElseIf contentType.StartsWith("image/", StringComparison.CurrentCultureIgnoreCase) Then
            Return "/Images/content-types/24/Image.png"
        ElseIf contentType.Equals("text/plain", StringComparison.CurrentCultureIgnoreCase) Then
            Return "/Images/content-types/24/Text.png"
        ElseIf contentType.Equals("application/pdf", StringComparison.CurrentCultureIgnoreCase) Then
            Return "/Images/content-types/24/PDF.png"
        ElseIf contentType.Equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document", StringComparison.CurrentCultureIgnoreCase) _
            OrElse contentType.Equals("application/msword", StringComparison.CurrentCultureIgnoreCase) Then
            Return "/Images/content-types/24/Word.png"
        ElseIf contentType.Equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", StringComparison.CurrentCultureIgnoreCase) _
            OrElse contentType.Equals("application/vnd.ms-excel", StringComparison.CurrentCultureIgnoreCase) Then
            Return "/Images/content-types/24/Excel.png"
        ElseIf contentType.Equals("application/vnd.openxmlformats-officedocument.presentationml.presentation", StringComparison.CurrentCultureIgnoreCase) _
            OrElse contentType.Equals("application/vnd.ms-powerpoint", StringComparison.CurrentCultureIgnoreCase) Then
            Return "/Images/content-types/24/PowerPoint.png"
        Else
            Return "/Images/content-types/24/File.png"
        End If
    End Function

    Public Shared Function GetIconPathByExtention(ByVal ext As String) As String
        If Not String.IsNullOrEmpty(ext) AndAlso ext.StartsWith(".") Then
            ext = ext.Substring(1)
        End If
        If String.IsNullOrEmpty(ext) Then
            Return "/Images/content-types/24/File.png"
        ElseIf ext.ToLower().Equals("jpg") _
            OrElse ext.ToLower().Equals("jpeg") _
            OrElse ext.ToLower().Equals("png") _
            OrElse ext.ToLower().Equals("gif") _
            OrElse ext.ToLower().Equals("bmp") _
            OrElse ext.ToLower().Equals("ico") Then
            Return "/Images/content-types/24/Image.png"
        ElseIf ext.ToLower().Equals("txt") _
            OrElse ext.ToLower().Equals("rtf") Then
            Return "/Images/content-types/24/Text.png"
        ElseIf ext.ToLower().Equals("pdf") Then
            Return "/Images/content-types/24/PDF.png"
        ElseIf ext.ToLower().Equals("doc") _
            OrElse ext.ToLower().Equals("docx") Then
            Return "/Images/content-types/24/Word.png"
        ElseIf ext.ToLower().Equals("xls") _
            OrElse ext.ToLower().Equals("xlsx") Then
            Return "/Images/content-types/24/Excel.png"
        ElseIf ext.ToLower().Equals("ppt") _
            OrElse ext.ToLower().Equals("pptx") Then
            Return "/Images/content-types/24/PowerPoint.png"
        Else
            Return "/Images/content-types/24/File.png"
        End If
    End Function

    Public Shared Sub EntityToDataSet(Of TEntity)(ByRef ds As DataSet, ByVal MyEntities As List(Of TEntity))
        Dim strTableName As String
        Dim drNewRow As DataRow
        For Each POCO In MyEntities
            Dim EntityFields = POCO.GetType.GetProperties.Where(Function(a) a.CanRead)
            If Not POCO.GetType.Assembly.IsDynamic Then
                strTableName = POCO.GetType.Name
            Else
                strTableName = POCO.GetType.BaseType.Name
            End If
            drNewRow = ds.Tables(strTableName).NewRow
            For Each field In EntityFields
                If drNewRow.Table.Columns.Contains(field.Name) Then
                    drNewRow(field.Name) = If(field.GetValue(POCO, Nothing), DBNull.Value)
                End If
            Next
            ds.Tables(strTableName).Rows.Add(drNewRow)
        Next POCO
    End Sub


End Class
