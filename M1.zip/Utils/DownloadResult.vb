﻿
Public Class DownloadResult
    Inherits System.Web.Mvc.ActionResult

    Private _virtualPath As String
    Private _fileDownloadName As String

    Public Sub New()

    End Sub

    Public Sub New(ByVal virtualPath As String)
        Me._virtualPath = virtualPath
    End Sub

    Public Sub New(ByVal virtualPath As String, ByVal fileDownloadName As String)
        Me._virtualPath = virtualPath
        Me._fileDownloadName = fileDownloadName
    End Sub

    Public Property VirtualPath() As String
        Get
            Return _virtualPath
        End Get
        Set(ByVal value As String)
            _virtualPath = value
        End Set
    End Property


    Public Property FileDownloadName() As String
        Get
            Return _fileDownloadName
        End Get
        Set(ByVal value As String)
            _fileDownloadName = value
        End Set
    End Property

    Public Overrides Sub ExecuteResult(ByVal context As System.Web.Mvc.ControllerContext)

        If Not String.IsNullOrEmpty(FileDownloadName) Then
            context.HttpContext.Response.AddHeader("content-disposition", "attachment; filename=" + Me._fileDownloadName)
        End If
        context.HttpContext.Response.TransmitFile(VirtualPath)

    End Sub

End Class
