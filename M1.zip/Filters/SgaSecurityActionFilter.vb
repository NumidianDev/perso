﻿Imports WebMatrix.WebData
Imports E_Trade.Data
Imports log4net

Public Class SgaSecurityActionFilter
    Inherits ActionFilterAttribute
    Implements IActionFilter

    Private Shared logger As ILog

    Public Overrides Sub OnActionExecuting(filterContext As System.Web.Mvc.ActionExecutingContext)
        
        logger = log4net.LogManager.GetLogger(filterContext.ActionDescriptor.ControllerDescriptor.ControllerType)

        Dim redirectDictionary As IDictionary(Of String, String) = New Dictionary(Of String, String)
        redirectDictionary.Add("controller", "Account")
        redirectDictionary.Add("action", "Login")
        redirectDictionary.Add("returnUrl", filterContext.HttpContext.Request.RawUrl)

        'filterContext.ActionDescriptor.ControllerDescriptor.ControllerType

        If Not HttpContext.Current.User.Identity.IsAuthenticated Then
            logger.Fatal(filterContext.ActionDescriptor.ActionName & " | Utilisateur non connecté " & HttpContext.Current.User.Identity.Name)
            filterContext.Result = New RedirectToRouteResult(routeValues:=New RouteValueDictionary(redirectDictionary))
        Else
            Dim db As DB = New DB()
            Try
                Dim sessionCOAB As COAB = db.COABS.Find(WebSecurity.GetUserId(HttpContext.Current.User.Identity.Name))
                If sessionCOAB Is Nothing Then
                    logger.Fatal(filterContext.ActionDescriptor.ActionName & " | Erreur d'authetification de l'utilisateur " & HttpContext.Current.User.Identity.Name)
                    filterContext.Result = New RedirectToRouteResult(routeValues:=New RouteValueDictionary(redirectDictionary))
                Else
                    logger.Debug(filterContext.ActionDescriptor.ActionName & " | Authetification réussie de l'utilisateur " & HttpContext.Current.User.Identity.Name)
                    MyBase.OnActionExecuting(filterContext)
                End If
            Catch ex As Exception
                logger.Fatal(filterContext.ActionDescriptor.ActionName & " | Erreur d'authetification de l'utilisateur " & HttpContext.Current.User.Identity.Name)
                filterContext.Result = New RedirectToRouteResult(routeValues:=New RouteValueDictionary(redirectDictionary))
            End Try
        End If

    End Sub

End Class
