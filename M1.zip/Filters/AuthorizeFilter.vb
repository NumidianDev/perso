﻿Imports E_Trade.Data
Imports WebMatrix.WebData

Public Class AuthorizeFilter
    Inherits AuthorizeAttribute

    Private Shared logger As log4net.ILog
    Private actionName As String
    Private controllerName As String

    Public Overrides Sub OnAuthorization(filterContext As AuthorizationContext)
        logger = log4net.LogManager.GetLogger(filterContext.ActionDescriptor.ControllerDescriptor.ControllerType)
        actionName = filterContext.ActionDescriptor.ActionName
        controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName
        logger.Debug("In Controller  " + controllerName + " : Action " + actionName)
        MyBase.OnAuthorization(filterContext)
    End Sub

    Protected Overrides Function AuthorizeCore(httpContext As HttpContextBase) As Boolean

        If Not httpContext.User.Identity.IsAuthenticated Then
            logger.Fatal(actionName & " | Utilisateur non authorisé " & httpContext.User.Identity.Name)
            Return False
        End If

        Dim db As Data.DB = New Data.DB()

        logger.Debug("AuthorizeCore  : POST DB")

        Try
            Dim sessionCOAB As Data.COAB = db.COABS.Find(WebSecurity.GetUserId(httpContext.User.Identity.Name))
            If sessionCOAB Is Nothing Then
                Return False
            Else
                Dim moduleInPackage As Modules
                If controllerName.ToLower().Equals("coab") Then
                    Return sessionCOAB.COAB_Profil.Id = 1
                End If
                moduleInPackage = sessionCOAB.Souscription.Package.Modules.Where(Function(m) (m.Libelle + "s").ToLower().Equals(controllerName.ToLower())).FirstOrDefault()
                If moduleInPackage Is Nothing Then
                    Return controllerName.ToLower.Equals("home") OrElse controllerName.ToLower().Equals("predom") OrElse controllerName.ToLower().Equals("upload")
                Else Return True
                End If
            End If
        Catch ex As Exception
            logger.Error("AuthorizeCore Error : " + ex.Message)
            Return False
        End Try

    End Function

    Protected Overrides Sub HandleUnauthorizedRequest(filterContext As AuthorizationContext)
        If filterContext.HttpContext.User.Identity.IsAuthenticated Then
            Dim redirectDictionary As RouteValueDictionary = New RouteValueDictionary()
            redirectDictionary.Add("action", "Index")
            redirectDictionary.Add("controller", "Home")
            filterContext.Result = New RedirectToRouteResult(redirectDictionary)
        Else
            logger.Error("HandleUnauthorizedRequest Default")
            MyBase.HandleUnauthorizedRequest(filterContext)
        End If
    End Sub
End Class
