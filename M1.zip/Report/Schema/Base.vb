﻿

Partial Public Class Base
End Class
