﻿Imports System.Web
Imports System.Web.Optimization

Public Class BundleConfig
    ' For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
    Public Shared Sub RegisterBundles(ByVal bundles As BundleCollection)

        '~/Scripts/jquery/jquery-{version}.js

        bundles.Add(New ScriptBundle("~/bundles/jqueryIE789").Include(
                   "~/Scripts/jquery/IE_678/jquery-{version}.js"))

        bundles.Add(New ScriptBundle("~/bundles/jquery").Include(
                   "~/Scripts/jquery/jquery-{version}.js"))

        '
        bundles.Add(New ScriptBundle("~/bundles/baseJS").Include( _
                   "~/Scripts/moment/moment.js", _
                   "~/Scripts/jquery/jquery-ui.js", _
                   "~/Scripts/jquery/IE_678/jquery.validate.js", _
                   "~/Scripts/jquery/IE_678/jquery.validate.unobtrusive.js", _
                   "~/Scripts/conditionnal-validate.js", _
                   "~/Scripts/typeahead/typeahead.bundle.js", _
                   "~/Scripts/app.js", _
                   "~/Scripts/ToWords.js"))

        bundles.Add(New ScriptBundle("~/bundles/unobtrusive").Include(
                  "~/Scripts/jquery/jquery.unobtrusive-ajax.js"))

        bundles.Add(New ScriptBundle("~/bundles/IEJS").Include(
                   "~/Scripts/html5shiv.js", _
                   "~/Scripts/respond.js"))

        bundles.Add(New ScriptBundle("~/bundles/bsJs").Include(
                   "~/Scripts/bootstrap/bootstrap.js", _
                   "~/Scripts/bootstrap-datetimepicker/bootstrap-datetimepicker.js"))

        bundles.Add(New ScriptBundle("~/bundles/messagesJs").Include(
                   "~/Scripts/bootbox.js", _
                   "~/Scripts/summernote.js"))

        bundles.Add(New ScriptBundle("~/bundles/dt").Include(
                   "~/Scripts/jquery.dataTables.js"))

        bundles.Add(New ScriptBundle("~/bundles/passMapJs").Include(
                    "~/Scripts/jquery-ui.js",
                   "~/Scripts/SgPassMap.js", _
                   "~/Scripts/SgaPassPicker.js"))

        bundles.Add(New ScriptBundle("~/bundles/MvcGridJs").Include(
                   "~/Scripts/gridmvc.js", "~/Content/datepicker/bootstrap-datepicker.js"))

        bundles.Add(New ScriptBundle("~/bundles/select2").Include(
                           "~/Scripts/Select2/select2.js", _
                           "~/Scripts/Select2/select2_locale_fr.js"))

        bundles.Add(New ScriptBundle("~/bundles/FileUpload").Include(
                    "~/Scripts/tmpl.js", _
                    "~/Scripts/SgaTemplates.tmpl", _
                    "~/Scripts/jquery-fileupload/jquery.iframe-transport.js", _
                    "~/Scripts/jquery-fileupload/jquery.fileupload.js", _
                    "~/Scripts/jquery-fileupload/jquery.fileupload-process.js", _
                    "~/Scripts/jquery-fileupload/jquery.fileupload-validate.js", _
                    "~/Scripts/jquery-fileupload/jquery.fileupload-ui.js"))

        bundles.Add(New ScriptBundle("~/bundles/formJs").Include(
                   "~/Scripts/bootstrap-switch/bootstrap-switch.js"))

        bundles.Add(New ScriptBundle("~/bundles/jqueryval").Include(
                    "~/Scripts/jquery/jquery.validate*"))

        bundles.Add(New StyleBundle("~/Content/loginCss").Include("~/Content/login/main.css", _
                                                              "~/Content/login/login.css", _
                                                              "~/Content/login/ie6.css"))

        bundles.Add(New StyleBundle("~/Content/passMapIE8").Include("~/Content/PassMap-IE8.css"))

        bundles.Add(New StyleBundle("~/Content/css").Include("~/Content/bootstrap.css",
                                                             "~/Content/bootstrap-multiselect.css",
                                                             "~/Content/navbar-fixed-top.css",
                                                             "~/Content/bootstrap-theme.css",
                                                             "~/Content/font-awesome.css",
                                                             "~/Content/timeline.css"))

        bundles.Add(New StyleBundle("~/Content/formcss").Include("~/Content/bootstrap-switch.css", _
                                                                 "~/Content/bootstrap-datetimepicker.css", _
                                                                 "~/Content/summernote.css"))

        bundles.Add(New StyleBundle("~/Content/maincss").Include("~/Content/Site.css",
                                                                 "~/Content/MKT.css"))

        bundles.Add(New StyleBundle("~/Content/maincssexceptIE8").Include("~/Content/IE679_10_inline.css"))

        bundles.Add(New StyleBundle("~/Content/select2").Include("~/Content/select2.css", _
                                                                 "~/Content/select2-bootstrap.css"))

        bundles.Add(New StyleBundle("~/Content/dtcss").Include("~/Content/jquery.dataTables.css"))

        bundles.Add(New StyleBundle("~/Content/MvcGridCss").Include("~/Content/Gridmvc.css", "~/Content/datepicker/gridmvc.datepicker.css"))


        BundleTable.EnableOptimizations = False
    End Sub
End Class