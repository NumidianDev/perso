﻿Imports System.Data.Entity
Imports E_Trade.Data
Imports WebMatrix.WebData
Imports System.Data.Entity.Validation
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports System.Threading.Thread

Public Class RemdocsController
    Inherits BaseController

    '
    ' GET: /Remdoc/
    Function Index(Optional ByVal encours As Boolean = True) As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim remdoc As IList(Of Remdoc)
        ViewBag.Encours = encours
        If encours Then
            remdoc = db.Remdoc.Include(Function(r) r.StatutRemdoc).Include(Function(r) r.Client).Include(Function(r) r.Agence).Include(Function(r) r.Souscription).Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutRemdoc <> 3 AndAlso c.Id_StatutRemdoc <> 8 AndAlso c.Id_StatutRemdoc <> 9)).ToList
        Else
            remdoc = db.Remdoc.Include(Function(r) r.StatutRemdoc).Include(Function(r) r.Client).Include(Function(r) r.Agence).Include(Function(r) r.Souscription).Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutRemdoc = 3 OrElse c.Id_StatutRemdoc = 8 OrElse c.Id_StatutRemdoc = 9)).ToList
        End If

        Return View(remdoc.OrderByDescending(Function(c) c.Id))
    End Function

    Function Reportings() As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim remdoc = db.Remdoc.Include(Function(r) r.StatutRemdoc).Include(Function(r) r.Client).Include(Function(r) r.Agence).Include(Function(r) r.Souscription).Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription)
        Return View(remdoc.ToList().OrderByDescending(Function(c) c.Id))

    End Function

    '
    ' GET: /Remdoc/Edit/5

    Function Details(Optional ByVal id As Integer = Nothing) As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim remdoc As Remdoc = db.Remdoc.Find(id)
        If IsNothing(remdoc) Then
            Return HttpNotFound()
        End If

        If remdoc.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If

        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle", remdoc.Id_StatutRemdoc)
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient)).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle", remdoc.Age_Agence)
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie", remdoc.Id_Souscription)

        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))
        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "CODE", "REF", remdoc.Devise)
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME")
        ViewBag.Ncp_Compte = New SelectList(db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(remdoc.Age_Agence) AndAlso cpt.Radical_Client.Equals(RadicalClient)), "Ncp", "DisplayString", remdoc.Ncp_Compte)
        Return View(remdoc)

    End Function

    Function Echange(Optional ByVal id As Integer = Nothing) As ActionResult

        Dim remdoc As Remdoc = db.Remdoc.Find(id)

        If IsNothing(remdoc) Then
            Return HttpNotFound()
        End If

        If remdoc.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If

        ViewBag.ObjectId = remdoc.Id
        ViewBag.Operation = "RDI"

        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle", remdoc.Id_StatutRemdoc)
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient)).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle", remdoc.Age_Agence)
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie", remdoc.Id_Souscription)

        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))
        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "CODE", "REF", remdoc.Devise)
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME")
        ViewBag.Ncp_Compte = New SelectList(db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(remdoc.Age_Agence) AndAlso cpt.Radical_Client.Equals(RadicalClient)), "Ncp", "DisplayString", remdoc.Ncp_Compte)
        ViewBag.id = id
        Return View(remdoc)

    End Function

#Region "reports"

    Function DDomiciliation(Optional ByVal id As Integer = Nothing) As ActionResult
        Dim remdoc As Remdoc = db.Remdoc.Find(id)
        If IsNothing(remdoc) Then
            Return HttpNotFound()
        End If
        Return PartialView("DDomiciliation", remdoc)
    End Function

    Function Print_Dom(ByVal Id As Integer, _
                       Activite As String, _
                       Adr_Fournisseur As String, _
                       NomBeneficiaire As String, _
                       Proformat As String, _
                       Proformat_Date As String, _
                       March_Importe As String, _
                       TarifDouanier As String, _
                       Nature_Produit As String, _
                       Quantite As String, _
                       Prix_Unitaire As String, _
                       Montant_Global As String, _
                       Signataire As String, _
                       Sign_Qualite As String, _
                       Sign_Date As String, _
                       Sign_Lieu As String
                       ) As ActionResult

        Dim errMessage As String = String.Empty

        Dim remdoc As Remdoc = db.Remdoc.Find(Id)
        If Not IsNothing(remdoc) Then
            Try
                remdoc.AdresseBeneficiaire = Adr_Fournisseur.Trim()
                remdoc.NomBeneficiaire = NomBeneficiaire.Trim
                remdoc.Activite = Activite.Trim()
                remdoc.Facture = Proformat.Trim()
                remdoc.DateFacture = Proformat_Date.Trim()
                remdoc.DescriptionMarchandise = March_Importe.Trim()
                remdoc.TarifDouanier = TarifDouanier.Trim
                remdoc.NatureProduit = Nature_Produit.Trim()
                remdoc.Qte = Quantite.Trim()
                remdoc.PrixUnit = Prix_Unitaire.Trim
                remdoc.Signataire = Signataire
                remdoc.QualtSignataire = Sign_Qualite
                remdoc.Client = Nothing

                db.Entry(remdoc).State = EntityState.Modified
                db.SaveChanges()
                Me.HttpContext.Session("Sign_Date") = Sign_Date
                Me.HttpContext.Session("Sign_Lieu") = Sign_Lieu

                Return Json(New With {.result = "OK"}, JsonRequestBehavior.AllowGet)
            Catch dbEx As Validation.DbEntityValidationException

                If dbEx.EntityValidationErrors.Count > 0 Then
                    Dim sb As StringBuilder = New StringBuilder()

                    For Each [error] In From validationErrors In dbEx.EntityValidationErrors
                                            From validationError In validationErrors.ValidationErrors
                                                Select New With {.PropertyName = validationError.PropertyName,
                                                                 .ErrorMessage = validationError.ErrorMessage,
                                                                 .ClassFullName = validationErrors.Entry.Entity.GetType().FullName}

                        sb.Append("<div class=""bs-callout bs-callout-danger"">")
                        sb.Append("<h4>" & [error].PropertyName & "</h4>")
                        sb.Append("<p>" & [error].ErrorMessage & "</p>")
                        sb.Append("</div>")

                    Next

                    errMessage = sb.ToString
                End If
                
                Return Json(New With {.result = "KO", .Message = errMessage}, JsonRequestBehavior.AllowGet)
            End Try
            
        End If

    End Function

    Sub rptDom(ByVal Id As Integer)

        Dim remdoc As Remdoc = db.Remdoc.Find(Id)

        If Not IsNothing(remdoc) Then

            Dim listRemdoc As IList(Of Remdoc) = New List(Of Remdoc)
            Dim listAgences As IList(Of Agence) = New List(Of Agence)
            Dim listClients As IList(Of Client) = New List(Of Client)
            Dim listComptes As IList(Of Compte) = New List(Of Compte)

            Dim ds As DataSet = New DataSet
            ds.ReadXmlSchema(Server.MapPath("~\Report\Schema\Base.xsd"))

            listRemdoc.Add(remdoc)
            listAgences.Add(remdoc.Agence)
            listClients.Add(remdoc.Client)
            listComptes.Add(db.Comptes.Where(Function(c) c.Age_Agence = remdoc.Age_Agence AndAlso c.Ncp = remdoc.Ncp_Compte).FirstOrDefault)

            UtilityFunctions.EntityToDataSet(Of Agence)(ds, listAgences)
            UtilityFunctions.EntityToDataSet(Of Client)(ds, listClients)
            UtilityFunctions.EntityToDataSet(Of Remdoc)(ds, listRemdoc)
            UtilityFunctions.EntityToDataSet(Of Compte)(ds, listComptes)

            'Dim Sign_Date As String = Me.HttpContext.Session("Sign_Date")
            'Dim Sign_Lieu As String = Me.HttpContext.Session("Sign_Lieu")

            Dim report As ReportDocument = New ReportDocument()
            report.Load(Server.MapPath("~\Report\RDI\DOM_ENG_REMDOC.rpt"))
            report.SetDataSource(ds)

            'Dim rd As ReportDocument = New ReportDocument()
            'Dim strRptPath As String = System.Web.HttpContext.Current.Server.MapPath("~/") + "Report//RDI//DOM_ENG_REMDOC.rpt"
            'rd.Load(strRptPath)


            'rd.SetParameterValue("RS", IIf(Not IsNothing(remdoc.Client.RS), remdoc.Client.RS, ""))
            'rd.SetParameterValue("Adresse", IIf(Not IsNothing(remdoc.Client.Adresse), remdoc.Client.Adresse, ""))
            'rd.SetParameterValue("RC", IIf(Not IsNothing(remdoc.Client.RC), remdoc.Client.RC, ""))
            'rd.SetParameterValue("NIDF", IIf(Not IsNothing(remdoc.Client.NIDF), remdoc.Client.NIDF, ""))
            'rd.SetParameterValue("NCP", IIf(Not IsNothing(remdoc.Ncp_Compte), remdoc.Ncp_Compte, ""))
            'rd.SetParameterValue("Type_Remise", IIf(Not IsNothing(remdoc.TypeRemise), remdoc.TypeRemise, ""))
            'rd.SetParameterValue("Montant_Global", IIf(Not IsNothing(remdoc.Montant), remdoc.Montant, ""))
            'rd.SetParameterValue("Devise", IIf(Not IsNothing(remdoc.Devise), remdoc.Devise, ""))

            'rd.SetParameterValue("Activite", IIf(Not IsNothing(remdoc.Activite), remdoc.Activite, ""))
            'rd.SetParameterValue("Qualite", IIf(Not IsNothing(remdoc.QualtSignataire), remdoc.QualtSignataire, ""))
            'rd.SetParameterValue("Fournisseur", IIf(Not IsNothing(remdoc.NomBeneficiaire), remdoc.NomBeneficiaire, ""))
            'rd.SetParameterValue("Adr_Fournisseur", IIf(Not IsNothing(remdoc.AdresseBeneficiaire), remdoc.AdresseBeneficiaire, ""))
            'rd.SetParameterValue("Proformat", IIf(Not IsNothing(remdoc.Facture), remdoc.Facture, ""))
            'rd.SetParameterValue("Proformat_Date", IIf(Not IsNothing(remdoc.DateFacture), remdoc.DateFacture, ""))
            'rd.SetParameterValue("March_Importe", IIf(Not IsNothing(remdoc.DescriptionMarchandise), remdoc.DescriptionMarchandise, ""))
            'rd.SetParameterValue("Tarif_Douanier", IIf(Not IsNothing(remdoc.TarifDouanier), remdoc.TarifDouanier, ""))
            'rd.SetParameterValue("Nature_Produit", IIf(Not IsNothing(remdoc.NatureProduit), remdoc.NatureProduit, ""))
            'rd.SetParameterValue("Quantite", IIf(Not IsNothing(remdoc.Qte), remdoc.Qte, ""))
            'rd.SetParameterValue("Prix_Unitaire", IIf(Not IsNothing(remdoc.PrixUnit), remdoc.PrixUnit, ""))

            'rd.SetParameterValue("Signateur", IIf(Not IsNothing(remdoc.Signataire), remdoc.Signataire, ""))
            'rd.SetParameterValue("Sign_Date", Sign_Date)
            'rd.SetParameterValue("Sign_Lieu", Sign_Lieu)
            Try
                report.ExportToHttpResponse(ExportFormatType.PortableDocFormat, System.Web.HttpContext.Current.Response, False, "crReport")
            Catch ex As Exception
                LogException(ex.Message)
            End Try

        End If

    End Sub


#End Region

End Class
