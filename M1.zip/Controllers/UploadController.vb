﻿Imports System.IO
Imports E_Trade.Data


Public Class UploadController
    Inherits BaseController
    '
    ' GET: /Dossier
    Private ReadOnly Property StorageRoot(ByVal Id As Integer) As String
        Get
            Dim d = db.PreDom_Dossier.Find(Id)
            Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, d.Radical, d.Modalite_paiement, d.Id)
            If (Not System.IO.Directory.Exists(filePath)) Then
                MkDir(filePath)
            End If
            Return filePath
        End Get
    End Property
    Function Document(ByVal Id As Integer?) As ActionResult
        ViewBag.Dossier = Id
        ViewBag.ListDoc = getListDoc(Id)
        Return PartialView("~/Views/Upload/Upload.vbhtml")
    End Function
    Function ListFiles(ByVal Id As Integer?) As ActionResult
        ViewBag.Dossier = Id
        Return PartialView()
    End Function
    Function Attacher(ByVal Id As Integer?) As ActionResult
        ViewBag.Dossier = Id
        Return PartialView()
    End Function
    <HttpGet>
    Function Delete(ByVal Dossier As Integer, ByVal id As String) As Integer
        Dim d = db.PreDom_Dossier.Find(Dossier)
        Dim Dir = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, d.Radical, d.Modalite_paiement, d.Id)
        Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, d.Radical, d.Modalite_paiement, d.Id, id)
        Dim cnt As Integer = System.IO.Directory.GetFiles(Dir).Length
        If (System.IO.File.Exists(filePath)) Then
            System.IO.File.Delete(filePath)
        End If
        Return Dossier
    End Function
    <HttpGet>
    Sub Download(ByVal Dossier As Integer, ByVal id As String)
        Dim filename = id
        Dim d = db.PreDom_Dossier.Find(Dossier)
        Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, d.Radical, d.Modalite_paiement, d.Id)
        Dim context = HttpContext
        If (System.IO.File.Exists(filePath)) Then
            context.Response.AddHeader("Content-Disposition", "attachment; filename=""" & filename & """")
            context.Response.ContentType = "application/octet-stream"
            context.Response.ClearContent()
            context.Response.WriteFile(filePath)
        Else
            context.Response.StatusCode = 404
        End If
    End Sub
    Private Function EncodeFile(fileName As String) As String

        Return Convert.ToBase64String(System.IO.File.ReadAllBytes(fileName))
    End Function
    <HttpPost>
    Public Function UploadFiles(ByVal Id As String) As ActionResult

        Dim r = New List(Of UploadFiles)()
        For Each f In Request.Files
            Dim statuses = New List(Of UploadFiles)()
            Dim headers = Request.Headers

            If (String.IsNullOrEmpty(headers("X-File-Name"))) Then
                UploadWholeFile(Request, Id, statuses)

            Else
                UploadPartialFile(headers("X-File-Name"), Request, Id, statuses)
            End If
            Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
            result.ContentType = "text/plain"
            Return result
        Next

        Return Json(r)
    End Function
    Function UploadList(ByVal Id As Integer) As ActionResult
        ViewBag.Dossier = Id
        Return PartialView()
    End Function
    Function UploadMsg(ByVal Id As Integer) As ActionResult
        ViewBag.Dossier = Id
        Return PartialView()
    End Function
    <HttpPost>
    Public Function FilesUploaded(ByVal Id As Integer) As ActionResult
        Dim d = db.PreDom_Dossier.Find(Id)
        Dim statuses = New List(Of UploadFiles)()
        Dim Chemin As String, Fichier As String
        Chemin = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, d.Radical, d.Modalite_paiement, d.Id)
        Fichier = Dir(Chemin & "\*.*")
        Do While Len(Fichier) > 0
            Dim info As New FileInfo(Path.Combine(Chemin, Fichier))
            Dim length As Long = info.Length

            statuses.Add(New UploadFiles() With
        {
            .name = Fichier,
            .size = info.Length,
            .date_creation = info.CreationTime,
            .type = info.Extension,
            .thumbnail = "Facture pro format ou contrat commercial",
            .Id = Id
        })
            Fichier = Dir()
        Loop
        Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
        result.ContentType = "text/plain"
        Return result


        Return Json(statuses, JsonRequestBehavior.AllowGet)
    End Function

    Private Sub UploadPartialFile(fileName As String, request As HttpRequestBase, Id As String, statuses As List(Of UploadFiles))

        If (Not request.Files.Count = 1) Then
            Throw New HttpRequestValidationException("Attempt to upload chunked file containing more than one fragment per request")
        End If
        Dim file = request.Files(0)
        Dim inputStream = file.InputStream

        Dim fullName = Path.Combine(StorageRoot(Id), Path.GetFileName(fileName))
        Dim fs = New FileStream(fullName, FileMode.Append, FileAccess.Write)
        Using (fs)
            Dim buffer = New Byte(1024) {}
            Dim l = inputStream.Read(buffer, 0, 1024)
            While (l > 0)

                fs.Write(buffer, 0, l)
                l = inputStream.Read(buffer, 0, 1024)
            End While
            fs.Flush()
            fs.Close()
        End Using
        statuses.Add(New UploadFiles() With
        {
            .name = fileName,
            .size = file.ContentLength,
            .Id = Id,
            .type = file.ContentType,
            .url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & "/Dossier/Download/" & fileName,
            .delete_url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & "/Dossier/Delete/" & fileName,
            .thumbnail = "data:image/png;base64," & EncodeFile(fullName),
        .delete_type = "GET"
        })
    End Sub

    Private Sub UploadWholeFile(request As HttpRequestBase, Id As String, statuses As List(Of UploadFiles))
        Try
            For i As Integer = 0 To request.Files.Count - 1
                Dim file = request.Files(i)
                Dim fullPath = Path.Combine(StorageRoot(Id), Path.GetFileName(file.FileName))
                file.SaveAs(fullPath)
                statuses.Add(New UploadFiles() With
                {
                    .name = file.FileName,
                    .size = file.ContentLength,
                    .Id = Id,
                    .type = file.ContentType,
                    .url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & "/Dossier/Download/" & file.FileName,
                    .delete_url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & Url.Action("Delete", "Dossier", New With {.Id = file.FileName}),
                    .thumbnail = "data:image/png;base64," & EncodeFile(fullPath),
                    .delete_type = "GET"
                })
            Next
        Catch ex As Exception

        End Try
    End Sub
    Function Index() As ActionResult
        Return View()
    End Function
    ' get select doc by modalite de paiment
    Function getSelectDoc(ByVal id As Integer) As String
        'Dim mp = db.PreDom_Dossier.Find(id).Modalite_paiement
        'Dim _doc = (From dt In db.PreDom_DocumentTypes _
        '            Where dt.Code_mp.Equals(CStr(mp))
        '            Select dt).ToList
        'Dim _s As String = "<select class='input-sm span2 required'>"
        '_s = _s + "<option value=''>A sélectionner </option>"
        'For Each z In _doc
        '    _s = _s + "<option value='" + z.Code + "'> " + z.Libelle + " </option>"
        'Next
        '_s = _s + "</select>"
        Return "Demande de domiciliation"
    End Function
    Function getListDoc(ByVal id As Integer) As List(Of PreDom_DocumentTypes)
        Dim mp = db.PreDom_Dossier.Find(id).Modalite_paiement
        Dim _doc = (From dt In db.PreDom_DocumentTypes _
                    Where dt.Code_mp.Equals(CStr(mp))
                    Select dt)
        Return _doc.ToList
    End Function

End Class