﻿Imports System.Data.Entity
Imports E_Trade.Data
Imports WebMatrix.WebData
Imports System.Data.Entity.Validation
Imports System.IO


Public Class MeetingController
    Inherits BaseController
    '
    ' GET: /Meeting
    Function Index(ByVal id As Integer) As ActionResult
        Dim p = db.PreDom_Dossier.Find(id)
        If IsNothing(p) Then
            Return HttpNotFound()
        End If
        ViewBag.stat = p.Statut
        Try
            Dim o = db.PreDom_Commentaires.Where(Function(m) m.IdCible.Equals(id)).ToList
            Return PartialView(o)
        Catch ex As Exception
            ViewBag.stat = ex.Message
        End Try

        Return PartialView()
    End Function

    Function Dialog(ByVal id As Integer) As ActionResult
        ViewBag.Id = id
        Return PartialView()
    End Function

    Sub CleanTemp()
        Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, "Temp")
        Dim nb As Integer = 1
        Dim dir As New DirectoryInfo(filePath)
        For Each myFile In dir.GetFiles("*.*")
            If DateDiff("d", myFile.LastAccessTime, Now) >= nb Then
                myFile.Delete()
            End If
        Next myFile
    End Sub

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Dialog(ByVal comments As PreDom_Commentaires, ByVal Fichier As IList(Of String)) As ActionResult
        Try
            Dim dossier = db.PreDom_Dossier.Find(comments.IdCible)
            Dim mailAgence = db.Agences.Where(Function(a) a.Age.Contains(dossier.Agence)).FirstOrDefault().Emails
            If dossier.Statut <> 3 Then
                Return Json(New With {.result = "ko", .message = "Le statut de votre dossier doit etre en complèment d'infos "}, JsonRequestBehavior.AllowGet)
            End If
            If String.IsNullOrEmpty(comments.Message) Then
                Return Json(New With {.result = "ko", .message = "Veuillez ajouter un commentaire"}, JsonRequestBehavior.AllowGet)
            End If
            Dim _from As String = db.Parametres.Where(Function(p) p.Param.Contains("EtradeMailerAdress")).FirstOrDefault().Value
            Dim _Objet As String = db.Parametres.Where(Function(p) p.Param.Contains("ObjetMailerPredom")).FirstOrDefault().Value
            Dim d = db.PreDom_Dossier.Find(comments.IdCible)
            Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, "Temp")
            comments.Operation = db.PreDom_Dossier.Find(comments.IdCible).Modalite_paiement.ToString()
            comments.DateSaisie = String.Format("{0:dd/MM/yyyy HH:mm:ss}", DateTime.Now)
            comments.Source = "C"
            comments.Message = HttpUtility.HtmlEncode(comments.Message)
            If ModelState.IsValid Then
                db.PreDom_Commentaires.Add(comments)
                db.SaveChanges()
                SendMail(mailAgence, _from, _Objet, comments.Message, Nothing, "", filePath, Fichier)
            End If
            CleanTemp()
        Catch ex As Exception
            Return Json(New With {.result = "ko", .message = ex.Message}, JsonRequestBehavior.AllowGet)
        End Try

        Return Json(New With {.result = "ok", .message = "Message envoyé !"}, JsonRequestBehavior.AllowGet)
    End Function

    <HttpPost>
    Public Function UploadFiles(ByVal Id As String) As ActionResult

        Dim r = New List(Of UploadFiles)()
        For Each f In Request.Files
            Dim statuses = New List(Of UploadFiles)()
            Dim headers = Request.Headers

            If (String.IsNullOrEmpty(headers("X-File-Name"))) Then
                UploadWholeFile(Request, Id, statuses)
            End If
            Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
            result.ContentType = "text/plain"
            Return result
        Next

        Return Json(r)
    End Function
    Private ReadOnly Property Root() As String
        Get
            Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, "Temp")
            If (Not System.IO.Directory.Exists(filePath)) Then
                MkDir(filePath)
            End If
            Return filePath
        End Get
    End Property
    Private Function EncodeFile(fileName As String) As String

        Return Convert.ToBase64String(System.IO.File.ReadAllBytes(fileName))
    End Function
    Private Sub UploadWholeFile(request As HttpRequestBase, Id As String, statuses As List(Of UploadFiles))
        Try
            For i As Integer = 0 To request.Files.Count - 1
                Dim file = request.Files(i)
                Dim fullPath = Path.Combine(Root(), Path.GetFileName(file.FileName))
                file.SaveAs(fullPath)
                statuses.Add(New UploadFiles() With
                {
                    .name = file.FileName,
                    .size = file.ContentLength,
                    .Id = Id,
                    .type = file.ContentType,
                    .url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & "/Dossier/Download/" & file.FileName,
                    .delete_url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & Url.Action("Delete", "Dossier", New With {.Id = file.FileName}),
                    .thumbnail = "data:image/png;base64," & EncodeFile(fullPath),
                    .delete_type = "GET"
                })
            Next
        Catch ex As Exception

        End Try
    End Sub
    <HttpGet>
    Function Delete(ByVal Dossier As Integer, ByVal id As String) As Integer
        Dim d = db.PreDom_Dossier.Find(Dossier)
        Dim Dir = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, "Temp")
        Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, "Temp", id)
        Dim cnt As Integer = System.IO.Directory.GetFiles(Dir).Length
        If (System.IO.File.Exists(filePath)) Then
            System.IO.File.Delete(filePath)
        End If
        Return Dossier
    End Function
    <HttpGet>
    Sub Download(ByVal Dossier As Integer, ByVal id As String)
        Dim filename = id
        Dim d = db.PreDom_Dossier.Find(Dossier)
        Dim filePath = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, "Temp", id)
        Dim context = HttpContext
        If (System.IO.File.Exists(filePath)) Then
            context.Response.AddHeader("Content-Disposition", "attachment; filename=""" & filename & """")
            context.Response.ContentType = "application/octet-stream"
            context.Response.ClearContent()
            context.Response.WriteFile(filePath)
        Else
            context.Response.StatusCode = 404
        End If
    End Sub
    Public Sub SendMail(ByVal destinataire As String, ByVal Expediteur As String, ByVal sujet As String, ByVal text As String, Optional ByVal dnFrom As String = "PREDOM@socgen.com", Optional ByVal CC As String = "", Optional filePath As String = Nothing, Optional Fichier As IList(Of String) = Nothing)
        Dim db As DB = New DB
        Dim s As IList(Of Integer) = Nothing
        Dim objMessage As System.Net.Mail.MailMessage
        Dim objAdrExp As System.Net.Mail.MailAddress
        Dim objAdrRec As System.Net.Mail.MailAddress
        Dim objSMTPClient As System.Net.Mail.SmtpClient
        Dim attachment As System.Net.Mail.Attachment
        Dim smtp As String = db.Parametres.Where(Function(m) m.Param.Equals("SMTPSERVER")).FirstOrDefault().Value

        Try
            objMessage = New System.Net.Mail.MailMessage()
            objAdrExp = New System.Net.Mail.MailAddress(Expediteur.Trim)
            objAdrRec = New System.Net.Mail.MailAddress(destinataire.Trim)
            objMessage.From = objAdrExp
            '----------
            If Not IsNothing(Fichier) AndAlso Fichier.Count > 0 Then
                For Each f In Fichier
                    attachment = New System.Net.Mail.Attachment(Path.Combine(filePath, CStr(f.ToString)))
                    objMessage.Attachments.Add(attachment)
                Next
            End If
            '-----------
            objMessage.To.Add(objAdrRec)
            objMessage.IsBodyHtml = True
            objMessage.Subject = sujet
            objMessage.Body = text
            objSMTPClient = New System.Net.Mail.SmtpClient(smtp)
            objSMTPClient.EnableSsl = False
            objSMTPClient.Port = 25
            objSMTPClient.Send(objMessage)
        Catch ex As Exception

        End Try
    End Sub
End Class