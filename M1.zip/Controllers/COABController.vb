﻿Imports System.Data.Entity
Imports WebMatrix.WebData
Imports E_Trade.Data

Namespace E_Trade.Web
    Public Class COABController
        Inherits BaseController
        '
        ' GET: /COAB/

        Function Index() As ActionResult
            Dim coabs = db.COABS.Include(Function(c) c.Souscription).Include(Function(c) c.COAB_Profil).Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription)
            Return View(coabs.ToList())
        End Function


        <HttpPost()> _
        Function ResetPwd(ByVal id As Integer) As ActionResult
            Dim _email As String = String.Empty
            Dim _newPWD As String = String.Empty
            Dim _coabName As String = String.Empty
            Try
                Dim smtpServer As String = db.Parametres.Where(Function(p) p.Param.Equals("SMTPSERVER")).FirstOrDefault().Value
                Dim afrom As String = db.Parametres.Where(Function(p) p.Param.Equals("EtradeMailerAdress")).FirstOrDefault.Value
                Dim dnfrom As String = db.Parametres.Where(Function(p) p.Param.Equals("EtradeMailerDisplayName")).FirstOrDefault.Value
                Dim cab As COAB = db.COABS.Where(Function(ca) ca.Id = id).FirstOrDefault
                _email = cab.Email
                _coabName = cab.Nom & " " & cab.Prenom
                _newPWD = SecurityUtils.CreateRandomPassword()
                WebSecurity.ResetPassword(_email, _newPWD)
                UtilityFunctions.SendMailMultipleAttachments(afrom, _email, "Réinitialisation de votre mot de passe Sg@Trade", "Votre mot de passe Sg@Trade a été réinitialisé : " & _newPWD, dnFrom:=dnfrom, SMTPServer:=smtpServer)
                Return (Json("Le nouveau mot de passe a été notifié par e-mail au coabonné " & _coabName, JsonRequestBehavior.AllowGet))
            Catch ex As Exception
                LogException("Problème a la réinitialisation du mot de passe du co-abonné " & _email)
                LogException(ex.Message)
                LogException("Stack trace .................... ")
                LogException(ex.StackTrace)
                If ex.InnerException IsNot Nothing Then
                    LogException("Inner Exception .................... ")
                    LogException(ex.InnerException.Message)
                    LogException("Inner stack trace .................... ")
                    LogException(ex.StackTrace)
                End If
            End Try
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            db.Dispose()
            MyBase.Dispose(disposing)
        End Sub

    End Class
End Namespace