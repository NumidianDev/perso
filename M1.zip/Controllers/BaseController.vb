﻿Imports E_Trade.Data
Imports System.IO
Imports System.Web.Script.Serialization
Imports E_Trade.Web.UtilityFunctions
Imports WebMatrix.WebData
Imports Newtonsoft.Json

<SgaSecurityActionFilter()>
Public Class BaseController
    Inherits System.Web.Mvc.Controller

    Protected Friend db As DB
    Protected Friend sessionCOAB As COAB

    Protected Overrides Sub Initialize(requestContext As System.Web.Routing.RequestContext)

        MyBase.Initialize(requestContext)

        If User.Identity.IsAuthenticated Then
            If AccountController.GetUserId(User.Identity.Name) = -1 Then
                AccountController.Quit()
                RedirectToAction("Index", "Home")
            End If
        End If

        ViewBag.ObjectId = -1
        ViewBag.Operation = String.Empty

        db = New DB()

        Try
            sessionCOAB = db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name))
        Catch ex As Exception
            sessionCOAB = Nothing
        End Try

        If sessionCOAB IsNot Nothing Then
            ViewBag.IsPrincipale = sessionCOAB.Id_COAB_Profil = 1
            ViewBag.IsSaisie = ViewBag.IsPrincipale OrElse sessionCOAB.Id_COAB_Profil = 2
            ViewBag.IsSaisieOnly = sessionCOAB.Id_COAB_Profil = 2
            ViewBag.IsConsult = ViewBag.IsSaisie OrElse sessionCOAB.Id_COAB_Profil = 3
            ViewBag.IsConsultOnly = sessionCOAB.Id_COAB_Profil = 3
        Else
            ViewBag.IsPrincipale = False
            ViewBag.IsSaisie = False
            ViewBag.IsConsult = False
            ViewBag.IsConsultOnly = False
            ViewBag.IsSaisieOnly = False
        End If

    End Sub

    <HttpGet()> _
    Function ComptesByAgenceAndClient(ByVal Agence As String, ByVal Client As String) As JsonResult

        LogInfo("Agence : " & Agence & " # Client : " & Client)
        Dim comptes As IList(Of Compte) = New List(Of Compte)
        LogInfo("Nb Comptes : " & comptes.Count)
        Dim query As String = "select * from Compte " & _
                            " Where Age_Agence = {0} " & _
                            " And Radical_Client = {1} "

        query = String.Format(query, Agence, Client)
        LogInfo("query  : " & query)
        If db Is Nothing Then
            LogException("db est null")
        End If
        Dim res = db.Database.SqlQuery(Of Compte)(query).ToList  'db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(Agence) AndAlso cpt.Radical_Client.Equals(Client)).ToList()

        LogInfo("Nb Comptes : " & res.Count)
        For Each cpt As Compte In res
            LogInfo(cpt.Ncp)
        Next

        Return Json(res, "application/json", Encoding.UTF8, JsonRequestBehavior.AllowGet)

    End Function

    Protected Friend Function GetPredomCount(ByVal encours As Boolean) As Integer
        Try
            Return db.PreDom_Dossier.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription).Count
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Protected Friend Function GetCredocsCount(ByVal encours As Boolean) As Integer
        If encours Then
            Return db.Credoc.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutCredoc < 8 OrElse c.Id_StatutCredoc > 10)).Count
        Else
            Return db.Credoc.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutCredoc >= 8 AndAlso c.Id_StatutCredoc <= 10)).Count
        End If
    End Function

    Protected Friend Function GetAllCredocsCount() As Integer
        Return db.Credoc.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription).Count
    End Function

    Protected Friend Function GetRemdocsCount(ByVal encours As Boolean) As Integer
        If encours Then
            Return db.Remdoc.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutRemdoc <> 3 AndAlso c.Id_StatutRemdoc <> 8 AndAlso c.Id_StatutRemdoc <> 9)).Count
        Else
            Return db.Remdoc.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutRemdoc = 3 OrElse c.Id_StatutRemdoc = 8 OrElse c.Id_StatutRemdoc = 9)).Count
        End If
    End Function

    Protected Friend Function GetAllRemdocsCount() As Integer
        Return db.Remdoc.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription).Count
    End Function

    Friend ReadOnly Property StorageRoot(ByVal operation As OperationType, ByVal IdCible As Int32) As String
        Get

            Dim radical As String = GetRadicalByOperation(operation, IdCible)

            If IdCible = 0 Then
                Throw New Exception("Erreur d'identification du dossier source")
            End If

            If String.IsNullOrEmpty(radical) Then
                Throw New Exception("Erreur d'identification du client")
            End If

            Return UtilityFunctions.GetDossierFileRoot(radical, operation, IdCible)

        End Get

    End Property

    <HttpGet()> _
    Function GetDocumentsType() As JsonResult

        Dim resultat As IList(Of DocumentTypes) = db.DocumentTypes.ToList()

        'Dim result As String
        'Using fs As FileStream = New FileStream(Server.MapPath("~/data/countries.json"), FileMode.Open)
        '    Using sr As StreamReader = New StreamReader(fs)
        '        result = sr.ReadToEnd()
        '    End Using
        'End Using
        'result = result.Substring(1, result.Length - 3)
        'Regex.Split(result, """,""")
        Return Json(resultat, JsonRequestBehavior.AllowGet)
    End Function

    Friend Function OperationResolver(ByVal operation As String) As OperationType

        Dim ope As UtilityFunctions.OperationType

        Select Case operation
            Case "CDI"
                ope = UtilityFunctions.OperationType.CDI
            Case "RDI"
                ope = UtilityFunctions.OperationType.RDI
        End Select

        Return ope

    End Function

    Protected Friend Function GetRadicalByOperation(ByVal operation As OperationType, ByVal IdCible As Int32) As String
        Select Case operation
            Case OperationType.CDI
                Return db.Credoc.Find(IdCible).Radical_Client
            Case OperationType.RDI
                Return db.Remdoc.Find(IdCible).Radical_Client
            Case Else
                Return String.Empty
        End Select
    End Function

    Protected Friend Sub LogSecurityViolation()
        log4net.LogManager.GetLogger(MyBase.GetType).Warn("Messages | Tentative d'accès à un dossier non authorisé | " & sessionCOAB.Nom & " " & sessionCOAB.Prenom & " | " & sessionCOAB.Souscription.Client.RC)
    End Sub

    Protected Friend Sub LogException(ByVal message As String)
        log4net.LogManager.GetLogger(MyBase.GetType).Warn("Messages | " & message & " | " & sessionCOAB.Nom & " " & sessionCOAB.Prenom & " | " & sessionCOAB.Souscription.Client.RC)
    End Sub

    Protected Friend Sub LogInfo(ByVal message As String)
        log4net.LogManager.GetLogger(MyBase.GetType).Info("Messages | " & message) ' & " | " & sessionCOAB.Nom & " " & sessionCOAB.Prenom & " | " & sessionCOAB.Souscription.Client.RC)
    End Sub

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub


End Class
