﻿Imports System.Data.Entity
Imports E_Trade.Data
Imports WebMatrix.WebData
Imports System.Data.Entity.Validation
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Threading.Thread

Public Class PredomController
    Inherits BaseController


    '
    ' GET: /Predom/
    Function Index() As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim o = From d In db.PreDom_Dossier, c In db.Clients
                Where d.Radical.Equals(c.Radical) And d.Id_Souscription.Equals(sessionCOAB.Id_Souscription)
                Order By d.Id Descending
                Select d
        Return View(o.ToList)
    End Function

    Sub setRefPreDom(ByVal id As Integer?)
        Dim ref As String = String.Concat(String.Format("{0:yy}", DateTime.Now), "0000001")
        If Not id Is Nothing Then
            Dim year = String.Format("{0:yy}", DateTime.Now)
            Dim NbMax = db.PreDom_Dossier.Where(Function(m) m.RefPreDOM.StartsWith(year)).Select(Function(m) m.RefPreDOM).ToArray().Max
            ref = If(CInt(NbMax) >= ref, CInt(NbMax + 1).ToString(), ref)
            db.Database.ExecuteSqlCommand(String.Format("Update Predom_Dossier SET RefPreDom = {0} Where Id = {1}", ref, id))
        End If
    End Sub

    '
    ' GET: /Predom/Create

    Function Create() As ActionResult
        'setAgence(sessionCOAB.Souscription.Radical_Client)
        Dim _radical As String = sessionCOAB.Souscription.Radical_Client.ToString()
        Dim _compte = From c In db.Comptes
                      Where c.Radical_Client.Equals(_radical)
                      Select New With {
                            .Ncp = c.Ncp,
                            .Compte = c.Ncp + " Clé " + c.clc,
                            .Agence = c.Age_Agence
                       }
        Dim ListAgence = (From c In db.Comptes
                          Join a In db.Agences On c.Age_Agence Equals a.Age
                          Where c.Radical_Client.Equals(sessionCOAB.Souscription.Radical_Client)
                          Select a.Age, a.Libelle)
        ViewBag.Radical = New SelectList(db.Clients, "Radical", "RS")
        'ViewBag.Agence = New SelectList(db.PreDom_AgenceCPT.Where(Function(m) m.Radical.Equals(sessionCOAB.Souscription.Radical_Client)).OrderBy(Function(m) m.Code), "Code", "Nom")
        ViewBag.Agence = New SelectList(ListAgence.Distinct, "Age", "Libelle")
        ViewBag.Devise = New SelectList(db.PreDom_Devise, "Code", "Libelle")
        ViewBag.Nature = New SelectList(db.PreDom_Nature, "Id", "Libelle")
        ViewBag.Activite = New SelectList(db.PreDom_Activite, "Id", "Libelle")
        ViewBag.Devise = New SelectList(db.PreDom_Devise.OrderBy(Function(m) m.Poids), "Code", "Libelle")
        ViewBag.Condition = New SelectList(db.PreDom_Condition, "Code", "Libelle")
        ViewBag.Modalite_paiement = New SelectList(db.PreDom_ModalitePaiement, "Code", "Libelle")
        ViewBag.Pays_fournisseur = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Pays_banque = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Pays_provenance = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Origine_marchandise = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Ncp_Compte = New SelectList(_compte, "Ncp", "Compte")
        ViewBag.TMP_Compte = New SelectList(_compte, "Agence", "Ncp")
        Return View()
    End Function

    '
    ' POST: /Predom/Create

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Create(ByVal p As PreDom_Dossier, ByVal Num As List(Of String), ByVal Date_Facture As List(Of DateTime)) As ActionResult

        Dim msg As New StringBuilder
        Try
            p.Statut = 1
            p.Id_Souscription = sessionCOAB.Id_Souscription
            p.Client.Radical = p.Radical
            Dim _f As PreDom_Facture = New PreDom_Facture
            _f.Dossier_Id = 1
            Try
                Dim _montant_string As String = Replace(p.Montant2, ".", ",")
                p.Montant = CDec(_montant_string)
            Catch ex As Exception
                ModelState.AddModelError("Montant2", ex.Message())
            End Try
            If ModelState.IsValid Then
                db.PreDom_Dossier.Add(p)
                db.Entry(p.Client).State = EntityState.Unchanged
                p.RefPreDOM = setRef(p.Id)
                db.SaveChanges()
                ' Add Facture
                If Num.Count > 0 Then
                    For i As Integer = 0 To Num.Count - 1
                        Dim facture As PreDom_Facture = New PreDom_Facture
                        If Not String.IsNullOrEmpty(Num(i)) And Not String.IsNullOrEmpty(Date_Facture(i)) Then
                            facture.Num = Num(i)
                            facture.Dossier_Id = p.Id
                            facture.Date_Facture = Date_Facture(i)
                            db.PreDom_Facture.Add(facture)
                            db.SaveChanges()
                        End If
                    Next
                End If
                Return RedirectToAction("Index")
            End If
        Catch ex As DbEntityValidationException
            msg.AppendLine(ex.Message)
            For Each vr As DbEntityValidationResult In ex.EntityValidationErrors
                For Each ve As DbValidationError In vr.ValidationErrors
                    msg.AppendLine(String.Format("{0}: {1}", ve.PropertyName, ve.ErrorMessage))
                Next
            Next
            Throw New DbEntityValidationException(msg.ToString, ex.EntityValidationErrors, ex)
        End Try
        Dim _compte = From c In db.Comptes
                      Where c.Radical_Client.Equals(p.Radical)
                      Select New With {
                            .Ncp = c.Ncp,
                            .Compte = c.Ncp + " Clé " + c.clc,
                            .Age = c.Agence
                       }
        Dim ListAgence = (From c In db.Comptes
                          Join a In db.Agences On c.Age_Agence Equals a.Age
                          Where c.Radical_Client.Equals(sessionCOAB.Souscription.Radical_Client)
                          Select a.Age, a.Libelle)
        ViewBag.Radical = New SelectList(db.Clients, "Radical", "RS")
        ViewBag.Agence = New SelectList(ListAgence.Distinct, "Age", "Libelle")
        ViewBag.Devise = New SelectList(db.PreDom_Devise, "Code", "Libelle")
        ViewBag.Nature = New SelectList(db.PreDom_Nature, "Id", "Libelle")
        ViewBag.Activite = New SelectList(db.PreDom_Activite, "Id", "Libelle")
        ViewBag.Devise = New SelectList(db.PreDom_Devise.OrderBy(Function(m) m.Poids), "Code", "Libelle")
        ViewBag.Condition = New SelectList(db.PreDom_Condition, "Code", "Libelle")
        ViewBag.Modalite_paiement = New SelectList(db.PreDom_ModalitePaiement, "Code", "Libelle")
        ViewBag.Pays_fournisseur = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Pays_banque = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Pays_provenance = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Origine_marchandise = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle")
        ViewBag.Ncp_Compte = New SelectList(_compte, "Ncp", "Compte", p.Ncp_Compte)
        ViewBag.TMP_Compte = New SelectList(_compte, "Agence", "Ncp")
        Return View(p)
    End Function

    '
    ' GET: /Predom/Edit/5

    Function Edit(Optional ByVal id As Integer = Nothing) As ActionResult
        Dim p As PreDom_Dossier = db.PreDom_Dossier.Find(id)
        If IsNothing(p) Or Not p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) Then
            Return HttpNotFound()
        End If
        If p.Statut > 1 Then
            Return RedirectToAction("Index")
        End If
        p.Montant2 = CDec(p.Montant)
        '----
        Dim _radical As String = sessionCOAB.Souscription.Radical_Client.ToString()
        Dim _compte = From c In db.Comptes
                      Where c.Radical_Client.Equals(_radical)
                      Select New With {
                            .Ncp = c.Ncp,
                            .Compte = c.Ncp + " Clé " + c.clc,
                           .Agence = c.Age_Agence
                       }
        '----------
        Dim ListAgence = (From c In db.Comptes
                          Join a In db.Agences On c.Age_Agence Equals a.Age
                          Where c.Radical_Client.Equals(sessionCOAB.Souscription.Radical_Client)
                          Select a.Age, a.Libelle).Distinct()
        '-----
        Dim _fc As New PreDom_Facture
        Dim list As List(Of PreDom_Facture) = New List(Of PreDom_Facture)
        _fc.Num = ""
        _fc.Date_Facture = String.Format("{0:dd/MM/yyyy}", DateTime.Now.ToShortDateString)
        _fc.Dossier_Id = p.Id
        list.Add(_fc)
        '-----------
        Dim _f = db.PreDom_Facture.Where(Function(f) f.Dossier_Id.Equals(id)).ToList()
        ViewBag.Radical = New SelectList(db.Clients, "Radical", "RS", p.Radical)
        ViewBag.Agence = New SelectList(ListAgence, "Age", "Libelle", p.Agence)
        ViewBag.Nature = New SelectList(db.PreDom_Nature, "Id", "Libelle", p.Nature)
        ViewBag.Activite = New SelectList(db.PreDom_Activite, "Id", "Libelle", p.Activite)
        ViewBag.Devise = New SelectList(db.PreDom_Devise.OrderBy(Function(m) m.Poids), "Code", "Libelle", p.Devise)
        ViewBag.Condition = New SelectList(db.PreDom_Condition, "Code", "Libelle", p.Condition)
        ViewBag.Modalite_paiement = New SelectList(db.PreDom_ModalitePaiement, "Code", "Libelle", p.Modalite_paiement)
        ViewBag.Pays_fournisseur = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Pays_fournisseur)
        ViewBag.Pays_banque = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Pays_banque)
        ViewBag.Pays_provenance = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Pays_provenance)
        ViewBag.Origine_marchandise = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Origine_marchandise)
        ViewBag.Ncp_Compte = New SelectList(_compte, "Ncp", "Compte", p.Ncp_Compte)
        ViewBag.TMP_Compte = New SelectList(_compte, "Agence", "Ncp")
        ViewBag.Facture = If(_f.Count().Equals(0), list, _f)
        Return View(p)
    End Function

    '
    ' POST: /Predom/Edit/5

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal p As PreDom_Dossier, ByVal Num As List(Of String), ByVal Date_Facture As List(Of DateTime)) As ActionResult
        ' Dim facture As PreDom_Facture = New PreDom_Facture
        Dim msg As New StringBuilder
        Dim j As Integer = 0
        If ModelState.IsValid Then
            Try
                '----------------
                Try
                    Dim _montant_string As String = Replace(p.Montant2, ".", ",")
                    p.Montant = CDec(_montant_string)
                Catch ex As Exception
                    ModelState.AddModelError("Montant2", ex.Message())
                End Try

                If Not p.Statut.Equals(1) Then
                    Redirect(Url.Action("Index"))
                End If
                Try
                    Dim f = db.PreDom_Facture.Where(Function(s) s.Dossier_Id.Equals(p.Id)).ToList()
                    If Not f Is Nothing Then
                        For Each u In f
                            db.PreDom_Facture.Remove(u)
                            db.SaveChanges()
                        Next

                    End If
                    If Num.Count > 0 Then
                        For i As Integer = 0 To Num.Count - 1
                            If ModelState.IsValid Then
                                If Not String.IsNullOrEmpty(Num(i)) And Not String.IsNullOrEmpty(Date_Facture(i)) Then
                                    Dim facture As PreDom_Facture = New PreDom_Facture
                                    facture.Num = Num(i)
                                    facture.Date_Facture = Date_Facture(i)
                                    facture.Dossier_Id = p.Id
                                    db.PreDom_Facture.Add(facture)
                                    j = j + 1
                                End If
                            End If
                        Next
                    End If
                    '
                Catch ex As Exception
                    msg.AppendLine(ex.Message)
                    ModelState.AddModelError("", "Erreur sur vos facture:")
                End Try
                p.Nbr_facture = j
                'p.Montant = Replace(p.Montant, ",", ".")
                db.Entry(p).State = EntityState.Modified
                db.SaveChanges()
            Catch ex As DbEntityValidationException
                msg.AppendLine(ex.Message)
                For Each vr As DbEntityValidationResult In ex.EntityValidationErrors
                    For Each ve As DbValidationError In vr.ValidationErrors
                        msg.AppendLine(String.Format("{0}: {1}", ve.PropertyName, ve.ErrorMessage))
                    Next
                Next

                Throw New DbEntityValidationException(msg.ToString, ex.EntityValidationErrors, ex)

            End Try


            Return RedirectToAction("Index")
        End If

        ViewBag.Radical = New SelectList(db.Clients, "Radical", "RS", p.Radical)
        Dim _radical As String = sessionCOAB.Souscription.Radical_Client.ToString()
        Dim _compte = From c In db.Comptes
                      Where c.Radical_Client.Equals(_radical)
                      Select New With {
                            .Ncp = c.Ncp,
                            .Compte = c.Ncp + " Clé " + c.clc,
                           .Agence = c.Age_Agence
                       }
        '----------
        Dim ListAgence = (From c In db.Comptes
                          Join a In db.Agences On a.Age Equals c.Age_Agence
                          Where c.Radical_Client.Equals(sessionCOAB.Souscription.Radical_Client)
                          Select a.Age, a.Libelle).Distinct()
        '-----
        Dim _fc As New PreDom_Facture
        Dim list As List(Of PreDom_Facture) = New List(Of PreDom_Facture)
        _fc.Num = ""
        _fc.Date_Facture = String.Format("{0:dd/MM/yyyy}", DateTime.Now.ToShortDateString)
        _fc.Dossier_Id = p.Id
        list.Add(_fc)
        '-----------
        Dim _f = db.PreDom_Facture.Where(Function(f) f.Dossier_Id.Equals(p.Id)).ToList()
        ViewBag.Radical = New SelectList(db.Clients, "Radical", "RS", p.Radical)
        ViewBag.Agence = New SelectList(ListAgence, "Age", "Libelle")
        ViewBag.Nature = New SelectList(db.PreDom_Nature, "Id", "Libelle", p.Nature)
        ViewBag.Activite = New SelectList(db.PreDom_Activite, "Id", "Libelle", p.Activite)
        ViewBag.Devise = New SelectList(db.PreDom_Devise.OrderBy(Function(m) m.Poids), "Code", "Libelle", p.Devise)
        ViewBag.Condition = New SelectList(db.PreDom_Condition, "Code", "Libelle", p.Condition)
        ViewBag.Modalite_paiement = New SelectList(db.PreDom_ModalitePaiement, "Code", "Libelle", p.Modalite_paiement)
        ViewBag.Pays_fournisseur = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Pays_fournisseur)
        ViewBag.Pays_banque = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Pays_banque)
        ViewBag.Pays_provenance = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Pays_provenance)
        ViewBag.Origine_marchandise = New SelectList(db.PreDom_Pays.OrderBy(Function(m) m.Libelle), "Code", "Libelle", p.Origine_marchandise)
        ViewBag.Ncp_Compte = New SelectList(_compte, "Ncp", "Compte")
        ViewBag.TMP_Compte = New SelectList(_compte, "Agence", "Ncp")
        ViewBag.Facture = If(_f.Count().Equals(0), list, _f)
        Return View(p)
    End Function

    <HttpGet()> _
    Function Annuler(Optional ByVal id As Integer = Nothing) As ActionResult
        Dim p As PreDom_Dossier = db.PreDom_Dossier.Find(id)
        If IsNothing(p) Or Not p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) Then
            Return HttpNotFound()
        End If
        ViewBag.Id = p.Id
        ViewBag.Ref = p.RefPreDOM
        Return PartialView()
    End Function
    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Annuler(ByVal d As PreDom_Dossier) As ActionResult
        Try
            Dim p As PreDom_Dossier = db.PreDom_Dossier.Find(d.Id)
            If IsNothing(p) Or Not p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) Then
                Return HttpNotFound()
            End If
            If p.Statut.Equals(1) Then
                db.Database.ExecuteSqlCommand(String.Format("Update Predom_Dossier SET Statut = {0} Where Id = {1}", 4, CInt(p.Id)))
                Return Json(New With {.result = "ok", .message = "Les dossier est annulé."}, JsonRequestBehavior.AllowGet)
            End If
        Catch ex As Exception
            Return Json(New With {.result = "ko", .message = ex.Message}, JsonRequestBehavior.AllowGet)
        End Try
        ViewBag.Id = d.Id
        Return PartialView()
    End Function
    ' GET: /Predom/Edit/5

    Function Details(Optional ByVal id As Integer = Nothing) As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim p As PreDom_Dossier = db.PreDom_Dossier.Find(id)
        If IsNothing(p) Or Not p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) Then
            Return HttpNotFound()
        End If
        Dim _radical As String = sessionCOAB.Souscription.Radical_Client.ToString()
        Try
            Dim _compte = (From c In db.Comptes
                           Where c.Ncp.Equals(p.Ncp_Compte) And c.Radical_Client.Equals(_radical) And c.Age_Agence.Equals(p.Agence)
                           Select c.Ncp + " Clé " + c.clc).FirstOrDefault()
            ViewBag.Ncp_Compte = _compte
        Catch ex As Exception

        End Try

        ViewBag.Agence = db.Agences.Where(Function(a) a.Age.Equals(p.Agence)).SingleOrDefault().Libelle
        ViewBag.facture = db.PreDom_Facture.Where(Function(f) f.Dossier_Id.Equals(id)).ToList()
        Dim paysfournisseur = db.PreDom_Pays.Where(Function(f) f.Code.Equals(p.Pays_fournisseur)).SingleOrDefault().Libelle
        ViewBag.Id = p.Id
        ViewBag.Pays_fournisseur = db.PreDom_Pays.Where(Function(f) f.Code.Equals(p.Pays_fournisseur)).SingleOrDefault().Libelle
        ViewBag.Pays_banque = db.PreDom_Pays.Where(Function(f) f.Code.Equals(p.Pays_banque)).SingleOrDefault().Libelle
        ViewBag.Pays_provenance = If(String.IsNullOrWhiteSpace(p.Pays_provenance), "", db.PreDom_Pays.Where(Function(f) f.Code.Equals(p.Pays_provenance)).SingleOrDefault().Libelle)
        ViewBag.Origine_marchandise = If(String.IsNullOrWhiteSpace(p.Origine_marchandise), "", db.PreDom_Pays.Where(Function(f) f.Code.Equals(p.Origine_marchandise)).SingleOrDefault().Libelle)
        ViewBag.ListDoc = db.PreDom_DocumentTypes.Where(Function(d) d.Code_mp.Equals(p.Modalite_paiement)).ToList()
        Return View(p)
    End Function
    '
    ' GET: /Predom/Delete/5

    Function Delete(Optional ByVal id As Integer = Nothing) As ActionResult
        Dim predom_dossier As PreDom_Dossier = db.PreDom_Dossier.Find(id)
        If IsNothing(predom_dossier) Then
            Return HttpNotFound()
        End If
        Return View(predom_dossier)
    End Function

    '
    ' POST: /Predom/Delete/5

    <HttpPost()>
    <ActionName("Delete")>
    <ValidateAntiForgeryToken()>
    Function DeleteConfirmed(ByVal id As Integer) As RedirectToRouteResult
        Dim predom_dossier As PreDom_Dossier = db.PreDom_Dossier.Find(id)
        db.PreDom_Dossier.Remove(predom_dossier)
        'db.SaveChanges()
        Return RedirectToAction("Index")
    End Function


    Function getCompteByAgence(ByVal age As String) As ActionResult
        Try
            Dim _radical = sessionCOAB.Souscription.Radical_Client
            Dim _ag = db.PreDom_Compte.Where(Function(a) a.Age_Agence.Equals(age) And a.Radical_Client.Equals(_radical)).ToList()
            Return PartialView(_ag)
        Catch ex As Exception
            Return PartialView()
        End Try
       
    End Function

    Function getClient() As ActionResult
        Dim _c As Client
        Try
            _c = db.Clients.Where(Function(m) m.Radical.Equals(sessionCOAB.Souscription.Radical_Client)).FirstOrDefault
        Catch ex As Exception
            _c = Nothing
        End Try
        Return Json(_c, JsonRequestBehavior.AllowGet)

    End Function
    Private Function CountFiles(ByVal Id As Integer) As Integer
        Try
            Dim d As PreDom_Dossier = db.PreDom_Dossier.Find(Id)
            Dim Chemin As String = Path.Combine(db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value, d.Radical, d.Modalite_paiement)
            Dim counter As Integer = Directory.GetFiles(Chemin, "*.*", SearchOption.AllDirectories).Length
            Return counter
        Catch ex As Exception
            Return 0
        End Try   
        Return 0
    End Function


    Function Soumettre(ByVal Id As Integer) As ActionResult

        Dim predom As PreDom_Dossier = db.PreDom_Dossier.Find(Id)

        If IsNothing(predom) Then
            Return HttpNotFound()
        End If
        If CountFiles(Id) = 0 Then
            Return Json(New With {.result = "ko", .message = "Merci de rattacher vos fichiers avant de soumettre à la banque."}, JsonRequestBehavior.AllowGet)
        End If
        If predom.Id_Souscription <> sessionCOAB.Id_Souscription Then
            Return Json(New With {.result = "ko", .message = "LogSecurityViolation."}, JsonRequestBehavior.AllowGet)
        End If
        Try
            If ModelState.IsValid Then
                Dim query = String.Format("UPDATE PreDom_Dossier SET Statut =2, DateCreation = '{0}' Where Id = {1}", DateTime.Now, Id)
                db.Database.ExecuteSqlCommand(query)
                SoumettreNotif(Id)
            End If
        Catch ex As Exception
            Return Json(New With {.result = "ko", .message = "Erreur :  " + ex.Message}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(New With {.result = "ok", .message = "Votre requête est soumis à la banque."}, JsonRequestBehavior.AllowGet)
    End Function
    ''' <summary>
    ''' ''''''' Soumettre un notification'''''''''''
    ''' </summary>
    Sub SoumettreNotif(ByVal Id As Integer)
        Dim predom As PreDom_Dossier = db.PreDom_Dossier.Find(Id)
        Dim _from As String = db.Parametres.Where(Function(p) p.Param.Contains("EtradeMailerAdress")).FirstOrDefault().Value
        Dim _Objet As String = db.Parametres.Where(Function(p) p.Param.Contains("ObjetMailerPredom")).FirstOrDefault().Value
        Dim mailCoab As String = sessionCOAB.Email
        Dim _b As String = String.Format(Fct.Template("~/Content/Template/Notifier.vbhtml"), predom.RefPreDOM)
        Fct.SendMail(mailCoab, _from, _Objet, _b, _from)
    End Sub
    ''' <summary>
    ''' ''''''''''''''''''
    ''' </summary>
    Function _Meeting(ByVal Id As Integer) As ActionResult
        Dim _m = From d In db.PreDom_Commentaires, c In db.PreDom_Commentaires
             Where d.IdCible.Equals(Id)
             Select d
        Return PartialView(_m.ToList)
    End Function
    Function _ListDocs(Optional ByVal id As Integer = Nothing) As ActionResult
        ViewBag.Id = id
        Return PartialView(Url.Action("FilesUploaded", "Upload", New With {.Id = id}))
    End Function
    Function _Details(Optional ByVal id As Integer = Nothing, Optional Obj As PreDom_Dossier = Nothing) As ActionResult
        Dim p = db.PreDom_Dossier.Find(id)
        If IsNothing(p) Or p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) Then
            Return HttpNotFound()
        End If
        ViewBag.Id = id
        ViewBag.O = p
        Return PartialView()
    End Function

    Function Messages(Optional ByVal id As Integer = Nothing) As ActionResult
        Dim p = db.PreDom_Dossier.Find(id)
        If IsNothing(p) Or Not p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) Then
            Return HttpNotFound()
        End If
        If p.Statut <> 3 Then
            Return RedirectToAction("Index")
        End If
        ViewBag.Id = id
        ViewBag.O = p
        ViewBag.facture = db.PreDom_Facture.Where(Function(f) f.Dossier_Id.Equals(id)).ToList()
        ViewBag.Pays_fournisseur = db.PreDom_Pays.Where(Function(f) f.Code.Equals(p.Pays_fournisseur)).SingleOrDefault().Libelle
        Return View()
    End Function
    Function _Upload(Optional ByVal id As Integer = Nothing) As ActionResult
        ViewBag.Id = id
        Return PartialView()
    End Function
    Function setRef(ByVal id As Integer?) As String
        Dim ref As String = String.Concat(String.Format("{0:yy}", DateTime.Now), "0000001")
        If Not id Is Nothing Then
            Dim year = String.Format("{0:yy}", DateTime.Now)
            Dim NbMax = db.PreDom_Dossier.Where(Function(m) m.RefPreDOM.StartsWith(year)).Select(Function(m) m.RefPreDOM).ToArray().Max
            ref = If(CInt(NbMax) >= ref, CInt(NbMax + 1).ToString(), ref)
            Return ref
        End If
        Return Nothing
    End Function
    Private Function GetPredomReport(predom As PreDom_Dossier) As String
        Try
            Dim ds As DataSet = New DataSet()
            Dim listPredom As IList(Of PreDom_Dossier) = New List(Of PreDom_Dossier)
            Dim listClient As IList(Of Client) = New List(Of Client)
            Dim listAgence As IList(Of Agence) = New List(Of Agence)
            Dim listActivite As IList(Of PreDom_Activite) = New List(Of PreDom_Activite)
            Dim Listmodalite As IList(Of PreDom_ModalitePaiement) = New List(Of PreDom_ModalitePaiement)
            Dim ag As Agence = db.Agences.Where(Function(a) a.Age.Equals(predom.Agence)).FirstOrDefault
            ds.ReadXmlSchema(Server.MapPath("~\Report\PREDOM\predom.xsd"))
            listPredom.Add(predom)
            listClient.Add(predom.Client)
            listAgence.Add(ag)
            listActivite.Add(predom.PreDom_Activite)
            Listmodalite.Add(predom.PreDom_ModalitePaiement)
            UtilityFunctions.EntityToDataSet(Of PreDom_Dossier)(ds, listPredom)
            UtilityFunctions.EntityToDataSet(Of Client)(ds, listClient)
            UtilityFunctions.EntityToDataSet(Of Agence)(ds, listAgence)
            UtilityFunctions.EntityToDataSet(Of PreDom_Activite)(ds, listActivite)
            UtilityFunctions.EntityToDataSet(Of PreDom_ModalitePaiement)(ds, Listmodalite)
            Dim report As ReportDocument = New ReportDocument()
            report.Load(Server.MapPath("~\Report\PREDOM\cr1.rpt"))
            report.SetDataSource(ds)
            Dim _p = db.Parametres.Where(Function(p) p.Param.Equals("PathDocument")).FirstOrDefault().Value
            Dim filePath As String = Path.Combine(_p, "Accusé_de_reception.pdf")
            report.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, filePath)
            Return filePath

        Catch ex As Exception
            LogException(ex.Message)
            LogException(ex.StackTrace)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
                LogException(ex.InnerException.StackTrace)
            End If
        End Try
    End Function
    Function GenerateReport(Optional ByVal id As Integer = Nothing, Optional ByVal typeDocument As UtilityFunctions.DocumentReglementaire = UtilityFunctions.DocumentReglementaire.ALL) As ActionResult
        Dim predom As PreDom_Dossier = db.PreDom_Dossier.Find(id)
        If predom.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If
        Dim doPath As String = GetPredomReport(predom)
        If Not String.IsNullOrEmpty(doPath) Then
            Return New DownloadResult(doPath, "Accusé_de_reception.pdf")
        End If
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class