﻿Imports System
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Web.Helpers
Imports System.Net.Mime.MediaTypeNames
Imports System.Security.Cryptography
Imports E_Trade.Data
Imports System.Net.Mail



Public Class Fct

    Public Shared Function getConnectionString() As String
        Return System.Configuration.ConfigurationManager.ConnectionStrings("ETRADE").ConnectionString
    End Function
    Private Shared Function Deltaconnect() As String
        Return System.Configuration.ConfigurationManager.ConnectionStrings("Delta").ConnectionString
    End Function
    Private Shared Function SafeSqlLiteral(ByVal inputSQL As String) As String
        Return inputSQL.Replace("'", "''").Replace(" ", "").Replace("/", "").Replace("-", "").Replace("+", "")
    End Function

    Public Shared Function CreateRandomPassword() As String

        Dim db As DB = New DB()
        Dim _passwordLength As Int32 = db.Parametres.Find("PasswordLength").Value
        Dim _allowedChars As String = db.Parametres.Find("AllowedChars").Value
        Dim randomNumber As New Random()
        Dim chars(_passwordLength - 1) As Char
        Dim allowedCharCount As Integer = _allowedChars.Length
        For i As Integer = 0 To _passwordLength - 1
            chars(i) = _allowedChars.Chars(CInt(Fix((_allowedChars.Length) * randomNumber.NextDouble())))
        Next i
        Return New String(chars)

    End Function

    Public Shared Function GetSHA512Hash(value As String) As String
        Dim SHA512Hasher = SHA512.Create
        Dim data = SHA512Hasher.ComputeHash(Encoding.[Default].GetBytes(value))
        Dim sBuilder = New StringBuilder()
        For i As Int32 = 0 To data.Length - 1
            sBuilder.Append(data(i).ToString("x2"))
        Next
        Return sBuilder.ToString()
    End Function

    Public Shared Function getClient(ByVal nif As String, ByVal rc As String) As RegisterModel
        Using conn = New SqlConnection
            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = Fct.getConnectionString
            End If

            Try

                'RegisterModel
                Dim queryString = String.Format("select * from PreDom_Client Where  replace( " &
                                                "	replace( " &
                                                "			replace( " &
                                                "					replace( " &
                                                "						  replace(NIDF,'/','') " &
                                                "					,'-','') " &
                                                "			,'_','') " &
                                                "	,'+','') " &
                                                "	,' ','') = '{0}' " &
                                                "	and	replace( " &
                                                "	replace( " &
                                                "			replace( " &
                                                "					replace( " &
                                                "						  replace(RC,'/','') " &
                                                "					,'-','') " &
                                                "			,'_','') " &
                                                "	,'+','') " &
                                                "	,' ','') = '{1}'", SafeSqlLiteral(nif), SafeSqlLiteral(rc))
                conn.Open()
                Using command = New SqlCommand(queryString, conn)
                    command.CommandTimeout = 0
                    command.CommandText = queryString
                    command.Connection = conn
                    Using Data As SqlDataReader = command.ExecuteReader()

                        If Data.Read() Then
                            Return New RegisterModel With {.radical = Data("radical"),
                                                .NIF = Data("NIDF"),
                                                .RC = Data("RC"),
                                                .rs = Data("RS"),
                                                .Agence = Data("age"),
                                                .EmailEntreprise = Data("Email")}
                        Else
                            Return Nothing
                        End If
                    End Using
                End Using
            Catch ex As Exception
                Return Nothing
            End Try
        End Using
    End Function


    Public Shared Function getValue(champ As String, table As String, params As String, val As String) As String
        If champ Is Nothing Or table Is Nothing Or params Is Nothing Then
            Return Nothing
        Else
            Dim conn As New SqlConnection
            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = Fct.getConnectionString
            End If
            ' Dim queryString = "select " & champ & " from " & table & " Where " & params & " = '" & val & "'"
            Dim queryString = String.Format("select {0} from {1} Where {2} = '{3}'", SafeSqlLiteral(champ), SafeSqlLiteral(table), SafeSqlLiteral(params), SafeSqlLiteral(val))
            Dim command = New SqlCommand(queryString, conn)
            Try
                conn.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()
                While reader.Read()
                    Return String.Format("{0}", reader(0))
                End While
            Catch ex As Exception
                Return Nothing
            End Try
        End If
        Return Nothing
    End Function

    Public Shared Function IsDomAllowed(nif As String, rc As String) As String
        If nif Is Nothing Or rc Is Nothing Then
            Return Nothing
        Else
            Dim conn As New SqlConnection
            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = Fct.getConnectionString
            End If
            Dim queryString = String.Format("select * from PreDom_Interdit Where  replace( " &
                                            "	replace( " &
                                            "			replace( " &
                                            "					replace( " &
                                            "						  replace(nif,'/','') " &
                                            "					,'-','') " &
                                            "			,'_','') " &
                                            "	,'+','') " &
                                            "	,' ','') = '{0}' " &
                                            "	or 	replace( " &
                                            "	replace( " &
                                            "			replace( " &
                                            "					replace( " &
                                            "						  replace(rc,'/','') " &
                                            "					,'-','') " &
                                            "			,'_','') " &
                                            "	,'+','') " &
                                            "	,' ','') = '{1}'", SafeSqlLiteral(nif), SafeSqlLiteral(rc))
            Dim command = New SqlCommand(queryString, conn)
            Try
                conn.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()
                While reader.Read()
                    Return String.Format("{0}", reader(0))
                End While
            Catch ex As Exception
                Return Nothing
            End Try
        End If
        Return Nothing
    End Function

    Public Shared Function IsEtrade(radical As String) As Integer
        If radical Is Nothing Then
            Return Nothing
        Else
            Dim conn As New SqlConnection
            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = Fct.getConnectionString
            End If
            Dim queryString = String.Format("select Id_Package from  Souscription  where Radical_client ='{0}'; ", Trim(radical))
            Dim command = New SqlCommand(queryString, conn)
            Try
                conn.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()
                While reader.Read()
                    Return CInt(reader(0))
                End While
            Catch ex As Exception
                Return 0
            End Try
        End If
        Return 0
    End Function

    Public Shared Function IsValideMail(ByVal str_mail As String) As Boolean
        If (str_mail <> "") Then
            Dim RegexpEmail As New Regex("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")
            Dim bEmailValid As Boolean = RegexpEmail.IsMatch(str_mail)
            Return bEmailValid
        Else
            Return False
        End If
    End Function

    Private Function GetFileSize(ByVal filename As String) As Long
        Dim fi As FileInfo = New FileInfo(filename)
        Return fi.Length
    End Function
    Public Shared Function SendMail(ByVal destinataire As String, ByVal Expediteur As String, ByVal sujet As String, ByVal text As String, Optional ByVal dnFrom As String = "PREDOM@socgen.com", Optional ByVal CC As String = "", Optional filePath As String = Nothing, Optional Fichier As IList(Of String) = Nothing) As Boolean
        Dim db As DB = New DB
        Dim s As IList(Of Integer) = Nothing
        Dim objMessage As System.Net.Mail.MailMessage
        Dim objAdrExp As System.Net.Mail.MailAddress
        Dim objAdrRec As System.Net.Mail.MailAddress
        Dim objSMTPClient As System.Net.Mail.SmtpClient
        Dim attachment As System.Net.Mail.Attachment
        Dim smtp As String = db.Parametres.Where(Function(m) m.Param.Equals("SMTPSERVER")).FirstOrDefault().Value

        Try
            objMessage = New System.Net.Mail.MailMessage()
            objAdrExp = New System.Net.Mail.MailAddress(Expediteur.Trim)
            objAdrRec = New System.Net.Mail.MailAddress(destinataire.Trim)
            objMessage.From = objAdrExp
            '----------
            If Not IsNothing(Fichier) AndAlso Fichier.Count > 0 Then
                For Each f In Fichier
                    attachment = New System.Net.Mail.Attachment(Path.Combine(filePath, CStr(f.ToString)))
                    objMessage.Attachments.Add(attachment)
                Next
            End If
            '-----------
            objMessage.To.Add(objAdrRec)
            objMessage.IsBodyHtml = True
            objMessage.Subject = sujet
            objMessage.Body = text
            objSMTPClient = New System.Net.Mail.SmtpClient(smtp)
            objSMTPClient.EnableSsl = False
            objSMTPClient.Port = 25
            objSMTPClient.Send(objMessage)
        Catch ex As Exception
            Return False
        End Try

        Return True
    End Function

    Public Shared Function Template(ByVal uri As String) As String
        Dim body As String = String.Empty
        Using sr As StreamReader = New StreamReader(System.Web.HttpContext.Current.Server.MapPath(uri))
            body = sr.ReadToEnd()
        End Using
        Return HttpUtility.HtmlDecode(body)
    End Function

    Shared Function NextID(ByVal o As Boolean) As Integer
        Dim conn As New SqlConnection
        Dim requete As String
        If conn.State = ConnectionState.Closed Then
            conn.ConnectionString = Fct.getConnectionString
        End If
        conn.Open()
        If o = True Then
            requete = "select (max( ident_current('dbo.dom_utilisateur'))) AS NextID"
        Else
            requete = "select (max( ident_current('dbo.dom_utilisateur')) + 1) AS NextID"
        End If
        Dim command = New SqlCommand(requete, conn)
        Dim reader As SqlDataReader = command.ExecuteReader()
        While reader.Read()
            Return reader(0)
        End While
        Return 0
    End Function

    Shared Function getCOAB(ByVal radical As String) As Integer
        Using conn = New SqlConnection
            Dim requete As String
            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = Fct.getConnectionString
            End If
            conn.Open()
            requete = String.Format("select count(*) Total from COAB C left join Souscription S on C.Id_Souscription = S.Id where S.Radical_Client = '{0}' ", radical)
            Using command = New SqlCommand(requete, conn)
                Using reader As SqlDataReader = command.ExecuteReader()
                    While reader.Read()
                        Return reader(0)
                    End While
                End Using
            End Using
        End Using
            Return 0
    End Function

    Public Shared Function getCompteClient(ByVal rc As String) As Boolean
        Dim lp = Fct.getValue("Value", "Parametres", "Param", "ListeProduits")
        Dim cn As New OleDbConnection
        Dim db As DB = New DB
        If cn.State = ConnectionState.Closed Then
            cn.ConnectionString = Deltaconnect()
        End If
        Dim q1 = "select trim(ncp) ncp, trim(age) age, trim(dev) dev,trim(cfe) cfe,trim(clc) clc,trim(cli) cli from bkcom where cli='" & rc & "' and ncp[1,3] in (" & lp & ")"
        Dim cmd As New OleDbCommand(q1, cn)
        Dim dr As OleDbDataReader
        cn.Open()
        dr = cmd.ExecuteReader()
        ' Recupere To Delta
        Dim csql As New SqlConnection
        If csql.State = ConnectionState.Closed Then
            csql.ConnectionString = Fct.getConnectionString
        End If
        db.Database.ExecuteSqlCommand("delete from Compte where Radical_Client = '" & rc & "'")
        csql.Open()
        Using bulkCopy As SqlBulkCopy = _
                  New SqlBulkCopy(csql)
            bulkCopy.DestinationTableName = "dbo.Compte"
            Try
                bulkCopy.WriteToServer(dr)
            Catch ex As Exception

            Finally
                dr.Close()
            End Try
        End Using
        Return True
    End Function

    Public Shared Function setCompteClient(ByVal cli As String) As Boolean
        If Not String.IsNullOrEmpty(cli) Then
            Dim csql As New SqlConnection
            If csql.State = ConnectionState.Closed Then
                csql.ConnectionString = Fct.getConnectionString()
            End If
            csql.Open()
            Dim _Query = String.Format("insert into Compte(Ncp, Age_Agence, Devise, cfe, clc, Radical_Client)  " &
                    "select distinct Ncp, Age_Agence, Devise, cfe, clc, Radical_Client " &
                    "from Predom_Compte " &
                    "where not exists (select * from Compte  " &
                    "where Predom_Compte.ncp=Compte.ncp and Predom_Compte.age_agence=Compte.age_agence and Predom_Compte.devise=Compte.devise) " &
                    "and Radical_Client in ('{0}') " &
                    "and cfe = 'N' ", cli)
            Dim selectCMD As SqlCommand = New SqlCommand(_Query, csql)
            selectCMD.CommandTimeout = 300000
            selectCMD.ExecuteNonQuery()
            Return True
        End If
        Return False
    End Function

    Public Shared Function setArrayToString(ByVal tab As IList) As String
        Dim s As String = ""
        Try
            For Each n In tab
                s = s + "," + n
            Next
        Catch ex As Exception
            Return s
        End Try
        Return s.TrimStart(",").ToString
    End Function

    Private Shared Function Adaptateur(p1 As String) As Object
        Throw New NotImplementedException
    End Function

End Class




