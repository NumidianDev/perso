﻿Imports E_Trade.Web.AccountController

Public Class HomeController
    Inherits BaseController


    Function Index() As ActionResult
        ViewBag.PredomCount = GetPredomCount(True)
        ViewBag.CredocCount = GetCredocsCount(True)
        ViewBag.RemdocCount = GetRemdocsCount(True)
        ViewBag.RepCredocCount = GetCredocsCount(False)
        ViewBag.RepRemdocCount = GetRemdocsCount(False)
        ViewBag.AllCredocCount = GetAllCredocsCount()
        ViewBag.AllRemdocCount = GetAllRemdocsCount()
        ViewBag.COABSCount = db.COABS.Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription).Count
        ViewBag.Package = (From m In db.Souscriptions
                          Where m.Id.Equals(sessionCOAB.Id_Souscription) And m.Id_Package.Equals(1)
                          Select m.Id_Package).ToList().Count()
        '---------------
        
        Return View()
    End Function

    Public Function ResetIndex(ByVal message As ManageMessageId?) As ActionResult
        ViewData("StatusMessage") =
            If(message = ManageMessageId.ChangePasswordSuccess, "Votre mot de passe à été modifié.", _
                If(message = ManageMessageId.SetPasswordSuccess, "Votre mot de passe à été crée.", _
                        ""))
        Return View("Index")
    End Function

    Function About() As ActionResult
        Return PartialView()
    End Function

    Function Contact() As ActionResult
        Return View()
    End Function
End Class
