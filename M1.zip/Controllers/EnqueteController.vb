﻿Imports System.Data.Entity.Core.Objects
Imports E_Trade.Data

Public Class EnqueteController
    Inherits BaseController


    '
    ' GET: /Enquete

    Function Index() As ActionResult

        Dim compagne As QCompangne = db.Compagnes _
                .Where(Function(c) EntityFunctions.TruncateTime(c.Debut) <= EntityFunctions.TruncateTime(Now) _
                AndAlso EntityFunctions.TruncateTime(c.Fin) >= EntityFunctions.TruncateTime(Now)).FirstOrDefault()

        ViewData("COMPAGNE") = IIf(compagne IsNot Nothing, compagne, Nothing)

        Dim questions As IEnumerable(Of QQuestion) = Nothing

        If compagne IsNot Nothing Then
            questions = db.Questions.Where(Function(q) q.Compagne = compagne.Id).ToList
        End If

        Return View(questions)

    End Function

    '
    ' GET: /Enquete/Details/5

    Function Details(ByVal id As Integer) As ActionResult
        Return View()
    End Function

    '
    ' GET: /Enquete/Create

    Function Create() As ActionResult
        Return View()
    End Function

    '
    ' POST: /Enquete/Create

    <HttpPost()>
    Function Create(ByVal collection As FormCollection) As ActionResult
        Try
            ' TODO: Add insert logic here
            Return RedirectToAction("Index")
        Catch
            Return View()
        End Try
    End Function

    '
    ' GET: /Enquete/Edit/5

    Function Edit(ByVal id As Integer) As ActionResult
        Return View()
    End Function

    '
    ' POST: /Enquete/Edit/5

    <HttpPost()>
    Function Edit(ByVal id As Integer, ByVal collection As FormCollection) As ActionResult
        Try
            ' TODO: Add update logic here

            Return RedirectToAction("Index")
        Catch
            Return View()
        End Try
    End Function

    '
    ' GET: /Enquete/Delete/5

    Function Delete(ByVal id As Integer) As ActionResult
        Return View()
    End Function

    '
    ' POST: /Enquete/Delete/5

    <HttpPost()>
    Function Delete(ByVal id As Integer, ByVal collection As FormCollection) As ActionResult
        Try
            ' TODO: Add delete logic here

            Return RedirectToAction("Index")
        Catch
            Return View()
        End Try
    End Function
End Class