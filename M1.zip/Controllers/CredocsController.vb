﻿Imports System.Data.Entity
Imports E_Trade.Data
Imports WebMatrix.WebData
Imports System.Data.Entity.Validation
Imports CrystalDecisions.CrystalReports.Engine
Imports System.IO
Imports E_Trade.Web.UtilityFunctions
Imports CrystalDecisions.Shared
Imports Ionic.Zip
Imports Newtonsoft.Json
Imports System.Threading.Thread

Public Class CredocsController
    Inherits BaseController

    '
    ' GET: /Credocs/
    Private selectedListDoc As IList(Of DocumentsCredoc) = New List(Of DocumentsCredoc)

    Function Index(Optional ByVal encours As Boolean = True) As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim credoc As IList(Of Credoc)
        ViewBag.Encours = encours

        If encours Then
            credoc = db.Credoc.Include(Function(c) c.StatutCredoc).Include(Function(c) c.Client).Include(Function(c) c.Agence).Include(Function(c) c.Souscription).Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutCredoc < 8 OrElse c.Id_StatutCredoc > 10)).ToList
        Else
            credoc = db.Credoc.Include(Function(c) c.StatutCredoc).Include(Function(c) c.Client).Include(Function(c) c.Agence).Include(Function(c) c.Souscription).Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription AndAlso (c.Id_StatutCredoc >= 8 AndAlso c.Id_StatutCredoc <= 10)).ToList
        End If
        Return View(credoc.OrderByDescending(Function(c) c.Id))
    End Function

    Function Reportings() As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim credoc = db.Credoc.Include(Function(c) c.StatutCredoc).Include(Function(c) c.Client).Include(Function(c) c.Agence).Include(Function(c) c.Souscription).Where(Function(c) c.Id_Souscription = sessionCOAB.Id_Souscription).ToList
        Return View(credoc.OrderByDescending(Function(c) c.Id))
    End Function

    Function Messages(Optional ByVal id As Integer = Nothing) As ActionResult

        Dim credoc As Credoc = db.Credoc.Find(id)

        If IsNothing(credoc) Then
            Return HttpNotFound()
        End If

        If credoc.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If

        ViewBag.Encours = (credoc.Id_StatutCredoc < 8 OrElse credoc.Id_StatutCredoc > 10)

        ViewBag.ObjectId = credoc.Id
        ViewBag.Operation = "CDI"

        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle", credoc.Id_StatutCredoc)
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient)).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle", credoc.Age_Agence)
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie", credoc.Id_Souscription)

        'Dim credocFilesRoot As String = GetOperationFileRoot(RadicalClient, OperationType.CDI, credoc.Id)

        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))
        ViewBag.ChargeFraisComm = New SelectList(propertiesDS.Tables("CFC").AsDataView(), "CFCID", "CFCNAME", credoc.ChargeFraisComm)
        ViewBag.Incoterm = New SelectList(propertiesDS.Tables("TCV").AsDataView(), "TCVID", "TCVNAME", credoc.Incoterm)
        ViewBag.TypeTolerence = New SelectList(propertiesDS.Tables("VARM").AsDataView(), "VARMID", "VARMNAME", credoc.TypeTolerence)
        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "CODE", "REF", credoc.Devise)
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME")
        ViewBag.Ncp_Compte = New SelectList(db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(credoc.Age_Agence) AndAlso cpt.Radical_Client.Equals(RadicalClient)), "Ncp", "DisplayString", credoc.Ncp_Compte)
        ViewBag.DocumentsCredoc = db.DocumentsCredoc.Where(Function(dc) dc.Id_Credoc = credoc.Id)
        ViewBag.TypePli = New SelectList(propertiesDS.Tables("PLI").AsDataView(), "PLIID", "PLINAME", credoc.TypePli)

        Return View(credoc)

    End Function
    '
    ' GET: /Credocs/Details/5

    Function Details(Optional ByVal id As Integer = Nothing) As ActionResult
        CurrentThread.CurrentCulture = New System.Globalization.CultureInfo("fr-FR")
        Dim credoc As Credoc = db.Credoc.Find(id)

        If IsNothing(credoc) Then
            Return HttpNotFound()
        End If

        If credoc.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If

        ViewBag.Encours = (credoc.Id_StatutCredoc < 8 OrElse credoc.Id_StatutCredoc > 10)

        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle", credoc.Id_StatutCredoc)
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient)).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle", credoc.Age_Agence)
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie", credoc.Id_Souscription)

        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))

        ViewBag.ChargeFraisComm = (From dr As DataRow In propertiesDS.Tables("CFC").AsEnumerable
                                   Where dr("CFCID").Equals(credoc.ChargeFraisComm)
                                   Select dr("CFCNAME")).FirstOrDefault.ToString
        'New SelectList(propertiesDS.Tables("CFC").AsDataView(), "CFCID", "CFCNAME", credoc.ChargeFraisComm)
        ViewBag.Incoterm = New SelectList(propertiesDS.Tables("TCV").AsDataView(), "TCVID", "TCVNAME", credoc.Incoterm)

        ViewBag.TypeTolerence = (From dr As DataRow In propertiesDS.Tables("VARM").AsEnumerable
                                   Where dr("VARMID").Equals(credoc.TypeTolerence)
                                   Select dr("VARMNAME")).FirstOrDefault.ToString
        'New SelectList(propertiesDS.Tables("VARM").AsDataView(), "VARMID", "VARMNAME", credoc.TypeTolerence)

        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "CODE", "REF", credoc.Devise)
        ViewBag.AssuranceACharge = (From dr As DataRow In propertiesDS.Tables("ASSC").AsEnumerable
                                   Where dr("ASSCID").Equals("O")
                                   Select dr("ASSCNAME")).FirstOrDefault.ToString
        'propertiesDS.Tables("ASSC").AsEnumerable.Where(Function(dr) "O".Equals(dr("ASSCID"))).Select(Function(dr) dr("ASSCNAME"))
        ViewBag.Ncp_Compte = New SelectList(db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(credoc.Age_Agence) AndAlso cpt.Radical_Client.Equals(RadicalClient)), "Ncp", "DisplayString", credoc.Ncp_Compte)
        ViewBag.DocumentsCredoc = db.DocumentsCredoc.Where(Function(dc) dc.Id_Credoc = credoc.Id)

        'ViewBag.TypePli = (From dr As DataRow In propertiesDS.Tables("PLI").AsEnumerable
        '                           Where dr("PLIID").Equals(credoc.TypePli)
        '                           Select dr("PLINAME")).FirstOrDefault.ToString
        ViewBag.TypePli = Fct.setArrayToString((From dr As DataRow In propertiesDS.Tables("PLI").AsEnumerable
                                 Where (credoc.TypePli).Contains(dr("PLIID"))
                                 Select dr("PLINAME")).ToList())

        ViewBag.ModePayement = (From dr As DataRow In propertiesDS.Tables("MODPAIEMENT").AsEnumerable
                                   Where dr("MPID").Equals(credoc.ModePayement)
                                   Select dr("MPVAL")).FirstOrDefault.ToString

        ViewBag.DetailsModePayementVisible = Not "VUE".Equals(credoc.ModePayement)

        Return View(credoc)

    End Function

    '
    ' GET: /Credocs/Create

    Function Create() As ActionResult

        ViewBag.Encours = True
        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle")
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient) AndAlso cpt.cfe.ToUpper.Equals("N")).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle")
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie")

        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))

        ViewBag.ChargeFraisComm = New SelectList(propertiesDS.Tables("CFC").AsDataView(), "CFCID", "CFCNAME")
        ViewBag.Incoterm = New SelectList(propertiesDS.Tables("TCV").AsDataView(), "TCVID", "TCVNAME")
        ViewBag.TypeTolerence = New SelectList(propertiesDS.Tables("VARM").AsDataView(), "VARMID", "VARMNAME")
        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "REF", "REF")
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME", "O")
        ViewBag.Ncp_Compte = New SelectList(New List(Of Compte), "Ncp", "DisplayString")
        ViewBag.DocumentTypes = New SelectList(db.DocumentTypes, "Id", "Libelle")
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME")
        ViewBag.TypePli = New SelectList(propertiesDS.Tables("PLI").AsDataView(), "PLIID", "PLINAME")
        ViewBag.ModePayement = New SelectList(propertiesDS.Tables("MODPAIEMENT").AsDataView(), "MPID", "MPVAL")
        ViewBag.OuvrirAuPres = New SelectList(propertiesDS.Tables("OuvrirAuPres").AsDataView(), "OPID", "OPNAME")
        ViewBag.Production = New SelectList(propertiesDS.Tables("PRODUCTION").AsDataView(), "PRODUCTIONID", "PRODUCTIONNAME", "Z")

        Dim newCredoc As Credoc = New Credoc With { _
                .DateCreation = Now, _
                .Client = db.Clients.Find(db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client), _
                .Id_StatutCredoc = 1, _
                .Id_Souscription = db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription, _
                .Etrade = True, _
                .AssuranceACharge = "O", _
                .IrrevocableConfirme = True
        }
        ' Add By Lmulud
        ' Fin Lmulud
        newCredoc.Radical_Client = newCredoc.Client.Radical
        Return View(newCredoc)
    End Function

    Function GetComptesByAgenceAndClient(ByVal Age_Agence As String, ByVal Radical_Client As String) As ActionResult
        Try

            LogInfo("Agence : " & Age_Agence & " # Client : " & Radical_Client)

            Dim comptes As IList(Of Compte) = New List(Of Compte)

            comptes = db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(Age_Agence) AndAlso cpt.Radical_Client.Equals(Radical_Client)).ToList()
            LogInfo("Nb Comptes : " & comptes.Count)

            For Each cpt As Compte In comptes
                LogInfo(cpt.Ncp)
            Next

            Dim res As List(Of Object) = New List(Of Object)

            For Each cpt As Compte In comptes
                res.Add(New With { _
                        .Ncp = cpt.Ncp, _
                        .Age_Agence = cpt.Age_Agence, _
                        .Devise = cpt.Devise, _
                        .cfe = cpt.cfe, _
                        .Radical_Client = cpt.Radical_Client})
            Next

            Return Json(res, "application/json", Encoding.UTF8, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            LogException(ex.Message)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
            End If
            Throw ex
        End Try

    End Function
    '
    ' POST: /Credocs/Create

    <HttpPost()> _
    Function Create(ByVal credoc As Credoc, ByVal Adresse As String, Optional Tpli() As String = Nothing) As ActionResult
        Dim er As Boolean = False
        Dim irrevocableConfirme = Boolean.Parse(Request.Form("IrrevocableConfirmeGroup").Split(",")(1))
        Dim nbPreDom = db.PreDom_Dossier.Where(Function(p) p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) AndAlso p.RefPreDOM.Equals(credoc.RefPreDom)).ToList()
        If nbPreDom.Count.Equals(0) Then
            ModelState.AddModelError("RefPreDom", "Référence inexistante sur votre liste des pré-domiciliations")
            er = True
        End If
        ' Added err les status Predom
        Dim err As String = getErrorStatus(credoc.RefPreDom)
        If Not String.IsNullOrEmpty(err) Then
            ModelState.AddModelError("", err)
        End If
        ' End err
        Try
            Dim _montant_string As String = Replace(credoc.MontantCDI, ",", ".")
            credoc.MontantCDIChiffre = CDec(_montant_string)
        Catch ex As Exception
            ModelState.AddModelError("Montant2", ex.Message())
        End Try
        If ModelState.IsValid And er.Equals(False) Then
            credoc.Client = Nothing
            'credoc.MontantDZD = credoc.MontantCDIChiffre
            credoc.DateCreation = Now
            credoc.REFWF = CStr(nbPreDom.FirstOrDefault().REFWF)
            processNestedDocumentsCreation(credoc)

            db.Credoc.Add(credoc)

            Try
                db.Entry(credoc).State = EntityState.Added
                db.SaveChanges()
                Try
                    db.Database.ExecuteSqlCommand(String.Format("Update Client SET Adresse = '{0}' Where Radical ='{1}'", Adresse, credoc.Radical_Client))
                Catch ex As Exception
                    Return RedirectToAction("Index")
                End Try
            Catch ex As DbEntityValidationException
                For Each validationErrors In ex.EntityValidationErrors
                    For Each validationError In validationErrors.ValidationErrors
                        Trace.TraceInformation("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage)
                        LogException("Property : " & validationError.PropertyName & " Error: " & validationError.ErrorMessage)
                    Next
                Next
            Catch ex1 As Exception
                LogException(ex1.Message)
            End Try
            Return RedirectToAction("Index")
        End If

        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle")
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient)).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle")
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie")

        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))

        ViewBag.ChargeFraisComm = New SelectList(propertiesDS.Tables("CFC").AsDataView(), "CFCID", "CFCNAME", credoc.ChargeFraisComm)
        ViewBag.Incoterm = New SelectList(propertiesDS.Tables("TCV").AsDataView(), "TCVID", "TCVNAME", credoc.Incoterm)
        ViewBag.TypeTolerence = New SelectList(propertiesDS.Tables("VARM").AsDataView(), "VARMID", "VARMNAME", credoc.TypeTolerence)
        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "REF", "REF", credoc.Devise)
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME", credoc.AssuranceACharge)
        ViewBag.Ncp_Compte = New SelectList(db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(credoc.Age_Agence) AndAlso cpt.Radical_Client.Equals(RadicalClient)), "Ncp", "DisplayString", credoc.Ncp_Compte)
        ViewBag.DocumentsCredoc = db.DocumentsCredoc.Where(Function(dc) dc.Id_Credoc = credoc.Id)
        ViewBag.TypePli = New SelectList(propertiesDS.Tables("PLI").AsDataView(), "PLIID", "PLINAME", credoc.TypePli)
        ViewBag.ModePayement = New SelectList(propertiesDS.Tables("MODPAIEMENT").AsDataView(), "MPID", "MPVAL", credoc.ModePayement)
        ViewBag.OuvrirAuPres = New SelectList(propertiesDS.Tables("OuvrirAuPres").AsDataView(), "OPID", "OPNAME", credoc.OuvrirAuPres)
        ViewBag.Production = New SelectList(propertiesDS.Tables("PRODUCTION").AsDataView(), "PRODUCTIONID", "PRODUCTIONNAME", credoc.Production)

        credoc.DateCreation = Now
        credoc.Client = db.Clients.Find(db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client)
        credoc.Id_StatutCredoc = 1
        credoc.Id_Souscription = db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription
        credoc.Etrade = True
        credoc.AssuranceACharge = "O"

        'credoc.Irrevocable = Not irrevocableConfirme
        credoc.IrrevocableConfirme = irrevocableConfirme

        ViewBag.Encours = True

        Return View(credoc)

    End Function

    '
    ' GET: /Credocs/Edit/5

    Function Edit(Optional ByVal id As Integer = Nothing) As ActionResult

        Dim credoc As Credoc = db.Credoc.Find(id)

        If IsNothing(credoc) Then
            Return HttpNotFound()
        End If

        If credoc.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If
        credoc.MontantCDI = CDec(credoc.MontantCDIChiffre)
        ViewBag.Encours = (credoc.Id_StatutCredoc < 8 OrElse credoc.Id_StatutCredoc > 10)
        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle", credoc.Id_StatutCredoc)
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient)).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle", credoc.Age_Agence)
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie", credoc.Id_Souscription)

        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))
        ViewBag.ChargeFraisComm = New SelectList(propertiesDS.Tables("CFC").AsDataView(), "CFCID", "CFCNAME", credoc.ChargeFraisComm)
        ViewBag.Incoterm = New SelectList(propertiesDS.Tables("TCV").AsDataView(), "TCVID", "TCVNAME", credoc.Incoterm)
        ViewBag.TypeTolerence = New SelectList(propertiesDS.Tables("VARM").AsDataView(), "VARMID", "VARMNAME", credoc.TypeTolerence)
        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "REF", "REF", credoc.Devise)
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME", credoc.AssuranceACharge)
        ViewBag.Ncp_Compte = New SelectList(db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(credoc.Age_Agence) AndAlso cpt.Radical_Client.Equals(RadicalClient)), "Ncp", "DisplayString", credoc.Ncp_Compte)
        ViewBag.DocumentsCredoc = db.DocumentsCredoc.Where(Function(dc) dc.Id_Credoc = credoc.Id)
        ViewBag.TypePli = New SelectList(propertiesDS.Tables("PLI").AsDataView(), "PLIID", "PLINAME")
        ViewBag.ModePayement = New SelectList(propertiesDS.Tables("MODPAIEMENT").AsDataView(), "MPID", "MPVAL", credoc.ModePayement)
        ViewBag.OuvrirAuPres = New SelectList(propertiesDS.Tables("OuvrirAuPres").AsDataView(), "OPID", "OPNAME", credoc.OuvrirAuPres)
        ViewBag.Production = New SelectList(propertiesDS.Tables("PRODUCTION").AsDataView(), "PRODUCTIONID", "PRODUCTIONNAME", credoc.Production)
        ViewBag.Tpli = getTabPli(credoc.TypePli)
        Return View(credoc)

    End Function
    '
    Function getTabPli(ByVal a As String) As Array
        Dim s As String = ""
        Return Split(a, ",")
    End Function

    '1111ZZZZZ
    ' POST: /Credocs/Edit/5

    <HttpPost()> _
    Function Edit(ByVal credoc As Credoc, ByVal Adresse As String, Optional Tpli() As String = Nothing) As ActionResult
        Dim er As Boolean = False
        Dim nbPreDom = db.PreDom_Dossier.Where(Function(p) p.Id_Souscription.Equals(sessionCOAB.Id_Souscription) And p.RefPreDOM.Contains(credoc.RefPreDom)).ToList()
        If nbPreDom.Count.Equals(0) Then
            ModelState.AddModelError("RefPreDom", "Référence inexistante sur votre liste des pré-domiciliations")
            er = True
        End If
        ' Added err les status Predom
        Dim err As String = getErrorStatus(credoc.RefPreDom)
        If Not String.IsNullOrEmpty(err) Then
            ModelState.AddModelError("", err)
        End If
        ' End err
        Dim irrevocableConfirme = Boolean.Parse(Request.Form("IrrevocableConfirmeGroup").Split(",")(1))
        Try
            Dim _montant_string As String = Replace(credoc.MontantCDI, ",", ".")
            credoc.MontantCDIChiffre = CDbl(_montant_string)
        Catch ex As Exception
            ModelState.AddModelError("MontantCDI", ex.Message())
        End Try
        If ModelState.IsValid And er.Equals(False) Then
            credoc.Client = Nothing
            Dim irrevocableGroup As Boolean = Request.Form.GetValues("IrrevocableConfirmeGroup").First
            credoc.Irrevocable = irrevocableGroup
            'credoc.MontantDZD = credoc.MontantCDIChiffre
            processNestedDocuments(credoc)
            credoc.REFWF = CStr(nbPreDom.FirstOrDefault().REFWF)
            db.Entry(credoc).State = EntityState.Modified
            db.SaveChanges()
            Try
                db.Database.ExecuteSqlCommand(String.Format("Update Client SET Adresse = '{0}' Where Radical ='{1}'", Adresse, credoc.Radical_Client))
            Catch ex As Exception
                Return RedirectToAction("Index")
            End Try
            Return RedirectToAction("Index")
        End If

        credoc.Client = db.Clients.Find(credoc.Radical_Client)
        credoc.StatutCredoc = db.StatutCredocs.Find(credoc.Id_StatutCredoc)

        'credoc.Irrevocable = Not irrevocableConfirme
        credoc.IrrevocableConfirme = irrevocableConfirme

        ViewBag.Id_StatutCredoc = New SelectList(db.StatutCredocs, "Id", "Libelle", credoc.Id_StatutCredoc)
        Dim RadicalClient As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
        ViewBag.Radical_Client = RadicalClient

        Dim AgenceClient As IList(Of Agence) = db.Comptes.Where(Function(cpt) cpt.Client.Radical.Equals(RadicalClient)).Select(Function(cpt) cpt.Agence).Distinct().ToList
        ViewBag.Age_Agence = New SelectList(AgenceClient, "Age", "Libelle", credoc.Age_Agence)
        ViewBag.Id_Souscription = New SelectList(db.Souscriptions, "Id", "USaisie", credoc.Id_Souscription)


        Dim propertiesDS As DataSet = New DataSet()
        propertiesDS.ReadXml(Server.MapPath("~/Properties/AppProperties.xml"))
        ViewBag.ChargeFraisComm = New SelectList(propertiesDS.Tables("CFC").AsDataView(), "CFCID", "CFCNAME", credoc.ChargeFraisComm)
        ViewBag.Incoterm = New SelectList(propertiesDS.Tables("TCV").AsDataView(), "TCVID", "TCVNAME", credoc.Incoterm)
        ViewBag.TypeTolerence = New SelectList(propertiesDS.Tables("VARM").AsDataView(), "VARMID", "VARMNAME", credoc.TypeTolerence)
        ViewBag.Devise = New SelectList(propertiesDS.Tables("DEVISE").AsDataView(), "REF", "REF", credoc.Devise)
        ViewBag.AssuranceACharge = New SelectList(propertiesDS.Tables("ASSC").AsDataView(), "ASSCID", "ASSCNAME", credoc.AssuranceACharge)
        ViewBag.Ncp_Compte = New SelectList(db.Comptes.Where(Function(cpt) cpt.Age_Agence.Equals(credoc.Age_Agence) AndAlso cpt.Radical_Client.Equals(RadicalClient)), "Ncp", "DisplayString", credoc.Ncp_Compte)
        ViewBag.DocumentsCredoc = db.DocumentsCredoc.Where(Function(dc) dc.Id_Credoc = credoc.Id)
        ViewBag.TypePli = New SelectList(propertiesDS.Tables("PLI").AsDataView(), "PLIID", "PLINAME", credoc.TypePli)
        ViewBag.ModePayement = New SelectList(propertiesDS.Tables("MODPAIEMENT").AsDataView(), "MPID", "MPVAL", credoc.ModePayement)
        ViewBag.OuvrirAuPres = New SelectList(propertiesDS.Tables("OuvrirAuPres").AsDataView(), "OPID", "OPNAME", credoc.OuvrirAuPres)
        ViewBag.Production = New SelectList(propertiesDS.Tables("PRODUCTION").AsDataView(), "PRODUCTIONID", "PRODUCTIONNAME", credoc.Production)
        ViewBag.Encours = (credoc.Id_StatutCredoc < 8 OrElse credoc.Id_StatutCredoc > 10)

        Return View(credoc)

    End Function


    Function Send(Optional ByVal id As Integer = Nothing) As ActionResult

        Dim credoc As Credoc = db.Credoc.Find(id)
        Dim allReports As IList(Of String) = New List(Of String)
        Dim divListDocs As TagBuilder = New TagBuilder("div")

        If IsNothing(credoc) Then
            Return HttpNotFound()
        End If

        If credoc.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If

        Try
            credoc.MontantCDI = credoc.MontantCDIChiffre
            allReports = InternalGetAllReports(credoc)
            Dim urlHelper As UrlHelper = New UrlHelper(Request.RequestContext)
            If ModelState.IsValid Then
                credoc.Id_StatutCredoc = 2
                db.Entry(credoc).State = EntityState.Modified
                db.SaveChanges()
            End If


            divListDocs.AddCssClass("list-group")

            For Each filePath As String In allReports
                Dim fileName As String = Path.GetFileName(filePath)
                Dim aTag As TagBuilder = New TagBuilder("a")
                aTag.MergeAttribute("href", urlHelper.Action("Download", "Files") _
                                            & "/" & fileName _
                                            & "?operation=CDI&IdCible=" & credoc.Id)
                aTag.AddCssClass("list-group-item")
                aTag.AddCssClass("list-group-item-info")
                If fileName.Equals("Demande_Ouverture.pdf") Then
                    aTag.InnerHtml = "<p> Demande d'ouverture du crédit documentaire</p>"
                ElseIf fileName.Equals("Domiciliation.pdf") Then
                    aTag.InnerHtml = "<p> Demande de domiciliation</p>"
                ElseIf fileName.Equals("Engagement.pdf") Then
                    aTag.InnerHtml = "<p> Engagement de non revante en l'état </p>"
                End If
                divListDocs.InnerHtml = divListDocs.InnerHtml & aTag.ToString(TagRenderMode.Normal)
            Next

        Catch ex As Exception

            LogException(ex.Message)
        End Try

        If Not Request.IsAjaxRequest Then
            Return Redirect(Request.UrlReferrer.ToString)
        Else
            Dim response As String = "<p>La demande d'ouverture à été soumise a votre banque.</p>"
            If allReports.Count > 0 Then
                response = response & "<p>En plus de votre pièce jointe, ci-joint les documents envoyé à la banque.</p> " & divListDocs.ToString(TagRenderMode.Normal)
            End If
            Return Content(response, "text/html") 'Json(Json.encode(), JsonRequestBehavior.AllowGet)
        End If



    End Function

    Function GenerateReport(Optional ByVal id As Integer = Nothing, Optional ByVal typeDocument As UtilityFunctions.DocumentReglementaire = UtilityFunctions.DocumentReglementaire.ALL) As ActionResult

        Dim credoc As Credoc = db.Credoc.Find(id)

        If IsNothing(credoc) Then
            Return HttpNotFound()
        End If

        If credoc.Id_Souscription <> sessionCOAB.Id_Souscription Then
            LogSecurityViolation()
            RedirectToAction("Index")
        End If

        Select Case typeDocument
            Case UtilityFunctions.DocumentReglementaire.ALL
                GetAllReports(credoc)
            Case UtilityFunctions.DocumentReglementaire.DDOM
                Dim ddomPath As String = GetDemandeDomiciliation(credoc)
                If Not String.IsNullOrEmpty(ddomPath) Then
                    Return New DownloadResult(ddomPath, "Demande de domiciliation.pdf")
                End If
            Case UtilityFunctions.DocumentReglementaire.DOUV
                Dim doPath As String = GetDemandeOuvertureReport(credoc)
                If Not String.IsNullOrEmpty(doPath) Then
                    Return New DownloadResult(doPath, "Demande Ouverture.pdf")
                End If

            Case UtilityFunctions.DocumentReglementaire.ENGA
                Dim engPath As String = GetEngagementReport(credoc)
                If Not String.IsNullOrEmpty(engPath) Then
                    Return New DownloadResult(engPath, "Engagement.pdf")
                End If
        End Select
        'Try
        '    Dim listCredoc As IList(Of Credoc) = New List(Of Credoc)
        '    Dim ds As DataSet = New DataSet
        '    ds.ReadXmlSchema(Server.MapPath("~\Report\Schema\Base.xsd"))
        '    listCredoc.Add(credoc)
        '    UtilityFunctions.EntityToDataSet(Of Credoc)(ds, listCredoc)

        '    Dim report As ReportDocument = New ReportDocument()
        '    report.Load(Server.MapPath("~\Report\CDI\DO.rpt"))
        '    report.SetDataSource(ds)
        '    report.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Server.MapPath("~\Files\CDI") & credoc.Id & ".pdf")
        '    ' Génération des documents
        'Catch ex As Exception
        '    Return Json("Une erreur est survenur pendant l'opération, la demande n'as pas pu être soumise", JsonRequestBehavior.AllowGet)
        'End Try

    End Function

    Private Function GetEngagementReport(credoc As Credoc) As String
        Try

            Dim listCredoc As IList(Of Credoc) = New List(Of Credoc)
            Dim listAgences As IList(Of Agence) = New List(Of Agence)
            Dim listClients As IList(Of Client) = New List(Of Client)
            Dim listComptes As IList(Of Compte) = New List(Of Compte)

            Dim ds As DataSet = New DataSet

            ds.ReadXmlSchema(Server.MapPath("~\Report\Schema\Base.xsd"))

            listCredoc.Add(credoc)
            listAgences.Add(credoc.Agence)
            listClients.Add(credoc.Client)
            listComptes.Add(db.Comptes.Where(Function(c) c.Age_Agence = credoc.Age_Agence AndAlso c.Ncp = credoc.Ncp_Compte).FirstOrDefault)

            UtilityFunctions.EntityToDataSet(Of Agence)(ds, listAgences)
            UtilityFunctions.EntityToDataSet(Of Client)(ds, listClients)
            UtilityFunctions.EntityToDataSet(Of Credoc)(ds, listCredoc)
            UtilityFunctions.EntityToDataSet(Of Compte)(ds, listComptes)

            Dim report As ReportDocument = New ReportDocument()
            Dim RPTPATH As String = Server.MapPath("~\Report\CDI\ENG.rpt")
            LogInfo(RPTPATH)
            report.Load(Server.MapPath("~\Report\CDI\ENG.rpt"))
            report.SetDataSource(ds)

            'Dim filePath As String = Path.Combine(StorageRoot(OperationResolver(OperationType.CDI), credoc.Id), OperationType.CDI.ToString & "__" & credoc.Id & "__" & Now.ToString("yyyyMMddhhmmss") & "__Engagement.pdf")
            Dim filePath As String = Path.Combine(StorageRoot(OperationResolver(OperationType.CDI), credoc.Id), "Engagement.pdf")
            LogInfo("Reporting file path ========== > " & filePath)
            report.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, filePath)

            Return filePath

        Catch ex As Exception
            LogException(ex.Message)
            LogException(ex.StackTrace)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
                LogException(ex.InnerException.StackTrace)
            End If
        End Try

    End Function

    Private Function GetDemandeOuvertureReport(credoc As Credoc) As String
        Try
            Dim listCredoc As IList(Of Credoc) = New List(Of Credoc)
            Dim listAgences As IList(Of Agence) = New List(Of Agence)
            Dim listClients As IList(Of Client) = New List(Of Client)
            Dim listComptes As IList(Of Compte) = New List(Of Compte)

            Dim ds As DataSet = New DataSet
            ds.ReadXmlSchema(Server.MapPath("~\Report\Schema\Base.xsd"))

            listCredoc.Add(credoc)
            listAgences.Add(credoc.Agence)
            listClients.Add(credoc.Client)
            listComptes.Add(db.Comptes.Where(Function(c) c.Age_Agence = credoc.Age_Agence AndAlso c.Ncp = credoc.Ncp_Compte).FirstOrDefault)

            UtilityFunctions.EntityToDataSet(Of Agence)(ds, listAgences)
            UtilityFunctions.EntityToDataSet(Of Client)(ds, listClients)
            UtilityFunctions.EntityToDataSet(Of Credoc)(ds, listCredoc)
            UtilityFunctions.EntityToDataSet(Of Compte)(ds, listComptes)
            UtilityFunctions.EntityToDataSet(Of DocumentsCredocsBancaire)(ds, credoc.DocumentsCredocsBancaire)
            UtilityFunctions.EntityToDataSet(Of DocumentsCredocsPli)(ds, credoc.DocumentsCredocsPlis)

            Dim report As ReportDocument = New ReportDocument()
            Dim RPTPATH As String = Server.MapPath("~\Report\CDI\DO.rpt")
            LogInfo(RPTPATH)
            report.Load(Server.MapPath("~\Report\CDI\DO.rpt"))

            report.SetDataSource(ds)

            'Dim filePath As String = Path.Combine(StorageRoot(OperationResolver(OperationType.CDI), credoc.Id), OperationType.CDI.ToString & "__" & credoc.Id & "__" & Now.ToString("yyyyMMddhhmmss") & "__Demande_Ouverture.pdf")
            Dim filePath As String = Path.Combine(StorageRoot(OperationResolver(OperationType.CDI), credoc.Id), "Demande_Ouverture.pdf")
            LogInfo("Reporting file path ========== > " & filePath)
            report.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, filePath)

            Return filePath

        Catch ex As Exception
            LogException(ex.Message)
            LogException(ex.StackTrace)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
                LogException(ex.InnerException.StackTrace)
            End If
        End Try
    End Function

    Private Function GetDemandeDomiciliation(credoc As Credoc) As String
        Try

            Dim listCredoc As IList(Of Credoc) = New List(Of Credoc)
            Dim listAgences As IList(Of Agence) = New List(Of Agence)
            Dim listClients As IList(Of Client) = New List(Of Client)
            Dim listComptes As IList(Of Compte) = New List(Of Compte)

            Dim ds As DataSet = New DataSet
            ds.ReadXmlSchema(Server.MapPath("~\Report\Schema\Base.xsd"))

            listCredoc.Add(credoc)
            listAgences.Add(credoc.Agence)
            listClients.Add(credoc.Client)
            listComptes.Add(db.Comptes.Where(Function(c) c.Age_Agence = credoc.Age_Agence AndAlso c.Ncp = credoc.Ncp_Compte).FirstOrDefault)

            UtilityFunctions.EntityToDataSet(Of Agence)(ds, listAgences)
            UtilityFunctions.EntityToDataSet(Of Client)(ds, listClients)
            UtilityFunctions.EntityToDataSet(Of Credoc)(ds, listCredoc)
            UtilityFunctions.EntityToDataSet(Of Compte)(ds, listComptes)

            Dim report As ReportDocument = New ReportDocument()
            Dim RPTPATH As String = Server.MapPath("~\Report\CDI\DOM.rpt")
            LogInfo(RPTPATH)
            report.Load(Server.MapPath("~\Report\CDI\DOM.rpt"))
            report.SetDataSource(ds)


            'Dim filePath As String = Path.Combine(StorageRoot(OperationResolver(OperationType.CDI), credoc.Id), OperationType.CDI.ToString & "__" & credoc.Id & "__" & Now.ToString("yyyyMMddhhmmss") & "__Demande_Domiciliation.pdf")
            Dim filePath As String = Path.Combine(StorageRoot(OperationResolver(OperationType.CDI), credoc.Id), "Domiciliation.pdf")
            LogInfo("Reporting file path ========== > " & filePath)
            report.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, filePath)

            Return filePath

        Catch ex As Exception
            LogException(ex.Message)
            LogException(ex.StackTrace)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
                LogException(ex.InnerException.StackTrace)
            End If
        End Try
    End Function

    Private Function InternalGetAllReports(credoc As Credoc) As IList(Of String)

        Dim AllDocs As IList(Of String) = New List(Of String)
        Try

            If credoc.Production Then
                Dim engagementPath As String = GetEngagementReport(credoc)
                If Not String.IsNullOrEmpty(engagementPath) Then
                    AllDocs.Add(engagementPath)
                End If
            End If

            Dim demandeOuverture As String = GetDemandeOuvertureReport(credoc)
            Dim demandedom As String = GetDemandeDomiciliation(credoc)

            If Not String.IsNullOrEmpty(demandeOuverture) Then
                AllDocs.Add(demandeOuverture)
            End If

            If Not String.IsNullOrEmpty(demandedom) Then
                AllDocs.Add(demandedom)
            End If

        Catch ex As Exception
            LogException(ex.Message)
            LogException(ex.StackTrace)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
                LogException(ex.InnerException.StackTrace)
            End If
        End Try

        Return AllDocs

    End Function

    Private Function GetAllReports(credoc As Credoc) As String

        Try

            Dim AllDocs As IList(Of String) = InternalGetAllReports(credoc)

            If AllDocs.Count > 0 Then
                Using _zip As New ZipFile()
                    _zip.AlternateEncodingUsage = ZipOption.AsNecessary
                    _zip.AddDirectoryByName("CDI_" & credoc.Id)
                    For Each doc As String In AllDocs
                        _zip.AddFile(doc, "CDI_" & credoc.Id)
                    Next

                    Response.Clear()
                    Response.BufferOutput = False
                    Dim zipName As String = [String].Format("CDI_{0}_{1}.zip", credoc.Id, Now.ToString("ddMMyyyy"))
                    Response.ContentType = "application/zip"
                    Response.AddHeader("content-disposition", "attachment; filename=" + zipName)
                    _zip.Save(Response.OutputStream)
                    Response.[End]()
                End Using
            End If

        Catch ex As Exception
            LogException(ex.Message)
            LogException(ex.StackTrace)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
                LogException(ex.InnerException.StackTrace)
            End If
        End Try

    End Function

    Private Sub processNestedDocuments(credoc As Credoc)

        Try

            Dim docBancaireToRemove As IList(Of DocumentsCredocsBancaire) = (From doc As DocumentsCredocsBancaire In credoc.DocumentsCredocsBancaire.AsEnumerable
                                                           Where doc.DeleteDocument OrElse doc.Exemplaires = 0
                                                           Select doc).ToList

            Dim docPliToRemove As IList(Of DocumentsCredocsPli) = (From doc As DocumentsCredocsPli In credoc.DocumentsCredocsPlis.AsEnumerable
                                                               Where doc.DeleteDocument OrElse doc.Exemplaires = 0
                                                               Select doc).ToList

            Dim docBancaireToCreate As IList(Of DocumentsCredocsBancaire) = (From doc As DocumentsCredocsBancaire In credoc.DocumentsCredocsBancaire.AsEnumerable
                                                           Where doc.Id = 0 AndAlso doc.Id_Credoc = 0 AndAlso Not doc.DeleteDocument AndAlso Not doc.Exemplaires = 0
                                                           Select doc).ToList

            Dim docPliToCreate As IList(Of DocumentsCredocsPli) = (From doc As DocumentsCredocsPli In credoc.DocumentsCredocsPlis.AsEnumerable
                                                           Where doc.Id = 0 AndAlso doc.Id_Credoc = 0 AndAlso Not doc.DeleteDocument AndAlso Not doc.Exemplaires = 0
                                                           Select doc).ToList


            For Each doc As DocumentsCredocsBancaire In docBancaireToRemove
                credoc.DocumentsCredocsBancaire.Remove(doc)
                Dim docDB As DocumentsCredoc = db.DocumentsCredoc.Find(doc.Id)
                If Not docDB Is Nothing Then
                    db.DocumentsCredoc.Remove(docDB)
                    db.SaveChanges()
                End If
            Next

            For Each doc As DocumentsCredocsBancaire In docBancaireToCreate
                db.DocumentsCredoc.Add(New DocumentsCredoc With { _
                                             .Exemplaires = doc.Exemplaires, _
                                             .Nom = doc.Nom, _
                                             .Circuit = "B", _
                                             .Id_Credoc = credoc.Id})
                db.SaveChanges()

            Next

            credoc.DocumentsCredocsBancaire.Clear()

            If Not credoc.TypePli.Equals("NP") Then

                For Each doc As DocumentsCredocsPli In docPliToRemove
                    credoc.DocumentsCredocsPlis.Remove(doc)
                    Dim docDB As DocumentsCredoc = db.DocumentsCredoc.Find(doc.Id)
                    If Not docDB Is Nothing Then
                        db.DocumentsCredoc.Remove(docDB)
                        db.SaveChanges()
                    End If
                Next

                For Each doc As DocumentsCredocsPli In docPliToCreate
                    db.DocumentsCredoc.Add(New DocumentsCredoc With { _
                                                 .Exemplaires = doc.Exemplaires, _
                                                 .Nom = doc.Nom, _
                                                 .Circuit = "P", _
                                                 .Id_Credoc = credoc.Id})
                    db.SaveChanges()
                Next
                credoc.DocumentsCredocsPlis.Clear()
            Else
                Dim docPliDb As IList(Of DocumentsCredoc) = db.DocumentsCredoc.Where(Function(d) d.Id_Credoc = credoc.Id AndAlso d.Circuit.Equals("P")).ToList
                For Each doc As DocumentsCredoc In docPliDb
                    If Not doc Is Nothing Then
                        db.DocumentsCredoc.Remove(doc)
                        db.SaveChanges()
                    End If
                Next
                credoc.DocumentsCredocsPlis.Clear()
            End If

        Catch ex As Exception

            LogException(ex.Message)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
            End If

        End Try


    End Sub

    Private Sub processNestedDocumentsCreation(credoc As Credoc)

        Try

            Dim docBancaireToRemove As IList(Of DocumentsCredocsBancaire) = (From doc As DocumentsCredocsBancaire In credoc.DocumentsCredocsBancaire.AsEnumerable
                                                                             Where doc.DeleteDocument OrElse doc.Exemplaires = 0
                                                                             Select doc).ToList

            Dim docPliToRemove As IList(Of DocumentsCredocsPli) = (From doc As DocumentsCredocsPli In credoc.DocumentsCredocsPlis.AsEnumerable
                                                                   Where doc.DeleteDocument OrElse doc.Exemplaires = 0
                                                                   Select doc).ToList

            Dim docBancaireToCreate As IList(Of DocumentsCredocsBancaire) = (From doc As DocumentsCredocsBancaire In credoc.DocumentsCredocsBancaire.AsEnumerable
                                                                             Where doc.Id = 0 AndAlso doc.Id_Credoc = 0 AndAlso Not doc.DeleteDocument AndAlso Not doc.Exemplaires = 0
                                                                             Select doc).ToList

            Dim docPliToCreate As IList(Of DocumentsCredocsPli) = (From doc As DocumentsCredocsPli In credoc.DocumentsCredocsPlis.AsEnumerable
                                                                   Where doc.Id = 0 AndAlso doc.Id_Credoc = 0 AndAlso Not doc.DeleteDocument AndAlso Not doc.Exemplaires = 0
                                                                   Select doc).ToList


            For Each doc As DocumentsCredocsBancaire In docBancaireToRemove
                credoc.DocumentsCredocsBancaire.Remove(doc)
                Dim docDB As DocumentsCredoc = db.DocumentsCredoc.Find(doc.Id)
                If Not docDB Is Nothing Then
                    db.DocumentsCredoc.Remove(docDB)
                    db.SaveChanges()
                End If
            Next

            For Each doc As DocumentsCredocsBancaire In docBancaireToCreate
                credoc.DocumentsCredocs.Add(New DocumentsCredoc With {
                                             .Exemplaires = doc.Exemplaires,
                                             .Nom = doc.Nom,
                                             .Circuit = "B"})

            Next

            credoc.DocumentsCredocsBancaire.Clear()

            If Not credoc.TypePli.Equals("NP") Then

                For Each doc As DocumentsCredocsPli In docPliToRemove
                    credoc.DocumentsCredocsPlis.Remove(doc)
                    Dim docDB As DocumentsCredoc = db.DocumentsCredoc.Find(doc.Id)
                    If Not docDB Is Nothing Then
                        db.DocumentsCredoc.Remove(docDB)
                        db.SaveChanges()
                    End If
                Next

                For Each doc As DocumentsCredocsPli In docPliToCreate
                    credoc.DocumentsCredocs.Add(New DocumentsCredoc With {
                                                 .Exemplaires = doc.Exemplaires,
                                                 .Nom = doc.Nom,
                                                 .Circuit = "P"})

                Next
                credoc.DocumentsCredocsPlis.Clear()
            Else
                credoc.DocumentsCredocsPlis.Clear()
            End If

        Catch ex As Exception

            LogException(ex.Message)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
            End If

        End Try
    End Sub
    ' Afficher les message d'erreur Credoc / Predom.
    Private Function getErrorStatus(ByVal ref As String) As String
        Dim bo As Boolean = False
        Dim msg As String = String.Empty
        Try
            Dim ld = db.PreDom_Dossier.FirstOrDefault(Function(d) d.RefPreDOM.Equals(ref))
            '---- 1er test statut brouillant
            If bo = False And ld.Statut.Equals(1) Then
                msg = String.Format(db.Parametres.FirstOrDefault(Function(m) m.Param.Equals("err1")).Value, ld.RefPreDOM)
                bo = True
            End If
            '---- 2ème test Référence Jira «
            If bo = False And String.IsNullOrEmpty(ld.REFWF) Then
                msg = String.Format(db.Parametres.FirstOrDefault(Function(m) m.Param.Equals("err2")).Value, ld.RefPreDOM)
                bo = True
            End If
            '---- 1er test statut annulé ou rejeté
            If bo = False And {4, 5}.Contains(ld.Statut) Then
                msg = String.Format(db.Parametres.FirstOrDefault(Function(m) m.Param.Equals("err3")).Value, ld.RefPreDOM)
                bo = True
            End If
            '---- 1er test statut cours ou complement d'infos
            If bo = False And {2, 3}.Contains(ld.Statut) Then
                msg = String.Format(db.Parametres.FirstOrDefault(Function(m) m.Param.Equals("err4")).Value, ld.RefPreDOM)
                bo = True
            End If
            '---- return msg
            Return HttpUtility.HtmlDecode(msg)
        Catch ex As Exception
            Return String.Empty
        End Try
        Return String.Empty
    End Function

    Function getPreDomByRef(ByVal id As String) As ActionResult
        If Not String.IsNullOrEmpty(id) Then
            Dim _dom = db.PreDom_Dossier.Where(Function(e) e.RefPreDOM.Equals(id)).FirstOrDefault
            Return Json(New With {.result = "ok", ._Agence = _dom.Agence, ._Montant = _dom.Montant, ._Devise = _dom.Devise}, JsonRequestBehavior.AllowGet)
        End If
        Return Json(New With {.result = "ko"}, JsonRequestBehavior.AllowGet)
    End Function

End Class
