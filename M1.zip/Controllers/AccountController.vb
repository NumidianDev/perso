﻿Imports System.Diagnostics.CodeAnalysis
Imports System.Security.Principal
Imports System.Transactions
Imports System.Web.Routing
Imports WebMatrix.WebData
Imports E_Trade.Data
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.IO
Imports CaptchaMvc.HtmlHelpers
Imports CaptchaMvc.Infrastructure
Imports System.Data.Entity

<Authorize()> _
Public Class AccountController
    Inherits System.Web.Mvc.Controller

    '
    ' GET: /Account/Login

    <AllowAnonymous()> _
    Public Function Login(ByVal returnUrl As String) As ActionResult
        'Session("Tab") = GenerateMap()
        ViewData("ReturnUrl") = returnUrl
        Return View()
    End Function

    '
    ' POST: /Account/Login

    <HttpPost()> _
    <AllowAnonymous()> _
    <ValidateAntiForgeryToken()> _
    Public Function Login(ByVal model As LoginModel, ByVal returnUrl As String) As ActionResult

        model.Password = ReversePassword(model)

        If ModelState.IsValid AndAlso WebSecurity.Login(model.UserName, model.Password, persistCookie:=model.RememberMe) Then
            Dim userId As Int32 = WebSecurity.GetUserId(model.UserName)
            Dim userContext As DB = New DB()
            Dim coabonne As COAB = userContext.COABS.Find(userId)
            Dim isDeny As String = Fct.IsDomAllowed(coabonne.Souscription.Client.NIDF, coabonne.Souscription.Client.RC)
            If Not String.IsNullOrEmpty(isDeny) Then
                ModelState.AddModelError("", "Vous êtes interdit de domiciliation, nous vous convions à prendre attache avec votre agence Société Générale Algérie.")
                Return View(model)
            End If
            If coabonne IsNot Nothing Then
                If coabonne.FirstUse Then
                    Return RedirectToAction("Manage", New With {.Message = "Veuillez entrer le nouveau mot de passe"})
                Else
                    Return RedirectToLocal(returnUrl)
                End If
            Else
                ModelState.AddModelError("", "Identifiant ou mot de passe est invalide")
                Return View(model)
            End If
        End If
        ModelState.AddModelError("", "Identifiant ou mot de passe est invalide")
        Return View(model)
    End Function

    '
    ' POST: /Account/LogOff

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Public Function LogOff() As ActionResult
        WebSecurity.Logout()
        Return RedirectToAction("Index", "Home")
    End Function

    '
    ' GET: /Account/Register
    <Authorize()> _
    <AllowAnonymous()> _
    Public Function Register() As ActionResult
        CaptchaUtils.CaptchaManager.StorageProvider = New CookieStorageProvider()
        Return View()
    End Function

    '
    ' POST: /Account/Register


    <HttpPost()> _
    <AllowAnonymous()> _
    <ValidateAntiForgeryToken()> _
    Public Function Register(ByVal model As RegisterModel) As ActionResult
        Dim userContext As DB = New DB()
        '--- verifier la captcha
        If (Not Me.IsCaptchaValid("Captcha is not valid")) Then
            ModelState.AddModelError("", "Les caractères que vous avez saisis ne correspondent pas à l'image Captcha, veuillez réessayer.")
            View(model)
        End If
        '------
        Dim isDeny As String = Fct.IsDomAllowed(model.NIF, model.RC)
        If Not String.IsNullOrEmpty(isDeny) Then
            ModelState.AddModelError("", "Vous êtes interdit de domiciliation, nous vous convions à prendre attache avec votre agence Société Générale Algérie.")
            View(model)
        End If
        '---------
        Dim isExist As Boolean = False
        Dim pwd = Fct.CreateRandomPassword
        '------
        If ModelState.IsValid Then
            ' Charger de Delta
            Try
                Dim _u As RegisterModel = Fct.getClient(nif:=model.NIF, rc:=model.RC)
                If _u Is Nothing Then
                    ModelState.AddModelError("", "Merci de vous approcher de votre agence SGA pour vérifier votre NIF ou votre RC.")
                    Return View(model)
                End If
                ' isEtrade Client
                Dim pack As Integer = Fct.IsEtrade(_u.radical)
                If pack = 1 Then
                    ModelState.AddModelError("", "Vous bénéficiez du pack SG@TRADE, vous êtes invités à accéder directement à l’outil sans besoin de vous réinscrire.")
                    Return View(model)
                End If
                ' comparaison Email entreprise
                Dim _isValidMailEntreprise As Boolean = String.Compare(Trim(_u.EmailEntreprise), Trim(model.EmailEntreprise), True)
                If _isValidMailEntreprise = True Then
                    ModelState.AddModelError("", "Votre Email Entreprise est incorrect, merci de vous approcher de votre agence SGA. ")
                    Return View(model)
                End If
                ' verifier le client ?
                Dim _isCoab = 0

                'Dim _isSouscrit = (From s In userContext.Souscriptions
                '                       Where s.Radical_Client.Equals(_u.radical.ToString())
                '                       Select s).FirstOrDefault()
                'If _isSouscrit.Id Then
                '    _isCoab = (From c In userContext.COABS
                '               Where c.Id_Souscription.Equals(_isSouscrit.Id)
                '               Select c).ToList().Count()
                'End If
                _isCoab = Fct.getCOAB(_u.radical)
                ' verfifier le COAB ?
                Dim _o = WebSecurity.ConfirmAccount(model.EmailContact, Nothing)
                Dim userName As String = model.EmailContact
                Dim mailEntreprise As String = model.EmailEntreprise
                If _o = False Then
                    Dim _r As String = WebSecurity.CreateUserAndAccount(userName, pwd, model, _o)
                    If String.IsNullOrEmpty(_r) Then
                        ModelState.AddModelError("", "Votre inscription n'est pas validée, Merci de contacter votre agence SGA . ")
                        Return View(model)
                    End If
                ElseIf _isCoab > 0 Then
                    Dim u As MembershipUser = Membership.GetUser(model.EmailContact)
                    Membership.UpdateUser(u)
                    pwd = userContext.COABS.Where(Function(c) c.Email.Equals(userName)).FirstOrDefault().PWD_TMP
                Else
                    ModelState.AddModelError("", "Votre Email Contact est déjà enregistré. Merci d'en choisir un autre.  ")
                    Return View(model)
                End If
                ' E
                Dim _from As String = userContext.Parametres.Where(Function(p) p.Param.Equals("EtradeMailerAdress")).FirstOrDefault().Value
                Dim _objet As String = userContext.Parametres.Where(Function(p) p.Param.Equals("ObjetMailerPredom")).FirstOrDefault().Value
                Dim BodyEntreprise As String = String.Format(Fct.Template("~/Content/Template/inscription_entreprise.vbhtml"), userName, pwd)
                Dim BodyContact As String = String.Format(Fct.Template("~/Content/Template/inscription_contact.vbhtml"), mailEntreprise)
                Fct.SendMail(model.EmailEntreprise, _from, _objet, BodyEntreprise)
                Fct.SendMail(model.EmailContact, _from, _objet, BodyContact)
                Try
                    Fct.setCompteClient(_u.radical)
                Catch ex As Exception

                End Try
                ' sending mail model.EmailContact

                'WebSecurity.Login(userName, pwd)             
                Return RedirectToAction("Login")
            Catch e As MembershipCreateUserException
                ModelState.AddModelError("", ErrorCodeToString(e.StatusCode))
            End Try

        End If
        Return View(model)
    End Function

    '
    ' GET: /Account/Manage

    Public Function Manage(ByVal message As ManageMessageId?) As ActionResult
        ViewData("StatusMessage") =
            If(message = ManageMessageId.ChangePasswordSuccess, "Votre mot de passe à été modifié.", _
                If(message = ManageMessageId.SetPasswordSuccess, "Votre mot de passe à été crée.", _
                        ""))
        Dim userContext As DB = New DB()
        ViewData("HasLocalPassword") = (userContext.COABS.Find(WebSecurity.CurrentUserId) IsNot Nothing)
        ViewData("ReturnUrl") = Url.Action("Manage")
        Return View()
    End Function

    '
    ' POST: /Account/Manage

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Public Function Manage(ByVal model As LocalPasswordModel) As ActionResult
        Dim userContext As DB = New DB()
        Dim hasLocalAccount = (userContext.COABS.Find(WebSecurity.CurrentUserId) IsNot Nothing)
        ViewData("HasLocalPassword") = hasLocalAccount
        ViewData("ReturnUrl") = Url.Action("Manage")
        If hasLocalAccount Then
            If ModelState.IsValid Then
                ' ChangePassword will throw an exception rather than return false in certain failure scenarios.
                Dim changePasswordSucceeded As Boolean

                Try
                    changePasswordSucceeded = WebSecurity.ChangePassword(User.Identity.Name, model.OldPassword, model.NewPassword)
                Catch e As Exception
                    changePasswordSucceeded = False
                End Try

                If changePasswordSucceeded Then
                    Return RedirectToAction("ResetIndex", "Home", New With {.Message = ManageMessageId.ChangePasswordSuccess})
                Else
                    ModelState.AddModelError("", "Le mot de passe actuel et/ou nouveau est invalide !")
                End If
            End If
        Else
            ' User does not have a local password so remove any validation errors caused by a missing
            ' OldPassword field
            Dim state = ModelState("OldPassword")
            If state IsNot Nothing Then
                state.Errors.Clear()
            End If

            If ModelState.IsValid Then
                Try
                    WebSecurity.CreateAccount(User.Identity.Name, model.NewPassword)
                    Return RedirectToAction("Manage", New With {.Message = ManageMessageId.SetPasswordSuccess})
                Catch e As Exception
                    ModelState.AddModelError("", e)
                End Try
            End If
        End If

        ' If we got this far, something failed, redisplay form 
        Return View(model)
    End Function

    <ChildActionOnly()>
    Public Function GetUserInfo() As PartialViewResult
        If User.Identity.IsAuthenticated Then
            Dim ctx As DB = New DB()
            Dim userId As Int32 = WebSecurity.GetUserId(User.Identity.Name)
            Dim ca As COAB = ctx.COABS.SingleOrDefault(Function(c) c.Id = userId)
            Return PartialView(ca)
        Else
            Return PartialView()
        End If
    End Function

    <HttpGet()> _
    <AllowAnonymous()> _
    Public Function GetMap()
        Dim size As Int32 = 20
        Dim offset = 4
        Dim oBitmap As Bitmap = New Bitmap(size * 5, size * 5)
        Dim oGraphic As Graphics = Graphics.FromImage(oBitmap)
        'Dim oColor As System.Drawing.Color
        Dim sColor As String = "Red"
        Dim sFont As String = "Arial, Helvetica, sans-serif"
        Dim mytab(25) As String
        Dim random As New Random()

        For i = 0 To 9
            Dim pos As Integer = random.Next(0, 24)
            While mytab(pos) <> ""
                pos = random.Next(0, 24)
            End While
            mytab(pos) = i
        Next

        'ViewBag.MyTab = mytab
        Session("Tab") = mytab

        Dim oBrushWrite As New SolidBrush(Color.Black)
        Dim oFont As New Font(sFont, 10)
        '---------- ligne 1  ---------
        Dim o1 As New PointF(offset, offset)
        oGraphic.DrawString(mytab(0), oFont, oBrushWrite, o1)
        Dim o2 As New PointF(offset, offset + size)
        oGraphic.DrawString(mytab(1), oFont, oBrushWrite, o2)
        Dim o3 As New PointF(offset, offset + (size * 2))
        oGraphic.DrawString(mytab(2), oFont, oBrushWrite, o3)
        Dim o4 As New PointF(offset, offset + (size * 3))
        oGraphic.DrawString(mytab(3), oFont, oBrushWrite, o4)
        Dim o5 As New PointF(offset, offset + (size * 4))
        oGraphic.DrawString(mytab(4), oFont, oBrushWrite, o5)
        '----- ligne 2  ---------------
        Dim o6 As New PointF(offset + size, offset)
        oGraphic.DrawString(mytab(5), oFont, oBrushWrite, o6)
        Dim o7 As New PointF(offset + size, offset + size)
        oGraphic.DrawString(mytab(6), oFont, oBrushWrite, o7)
        Dim o8 As New PointF(offset + size, offset + (size * 2))
        oGraphic.DrawString(mytab(7), oFont, oBrushWrite, o8)
        Dim o9 As New PointF(offset + size, offset + (size * 3))
        oGraphic.DrawString(mytab(8), oFont, oBrushWrite, o9)
        Dim o10 As New PointF(offset + size, offset + (size * 4))
        oGraphic.DrawString(mytab(9), oFont, oBrushWrite, o10)
        '----- ligne 3  ---------------
        Dim o11 As New PointF(offset + (size * 2), offset)
        oGraphic.DrawString(mytab(10), oFont, oBrushWrite, o11)
        Dim o12 As New PointF(offset + (size * 2), offset + size)
        oGraphic.DrawString(mytab(11), oFont, oBrushWrite, o12)
        Dim o13 As New PointF(offset + (size * 2), offset + (size * 2))
        oGraphic.DrawString(mytab(12), oFont, oBrushWrite, o13)
        Dim o14 As New PointF(offset + (size * 2), offset + (size * 3))
        oGraphic.DrawString(mytab(13), oFont, oBrushWrite, o14)
        Dim o15 As New PointF(offset + (size * 2), offset + (size * 4))
        oGraphic.DrawString(mytab(14), oFont, oBrushWrite, o15)
        '----- ligne 4  ---------------
        Dim o16 As New PointF(offset + (size * 3), offset)
        oGraphic.DrawString(mytab(15), oFont, oBrushWrite, o16)
        Dim o17 As New PointF(offset + (size * 3), offset + size)
        oGraphic.DrawString(mytab(16), oFont, oBrushWrite, o17)
        Dim o18 As New PointF(offset + (size * 3), offset + (size * 2))
        oGraphic.DrawString(mytab(17), oFont, oBrushWrite, o18)
        Dim o19 As New PointF(offset + (size * 3), offset + (size * 3))
        oGraphic.DrawString(mytab(18), oFont, oBrushWrite, o19)
        Dim o20 As New PointF(offset + (size * 3), offset + (size * 4))
        oGraphic.DrawString(mytab(19), oFont, oBrushWrite, o20)
        '----- ligne 5  ---------------
        Dim o21 As New PointF(offset + (size * 4), offset)
        oGraphic.DrawString(mytab(20), oFont, oBrushWrite, o21)
        Dim o22 As New PointF(offset + (size * 4), offset + size)
        oGraphic.DrawString(mytab(21), oFont, oBrushWrite, o22)
        Dim o23 As New PointF(offset + (size * 4), offset + (size * 2))
        oGraphic.DrawString(mytab(22), oFont, oBrushWrite, o23)
        Dim o24 As New PointF(offset + (size * 4), offset + (size * 3))
        oGraphic.DrawString(mytab(23), oFont, oBrushWrite, o24)
        Dim o25 As New PointF(offset + (size * 4), offset + (size * 4))
        oGraphic.DrawString(mytab(24), oFont, oBrushWrite, o25)

        oGraphic.DrawLine(Pens.Gray, New PointF(0, 0), New PointF(size * 5, 0))
        oGraphic.DrawLine(Pens.Gray, New PointF(0, size), New PointF(size * 5, size))
        oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 2), New PointF(size * 5, size * 2))
        oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 3), New PointF(size * 5, size * 3))
        oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 4), New PointF(size * 5, size * 4))
        oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 5 - 1), New PointF(size * 5 - 1, size * 5 - 1))

        oGraphic.DrawLine(Pens.Gray, New PointF(0, 0), New PointF(0, size * 5))
        oGraphic.DrawLine(Pens.Gray, New PointF(size, 0), New PointF(size, size * 5))
        oGraphic.DrawLine(Pens.Gray, New PointF(size * 2, 0), New PointF(size * 2, size * 5))
        oGraphic.DrawLine(Pens.Gray, New PointF(size * 3, 0), New PointF(size * 3, size * 5))
        oGraphic.DrawLine(Pens.Gray, New PointF(size * 4, 0), New PointF(size * 4, size * 5))
        oGraphic.DrawLine(Pens.Gray, New PointF(size * 5 - 1, 0), New PointF(size * 5 - 1, size * 5 - 1))
        oBitmap.Save(Server.MapPath("~/Images/map.png"), ImageFormat.Png)
        Using im As Bitmap = New Bitmap(Server.MapPath("~/Images/map.png"))
            Using ms As MemoryStream = New MemoryStream()
                im.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                Response.ContentType = "image/png"
                ms.WriteTo(Response.OutputStream)
            End Using
        End Using

    End Function


#Region "Helpers"

    'Private Function GenerateMap() As String()

    '    Dim size As Int32 = 20
    '    Dim offset = 4
    '    Dim oBitmap As Bitmap = New Bitmap(size * 5, size * 5)
    '    Dim oGraphic As Graphics = Graphics.FromImage(oBitmap)
    '    'Dim oColor As System.Drawing.Color
    '    Dim sColor As String = "Red"
    '    Dim sFont As String = "Arial, Helvetica, sans-serif"
    '    Dim mytab(25) As String
    '    Dim random As New Random()

    '    For i = 0 To 9
    '        Dim pos As Integer = random.Next(0, 24)
    '        While mytab(pos) <> ""
    '            pos = random.Next(0, 24)
    '        End While
    '        mytab(pos) = i
    '    Next

    '    'Session("Tab") = mytab

    '    Dim oBrushWrite As New SolidBrush(Color.Black)
    '    Dim oFont As New Font(sFont, 10)
    '    '---------- ligne 1  ---------
    '    Dim o1 As New PointF(offset, offset)
    '    oGraphic.DrawString(mytab(0), oFont, oBrushWrite, o1)
    '    Dim o2 As New PointF(offset, offset + size)
    '    oGraphic.DrawString(mytab(1), oFont, oBrushWrite, o2)
    '    Dim o3 As New PointF(offset, offset + (size * 2))
    '    oGraphic.DrawString(mytab(2), oFont, oBrushWrite, o3)
    '    Dim o4 As New PointF(offset, offset + (size * 3))
    '    oGraphic.DrawString(mytab(3), oFont, oBrushWrite, o4)
    '    Dim o5 As New PointF(offset, offset + (size * 4))
    '    oGraphic.DrawString(mytab(4), oFont, oBrushWrite, o5)
    '    '----- ligne 2  ---------------
    '    Dim o6 As New PointF(offset + size, offset)
    '    oGraphic.DrawString(mytab(5), oFont, oBrushWrite, o6)
    '    Dim o7 As New PointF(offset + size, offset + size)
    '    oGraphic.DrawString(mytab(6), oFont, oBrushWrite, o7)
    '    Dim o8 As New PointF(offset + size, offset + (size * 2))
    '    oGraphic.DrawString(mytab(7), oFont, oBrushWrite, o8)
    '    Dim o9 As New PointF(offset + size, offset + (size * 3))
    '    oGraphic.DrawString(mytab(8), oFont, oBrushWrite, o9)
    '    Dim o10 As New PointF(offset + size, offset + (size * 4))
    '    oGraphic.DrawString(mytab(9), oFont, oBrushWrite, o10)
    '    '----- ligne 3  ---------------
    '    Dim o11 As New PointF(offset + (size * 2), offset)
    '    oGraphic.DrawString(mytab(10), oFont, oBrushWrite, o11)
    '    Dim o12 As New PointF(offset + (size * 2), offset + size)
    '    oGraphic.DrawString(mytab(11), oFont, oBrushWrite, o12)
    '    Dim o13 As New PointF(offset + (size * 2), offset + (size * 2))
    '    oGraphic.DrawString(mytab(12), oFont, oBrushWrite, o13)
    '    Dim o14 As New PointF(offset + (size * 2), offset + (size * 3))
    '    oGraphic.DrawString(mytab(13), oFont, oBrushWrite, o14)
    '    Dim o15 As New PointF(offset + (size * 2), offset + (size * 4))
    '    oGraphic.DrawString(mytab(14), oFont, oBrushWrite, o15)
    '    '----- ligne 4  ---------------
    '    Dim o16 As New PointF(offset + (size * 3), offset)
    '    oGraphic.DrawString(mytab(15), oFont, oBrushWrite, o16)
    '    Dim o17 As New PointF(offset + (size * 3), offset + size)
    '    oGraphic.DrawString(mytab(16), oFont, oBrushWrite, o17)
    '    Dim o18 As New PointF(offset + (size * 3), offset + (size * 2))
    '    oGraphic.DrawString(mytab(17), oFont, oBrushWrite, o18)
    '    Dim o19 As New PointF(offset + (size * 3), offset + (size * 3))
    '    oGraphic.DrawString(mytab(18), oFont, oBrushWrite, o19)
    '    Dim o20 As New PointF(offset + (size * 3), offset + (size * 4))
    '    oGraphic.DrawString(mytab(19), oFont, oBrushWrite, o20)
    '    '----- ligne 5  ---------------
    '    Dim o21 As New PointF(offset + (size * 4), offset)
    '    oGraphic.DrawString(mytab(20), oFont, oBrushWrite, o21)
    '    Dim o22 As New PointF(offset + (size * 4), offset + size)
    '    oGraphic.DrawString(mytab(21), oFont, oBrushWrite, o22)
    '    Dim o23 As New PointF(offset + (size * 4), offset + (size * 2))
    '    oGraphic.DrawString(mytab(22), oFont, oBrushWrite, o23)
    '    Dim o24 As New PointF(offset + (size * 4), offset + (size * 3))
    '    oGraphic.DrawString(mytab(23), oFont, oBrushWrite, o24)
    '    Dim o25 As New PointF(offset + (size * 4), offset + (size * 4))
    '    oGraphic.DrawString(mytab(24), oFont, oBrushWrite, o25)

    '    oGraphic.DrawLine(Pens.Gray, New PointF(0, 0), New PointF(size * 5, 0))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(0, size), New PointF(size * 5, size))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 2), New PointF(size * 5, size * 2))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 3), New PointF(size * 5, size * 3))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 4), New PointF(size * 5, size * 4))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(0, size * 5 - 1), New PointF(size * 5 - 1, size * 5 - 1))

    '    oGraphic.DrawLine(Pens.Gray, New PointF(0, 0), New PointF(0, size * 5))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(size, 0), New PointF(size, size * 5))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(size * 2, 0), New PointF(size * 2, size * 5))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(size * 3, 0), New PointF(size * 3, size * 5))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(size * 4, 0), New PointF(size * 4, size * 5))
    '    oGraphic.DrawLine(Pens.Gray, New PointF(size * 5 - 1, 0), New PointF(size * 5 - 1, size * 5 - 1))
    '    oBitmap.Save(Server.MapPath("~/Images/map.png"), ImageFormat.Png)
    '    Return mytab

    'End Function

    Private Function ReversePassword(ByVal model As LoginModel) As String

        Dim items As New Dictionary(Of String, String)
        items.Add("A", "0")
        items.Add("B", "1")
        items.Add("C", "2")
        items.Add("D", "3")
        items.Add("E", "4")
        items.Add("F", "5")
        items.Add("G", "6")
        items.Add("H", "7")
        items.Add("I", "8")
        items.Add("J", "9")
        items.Add("K", "10")
        items.Add("L", "11")
        items.Add("M", "12")
        items.Add("N", "13")
        items.Add("O", "14")
        items.Add("P", "15")
        items.Add("Q", "16")
        items.Add("R", "17")
        items.Add("S", "18")
        items.Add("T", "19")
        items.Add("U", "20")
        items.Add("V", "21")
        items.Add("W", "22")
        items.Add("X", "23")
        items.Add("Y", "24")

        Dim tab As Array = Session("Tab")

        Dim ix As Integer = 0
        Dim s As String = ""
        Try
            While ix <= model.Password.Length - 1
                s = s + tab(items(model.Password(ix)))
                ix = ix + 1
            End While
        Catch ex As Exception
            Return Nothing
        End Try
        Return s

    End Function

    Private Function RedirectToLocal(ByVal returnUrl As String) As ActionResult
        If Url.IsLocalUrl(returnUrl) Then
            Return Redirect(returnUrl)
        Else
            Return RedirectToAction("Index", "Home")
        End If
    End Function

    Public Shared Function GetUserId(ByVal name As String) As Int32
        Return WebSecurity.GetUserId(name)
    End Function

    Public Shared Sub Quit()
        WebSecurity.Logout()
    End Sub

    Public Enum ManageMessageId
        ChangePasswordSuccess
        SetPasswordSuccess
        RemoveLoginSuccess
    End Enum

    Public Function ErrorCodeToString(ByVal createStatus As MembershipCreateStatus) As String
        ' See http://go.microsoft.com/fwlink/?LinkID=177550 for
        ' a full list of status codes.
        Select Case createStatus
            Case MembershipCreateStatus.DuplicateUserName
                Return "L'utilisateur existe déjà, veuillez entrer un nouvel identifiant."

            Case MembershipCreateStatus.DuplicateEmail
                Return "L'adresse e-mail as déjà été enregistré dans la base."

            Case MembershipCreateStatus.InvalidPassword
                Return "Le mot de passe est invalide, veuillez entrer une autre valeur."

            Case MembershipCreateStatus.InvalidEmail
                Return "L'adresse e-mail est invalide veuillez vérifier et réessayer."

            Case MembershipCreateStatus.InvalidAnswer
                Return "The password retrieval answer provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidQuestion
                Return "The password retrieval question provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidUserName
                Return "L'identifiant est invalide veuillez vérifier et réessayer."

            Case MembershipCreateStatus.ProviderError
                Return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator."

            Case MembershipCreateStatus.UserRejected
                Return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator."

            Case Else
                Return "Une erreur inconnue est survenue. merci de vérifier vos données et réessayer. Si le problème persiste, Veuillez contacter la banque."
        End Select
    End Function
#End Region

End Class
