﻿Imports E_Trade.Data
Imports WebMatrix.WebData
Imports E_Trade.Web.UtilityFunctions

Namespace E_Trade.Web
    Public Class MessagesController
        Inherits BaseController

        Function Sender(ByVal IdCible As Int32, ByVal Operation As String) As ActionResult
            Return PartialView("Sender", New Commentaires() With {.IdCible = IdCible, .Source = "C", .Operation = Operation})
        End Function

        Function FileSender(ByVal IdCible As Int32, ByVal Operation As String) As ActionResult
            Return PartialView("FileSender", New Commentaires() With {.IdCible = IdCible, .Source = "C", .Operation = Operation})
        End Function

        <HttpPost()>
        Function GetTimeline(Ope As String, idc As String) As ActionResult

            Dim com = db.Commentaires.Where(Function(c) c.Operation = Ope And c.IdCible = idc).OrderByDescending(Function(c) c.DateSaisie)
            Dim msg As New StringBuilder("<ul class=""timeline"" id=""lstMsg"">")

            For Each c In com
                Select Case c.Source
                    Case "C"
                        msg.Append("<li>")
                        msg.Append("<div class=""timeline-badge""><i class=""glyphicon glyphicon-user""></i></div>")
                        msg.Append("<div class=""timeline-panel"">")
                        msg.Append("<div class=""timeline-heading"">")
                        msg.Append("<h4 class=""timeline-title""> Client </h4>")
                        msg.Append("<p><small class=""text-muted""><i class=""fa fa-clock-o""></i> " + c.DateSaisie + "</small></p>")
                        msg.Append("</div>")
                        msg.Append("<div class=""timeline-body"">")
                        msg.Append("<p>" + c.Message + "</p>")
                        msg.Append("</div>")
                        msg.Append("</div>")
                        msg.Append("</li>")
                    Case "B"
                        msg.Append("<li class=""timeline-inverted"">")
                        msg.Append("<div class=""timeline-badge warning""><i class=""glyphicon glyphicon-home""></i></div>")
                        msg.Append("<div class=""timeline-panel"">")
                        msg.Append("<div class=""timeline-heading"">")
                        msg.Append("<h4 class=""timeline-title""> Société Générale Algérie </h4>")
                        msg.Append("<p><small class=""text-muted""><i class=""fa fa-clock-o""></i>" + c.DateSaisie + "</small></p>")
                        msg.Append("</div>")
                        msg.Append("<div class=""timeline-body"">")
                        msg.Append("<p>" + c.Message + "</p>")
                        msg.Append("</div>")
                        msg.Append("</div>")
                        msg.Append("</li>")
                End Select
            Next
            msg.Append("</ul>")

            Return Json(New With {.result = "OK", .message = msg.ToString}, JsonRequestBehavior.AllowGet)

        End Function

        '<ValidateInput(False)>

        <HttpPost()>
        Function Save_Msg(ByVal Ope As String, ByVal idc As Int32, ByVal Msg As String, ByVal filesPath As IList(Of String)) As ActionResult

            Dim com As Commentaires = New Commentaires()

            Try
                com.Message = Msg
                com.Source = "C"
                com.DateSaisie = Now
                com.IdCible = idc
                com.Operation = Ope

                db.Commentaires.Add(com)
                db.SaveChanges()

                Dim m As New StringBuilder("<li>")
                m.Append("<div class=""timeline-badge""><i class=""glyphicon glyphicon-user""></i></div>")
                m.Append("<div class=""timeline-panel"">")
                m.Append("<div class=""timeline-heading"">")
                m.Append("<h4 class=""timeline-title""> Client </h4>")
                m.Append("<p><small class=""text-muted""><i class=""fa fa-clock-o""></i> " + com.DateSaisie + "</small></p>")
                m.Append("</div>")
                m.Append("<div class=""timeline-body"">")
                m.Append("<p>" + com.Message + "</p>")
                m.Append("</div>")
                m.Append("</div>")
                m.Append("</li>")

                Notif_Client(OperationResolver(Ope), idc, Msg, filesPath)

                Return Json(New With {.result = "OK", .message = "votre message à eté envoyé", .com = m.ToString}, JsonRequestBehavior.AllowGet)

            Catch ex As Exception

                Return Json(New With {.result = "KO", .message = "Erreur d'envoie"}, JsonRequestBehavior.AllowGet)

            End Try

        End Function

        Sub Notif_Client(ByVal ope As OperationType, ByVal IdCible As Int32, Msg As String, ByVal filesPath As IList(Of String))

            Dim radical As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(User.Identity.Name)).Id_Souscription).Radical_Client
            Dim age As Agence = Nothing
            Dim refWF As String = String.Empty

            Try
                Select Case ope
                    Case OperationType.CDI
                        Dim cred As Credoc = db.Credoc.Find(IdCible)
                        age = db.Agences.Where(Function(a) a.Age = cred.Age_Agence).FirstOrDefault
                        refWF = cred.REFWF
                    Case OperationType.RDI
                        Dim remd As Remdoc = db.Remdoc.Find(IdCible)
                        age = db.Agences.Where(Function(a) a.Age = remd.Age_Agence).FirstOrDefault
                        refWF = remd.REFWF
                    Case Else
                        Exit Sub
                End Select
            Catch ex As Exception
                ' Log impossible de récuperer l'agence du dossier
                Exit Sub
            End Try

            Dim afrm As String = "ETRADE_MAILER@socgen.com"

            Try
                Dim afrmParam As Parametres = db.Parametres.Where(Function(p) p.Param.Equals("EtradeMailerAdress")).FirstOrDefault()
                If afrmParam IsNot Nothing Then
                    afrm = IIf(String.IsNullOrEmpty(afrmParam.Value), afrm, afrmParam.Value)
                End If
            Catch ex As Exception

            End Try

            Dim dnfrm As String = "MAILER E-Trade"

            Try
                Dim dnfrmParam As Parametres = db.Parametres.Where(Function(p) p.Param.Equals("EtradeMailerDisplayName")).FirstOrDefault()
                If dnfrmParam IsNot Nothing Then
                    dnfrm = IIf(String.IsNullOrEmpty(dnfrmParam.Value), dnfrm, dnfrmParam.Value)
                End If
            Catch ex As Exception

            End Try

            Dim ato As String() = Split(age.Emails, ";")

            Dim obj = "Message Client " & ope.ToString & " Radical " & radical.ToString

            Dim smtpServer As String = "172.31.2.1"

            Try
                'SMTPSERVER
                Dim smtpServerParam As Parametres = db.Parametres.Where(Function(p) p.Param.Equals("SMTPSERVER")).FirstOrDefault()
                If smtpServerParam IsNot Nothing Then
                    smtpServer = IIf(String.IsNullOrEmpty(smtpServerParam.Value), smtpServer, smtpServerParam.Value)
                End If
            Catch ex As Exception

            End Try

            Try
                Dim objParam As Parametres = db.Parametres.Where(Function(p) p.Param.Equals("ObjectMailerClientToBank")).FirstOrDefault()
                If objParam IsNot Nothing Then
                    obj = IIf(String.IsNullOrEmpty(objParam.Value), obj, objParam.Value)
                End If
            Catch ex As Exception

            End Try
            
            Dim jiraUrl As String = String.Empty
            Try
                jiraUrl = db.Parametres.Find("JiraUrl").Value
            Catch ex As Exception
                jiraUrl = "http://sga-jira-test:8080/browse/"
            End Try
           
            If Not jiraUrl.EndsWith("/") Then
                jiraUrl = jiraUrl + "/"
            End If

            Dim sb As New StringBuilder
            sb.AppendLine("<div>" + Msg + "</div> ")
            sb.AppendLine("<div>Cliquez <a href='" & jiraUrl & refWF + "' title='cliquer ici'> ici</a><span> pour plus de détails .</span></div>")

            Try
                LogInfo("Befor sending")
                SendMailMultipleAttachments(afrm, ato, obj, sb.ToString, dnfrm, TryGetFiles(radical, ope, IdCible, filesPath), Nothing, Nothing, smtpServer)
                LogInfo("After sending")
            Catch ex As Exception
                LogInfo("Notif_Client" & ex.Message)
            End Try

        End Sub



    End Class
End Namespace