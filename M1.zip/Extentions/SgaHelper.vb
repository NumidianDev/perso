﻿Imports System.Runtime.CompilerServices
Imports System.Diagnostics.CodeAnalysis

Public Module SgaHelper

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <Extension()> _
    Public Function EditorForDocumentsCredoc(Of TModel, TValue)(htmlHelper As HtmlHelper(Of TModel), expression As Linq.Expressions.Expression(Of Func(Of TModel, TValue))) As MvcHtmlString
        Return Html.EditorExtensions.EditorFor(htmlHelper, expression, additionalViewData:=Nothing)
    End Function

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <Extension()> _
    Public Function EditorForDocumentsCredoc(Of TModel, TValue)(htmlHelper As HtmlHelper(Of TModel), expression As Linq.Expressions.Expression(Of Func(Of TModel, TValue)), additionalViewData As Object) As MvcHtmlString
        Return Html.EditorExtensions.EditorFor(htmlHelper, expression, additionalViewData)
    End Function

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <Extension()> _
    Public Function EditorForDocumentsCredoc(Of TModel, TValue)(htmlHelper As HtmlHelper(Of TModel), expression As Linq.Expressions.Expression(Of Func(Of TModel, TValue)), predicate As System.Func(Of TModel, Boolean)) As MvcHtmlString
        Dim model As TModel = htmlHelper.ViewContext.ViewData.ModelMetadata.Model
        If predicate.Invoke(model) Then
            Return Html.EditorExtensions.EditorFor(htmlHelper, expression, additionalViewData:=Nothing)
        Else
            Return MvcHtmlString.Empty
        End If
    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Function DropDownListFor(Of TModel, TProperty)(htmlHelper As HtmlHelper(Of TModel), expression As Linq.Expressions.Expression(Of Func(Of TModel, TProperty)), selectList As IEnumerable(Of SelectListItem), ByVal classes As Object, disabled As Boolean) As MvcHtmlString
        If disabled Then
            If classes IsNot Nothing Then
                Return MvcHtmlString.Create(htmlHelper.HiddenFor(expression).ToString() + htmlHelper.DropDownListFor(expression, selectList, classes).ToString())
            Else
                Return MvcHtmlString.Create(htmlHelper.HiddenFor(expression).ToString() + htmlHelper.DropDownListFor(expression, selectList, New With { _
                    Key .disabled = "disabled" _
                   }).ToString())
            End If
        Else
            Return htmlHelper.DropDownListFor(expression, selectList, classes)
        End If
    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Function DropDownListFor(Of TModel, TProperty)(htmlHelper As HtmlHelper(Of TModel), expression As Linq.Expressions.Expression(Of Func(Of TModel, TProperty)), selectList As IEnumerable(Of SelectListItem), disabled As Boolean) As MvcHtmlString
        If disabled Then
            Return MvcHtmlString.Create(htmlHelper.HiddenFor(expression).ToString() + htmlHelper.DropDownListFor(expression, selectList, New With { _
             Key .disabled = "disabled" _
            }).ToString())
        Else
            Return htmlHelper.DropDownListFor(expression, selectList)
        End If
    End Function

    '<Extension()> _
    'Function Image(ByVal helper As HtmlHelper, ByVal id As String, ByVal url As String, ByVal alternateText As String) As String
    '    Return Image(helper, id, url, alternateText, Nothing)
    'End Function

    '<Extension()> _
    'Function Image(ByVal helper As HtmlHelper, ByVal id As String, ByVal url As String, ByVal alternateText As String, ByVal htmlAttributes As Object) As String
    '    ' Create tag builder
    '    Dim builder = New TagBuilder("img")

    '    ' Create valid id
    '    builder.GenerateId(id)

    '    ' Add attributes
    '    builder.MergeAttribute("src", url)
    '    builder.MergeAttribute("alt", alternateText)
    '    builder.MergeAttributes(New RouteValueDictionary(htmlAttributes))

    '    ' Render tag
    '    Return builder.ToString(TagRenderMode.SelfClosing)
    'End Function

    <Extension()> _
    Function RemoveLink(htmlHelper As HtmlHelper, linkText As String, container As String, deleteElement As String) As IHtmlString
        Dim js = String.Format("javascript:removeNestedForm(this,'{0}','{1}');return false;", container, deleteElement)
        Dim tb As New TagBuilder("a")
        tb.Attributes.Add("href", "#")
        tb.Attributes.Add("onclick", js)
        tb.InnerHtml = linkText
        Dim tag = tb.ToString(TagRenderMode.Normal)
        Return MvcHtmlString.Create(tag)
    End Function

    <Extension()> _
    Function AddLink(Of TModel)(htmlHelper As HtmlHelper(Of TModel), linkText As String, containerElement As String, counterElement As String, collectionProperty As String, nestedType As Type, Optional ByVal circuit As String = "B") As IHtmlString
        Dim ticks = DateTime.UtcNow.Ticks
        Dim nestedObject = Activator.CreateInstance(nestedType)
        Try
            Dim circuitProperty As Reflection.PropertyInfo = nestedObject.GetType.GetProperty("Circuit")
            If circuitProperty.CanWrite Then
                Dim method As Reflection.MethodInfo = circuitProperty.GetSetMethod
                If method.IsPublic Then
                    circuitProperty.SetValue(nestedObject, circuit, Nothing)
                End If
            End If
        Catch ex As Exception

        End Try
        Dim [partial] = htmlHelper.EditorFor(Function(x) nestedObject).ToHtmlString().JsEncode()
        [partial] = [partial].Replace("id=\""$VB$Local_nestedObject", "id=\""" & collectionProperty & "_" & Convert.ToString(ticks) & "_")
        [partial] = [partial].Replace("name=\""$VB$Local_nestedObject", "name=\""" & collectionProperty & "[" & Convert.ToString(ticks) & "]")
        Dim js = String.Format("javascript:addNestedForm('{0}','{1}','{2}','{3}','{4}');return false;", containerElement, counterElement, collectionProperty, ticks, [partial])
        Dim tb As New TagBuilder("a")
        tb.AddCssClass("col-md-4")
        tb.Attributes.Add("href", "#")
        tb.Attributes.Add("onclick", js)
        tb.InnerHtml = linkText
        Dim tag = tb.ToString(TagRenderMode.Normal)
        Return MvcHtmlString.Create(tag)
    End Function

    <Extension()> _
    Private Function JsEncode(s As String) As String
        If String.IsNullOrEmpty(s) Then
            Return ""
        End If
        Dim i As Integer
        Dim len As Integer = s.Length
        Dim sb As New StringBuilder(len + 4)
        Dim t As String
        For i = 0 To len - 1
            Dim c As Char = s(i)
            Select Case c
                Case ">"c, """"c, "\"c
                    sb.Append("\"c)
                    sb.Append(c)
                    Exit Select
                Case ControlChars.Back
                    sb.Append("\b")
                    Exit Select
                Case ControlChars.Tab
                    sb.Append("\t")
                    Exit Select
                Case ControlChars.Lf
                    Exit Select
                Case ControlChars.FormFeed
                    sb.Append("\f")
                    Exit Select
                Case ControlChars.Cr
                    Exit Select
                Case Else
                    If c < " "c Then
                        Dim tmp As New String(c, 1)
                        t = "000" & Integer.Parse(tmp, System.Globalization.NumberStyles.HexNumber)
                        sb.Append("\u" & t.Substring(t.Length - 4))
                    Else
                        sb.Append(c)
                    End If
                    Exit Select
            End Select
        Next
        Return sb.ToString()
    End Function

End Module




