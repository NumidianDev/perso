﻿Imports System.Diagnostics.CodeAnalysis
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Linq.Expressions
Imports System.Text
Imports System.Web.Mvc.Properties
Imports System.Web.Routing
Imports System.Runtime.CompilerServices

Public Module CheckBoxExtensions

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <Extension()> _
    Public Function SgaCheckBoxFor(Of TModel)(htmlHelper As HtmlHelper(Of TModel), expression As Expression(Of Func(Of TModel, Boolean))) As MvcHtmlString
        Return SgaCheckBoxFor(htmlHelper, expression, htmlAttributes:=Nothing)
    End Function

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <System.Runtime.CompilerServices.Extension()> _
    Public Function SgaCheckBoxFor(Of TModel)(htmlHelper__1 As HtmlHelper(Of TModel), expression As Expression(Of Func(Of TModel, Boolean)), htmlAttributes As Object) As MvcHtmlString
        Return SgaCheckBoxFor(htmlHelper__1, expression, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes))
    End Function

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <Extension()> _
    Public Function SgaRadioFor(Of TModel)(htmlHelper As HtmlHelper(Of TModel), expression As Expression(Of Func(Of TModel, Boolean))) As MvcHtmlString
        Return SgaRadioFor(htmlHelper, expression, htmlAttributes:=Nothing)
    End Function

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <System.Runtime.CompilerServices.Extension()> _
    Public Function SgaRadioFor(Of TModel)(htmlHelper__1 As HtmlHelper(Of TModel), expression As Expression(Of Func(Of TModel, Boolean)), htmlAttributes As Object) As MvcHtmlString
        Return SgaRadioFor(htmlHelper__1, expression, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes))
    End Function


    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <System.Runtime.CompilerServices.Extension()> _
    Public Function SgaCheckBoxFor(Of TModel)(htmlHelper As HtmlHelper(Of TModel), expression As Expression(Of Func(Of TModel, Boolean)), htmlAttributes As IDictionary(Of String, Object)) As MvcHtmlString
        If expression Is Nothing Then
            Throw New ArgumentNullException("expression")
        End If

        Dim metadata As ModelMetadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData)
        Dim isChecked As System.Nullable(Of Boolean) = Nothing
        If metadata.Model IsNot Nothing Then
            Dim modelChecked As Boolean
            If [Boolean].TryParse(metadata.Model.ToString(), modelChecked) Then
                isChecked = modelChecked
            End If
        End If

        Return SgaCheckBoxHelper(htmlHelper, metadata, ExpressionHelper.GetExpressionText(expression), isChecked, htmlAttributes)
    End Function

    <SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification:="This is an appropriate nesting of generic types")> _
    <System.Runtime.CompilerServices.Extension()> _
    Public Function SgaRadioFor(Of TModel)(htmlHelper As HtmlHelper(Of TModel), expression As Expression(Of Func(Of TModel, Boolean)), htmlAttributes As IDictionary(Of String, Object)) As MvcHtmlString
        If expression Is Nothing Then
            Throw New ArgumentNullException("expression")
        End If

        Dim metadata As ModelMetadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData)
        Dim isChecked As System.Nullable(Of Boolean) = Nothing
        If metadata.Model IsNot Nothing Then
            Dim modelChecked As Boolean
            If [Boolean].TryParse(metadata.Model.ToString(), modelChecked) Then
                isChecked = modelChecked
            End If
        End If

        Return SgaRadioHelper(htmlHelper, metadata, ExpressionHelper.GetExpressionText(expression), isChecked, htmlAttributes)
    End Function


    Private Function SgaCheckBoxHelper(htmlHelper As HtmlHelper, metadata As ModelMetadata, name As String, isChecked As System.Nullable(Of Boolean), htmlAttributes As IDictionary(Of String, Object)) As MvcHtmlString
        Dim attributes As RouteValueDictionary = ToRouteValueDictionary(htmlAttributes)

        Dim explicitValue As Boolean = isChecked.HasValue
        If explicitValue Then
            ' Explicit value must override dictionary
            attributes.Remove("checked")
        End If

        Return SgaInputHelper(htmlHelper, InputType.CheckBox, metadata, name, value:="true", useViewData:=Not explicitValue, _
         isChecked:=If(isChecked, False), setId:=True, isExplicitValue:=False, format:=Nothing, htmlAttributes:=attributes)
    End Function

    Private Function SgaRadioHelper(htmlHelper As HtmlHelper, metadata As ModelMetadata, name As String, isChecked As System.Nullable(Of Boolean), htmlAttributes As IDictionary(Of String, Object)) As MvcHtmlString
        Dim attributes As RouteValueDictionary = ToRouteValueDictionary(htmlAttributes)

        Dim explicitValue As Boolean = isChecked.HasValue
        If explicitValue Then
            ' Explicit value must override dictionary
            attributes.Remove("checked")
        End If

        Return SgaInputHelper(htmlHelper, InputType.Radio, metadata, name, value:="true", useViewData:=Not explicitValue, _
         isChecked:=If(isChecked, False), setId:=True, isExplicitValue:=False, format:=Nothing, htmlAttributes:=attributes)
    End Function

    
    Private Function SgaInputHelper(htmlHelper__1 As HtmlHelper, inputType__2 As InputType, metadata As ModelMetadata, name As String, value As Object, useViewData As Boolean, _
            isChecked As Boolean, setId As Boolean, isExplicitValue As Boolean, format As String, htmlAttributes As IDictionary(Of String, Object)) As MvcHtmlString

        Dim fullName As String = htmlHelper__1.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(name)

        Dim groupName As String = String.Empty

        If htmlAttributes IsNot Nothing AndAlso htmlAttributes.Keys.Contains("groupName") Then
            groupName = htmlAttributes("groupName")
        End If

        If [String].IsNullOrEmpty(fullName) Then
            Throw New ArgumentException("Nom d'attribut null ou vide", "name")
        End If

        Dim tagBuilder As New TagBuilder("input")
        tagBuilder.MergeAttributes(htmlAttributes)
        tagBuilder.MergeAttribute("type", HtmlHelper.GetInputTypeString(inputType__2))

        If Not String.IsNullOrEmpty(groupName) Then
            tagBuilder.MergeAttribute("name", groupName, True)
        Else
            tagBuilder.MergeAttribute("name", fullName, True)
        End If

        Dim valueParameter As String = htmlHelper__1.FormatValue(value, format)
        Dim usedModelState As Boolean = False

        Dim modelValue As Boolean = If(metadata.Model, False)
        Select Case inputType__2
            Case InputType.CheckBox
                Dim modelStateWasChecked As System.Nullable(Of Boolean) = Boolean.Parse(modelValue) 'TryCast(htmlHelper__1.GetModelStateValue(fullName, GetType(Boolean)), System.Nullable(Of Boolean))
                If modelStateWasChecked.HasValue Then
                    isChecked = modelStateWasChecked.Value
                    usedModelState = True
                End If
                GoTo 1
            Case InputType.Radio
1:              If Not usedModelState Then
                    Dim modelStateValue As String = modelValue 'TryCast(htmlHelper__1.GetModelStateValue(fullName, GetType(String)), String)
                    If modelStateValue IsNot Nothing Then
                        isChecked = [String].Equals(modelStateValue, valueParameter, StringComparison.OrdinalIgnoreCase)
                        usedModelState = True
                    End If
                End If
                If Not usedModelState AndAlso useViewData Then
                    isChecked = Boolean.Parse(modelValue) 'htmlHelper__1.EvalBoolean(fullName)
                End If
                If isChecked Then
                    tagBuilder.MergeAttribute("checked", "checked")
                End If
                tagBuilder.MergeAttribute("value", valueParameter, isExplicitValue)
                Exit Select
            Case Else
                'htmlHelper__1.GetModelStateValue(fullName, GetType(String))
                Dim attemptedValue As String = DirectCast(value, String)
                ' htmlHelper__1.EvalString(fullName, format)
                tagBuilder.MergeAttribute("value", If(attemptedValue, (If((useViewData), value, valueParameter))), isExplicitValue)
                Exit Select
        End Select

        If setId Then
            If Not String.IsNullOrEmpty(groupName) Then
                tagBuilder.GenerateId(groupName)
            Else
                tagBuilder.GenerateId(fullName)
            End If
        End If

        ' If there are any errors for a named field, we add the css attribute.
        Dim modelState As ModelState
        If htmlHelper__1.ViewData.ModelState.TryGetValue(fullName, modelState) Then
            If modelState.Errors.Count > 0 Then
                tagBuilder.AddCssClass(HtmlHelper.ValidationInputCssClassName)
            End If
        End If

        tagBuilder.MergeAttributes(htmlHelper__1.GetUnobtrusiveValidationAttributes(name, metadata))

        If inputType__2 = InputType.CheckBox OrElse inputType__2 = InputType.Radio Then
            ' Render an additional <input type="hidden".../> for checkboxes. This
            ' addresses scenarios where unchecked checkboxes are not sent in the request.
            ' Sending a hidden input makes it possible to know that the checkbox was present
            ' on the page when the request was submitted.
            Dim inputItemBuilder As New StringBuilder()
            inputItemBuilder.Append(tagBuilder.ToString())
            'TagRenderMode.SelfClosing
            Dim spanInput As New TagBuilder("span")
            spanInput.Attributes.Add("class", "lbl")
            inputItemBuilder.Append(spanInput.ToString())
            'TagRenderMode.SelfClosing

            Dim hiddenInput As New TagBuilder("input")
            hiddenInput.MergeAttribute("type", HtmlHelper.GetInputTypeString(InputType.Hidden))
            If Not String.IsNullOrEmpty(groupName) Then
                hiddenInput.MergeAttribute("name", groupName)
            Else
                hiddenInput.MergeAttribute("name", fullName)
            End If

            hiddenInput.MergeAttribute("value", "false")
            inputItemBuilder.Append(hiddenInput.ToString())
            'TagRenderMode.SelfClosing
            Return MvcHtmlString.Create(inputItemBuilder.ToString())
        End If

        Dim res As MvcHtmlString = MvcHtmlString.Create(tagBuilder.ToString())
        'TagRenderMode.SelfClosing
        Return res

    End Function

    Private Function ToRouteValueDictionary(dictionary As IDictionary(Of String, Object)) As RouteValueDictionary
        Return If(dictionary Is Nothing, New RouteValueDictionary(), New RouteValueDictionary(dictionary))
    End Function

End Module
