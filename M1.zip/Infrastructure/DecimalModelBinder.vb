﻿Imports System.Globalization

Public Class DecimalModelBinder
    Implements IModelBinder

    Public Function BindModel(controllerContext As System.Web.Mvc.ControllerContext, bindingContext As System.Web.Mvc.ModelBindingContext) As Object Implements System.Web.Mvc.IModelBinder.BindModel
        Dim valueResult As ValueProviderResult = bindingContext.ValueProvider.GetValue(bindingContext.ModelName)
        Dim modelState As ModelState = New ModelState With {.Value = valueResult}
        Dim actualValue As Object = Nothing
        Try
            actualValue = Convert.ToDecimal(valueResult.AttemptedValue, CultureInfo.CurrentCulture)
        Catch ex As Exception
            modelState.Errors.Add(ex)
        End Try
        bindingContext.ModelState.Add(bindingContext.ModelName, modelState)
        Return actualValue
    End Function

End Class
