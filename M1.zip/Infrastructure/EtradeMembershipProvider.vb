﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Web.Security
Imports E_Trade.Data
Imports WebMatrix.WebData
Imports System.Data.Entity

Public Class EtradeMembershipProvider
    Inherits ExtendedMembershipProvider
    Private db As DB
    Public Overrides Property ApplicationName As String
        Get
            Throw New NotImplementedException()
        End Get
        Set(value As String)
            Throw New NotImplementedException()
        End Set
    End Property

    Public Overrides Function ChangePassword(username As String, oldPassword As String, newPassword As String) As Boolean
        Dim usersContext As DB = New DB()
        Dim user As COAB = usersContext.COABS.Where(Function(ca) ca.Email.Equals(username)).FirstOrDefault
        If user IsNot Nothing Then
            user.PWD = SecurityUtils.GetSHA512Hash(newPassword)
            user.PWD_TMP = newPassword
            user.FirstUse = False
            usersContext.SaveChanges()
            Return True
        Else
            Return False
        End If
    End Function

    Public Overrides Function ChangePasswordQuestionAndAnswer(username As String, password As String, newPasswordQuestion As String, newPasswordAnswer As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function ConfirmAccount(accountConfirmationToken As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function ConfirmAccount(userName As String, accountConfirmationToken As String) As Boolean
        Dim db As DB = New DB()
        Dim _r = db.COABS.Where(Function(u) u.Email.Contains(userName) And u.Actif.Equals(True)).ToList()
        If _r.Count > 0 Then
            Return True
        End If
        Return False
    End Function

    Public Overloads Overrides Function CreateAccount(userName As String, password As String, requireConfirmationToken As Boolean) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function CreateUser(username As String, password As String, email As String, passwordQuestion As String, passwordAnswer As String, isApproved As Boolean, _
        providerUserKey As Object, ByRef status As MembershipCreateStatus) As MembershipUser
        Dim args = New ValidatePasswordEventArgs(username, password, True)
        OnValidatingPassword(args)

        Dim usersContext As DB = New DB()

        If args.Cancel Then
            status = MembershipCreateStatus.InvalidPassword
            Return Nothing
        End If

        If RequiresUniqueEmail AndAlso GetUserNameByEmail(email) <> String.Empty Then
            status = MembershipCreateStatus.DuplicateEmail
            Return Nothing
        End If

        Dim user = GetUser(username, True)

        If user Is Nothing Then
            Dim userObj = New COAB() With { _
             .Email = username, _
             .PWD = SecurityUtils.GetSHA512Hash(password)
            }


            usersContext.COABS.Add(userObj)


            status = MembershipCreateStatus.Success

            Return GetUser(username, True)
        End If
        status = MembershipCreateStatus.DuplicateUserName

        Return Nothing
    End Function
    ' ajouter ceate Client
    Private Function setClient(pc As PreDom_Client) As Client
        Dim db As DB = New DB()
        Dim c As Client
        Try
            c = db.Clients.Find(pc.Radical)
        Catch ex As Exception
            c = Nothing
        End Try

        If pc IsNot Nothing Then
            If c IsNot Nothing Then
                db.Entry(c).State = EntityState.Modified
            Else
                c = New Client() With {
                           .Radical = pc.Radical,
                           .Adresse = pc.Adresse,
                           .NIDF = Trim(pc.NIDF),
                           .RC = Trim(pc.RC),
                           .RS = pc.RS,
                           .Email = pc.Email,
                           .Tel = pc.Tel,
                           .NIN = pc.NIN,
                           .age = pc.age
                           }
                db.Clients.Add(c)
            End If
            db.SaveChanges()
        End If
        Return c
    End Function
    ' ajouter create souscription
    Private Function setSouscription(ByVal _radical As String) As Integer
        Dim db As DB = New DB()
        Dim _user As String = db.Utilisateurs.FirstOrDefault().ToString
        If Not String.IsNullOrEmpty(_radical) Then
            Dim userSouscription = New Souscription() With { _
                        .Radical_Client = _radical, _
                        .Id_Package = 2, _
                        .Id_StatutSouscription = 2, _
                        .USaisie = "9999", _
                        .DateSaisie = DateTime.Now, _
                        .UValidation = "9999", _
                        .DateValidation = DateTime.Now
                     }
            db.Souscriptions.Add(userSouscription)
            db.SaveChanges()
            Return userSouscription.Id
        End If
        Return 0
    End Function
    '
    Private Sub UpdateCOAB(ByVal coab As COAB)
        Dim db As DB = New DB
        db.Entry(coab).State = EntityState.Modified
        db.SaveChanges()
    End Sub
    Public Overloads Overrides Function CreateUserAndAccount(userName As String, password As String, requireConfirmation As Boolean, values As System.Collections.Generic.IDictionary(Of String, Object)) As String
        Dim args = New ValidatePasswordEventArgs(userName, password, True)
        OnValidatingPassword(args)
        Dim _nom As String = values.Values(0).ToString
        Dim _prenom As String = values.Values(1).ToString
        Dim _nif As String = values.Values(2).ToString
        Dim _rc As String = values.Values(3).ToString
        Dim usersContext As DB = New DB()
        Dim _u = usersContext.Utilisateurs.FirstOrDefault().Matricule
        Dim userSouscription As Souscription
        ' verifier l'existance de COAB
        Dim user = GetUser(userName, True)
        ' verifier l'existance de client
        Dim Pclient = usersContext.PreDom_Client.Where(Function(c) c.NIDF.Equals(_nif) Or c.RC.Contains(_rc)).First
        '-- chercher l'existance de la souscription
        Dim _s = usersContext.Souscriptions.Where(Function(s) s.Radical_Client.Equals(Pclient.Radical.ToString)).FirstOrDefault()
        If user Is Nothing And Not Pclient Is Nothing Then
            ' SOUSCRIPTION
            Dim Ids As Integer
            If _s Is Nothing Then
                ' set Client
                Dim _client = setClient(Pclient)
                ' set Souscription  
                Ids = setSouscription(Pclient.Radical)
            ElseIf _s.Id_Package.Equals(1) Then
                Return Nothing
            Else
                userSouscription = _s
                Ids = userSouscription.Id
            End If
            ' COAB
            '
            Dim userCOAB = New COAB() With { _
             .Nom = _nom, _
             .NomAV = _nom, _
             .PrenomAV = _prenom, _
             .Prenom = _prenom, _
             .Email = userName, _
             .EmailAV = userName, _
             .PWD = SecurityUtils.GetSHA512Hash(password), _
             .PWD_TMP = password, _
             .FirstUse = args.IsNewUser, _
             .Actif = True, _
             .ActifAV = True, _
             .Id_Souscription = Ids, _
             .Id_COAB_Profil = 2, _
             .Id_COAB_ProfilAV = 2, _
             .Notif = 1
            }
            ' add COAB
            usersContext.COABS.Add(userCOAB)
            usersContext.SaveChanges()
            Return GetUser(userName, True).Email
        End If
        Return Nothing
    End Function

    Public Overrides Function DeleteAccount(userName As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides Function DeleteUser(username As String, deleteAllRelatedData As Boolean) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides ReadOnly Property EnablePasswordReset() As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides ReadOnly Property EnablePasswordRetrieval As Boolean
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides Function FindUsersByEmail(emailToMatch As String, pageIndex As Integer, pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
        Throw New NotImplementedException()
    End Function

    Public Overrides Function FindUsersByName(usernameToMatch As String, pageIndex As Integer, pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function GeneratePasswordResetToken(userName As String, tokenExpirationInMinutesFromNow As Integer) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetAccountsForUser(userName As String) As System.Collections.Generic.ICollection(Of WebMatrix.WebData.OAuthAccountData)
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetAllUsers(pageIndex As Integer, pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetCreateDate(userName As String) As Date
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetLastPasswordFailureDate(userName As String) As Date
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetNumberOfUsersOnline() As Integer
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetPassword(username As String, answer As String) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetPasswordChangedDate(userName As String) As Date
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetPasswordFailuresSinceLastSuccess(userName As String) As Integer
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function GetUser(username As Object, userIsOnline As Boolean) As MembershipUser
        Dim usersContext As DB = New DB()
        Dim user = usersContext.COABS.Where(Function(u) u.Email.Equals(username)).FirstOrDefault
        If user IsNot Nothing Then
            Dim memUser = New MembershipUser("MembershipProvider", username, user.Id, user.Id, String.Empty, String.Empty, _
             True, False, DateTime.MinValue, DateTime.MinValue, DateTime.MinValue, DateTime.Now, _
             DateTime.Now)
            Return memUser
        End If
        Return Nothing
    End Function

    Public Overrides Function GetUser(username As String, userIsOnline As Boolean) As MembershipUser
        Dim usersContext As DB = New DB()
        Dim user = usersContext.COABS.Where(Function(ca) ca.Email.Equals(username)).FirstOrDefault
        If user IsNot Nothing Then
            Dim memUser = New MembershipUser("EtradeMembershipProvider", username, user.Id, user.Email, String.Empty, String.Empty,
             True, False, DateTime.MinValue, DateTime.MinValue, DateTime.MinValue, DateTime.Now,
             DateTime.Now)
            Return memUser
        End If
        Return Nothing
    End Function

    Public Overrides Function GetUserIdFromPasswordResetToken(token As String) As Integer
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetUserNameByEmail(email As String) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function IsConfirmed(userName As String) As Boolean
        Dim _coab = db.COABS.Where(Function(c) c.Email.Equals(userName)).ToList()
        If _coab.Count > 0 Then
            Return False
        End If
        Return True
    End Function

    Public Overrides ReadOnly Property MaxInvalidPasswordAttempts As Integer
        Get
            Return 6
        End Get
    End Property

    Public Overrides ReadOnly Property MinRequiredNonAlphanumericCharacters As Integer
        Get
            Return 1
        End Get
    End Property

    Public Overrides ReadOnly Property MinRequiredPasswordLength As Integer
        Get
            Return 6
        End Get
    End Property

    Public Overrides ReadOnly Property PasswordAttemptWindow As Integer
        Get
            Return 6
        End Get
    End Property

    Public Overrides ReadOnly Property PasswordFormat As System.Web.Security.MembershipPasswordFormat
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides ReadOnly Property PasswordStrengthRegularExpression As String
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides ReadOnly Property RequiresQuestionAndAnswer As Boolean
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides ReadOnly Property RequiresUniqueEmail As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Function ResetPassword(username As String, answer As String) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function ResetPasswordWithToken(token As String, newPassword As String) As Boolean
        Dim usersContext As DB = New DB()
        Dim requiredUser = usersContext.COABS.Where(Function(ca) ca.Email.Equals(token) AndAlso ca.Actif).FirstOrDefault
        requiredUser.PWD = SecurityUtils.GetSHA512Hash(newPassword)
        requiredUser.FirstUse = True
        usersContext.SaveChanges()
        Return True
    End Function

    Public Overrides Function UnlockUser(userName As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides Sub UpdateUser(user As System.Web.Security.MembershipUser)
        Dim db As DB = New DB
        Try
            Dim _c = db.COABS.Where(Function(c) c.Email.Equals(user.UserName) AndAlso c.Actif.Equals(True)).FirstOrDefault
            Dim newPasswored As String = SecurityUtils.CreateRandomPassword()
            ChangePassword(_c.Email, _c.PWD_TMP, newPasswored)
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

    End Sub

    Public Overrides Function ValidateUser(username As String, password As String) As Boolean
        Dim SHA512Hash = SecurityUtils.GetSHA512Hash(password)
        Dim usersContext As DB = New DB()
        Dim requiredUser = usersContext.COABS.Where(Function(ca) ca.Email.Equals(username) AndAlso ca.PWD.Equals(SHA512Hash) AndAlso ca.Actif AndAlso ca.Souscription.Id_StatutSouscription < 6 AndAlso ca.Souscription.Id_StatutSouscription > 1).FirstOrDefault
        Return requiredUser IsNot Nothing
    End Function


End Class


