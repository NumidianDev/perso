﻿' Note: For instructions on enabling IIS6 or IIS7 classic mode, 
' visit http://go.microsoft.com/?LinkId=9394802
Imports System.Web.Http
Imports System.Web.Optimization
Imports System.Web.Configuration
Imports E_Trade.Data
Imports System.Data.Entity
Imports CaptchaMvc.Infrastructure

Public Class MvcApplication
    Inherits System.Web.HttpApplication

    Sub Application_Start()

        Dim configLogFileName As String = HttpRuntime.AppDomainAppPath + WebConfigurationManager.AppSettings("configLogFileName")
        log4net.Config.XmlConfigurator.ConfigureAndWatch(configFile:=New System.IO.FileInfo(configLogFileName))
        Database.SetInitializer(Of DB)(Nothing)
        ModelBinders.Binders.Add(GetType(System.Decimal), New DecimalModelBinder())
        AreaRegistration.RegisterAllAreas()
        WebApiConfig.Register(GlobalConfiguration.Configuration)
        FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters)
        RouteConfig.RegisterRoutes(RouteTable.Routes)
        BundleConfig.RegisterBundles(BundleTable.Bundles)
        AuthConfig.RegisterAuth()
        CaptchaUtils.CaptchaManager.StorageProvider = New CookieStorageProvider()
        MvcHandler.DisableMvcResponseHeader = True
    End Sub

    Protected Sub Application_PreSendRequestHeaders()
        Response.Headers.Set("Server", "SGA v1.0")
        Response.Headers.Remove("X-AspNet-Version")
        Response.Headers.Remove("X-AspNetMvc-Version")
    End Sub
   

End Class
