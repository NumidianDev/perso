﻿'Imports System.Web
'Imports System.Web.Services
'Imports System.IO
'Imports System.Web.Script.Serialization
'Imports log4net
'Imports WebMatrix.WebData
'Imports System.Web.Helpers
'Imports E_Trade.Web.UtilityFunctions

'Public Class UploadHandler
'    Implements System.Web.IHttpHandler

'    Private Shared ReadOnly logger As ILog = log4net.LogManager.GetLogger(GetType(UploadHandler))

'    Private ReadOnly js As JavaScriptSerializer

'    Protected Friend db As Data.DB

'    'Path should! always end with '/'

'    Public Sub New()

'        js = New JavaScriptSerializer()
'        js.MaxJsonLength = 41943040

'        If HttpContext.Current.User.Identity.IsAuthenticated Then
'            If AccountController.GetUserId(HttpContext.Current.User.Identity.Name) = -1 Then
'                AccountController.Quit()
'            End If
'        End If

'        db = New Data.DB()

'    End Sub

'    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
'        Get
'            Return False
'        End Get
'    End Property

'    Public Sub ProcessRequest(context As HttpContext) Implements System.Web.IHttpHandler.ProcessRequest
'        logger.Debug("ProcessRequest - Begin")
'        If context.User.Identity.IsAuthenticated Then
'            context.Response.AddHeader("Pragma", "no-cache")
'            context.Response.AddHeader("Cache-Control", "private, no-cache")
'            HandleMethod(context)
'        Else
'            logger.Debug("ProcessRequest - End - Redirect Login")
'            context.Response.Redirect("/Login")
'        End If
'        logger.Debug("ProcessRequest - End")
'    End Sub

'    ' Handle request based on method
'    Private Sub HandleMethod(context As HttpContext)
'        Select Case context.Request.HttpMethod
'            Case "HEAD", "GET"
'                If GivenFilename(context) Then
'                    DeliverFile(context)
'                Else
'                    ListCurrentFiles(context)
'                End If
'                Exit Select

'            Case "POST", "PUT"
'                UploadFile(context)
'                Exit Select

'            Case "DELETE"
'                DeleteFile(context)
'                Exit Select

'            Case "OPTIONS"
'                ReturnOptions(context)
'                Exit Select
'            Case Else

'                context.Response.ClearHeaders()
'                context.Response.StatusCode = 405
'                Exit Select
'        End Select
'    End Sub

'    Private Shared Sub ReturnOptions(context As HttpContext)
'        context.Response.AddHeader("Allow", "DELETE,GET,HEAD,POST,PUT,OPTIONS")
'        context.Response.StatusCode = 200
'    End Sub

'    ' Delete file from the server
'    Private Sub DeleteFile(context As HttpContext)
'        Dim filePath = Path.Combine(StorageRoot(OperationResolver(context.Request("operation")), context.Request("IdCible")), context.Request("f"))
'        If File.Exists(filePath) Then
'            File.Delete(filePath)
'        End If
'    End Sub

'    ' Upload file to the server
'    Private Sub UploadFile(context As HttpContext)
'        logger.Debug("UploadFile - Begin")
'        Dim statuses = New List(Of FilesStatus)()
'        Dim headers = context.Request.Headers

'        If String.IsNullOrEmpty(headers("X-File-Name")) Then
'            UploadWholeFile(context, statuses)
'        Else
'            UploadPartialFile(headers("X-File-Name"), context, statuses)
'        End If
'        logger.Debug("UploadFile - End")
'        WriteJsonIframeSafe(context, statuses)
'    End Sub

'    ' Upload partial file
'    Private Sub UploadPartialFile(fileName As String, context As HttpContext, statuses As List(Of FilesStatus))
'        If context.Request.Files.Count <> 1 Then
'            Throw New HttpRequestValidationException("Attempt to upload chunked file containing more than one fragment per request")
'        End If
'        Dim inputStream = context.Request.Files(0).InputStream
'        Dim fullName = StorageRoot & Path.GetFileName(fileName)

'        Using fs = New FileStream(fullName, FileMode.Append, FileAccess.Write)
'            Dim buffer = New Byte(1023) {}

'            Dim l = inputStream.Read(buffer, 0, 1024)
'            While l > 0
'                fs.Write(buffer, 0, l)
'                l = inputStream.Read(buffer, 0, 1024)
'            End While
'            fs.Flush()
'            fs.Close()
'        End Using
'        statuses.Add(New FilesStatus(New FileInfo(fullName)))
'    End Sub

'    ' Upload entire file
'    Private Sub UploadWholeFile(context As HttpContext, statuses As List(Of FilesStatus))

'        logger.Debug("UploadWholeFile - Begin")
'        logger.Debug("UploadWholeFile - Nombre de fichier posté " & context.Request.Files.Count)

'        For i As Integer = 0 To context.Request.Files.Count - 1
'            Dim file = context.Request.Files(i)

'            Dim fullPath = StorageRoot & Path.GetFileName(file.FileName)

'            logger.Debug("file path " & fullPath)
'            file.SaveAs(fullPath)

'            Dim fullName As String = Path.GetFileName(file.FileName)
'            Dim fs As FilesStatus = New FilesStatus(fullName, file.ContentLength, fullPath)

'            Try
'                Dim nbLignes As Integer = context.Request.Form.Item("nbLignes")
'                If nbLignes = 0 Then
'                    Throw New Exception("Le nombre de lignes doit être un entier non signé et different de zéro!")
'                Else
'                    fs.LinesCount = nbLignes
'                End If
'            Catch ex As Exception
'                Throw New Exception("Le nombre de lignes doit être un entier non signé et different de zéro !")
'            End Try
'            statuses.Add(fs)
'        Next

'        logger.Debug("UploadWholeFile - End")

'    End Sub

'    Private Sub WriteJsonIframeSafe(context As HttpContext, statuses As List(Of FilesStatus))
'        context.Response.AddHeader("Vary", "Accept")
'        Try
'            If context.Request("HTTP_ACCEPT").Contains("application/json") Then
'                context.Response.ContentType = "application/json"
'            Else
'                context.Response.ContentType = "text/plain"
'            End If
'        Catch
'            context.Response.ContentType = "text/plain"
'        End Try

'        Dim jsonObj = js.Serialize(statuses.ToArray())
'        context.Response.Write(jsonObj)
'    End Sub

'    Private Shared Function GivenFilename(context As HttpContext) As Boolean
'        Return Not String.IsNullOrEmpty(context.Request("f"))
'    End Function

'    Private Sub DeliverFile(context As HttpContext)
'        Dim filename = context.Request("f")
'        Dim filePath = StorageRoot & Convert.ToString(filename)

'        If File.Exists(filePath) Then
'            context.Response.AddHeader("Content-Disposition", "attachment; filename=""" & Convert.ToString(filename) & """")
'            context.Response.ContentType = "application/octet-stream"
'            context.Response.ClearContent()
'            context.Response.WriteFile(filePath)
'        Else
'            context.Response.StatusCode = 404
'        End If
'    End Sub

'    Private Sub ListCurrentFiles(context As HttpContext)
'        Dim files = New DirectoryInfo(StorageRoot).GetFiles("*", SearchOption.TopDirectoryOnly).Where(Function(f) Not f.Attributes.HasFlag(FileAttributes.Hidden)).[Select](Function(f) New FilesStatus(f)).ToArray()

'        Dim jsonObj As String = js.Serialize(files)
'        context.Response.AddHeader("Content-Disposition", "inline; filename=""files.json""")
'        context.Response.Write(jsonObj)
'        context.Response.ContentType = "application/json"
'    End Sub

'    <HttpGet()> _
'    Public Function ListFiles(ByVal IdCible As Int32, ByVal operation As String) As ActionResult

'        Dim radical As String = db.Souscriptions.Find(db.COABS.Find(WebSecurity.GetUserId(HttpContext.Current.User.Identity.Name)).Id_Souscription).Radical_Client

'        If String.IsNullOrEmpty(operation) Then
'            Throw New Exception("Erreur d'identification du type de dossier")
'        End If

'        Dim fileList As ViewFilesList = ListDirectory(UtilityFunctions.GetDossierFileRoot(radical, OperationResolver(operation), IdCible), OperationResolver(operation), IdCible)

'        Dim result As JsonResult = Json(fileList, JsonRequestBehavior.AllowGet)

'        result.MaxJsonLength = Int32.MaxValue

'        Return result

'    End Function

'    Private Function ListDirectory(ByVal dirPath As String, ByVal operation As OperationType, ByVal IdCible As Int32) As ViewFilesList
'        Dim result As ViewFilesList = New ViewFilesList()
'        Dim di As New IO.DirectoryInfo(dirPath)
'        Dim fis As IO.FileInfo() = di.GetFiles()

'        For Each fi As FileInfo In fis
'            If Not fi.Name.Equals("Thumbs.db") Then

'                If fi.Name.Equals("Demande_Ouverture.pdf") OrElse
'                   fi.Name.Equals("Domiciliation.pdf") OrElse
'                   fi.Name.Equals("Engagement.pdf") Then

'                    result.files.Add(New ViewDataUploadFilesResult() With { _
'                                 .Name = fi.Name, _
'                                 .OriginName = fi.Name, _
'                                 .size = fi.Length, _
'                                 .IdCible = IdCible, _
'                                 .DateCreation = fi.CreationTime.ToString("dd/MM/yyyy"), _
'                                 .thumbnailUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & GetIconPathByExtention(Path.GetExtension(fi.Name)), _
'                                 .url = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & "/Files/Download/" & fi.Name & "?operation=" & operation.ToString & "&IdCible=" & IdCible, _
'                                 .delete_url = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & "/Files/Delete/" & fi.Name & "?operation=" & operation.ToString & "&IdCible=" & IdCible, _
'                                 .delete_type = "GET"})
'                Else
'                    Dim nameParts As String() = Regex.Split(fi.Name, "[_]{2}")
'                    Dim displayName As String = nameParts.Last

'                    result.files.Add(New ViewDataUploadFilesResult() With { _
'                                     .Name = fi.Name, _
'                                     .OriginName = displayName, _
'                                     .size = fi.Length, _
'                                     .IdCible = nameParts(1), _
'                                     .DateCreation = fi.CreationTime.ToString("dd/MM/yyyy"), _
'                                     .thumbnailUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & GetIconPathByExtention(Path.GetExtension(fi.Name)), _
'                                     .url = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & "/Files/Download/" & fi.Name & "?operation=" & operation.ToString & "&IdCible=" & IdCible, _
'                                     .delete_url = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & "/Files/Delete/" & fi.Name & "?operation=" & operation.ToString & "&IdCible=" & IdCible, _
'                                     .delete_type = "GET"})
'                End If

'            End If
'        Next

'        If Directory.Exists(dirPath & "Swift") Then
'            Dim swiftDi As New IO.DirectoryInfo(dirPath & "Swift\")
'            Dim swiftFis As IO.FileInfo() = swiftDi.GetFiles()
'            For Each fi As FileInfo In swiftFis
'                result.files.Add(New ViewDataUploadFilesResult() With { _
'                                 .Name = fi.Name, _
'                                 .OriginName = fi.Name, _
'                                 .size = fi.Length, _
'                                 .IdCible = IdCible, _
'                                 .DateCreation = fi.CreationTime.ToString("dd/MM/yyyy"), _
'                                 .thumbnailUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & GetIconPathByExtention(Path.GetExtension(fi.Name)), _
'                                 .url = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & "/Files/Download/" & fi.Name & "?operation=" & operation.ToString & "&IdCible=" & IdCible, _
'                                 .delete_url = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(HttpContext.Current.Request.ApplicationPath), String.Empty, HttpContext.Current.Request.ApplicationPath) & "/Files/Delete/" & fi.Name & "?operation=" & operation.ToString & "&IdCible=" & IdCible, _
'                                 .delete_type = "GET"})
'            Next

'        End If


'        Return result
'    End Function

'    Friend Function OperationResolver(ByVal operation As String) As OperationType

'        Dim ope As UtilityFunctions.OperationType

'        Select Case operation
'            Case "CDI"
'                ope = UtilityFunctions.OperationType.CDI
'            Case "RDI"
'                ope = UtilityFunctions.OperationType.RDI
'        End Select

'        Return ope

'    End Function

'    Friend ReadOnly Property StorageRoot(ByVal operation As OperationType, ByVal IdCible As Int32) As String
'        Get

'            Dim radical As String = GetRadicalByOperation(operation, IdCible)

'            If IdCible = 0 Then
'                Throw New Exception("Erreur d'identification du dossier source")
'            End If

'            If String.IsNullOrEmpty(radical) Then
'                Throw New Exception("Erreur d'identification du client")
'            End If

'            Return UtilityFunctions.GetDossierFileRoot(radical, operation, IdCible)

'        End Get

'    End Property

'    Protected Friend Function GetRadicalByOperation(ByVal operation As OperationType, ByVal IdCible As Int32) As String
'        Select Case operation
'            Case OperationType.CDI
'                Return db.Credoc.Find(IdCible).Radical_Client
'            Case OperationType.RDI
'                Return db.Remdoc.Find(IdCible).Radical_Client
'            Case Else
'                Return String.Empty
'        End Select
'    End Function

'End Class