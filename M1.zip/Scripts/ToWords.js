﻿// Convert numbers to words
// copyright 25th July 2006, by Stephen Chapman http://javascript.about.com
// permission to use this Javascript on your web page is granted
// provided that all of the code (including this copyright notice) is
// used exactly as shown (you can change the numbering system if you wish)

// American Numbering System
//var th = ['', 'thousand', 'million', 'billion', 'trillion'];
// uncomment this line for English Number System
//var th = ['', 'thousand', 'million', 'milliard', 'billion'];
var currs = {};
currs['DZD'] = 'Dinars Algériens';
currs['EUR'] = 'Euros';
currs['USD'] = 'Dollars Américains';
currs['GBP'] = 'Livres Sterling';
currs['JPY'] = 'Yens';
currs['CHF'] = 'Francs Suisses';
currs['CAD'] = 'Dollars Canadiens';
currs['MAD'] = 'Dirhams Marocains';
currs['TND'] = 'Dinars Tunisiens';
currs['SEK'] = 'Couronnes suedoises';
currs['KWD'] = 'Dinars Kuwaiti';

var currssubdivision = {};
currssubdivision['DZD'] = 'Centimes';
currssubdivision['EUR'] = 'Centimes';
currssubdivision['USD'] = 'Cents';
currssubdivision['GBP'] = 'Pennies';
currssubdivision['JPY'] = 'Sens';
currssubdivision['CHF'] = 'Centimes';
currssubdivision['CAD'] = 'Cents';
currssubdivision['MAD'] = 'Centimes';
currssubdivision['TND'] = 'Millime';
currssubdivision['SEK'] = 'Öre';
currssubdivision['KWD'] = 'Fils';

var th = ['', 'mille', 'million', 'milliard'];

var dg = ['zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf'];
var tn = ['dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-Sept', 'dix-Huit', 'dix-Neuf'];
var tw = ['vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante-dix', 'quatre-vingt', 'quatre-vingt-dix'];

function numberToWords(s,dev) {

    s = s.toString();
    s = s.replace(/[\, ]/g, '.');
    if (s != parseFloat(s))
        return 'Veuillez saisir un nombre';

    var x = s.indexOf('.');
    if (x == -1) x = s.indexOf(',');
    if (x == -1) x = s.length;
    if (x > 15) return 'Le nombre et trop grand';

    var str = '';

    // (dev == 'EUR' ? ' d\'' : ' de ' )
    str += genericToWords(s,x) + ' ' + currs[dev] ;

    if (x != s.length) {
        str += ' et ' + genericToWords(s.substring(x + 1), s.length - x - 1) + ' ' + currssubdivision[dev];
    }

    return str.replace(/\s+/g, ' ').replace(/^./, function (match) {
        return match.toUpperCase();
    }); 
}

function genericToWords(s,x) {
    
    var n = s.split('');
    var str = '';
    var sk = 0;

    for (var i = 0; i < x; i++) {
        if ((x - i) % 3 == 2) {
            if (n[i] == '1') {
                str += tn[Number(n[i + 1])] + ' ';
                i++; sk = 1;
            } else if (n[i] == 7 || n[i] == 9) {
                str += tw[n[i] - 3] + ((n[i + 1] == 1 && n[i] == 7) ? ' et ' : '-') + tn[Number(n[i + 1])] + ' ';
                i++; sk = 1;
            } else if (n[i] != 0) {
                if (n[i + 1] != 0) {
                    str += tw[n[i] - 2] + ((n[i + 1] == 1 && n[i] != 8) ? ' et ' : '-') + dg[Number(n[i + 1])] + ' ';
                    i++; sk = 1;
                }
                else {
                    str += tw[n[i] - 2] + (n[i] == 8 ? 's ' : ' ');
                    sk = 1;
                }
            }
        } else if (n[i] != 0) {
            if (!(n[i] == 1 && (((x - i) % 3 == 0))))
                str += ((n[i] == 1 && (((x - i - 1) / 3) % 3 == 1)) ? '' : dg[n[i]] + ' ');
            if ((x - i) % 3 == 0)
                str += (((x - i == 3) && (n[i + 1] == 0) && (n[i + 2] == 0)) ? 'cents ' : 'cent ');
            sk = 1;
        } if ((x - i) % 3 == 1) {
            if (sk) {
                if (((x - i - 1) / 3) > 3) {
                    str += th[((x - i - 1) / 3) % 3] + (((Number(s.substring(0, i + 1)) > 1) && (((x - i - 1) / 3) % 3 > 1)) ? 's ' : ' ');
                }
                else {
                    str += th[(x - i - 1) / 3] + (((Number(s.substring(0, i + 1)) > 1) && (((x - i - 1) / 3) % 3 > 1)) ? 's ' : ' ');
                }
                sk = 0;
            }
        }
    }

    return str;
}

