﻿/********************************************************************/
/*                              ENUMS                               */
/********************************************************************/

var DocumentReglementaire = {
    ALL: 0,
    DOUV: 1,
    ENGA: 2,
    DDOM: 3    
}


/********************************************************************/

/********************************************************************/
function CredocNatureChange(newStatus) {
    var fgrp = $('.engagement')
    if (newStatus == 'A renseigner' || newStatus == 'False') {
        fgrp.slideUp(500);
    } else {
        fgrp.slideDown(500);
    }
    $('#Production').validate();
}





window.locale = {
    "fileupload": {
        "errors": {
            "maxFileSize": "Le fichier est trop volumineux",
            "minFileSize": "Le fichier est trop petit",
            "acceptFileTypes": "Type de fichier non autorisé",
            "maxNumberOfFiles": "Nombre de fichiers maximum dépassé",
            "uploadedBytes": "Nombres d'octets chargés dépasse la taille du fichier",
            "emptyResult": "Le fichier n'as pas été chargé"
        },
        "error": "Erreur",
        "start": "Charger",
        "cancel": "Annuler",
        "destroy": "Supprimer"
    }
};

/************************************************************************/
/*  Fonctions Utilitaires                                               */
/************************************************************************/

var formatFileSizeDoc = function (bytes) {
    if (typeof bytes !== 'number') {
        return '';
    }
    if (bytes >= 1000000000) {
        return (bytes / 1000000000).toFixed(2) + ' GB';
    }
    if (bytes >= 1000000) {
        return (bytes / 1000000).toFixed(2) + ' MB';
    }
    return (bytes / 1000).toFixed(2) + ' KB';
};

var renderDocTemplate = function (files) {
    var func = tmpl('template-list-document');
    var result = func({
        files: files,
        formatFileSize: formatFileSizeDoc
    });
    return result;
};

/*****************************************/
/* Initialisation des object html avancé */
/*****************************************/

function initwysiwyg() {
    $('#editor').summernote({
        height: 150
    });
};

function initFileUpload() {
    'use strict';
    //var autoTrigger = !$.browser.msie;
    var auto = $('#fileupload').attr('data-info');
    var factureCommerciale = /^true$/i.test(auto);
    var acceptedFilesTypes = /(\.|\/)(gif|jpe?g|png|pdf|txt|doc|docx|xls|xlsx|xlsm)$/i;

    $('#fileupload').fileupload({
        autoUpload: true,
        acceptFileTypes: acceptedFilesTypes,
        maxFileSize: 4000000,
        messages: {
            maxNumberOfFiles: 'Vous avez atteind le nombre maximum de fichiers authorisés',
            acceptFileTypes: 'Type de fichier non authorisé',
            maxFileSize: 'Le fichier est trop volumineux, la taille maximale est de 4 Mo',
            minFileSize: 'Le fichier est trop petit'
        }
    }).bind('fileuploaddestroy', function (e, data) {
        var buttonUrl = data.context.find('button.btn.btn-danger').attr('data-url');
        var buttonType = data.context.find('button.btn.btn-danger').attr('data-type') || 'DELETE';
        if (buttonUrl) {
            data = $.extend(data, {
                url: buttonUrl,
                type: buttonType
            });
        }
    });

};

var Example = (function () {
    "use strict";

    var elem,
            hideHandler,
            that = {};

    that.init = function (options) {
        elem = $(options.selector);
    };

    that.show = function (text) {
        clearTimeout(hideHandler);

        elem.find("span").html(text);
        elem.delay(200).fadeIn().delay(4000).fadeOut();
    };

    return that;
} ());


/****************************************************************************************/

function removeNestedForm(element, container, deleteElement) {
    $container = $(element).parents(container);
    $container.find(deleteElement).val('True');
    try {
        $container.removeClass('inline');
    } catch (e) {
        
    }

    try {
        $container.removeClass('inline_exceptIE8');
    } catch (e) {

    }

    $container.hide();
}

function addNestedForm(container, counter, property,ticks, content) {
    var nextIndex = $(counter).length;
    var pattern = new RegExp(ticks, "gi");
    content = content.replace(pattern, nextIndex);

    $(container).append(content);
    // ajouter typeahead
    //var newInput = $(container + ' .taginput')[nextIndex];
    $('input[name^="' + property + '[' + nextIndex + '].Nom"]').typeahead(null, {
        name: 'documentTypes',
        displayKey: 'Libelle',
        // `ttAdapter` wraps the suggestion engine in an adapter that
        // is compatible with the typeahead jQuery plugin
        source: documentTypes.ttAdapter()
    });

    $("span.twitter-typeahead").removeAttr('style');




}

/*******************************************************************************************/

function AgenceChange(newAgence) {

    if (newAgence && $.isArray(newAgence)) {
        newAgence = newAgence[0];
    }

    if (newAgence) {
        var radical = $('#Radical_Client').val();

        $.ajax({
            cache: false,
            type: "GET",
            url: $('#CptDetailsUrl').val(),
            data: { 'Age_Agence': newAgence, 'Radical_Client': radical },
            success: function (data) {
                $('#Ncp_Compte').empty();
                $.each(data, function (id, option) {
                    $('#Ncp_Compte').append($('<option></option>').val(option.Ncp).html(option.Age_Agence + ' - ' + option.Ncp));
                });
            },
            error: function (xhr, ajaxOptions, thrownError) {
                Example.show('Une erreur est survenue lors du chargement des comptes !');
            }
        });
    }
    
}

/*************************************************************************************************/

var documentTypes = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.obj.whitespace('Libelle'),
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    limit: 25,
    remote: window.applicationBaseUrl + 'Base/GetDocumentsType'
});

documentTypes.initialize();
/*********************   Fct Pli Change   ************************/
function PliChange(newValue) {
    //alert(newValue);
    var docPliContainer = $('#docPliContainer');
    if (newValue == 'NP') {
        $('#docPliContainer').slideUp(500);
        $('input[id=TypePli]').eq(2).prop('checked', false).parent().removeClass("multiselect-on");
        $('input[id=TypePli]').eq(3).prop('checked', false).parent().removeClass("multiselect-on");
    } else {
        $('#docPliContainer').slideDown(500);
        $('input[id=TypePli]').eq(1).prop('checked', false).parent().removeClass("multiselect-on");
    }
}
/************Add By Lmulud - Select Multiple ***********************************/
jQuery.fn.multiselect = function () {
    $(this).each(function () {
        var checkboxes = $(this).find("input:checkbox");
        checkboxes.each(function () {
            var checkbox = $(this);
            // Highlight pre-selected checkboxes
            if (checkbox.prop("checked"))
                checkbox.parent().addClass("multiselect-on");

            // Highlight checkboxes that the user selects
            checkbox.click(function () {
                PliChange($(this).val());
                if (checkbox.prop("checked"))
                    checkbox.parent().addClass("multiselect-on");                  
                else
                    checkbox.parent().removeClass("multiselect-on");
                
            });
        });
    });
};
/*******************************************************/