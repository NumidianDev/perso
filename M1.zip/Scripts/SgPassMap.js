(function ($) {
    if (typeof Array.prototype.forEach != 'function') {
        Array.prototype.forEach = function (callback) {
            for (var i = 0; i < this.length; i++) {
                callback.apply(this, [this[i], i, this]);
            }
        };
    }
    $.widget("sga.PassMap", {
        version: "1.0.0",
        options: {
            mapUrl: "PassMap",
            size: "20",
            target: '.pass-input',
            clickHandler: 'sgaPassChange',
            buttons: true,
            _storage: []
        },
        _event: '',
        _events: [],
        _create: function () {
            var element = this.element;
            if (element.data('mapurl') != undefined) this.options.mapUrl = element.data("mapurl");
            if (element.data('size') != undefined) this.options.size = element.data("size");
            if (element.data('target') != undefined) this.options.target = element.data("target");
            if (element.data('clickHandler') != undefined) this.options.clickHandler = element.data("clickHandler");
            element.data("_storage", []);
            this._renderMap();
        },
        _renderMapElements: function () {
            var img, map, table, tr, td, i, j, that = this;
            this.element.html("");
            table = $("<table/>");
            tr = $("<tr/>");
            passTd = $("<td/>");
            passTd.attr('rowspan', '2');
            var img = $('<img/>');
            img.attr('src', this.options.mapUrl);
            img.attr('usemap', '#map');
            $(img).load();
            img.appendTo(passTd);
            img.css({ 'padding-top': '4px' });
            map = $("<map/>");
            map.attr('name', 'map');
            map.attr('id', 'map');
            var letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y'];
            letters.forEach(function (value, index, array) {
                area = $("<area/>"); area.attr('alt', '');
                area.attr('shape', 'rect');
                var mod = index % 5;
                var ligne = Math.floor(index / 5);
                var coord = '' + eval(ligne * that.options.size) + ',' + eval(mod * that.options.size) + ',' + eval((ligne + 1) * that.options.size) + ',' + eval((mod + 1) * that.options.size) + '';
                area.attr('coords', coord);
                area.attr('href', 'javascript:void(0)');
                area.on('click', function (e) {
                    if (that.options.clickHandler) {
                        // && (typeof that.options.clickHandler === "function")) 
                        var Clickhdl = window[that.options.clickHandler];
                        if (typeof Clickhdl === "function") {
                            Clickhdl.apply(this, [e, value, that.options.target]);
                        }
                    }
                });
                //area.attr('onclick', 'javascript:sgaPassChange("' + value + '","' + that.options.target + '")');
                area.appendTo(map);
            });
            map.appendTo(passTd);
            passTd.appendTo(tr);
            if (/firefox/.test(navigator.userAgent.toLowerCase())) {
                passTd = $("<td/>").html("<input type='button' class='inputPassReset noModeContrast btn-reset' style='top:-11px' value='Effacer'></input>").appendTo(tr);
            } else {
                if (/chrom(e|ium)/.test(navigator.userAgent.toLowerCase())) {
                    passTd = $("<td/>").html("<input type='button' class='inputPassReset noModeContrast btn-reset' value='Effacer'></input>").appendTo(tr);
                } else {
                    passTd = $("<td/>").html("<input type='button' class='inputPassReset ie noModeContrast btn-reset' style='top:-6px' value='Effacer'></input>").appendTo(tr);
                }
            }
            tr.appendTo(table);
            tr = $("<tr/>");
            passTd = $("<td/>").html("<input type='button' class='inputPassReset noModeContrast btn-close' value='Ok' style='top:-30px;'></input>").appendTo(tr);
            tr.appendTo(table);
            table.appendTo(this.element);
        },
        _renderMap: function () {
            this._renderMapElements();
            this._initButtons();
        },
        _changeTarget: function (value) {
            var targetElement = $(this.options.target);
            targetElement.val(targetElement.val() + value);
        },
        _initButtons: function () {
            var that = this, table = this.element.find('table');
            table.find('.btn-reset').on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var targetElement = $(that.options.target);
                targetElement.val('');
            });

        },
        _destroy: function () { }, _setOption: function (key, value) { this._super('_setOption', key, value); }
    })
})(jQuery);