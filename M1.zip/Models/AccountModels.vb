﻿Imports System.ComponentModel
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Globalization
Imports System.Data.Entity
Imports CaptchaMvc.HtmlHelpers

Public Class UsersContext
    Inherits DbContext

    Public Sub New()
        MyBase.New("DefaultConnection")
    End Sub

    Public Property UserProfiles As DbSet(Of UserProfile)
End Class

<Table("UserProfile")> _
Public Class UserProfile
    <Key()> _
    <DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)> _
    Public Property UserId As Integer

    Public Property UserName As String
End Class

Public Class RegisterExternalLoginModel
    <Required()> _
    <Display(Name:="User name")> _
    Public Property UserName As String

    Public Property ExternalLoginData As String
End Class

Public Class LocalPasswordModel
    <Required()> _
    <DataType(DataType.Password)> _
    <Display(Name:="Mot de passe actuel")> _
    Public Property OldPassword As String

    <Required()> _
    <StringLength(100, ErrorMessage:="Le {0} doit avoir {2} characters au moin.", MinimumLength:=6)> _
    <RegularExpression("([0-9]){6}", ErrorMessage:="Mot de passe invalide, doit être sur 6 positions numérique")>
    <DataType(DataType.Password)> _
    <Display(Name:="Nouveau Mot de passe")> _
    Public Property NewPassword As String

    <DataType(DataType.Password)> _
    <Display(Name:="Confirmer le nouveau mot de passe")> _
    <Compare("NewPassword", ErrorMessage:="La confirmation ne correspond pas avec le nouveau mote passe.")> _
Public Property ConfirmPassword As String
End Class

Public Class LoginModel
    <Required()> _
    <Display(Name:="Login")> _
    Public Property UserName As String

    <Required()> _
    <DataType(DataType.Password)> _
    <Display(Name:="Mot de passe")> _
    Public Property Password As String

    <Display(Name:="Rester connecté ?")> _
    Public Property RememberMe As Boolean
End Class

Public Class RegisterModel
    <Required(ErrorMessage:="Ce champ est necessaire")> _
    <Display(Name:="Nom")> _
    Public Property Nom As String
    <Required(ErrorMessage:="Ce champ est necessaire")> _
    <Display(Name:="Prenom")> _
    Public Property Prenom As String
    <Required(ErrorMessage:="Ce champ est necessaire")> _
    <Display(Name:="N° d'identification fiscale")> _
    Public Property NIF As String
    <Required(ErrorMessage:="Ce champ est necessaire")> _
    <Display(Name:="N° du registre de commerce")> _
   Public Property RC As String
    <Required(ErrorMessage:="Ce champ est necessaire")> _
    <RegularExpression("^[a-zA-Z0-9\._-]+@[a-zA-Z0-9\.-]{2,}[\.][a-zA-Z]{2,4}$", ErrorMessage:="Format d'email invalide.")> _
    <Display(Name:="Email Entreprise")> _
    Public Property EmailEntreprise As String
    <Required(ErrorMessage:="Ce champ est necessaire")> _
     <RegularExpression("^[a-zA-Z0-9\._-]+@[a-zA-Z0-9\.-]{2,}[\.][a-zA-Z]{2,4}$", ErrorMessage:="Format d'email invalide.")> _
    <Display(Name:="Email Contact")> _
    Public Property EmailContact As String
    Public Property Agence As String
    Property radical As Object

    Property rs As Object

End Class

Public Class ExternalLogin
    Public Property Provider As String
    Public Property ProviderDisplayName As String
    Public Property ProviderUserId As String
End Class
Public Class Feedback
    Public Property Id As String
    Public Property Title As String
    Public Property Comment As String
End Class
