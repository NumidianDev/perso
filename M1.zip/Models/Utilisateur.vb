﻿Imports System.ComponentModel.DataAnnotations
Imports E_Trade.Data
Imports System.Globalization

Public Class Utilisateur

    Public Property client As Client
    Public Property souscription As Souscription
    Public Property coabs As IList(Of COAB)

End Class