﻿Public Class ViewDataUploadFilesResult
    Public Property OriginName() As String
        Get
            Return m_OriginName
        End Get
        Set(value As String)
            m_OriginName = value
        End Set
    End Property
    Private m_OriginName As String
    Public Property Name() As String
        Get
            Return m_Name
        End Get
        Set(value As String)
            m_Name = value
        End Set
    End Property
    Private m_Name As String


    Public Property size() As Integer
        Get
            Return m_size
        End Get
        Set(value As Integer)
            m_size = Value
        End Set
    End Property
    Private m_size As Integer
    Public Property type() As String
        Get
            Return m_type
        End Get
        Set(value As String)
            m_type = Value
        End Set
    End Property
    Private m_type As String
    Public Property url() As String
        Get
            Return m_url
        End Get
        Set(value As String)
            m_url = Value
        End Set
    End Property
    Private m_url As String
    Public Property delete_url() As String
        Get
            Return m_delete_url
        End Get
        Set(value As String)
            m_delete_url = Value
        End Set
    End Property
    Private m_delete_url As String
    Public Property thumbnailUrl() As String
        Get
            Return m_thumbnail_url
        End Get
        Set(value As String)
            m_thumbnail_url = value
        End Set
    End Property
    Private m_thumbnail_url As String
    Public Property delete_type() As String
        Get
            Return m_delete_type
        End Get
        Set(value As String)
            m_delete_type = Value
        End Set
    End Property
    Private m_delete_type As String

    Public Property Ope() As UtilityFunctions.OperationType
        Get
            Return m_ope
        End Get
        Set(value As UtilityFunctions.OperationType)
            m_ope = value
        End Set
    End Property
    Private m_ope As UtilityFunctions.OperationType

    Public Property IdCible() As Int32
        Get
            Return m_idCible
        End Get
        Set(value As Int32)
            m_idCible = value
        End Set
    End Property
    Private m_idCible As Int32

    Public Property DateCreation() As String
        Get
            Return m_DateCreation
        End Get
        Set(value As String)
            m_DateCreation = value
        End Set
    End Property
    Private m_DateCreation As String

End Class