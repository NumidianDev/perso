﻿Public Class Select2DTO

    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property Text() As String
        Get
            Return m_text
        End Get
        Set(value As String)
            m_text = value
        End Set
    End Property
    Private m_text As String

End Class
