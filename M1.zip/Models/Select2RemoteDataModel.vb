﻿Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

Public Class Select2RemoteDataModel

    <DisplayName("Country Name")>
    Public Property CountryName() As String
        Get
            Return m_CountryName
        End Get
        Set(value As String)
            m_CountryName = value
        End Set
    End Property
    Private m_CountryName As String

End Class
