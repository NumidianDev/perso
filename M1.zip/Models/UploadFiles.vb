﻿Imports System.ComponentModel.DataAnnotations

Public Class UploadFiles
    Public Property name() As String
        Get
            Return m_name
        End Get
        Set(value As String)
            m_name = value
        End Set
    End Property
    Private m_name As String

    Public Property Id() As Integer
        Get
            Return m_Id
        End Get
        Set(value As Integer)
            m_Id = value
        End Set
    End Property
    Private m_Id As Integer
    Public Property size() As Integer
        Get
            Return m_size
        End Get
        Set(value As Integer)
            m_size = value
        End Set
    End Property
    Private m_size As Integer
    Public Property type() As String
        Get
            Return m_type
        End Get
        Set(value As String)
            m_type = value
        End Set
    End Property
    Private m_type As String
    Public Property url() As String
        Get
            Return m_url
        End Get
        Set(value As String)
            m_url = value
        End Set
    End Property
    Private m_url As String
    Public Property delete_url() As String
        Get
            Return m_delete_url
        End Get
        Set(value As String)
            m_delete_url = value
        End Set
    End Property
    Private m_delete_url As String
    Public Property thumbnail() As String
        Get
            Return m_thumbnail_url
        End Get
        Set(value As String)
            m_thumbnail_url = value
        End Set
    End Property
    Private m_thumbnail_url As String
    Public Property delete_type() As String
        Get
            Return m_delete_type
        End Get
        Set(value As String)
            m_delete_type = value
        End Set
    End Property
    Private m_delete_type As String


    Public Property date_creation() As String
        Get
            Return m_date_creation
        End Get
        Set(value As String)
            m_date_creation = value
        End Set
    End Property
    Private m_date_creation As String
    '--------------
    Public Property Ext() As String
        Get
            Dim ex = New Dictionary(Of String, String)
            ex.Add(".pdf", "PDF.png")
            ex.Add(".xls", "Excel.png")
            ex.Add(".xlsx", "Excel.png")
            ex.Add(".doc", "Word.png")
            ex.Add(".docx", "Word.png")
            ex.Add(".avi", "Multimedia.png")
            ex.Add(".mp4", "Multimedia.png")
            ex.Add(".png", "Image.png")
            ex.Add(".gif", "Image.png")
            ex.Add(".jpg", "Image.png")
            ex.Add(".jpeg", "Image.png")
            ex.Add(".txt", "File.png")
            Try
                Return ex.Item(type)
            Catch e As Exception
                Return "FileNotFound.png"
            End Try
        End Get
        Set(value As String)

        End Set
    End Property
    Private ex As String

End Class