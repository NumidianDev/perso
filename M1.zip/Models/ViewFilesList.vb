﻿Public Class ViewFilesList

    Public Property files() As IList(Of ViewDataUploadFilesResult)
        Get
            Return _files
        End Get
        Set(value As IList(Of ViewDataUploadFilesResult))
            _files = value
        End Set
    End Property
    Private _files As IList(Of ViewDataUploadFilesResult)

    Sub New()
        MyBase.New()
        _files = New List(Of ViewDataUploadFilesResult)
    End Sub

End Class
