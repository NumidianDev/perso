import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sga-toolbar',
  templateUrl: './sga-toolbar.component.html',
  styleUrls: ['./sga-toolbar.component.css']
})
export class SgaToolbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
