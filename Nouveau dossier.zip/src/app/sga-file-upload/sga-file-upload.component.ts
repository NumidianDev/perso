import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';  
import { catchError, map } from 'rxjs/operators';  

import { UploadService } from  '../upload.service';
import { FileType } from '../file-type.class';
import { MatDialog, MatDialogConfig } from '@angular/material';

@Component({
  selector: 'app-sga-file-upload',
  templateUrl: './sga-file-upload.component.html',
  styleUrls: ['./sga-file-upload.component.css']
})
export class SgaFileUploadComponent implements OnInit {

  files: any[] = [];

  @ViewChild('fileDropRef', {static: false}) fileDropRef: ElementRef;

  constructor(private uploadService: UploadService, private dialog: MatDialog) { }

  ngOnInit() {
  }

  reset() {
    this.fileDropRef.nativeElement.value = '';
  }

  /**
   * on file drop handler
   */
  onFileDropped($event) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    console.log("Deleting file " + index);
    this.files.splice(index, 1);
  }

  deleteFiles() {
    console.log("Deleting files ");
    this.files = [];
    this.reset();
  }

  /**
   * Simulate the upload process
   */
  uploadFilesSimulator(index: number) {

    setTimeout(() => {
      if (index === this.files.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            clearInterval(progressInterval);
            this.uploadFilesSimulator(index + 1);
          } else {
            this.files[index].progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    
    if (files.length > 0){
      console.log(files);
      this.files.push(files[0]);
        this.uploadFile(0);
    }else{
      return;
    }
    /*for (const item of files) {
      item.progress = 0;
      this.files.push(item);
    }
    this.uploadFilesSimulator(0);*/
  }

  uploadFile(index) {  

    if(FileType.mime_xslx.includes(this.files[index].type)){

      console.log('check file type ',FileType.mime_xslx.includes(this.files[index].type));
      const formData = new FormData();  
      formData.append('files', this.files[index]);  
      this.files[index].inProgress = true;  
      this.uploadService.upload(formData).pipe(  
        map(event => {  
          switch (event.type) {
            case HttpEventType.Sent:
              console.log('Request has been made!');
              break;
            case HttpEventType.ResponseHeader:
              console.log('Response header has been received!');
              break;
            case HttpEventType.UploadProgress:
              this.files[index].progress = Math.round(event.loaded * 100 / event.total); 
              console.log(`Uploaded! ${this.files[index].progress}%`);
              break;
            case HttpEventType.Response:
              console.log('User successfully created!', event.body);
              setTimeout(() => {
                this.files[index].progress = 0;
              }, 1500);
              return event; 
          }
        }),  
        catchError((error: HttpErrorResponse) => {  
          this.files[index].inProgress = false;  
          return of(`${this.files[index].data.name} upload failed.`);  
        })).subscribe((event: any) => {  
          if (typeof (event) === 'object') { 
            console.log(event.body);  
          }  
        });  
    }else {
      this.files.pop();
      const dialogConfig = new MatDialogConfig();
      dialogConfig.autoFocus = true;
      
    };
    
  }


  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
}
