import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';  
import { FetchDataComponent } from './fetch-data/fetch-data.component';

const routes: Routes = [  
  { path: 'fetch-data', component: FetchDataComponent, pathMatch: 'full' }
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forRoot(routes)],  
  exports: [CommonModule, RouterModule]
})
export class AppRoutingModule { }
