using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SgaConverter.Interfaces
{
    public interface IFileService
    {
        public void SaveFile (List<IFormFile> files);
        public (string fileType, byte[] archiveData, string archiveName) FetechFiles (string subDirectory);

        public string SizeConverter (long bytes);

    }
}