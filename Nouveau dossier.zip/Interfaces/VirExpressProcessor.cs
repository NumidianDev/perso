namespace SgaConverter.Interfaces
{
    public interface VirExpressProcessor
    {
         
    }
}