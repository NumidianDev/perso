using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SgaConverter.Interfaces;

namespace SgaConverter.Controllers {
    [Route ("api/[controller]")]
    public class FileController : ControllerBase {
        private readonly IFileService _fileService;
        private readonly ILogger<FileController> _logger;
        
        public FileController (IFileService fileService, ILogger<FileController> logger) {
            _fileService = fileService;
            _logger = logger;
        }

        // download file(s) to client according path: rootDirectory/subDirectory with single zip file
        [HttpGet ("Download/{subDirectory}")]
        public IActionResult DownloadFiles (string subDirectory) {
            try {
                var (fileType, archiveData, archiveName) = _fileService.FetechFiles (subDirectory);

                return File (archiveData, fileType, archiveName);
            } catch (Exception exception) {
                return BadRequest ($"Error: {exception.Message}");
            }
        }

        // upload file(s) to server that palce under path: rootDirectory/subDirectory
        [HttpPost ("upload")]
        public IActionResult UploadFile ([FromForm (Name = "files")] List<IFormFile> files) {
            try {
                _logger.LogCritical(_fileService.SizeConverter (files.Sum (f => f.Length)));
                _fileService.SaveFile (files);
                _logger.LogTrace(_fileService.SizeConverter (files.Sum (f => f.Length)));
                return Ok (new { files.Count, Size = _fileService.SizeConverter (files.Sum (f => f.Length)) });
            } catch (Exception exception) {
                return BadRequest ($"Error: {exception.Message}");
            }
        }

    }
}