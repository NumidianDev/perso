﻿(function () {
    'use strict';

    var commonModule = angular.module('common', ['ngMaterial', 'mdDataTable']);

    var mainModule = angular.module('mainApp', ['common']);
    mainModule.controller('mainCtrl', function ($scope, $http, $mdToast) {
        $scope.header = "Suivi du budget - SGA";
    });
}());