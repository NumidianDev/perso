﻿(function () {
    'use strict';

    var commonModule = angular.module('common', ['ngMaterial', 'ngMdIcons', 'md.data.table', 'ngMessages']);
    var mainModule = angular.module('mainApp', ['common']);

    mainModule.config(function($mdDateLocaleProvider) {

        // Example of a French localization.
        $mdDateLocaleProvider.months = ["janvier",
                                        "f\u00e9vrier",
                                        "mars",
                                        "avril",
                                        "mai",
                                        "juin",
                                        "juillet",
                                        "ao\u00fbt",
                                        "septembre",
                                        "octobre",
                                        "novembre",
                                        "d\u00e9cembre"]; 
        $mdDateLocaleProvider.shortMonths = ["janv.",
                                             "f\u00e9vr.",
                                             "mars",
                                             "avr.",
                                             "mai",
                                             "juin",
                                             "juil.",
                                             "ao\u00fbt",
                                             "sept.",
                                             "oct.",
                                             "nov.",
                                             "d\u00e9c."];
        $mdDateLocaleProvider.days = ["dimanche",
                                      "lundi",
                                      "mardi",
                                      "mercredi",
                                      "jeudi",
                                      "vendredi",
                                      "samedi"];
        $mdDateLocaleProvider.shortDays = ["dim.",
                                           "lun.",
                                           "mar.",
                                           "mer.",
                                           "jeu.",
                                           "ven.",
                                           "sam."];

        // Can change week display to start on Monday.
        $mdDateLocaleProvider.firstDayOfWeek = 0;
        
        // Example uses moment.js to parse and format dates.
        $mdDateLocaleProvider.parseDate = function(dateString) {
            var m = moment(dateString, 'L', true);
            return m.isValid() ? m.toDate() : new Date(NaN);
        };

        $mdDateLocaleProvider.formatDate = function(date) {
            var m = moment(date);
            return m.isValid() ? m.format('L') : '';
        };

        $mdDateLocaleProvider.monthHeaderFormatter = function(date) {
            return $mdDateLocaleProvider.shortMonths[date.getMonth()] + ' ' + date.getFullYear();
        };

        // In addition to date display, date components also need localized messages
        // for aria-labels for screen-reader users.

        $mdDateLocaleProvider.weekNumberFormatter = function(weekNumber) {
            return 'Semaine ' + weekNumber;
        };

        $mdDateLocaleProvider.msgCalendar = 'Calendrier';
        $mdDateLocaleProvider.msgOpenCalendar = 'Ouvrir le calendrier';

        // You can also set when your calendar begins and ends.
        $mdDateLocaleProvider.firstRenderableDate = new Date(1800, 1, 1);
        $mdDateLocaleProvider.lastRenderableDate = new Date(3000, 12, 31);
    });

    commonModule.factory('viewModelHelper', function ($http, $q, $window, $location) { return SgaApp.viewModelHelper($http, $q, $window, $location); });
    commonModule.factory('validator', function () { return valJs.validator(); });
        
    mainModule.controller('mainCtrl', function (budgetService, $scope, $http, $q, $window, $location, $mdToast, viewModelHelper) {

        $scope.header = "Suivi du budget - SGA";
        $scope.currentDirection = null;

        var directionDeferred = null;

        budgetService.DirectionSuccess = function success(direction) {
            $scope.currentDirection = direction.data;
            budgetService.currentDirection = direction.data;
            directionDeferred.resolve();
        }

        var initialize = function () {
            directionDeferred = $q.defer();
            budgetService.GetCurrentDirection();
        }

        $scope.toggleEditDepense = function () {
            viewModelHelper.toggleEditDepense();
        }
        $scope.toggleEditBudget = function () {
            viewModelHelper.toggleEditBudget();
        }
        $scope.EditDepense = function () {
            return viewModelHelper.EditDepense;
        }
        $scope.EditBudget = function () {
            return viewModelHelper.EditBudget;
        }

        initialize();
    });
}());


(function (SgaApp) {
    var viewModelHelper = function ($http, $q, $window, $location) {

        var self = this;

        self.EditDepense = false;
        self.EditBudget = false;

        self.modelIsValid = true;
        self.modelErrors = [];

        self.toggleEditDepense = function () {
            self.EditDepense = !self.EditDepense;
        }

        self.toggleEditBudget = function () {
            self.EditBudget = !self.EditBudget;
        }

        self.resetModelErrors = function () {
            self.modelErrors = [];
            self.modelIsValid = true;
        }

        self.apiGet = function (uri, data, success, failure, always) {
            self.modelIsValid = true;
            $http.get(SgaApp.rootPath + uri, data)
                .then(function (result) {
                    success(result);
                    if (always != null)
                        always();
                }, function (result) {
                    if (failure != null) {
                        failure(result);
                    }
                    else {
                        var errorMessage = result.status + ':' + result.statusText;
                        if (result.data != null && result.data.Message != null)
                            errorMessage += ' - ' + result.data.Message;
                        self.modelErrors = [errorMessage];
                        self.modelIsValid = false;
                    }
                    if (always != null)
                        always();
                });
        }

        self.apiPost = function (uri, data, success, failure, always) {
            self.modelIsValid = true;
            $http.post(SgaApp.rootPath + uri, data)
                .then(function (result) {
                    success(result);
                    if (always != null)
                        always();
                }, function (result) {
                    if (failure != null) {
                        failure(result);
                    }
                    else {
                        var errorMessage = result.status + ':' + result.statusText;
                        if (result.data != null && result.data.Message != null)
                            errorMessage += ' - ' + result.data.Message;
                        self.modelErrors = [errorMessage];
                        self.modelIsValid = false;
                    }
                    if (always != null)
                        always();
                });
        }

        self.goBack = function () {
            $window.history.back();
        }

        self.navigateTo = function (path) {
            $location.path(SgaApp.rootPath + path);
        }

        self.refreshPage = function (path) {
            $window.location.href = SgaApp.rootPath + path;
        }

        self.clone = function (obj) {
            return JSON.parse(JSON.stringify(obj))
        }

        return this;
    };
    SgaApp.viewModelHelper = viewModelHelper;
}(window.SgaApp));
