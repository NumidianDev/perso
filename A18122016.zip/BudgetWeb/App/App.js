﻿(function () {
    'use strict';

    var commonModule = angular.module('common', ['ngMaterial', 'md.data.table']);
    var mainModule = angular.module('mainApp', ['common']);

    commonModule.factory('viewModelHelper', function ($http, $q, $window, $location) { return SgaApp.viewModelHelper($http, $q, $window, $location); });
    commonModule.factory('validator', function () { return valJs.validator(); });
        
    mainModule.controller('mainCtrl', function ($scope, $http, $q, $window, $location, $mdToast, viewModelHelper) {
        $scope.header = "Suivi du budget - SGA";
    });
}());


(function (SgaApp) {
    var viewModelHelper = function ($http, $q, $window, $location) {

        var self = this;

        self.modelIsValid = true;
        self.modelErrors = [];

        self.resetModelErrors = function () {
            self.modelErrors = [];
            self.modelIsValid = true;
        }

        self.apiGet = function (uri, data, success, failure, always) {
            self.modelIsValid = true;
            $http.get(SgaApp.rootPath + uri, data)
                .then(function (result) {
                    success(result);
                    if (always != null)
                        always();
                }, function (result) {
                    if (failure != null) {
                        failure(result);
                    }
                    else {
                        var errorMessage = result.status + ':' + result.statusText;
                        if (result.data != null && result.data.Message != null)
                            errorMessage += ' - ' + result.data.Message;
                        self.modelErrors = [errorMessage];
                        self.modelIsValid = false;
                    }
                    if (always != null)
                        always();
                });
        }

        self.apiPost = function (uri, data, success, failure, always) {
            self.modelIsValid = true;
            $http.post(SgaApp.rootPath + uri, data)
                .then(function (result) {
                    success(result);
                    if (always != null)
                        always();
                }, function (result) {
                    if (failure != null) {
                        failure(result);
                    }
                    else {
                        var errorMessage = result.status + ':' + result.statusText;
                        if (result.data != null && result.data.Message != null)
                            errorMessage += ' - ' + result.data.Message;
                        self.modelErrors = [errorMessage];
                        self.modelIsValid = false;
                    }
                    if (always != null)
                        always();
                });
        }

        self.goBack = function () {
            $window.history.back();
        }

        self.navigateTo = function (path) {
            $location.path(SgaApp.rootPath + path);
        }

        self.refreshPage = function (path) {
            $window.location.href = SgaApp.rootPath + path;
        }

        self.clone = function (obj) {
            return JSON.parse(JSON.stringify(obj))
        }

        return this;
    };
    SgaApp.viewModelHelper = viewModelHelper;
}(window.SgaApp));
