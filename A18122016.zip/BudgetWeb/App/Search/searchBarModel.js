﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('searchBarCtrl', function ($scope, budgetService, searchService, $http, $q, $window, $location, $mdToast, $timeout, $mdDialog, viewModelHelper) {

        var initialize = function () {

        }

        initialize();

    });
}());
