﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('searchCtrl', function ($scope, budgetService, searchService, $http, $q, $window, $location, $mdToast, $timeout, $mdDialog, viewModelHelper) {

        $scope.paginationLimit = 10;

        $scope.paginationPage = 1;

        

        $scope.searchQuery = null;

        $scope.inSearch = false;

        $scope.selectedCategorie = null;

        $scope.SearchModel = {
            query: '',
            result: {
                factures: [],
                bdcs: [],
                contrats: [],
                fournisseurs: [],
                fgs: []
            },
            resultCategories : [
            { name: "Factures", count: 0},
            { name: "BDCs", count: 0 },
            { name: "Contrats", count: 0 },
            { name: "Fournisseurs", count: 0 },
            { name: "Frais Généraux", count: 0 }
            ]
        }

        $scope.total = $scope.SearchModel.result.bdcs.length;

        $scope.limitOptions = [5, 10, 15, {
            label: 'All',
            value: function () {
                return $scope.SearchModel.result.bdcs.length;
            }
        }];

        $scope.selectItem = function (item) {
            $scope.selectedCategorie = item;
        }

        var deferred = null;

        $scope.toggleSearch = function () {
            viewModelHelper.toggleSearch();
        }

        $scope.showSearch = function () {
            return viewModelHelper.showSearch;
        }

        $scope.fireSearch = function () {
            deferred = $q.defer();
            $scope.inSearch = !$scope.inSearch;
            searchService.search($scope.SearchModel);
        }

        var initialize = function () {
            searchService.searchSuccess = function success(result) {
                deferred.resolve();
                $scope.inSearch = !$scope.inSearch;
                $scope.SearchModel = result.data;
            }

            
        }

        initialize();

    });
}());
