﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('searchCtrl', function ($scope, budgetService, searchService, $http, $q, $window, $location, $mdToast, $timeout, $mdDialog, viewModelHelper) {

        $scope.searchQuery = null;

        $scope.SearchModel = {
            query: ''
        }

        var deferred = null;

        $scope.toggleSearch = function () {
            viewModelHelper.toggleSearch();
        }

        $scope.showSearch = function () {
            return viewModelHelper.showSearch;
        }

        $scope.fireSearch = function () {
            deferred = $q.defer();
            searchService.search($scope.SearchModel);
        }

        var initialize = function () {
            searchService.searchSuccess = function success(result) {
                alert(result);
                deferred.resolve();
            }
        }

        initialize();

    });
}());
