﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('searchCtrl', function ($scope, budgetService, searchService, $http, $q, $window, $location, $mdToast, $timeout, $mdDialog, viewModelHelper) {

        $scope.searchQuery = null;

        $scope.inSearch = false;

        $scope.SearchModel = {
            query: '',
            result: {
                factures: [],
                bdcs: [],
                contrats: [],
                fournisseurs: [],
                fgs: []
            }
        }

        $scope.resultCategories = [
            { name: "Factures", count: $scope.SearchModel.result.factures.length},
            { name: "BDCs", count: $scope.SearchModel.result.bdcs.length },
            { name: "Contrats", count: $scope.SearchModel.result.contrats.length },
            { name: "Fournisseurs", count: $scope.SearchModel.result.fournisseurs.length },
            { name: "Frais Généraux", count: $scope.SearchModel.result.fgs.length }
        ];

        

        var deferred = null;

        $scope.toggleSearch = function () {
            viewModelHelper.toggleSearch();
        }

        $scope.showSearch = function () {
            return viewModelHelper.showSearch;
        }

        $scope.fireSearch = function () {
            deferred = $q.defer();
            $scope.inSearch = !$scope.inSearch;
            searchService.search($scope.SearchModel);
        }

        var initialize = function () {
            searchService.searchSuccess = function success(result) {
                deferred.resolve();
                $scope.inSearch = !$scope.inSearch;
                $scope.SearchModel = result.data;
            }
        }

        initialize();

    });
}());
