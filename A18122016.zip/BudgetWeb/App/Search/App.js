﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.factory('searchService', function ($rootScope, $http, $q, $location, viewModelHelper) {
        return SgaApp.searchService($rootScope, $http, $q, $location, viewModelHelper);
    });

}());
