﻿(function (SgaApp) {
    var searchService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.searchSuccess = null;

        self.search = function (searchModel) {
            return viewModelHelper.apiPost('Search/All', searchModel, self.searchSuccess);
        }

        return this;

    };

    SgaApp.searchService = searchService;

}(window.SgaApp));

