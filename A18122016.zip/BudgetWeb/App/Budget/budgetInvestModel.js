﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('budgetInvestListCtrl', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.tableHeader = "";
        $scope.budgetService = budgetService;
        $scope.viewModelHelper = viewModelHelper;
        $scope.bottom = false;

        $scope.selected = [];

        var deferred = null;

        $scope.investCollection = [];

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        budgetService.onBudgetSelected.push(function () {
            $scope.tableHeader = "Investissements de l'exercice " + budgetService.selectedBudget.Exercice
            $scope.refreshInvest();
        })

        budgetService.investSuccess = function success(invests) {
            $scope.investCollection = invests.data.pagedInvest;
            $scope.query = invests.data.sortParam;
            deferred.resolve();
        }

        var initialize = function () {
            $scope.refreshInvest();
        }

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            budgetService.selectedInvest = item;
            if (budgetService.onInvestSelected.length > 0) {
                angular.forEach(budgetService.onInvestSelected, function (handler) {
                    handler();
                });
            }
        }

        $scope.refreshInvest = function () {
            if (budgetService.selectedBudget) {
                deferred = $q.defer();
                $scope.promiseInvest = deferred.promise;
                budgetService.getInvestByBudget($scope.query);
            }
        }

        initialize();
    });
}());
