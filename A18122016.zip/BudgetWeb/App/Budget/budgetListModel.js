﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('budgetListCtrl', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.budgetHeader = "Liste des budgets";
        $scope.budgetService = budgetService;
        $scope.viewModelHelper = viewModelHelper;
        $scope.bottom = false;

        $scope.selected = [];

        var deferred = null;

        $scope.budgets = [];

        $scope.query = budgetService.query;

        budgetService.success = function success(budgets) {
            $scope.budgets = budgets;
            deferred.resolve();
        }

        var initialize = function () {
            $scope.refreshBudgets();
        }

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            budgetService.selectedBudget = item;
            angular.forEach(budgetService.onBudgetSelected, function (handler) {
                handler();
            });
        }

        $scope.refreshBudgets = function () {
            deferred = $q.defer();
            $scope.promise = deferred.promise;
            budgetService.getAllBudgets();
        }

        initialize();

    });
}());
