﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('budgetListCtrl', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.tableHeader = "Liste des budgets";
        $scope.budgetService = budgetService;
        $scope.viewModelHelper = viewModelHelper;
        $scope.bottom = false;

        $scope.selected = [];

        var deferred = null;

        $scope.budgets = [];

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        budgetService.success = function success(budgets) {
            $scope.budgets = budgets.data.pagedBudgets;
            $scope.query = budgets.data.sortParam;
            if (budgets.data.pagedBudgets.length > 0) { $scope.tableHeader = "Liste des budgets " + budgets.data.pagedBudgets[0].Direction.Code }
            deferred.resolve();
        }

        var initialize = function () {
            $scope.refreshBudgets();
        }

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            budgetService.selectedBudget = item;
            angular.forEach(budgetService.onBudgetSelected, function (handler) {
                handler();
            });
        }

        $scope.refreshBudgets = function () {
            deferred = $q.defer();
            $scope.promiseList = deferred.promise;
            budgetService.getAllBudgets($scope.query);
        }

        initialize();

    });
}());
