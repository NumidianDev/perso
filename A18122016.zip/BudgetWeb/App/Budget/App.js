﻿(function () {
    'use strict';
    //var commonModule = angular.module('common');
    //var budgetModule = angular.module('budgetApp', ['common']);
    var mainModule = angular.module('mainApp');
    mainModule.controller('budgetListCtrl', function ($scope, $http, $mdToast) {
        $scope.budgetHeader = "Liste des budgets";
        $scope.paginatorCallback = paginatorCallback;

        function paginatorCallback(page, pageSize) {
            var offset = (page - 1) * pageSize;

            return $http.get('http://localhost:18028/api/BudgetService', {
                'appId': 'a03ba45f',
                'appKey': 'b4c78c1472425c13f9ce0e5e45aa1e16',
                'offset': offset,
                'limit': pageSize,
                'query': '*',
                'fields': ['*'],
                'sort': {
                    'field': 'Id',
                    'order': 'desc'
                }
            }).then(function (result) {
                return {
                    results: result.data,
                    totalResultCount: result.data.length
                }
            });
        }

    });
}());