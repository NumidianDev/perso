﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');
    mainModule.controller('budgetListCtrl', function ($scope,$timeout, $http, $mdToast) {
        $scope.budgetHeader = "Liste des budgets";
        
        $scope.selected = [];

        $scope.query = {
            order: 'Exercice',
            limit: 5,
            page: 1
        };

        $scope.budgets = [];

        function success(budgets) {
            $scope.budgets = budgets;
        }

        $scope.promise = $timeout(function () {

        }, 2000);

        $scope.getBudgets = function () {
            $http.get('http://localhost:18028/api/BudgetService').then(function (result) {
                $scope.budgets = result;
            });
        };
    });
}());