﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');
    mainModule.factory('budgetService', function ($rootScope, $http, $q, $location, viewModelHelper) { return SgaApp.budgetService($rootScope, $http, $q, $location, viewModelHelper); });

    mainModule.controller('budgetListCtrl', function ($scope,budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {
        $scope.budgetHeader = "Liste des budgets";
        $scope.budgetService = budgetService;
        $scope.viewModelHelper = viewModelHelper;
        $scope.bottom = true;

        $scope.selected = [];
        var deferred = $q.defer();

        $scope.query = {
            order: 'Exercice',
            limit: 5,
            page: 1
        };

        $scope.budgets = [];

        var initialize = function () {
            $scope.refreshBudgets();
        }

        //var loading = function(){
        //    $timeout(function () {

        //    }, 3000);
        //};

        $scope.refreshBudgets = function () {
            
            $scope.promise = deferred.promise;
            return viewModelHelper.apiGet('api/BudgetService', $scope.query, success);
        }

        function success(budgets) {
            $scope.budgets = budgets;
            deferred.resolve();
        }

        initialize();

    });
}());

(function (SgaApp) {
    var budgetService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.budgetId = 0;

        return this;
    };
    SgaApp.budgetService = budgetService;
}(window.SgaApp));
