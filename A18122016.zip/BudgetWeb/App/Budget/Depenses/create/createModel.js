﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('depenseCreateCtrl', function ($scope, budgetService, depenseService, $http, $q, $window, $location, $mdToast, $mdDialog, $timeout, viewModelHelper) {

        $scope.currentBudgetItem = null;
        $scope.bottom = false;
        $scope.hideFAB = $scope.currentBudgetItem == null;
        $scope.isOpen = false;
        $scope.createTarget = null;
        
        var parent = $scope;
        
        $scope.createItems = [
        { name: "Facture",type:1, icon: "img/icons/twitter.svg", direction: "bottom" },
        { name: "BDC", type: 2, icon: "img/icons/facebook.svg", direction: "top" },
        { name: "Contrat", type: 3, icon: "img/icons/hangout.svg", direction: "bottom" }
        ];

        var initialize = function () {
            budgetService.onInvestSelected.push(function () {
                selectHandler(budgetService.selectedInvest);
            });
            budgetService.onFraisSelected.push(function () {
                selectHandler(budgetService.selectedFrais);
            });
        }

        var selectHandler = function (budgetItem) {
            $scope.currentBudgetItem = budgetItem //budgetService.selectedInvest;
            $scope.hideFAB = $scope.currentBudgetItem == null;
        }

        $scope.showTabDialog = function (ev, item) {
            $scope.createTarget = item;
            $mdDialog.show({
                controller: DialogController,
                controllerAs: 'ctrl',
                templateUrl: '../App/Budget/Depenses/create/depenseCreateDialog.tmpl.html',
                parent: angular.element(document.body),
                targetEvent: ev,
                clickOutsideToClose: false,
                fullscreen:true
            })
                .then(function (answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function () {
                    $scope.status = 'You cancelled the dialog.';
                });
        };

        function DialogController($scope, $mdDialog) {

            $scope.selectedItem = parent.currentBudgetItem;
            $scope.typeDepense = parent.createTarget;
            $scope.fournisseurs = null;

            //$scope.depense = {
            //    Numero: 0,
            //    DateEmission: new Date()
            //}

            $scope.hide = function () {
                $mdDialog.hide();
            };

            $scope.cancel = function () {
                $mdDialog.cancel();
            };

            $scope.answer = function (answer) {
                $mdDialog.hide(answer);
            };

            $scope.loadFournisseurs = function () {
                  
            }
        }

        initialize();

    });
}());
