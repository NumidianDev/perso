﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('depenseCreateCtrl', function ($scope, budgetService, depenseService, $http, $q, $window, $location, $mdToast, $mdDialog,$mdEditDialog, $timeout, viewModelHelper) {

        $scope.currentBudgetItem = budgetService.selectedBudgetElement;
        $scope.bottom = false;
        $scope.hideFAB = $scope.currentBudgetItem == null;
        $scope.isOpen = false;
        $scope.createTarget = budgetService.createDepenseType;
        $scope.FITabLabel = ($scope.currentBudgetItem && $scope.currentBudgetItem.Nom) ? "Maintenance & Installation" : "Frais Informatique";

        $scope.createItems = [
        { name: "Facture",type:1, icon: "img/icons/twitter.svg", direction: "bottom" },
        { name: "BDC", type: 2, icon: "img/icons/facebook.svg", direction: "top" },
        { name: "Contrat", type: 3, icon: "img/icons/hangout.svg", direction: "bottom" }
        ];

        $scope.fournisseurs = null;
        $scope.devises = null;
        $scope.taxes = null;
        $scope.engagements = null;

        var fournisseurDeferred = null;
        var deviseDeferred = null;
        var taxeDeferred = null;
        var engagementDeferred = null;

        $scope.depense = {
            Id: 0,
            Numero:null,
            Avenant:null,
            TypeId: null,
            DateDebut: null,
            DateFin: null,
            DateCreation: null,
            DateEmission: null,
            DateEnvoieCF: null,
            DateReceptionCible: null,
            DeviseId: null,
            Taux: null,
            ElementBudgetId:null,
            EngagementId: null,
            FournisseurId: null,
            Montant: 0,
            Remise: 0,
            RS:0,
            TVA:0,
            TTC: 0,
            Materiels: [],
            Logiciels: [],
            FraisInformatiques: [],
            FraisTelecoms: [],
            FG_Invests: []
        };


        budgetService.fournisseurSuccess = function success(fournisseurs) {
            $scope.fournisseurs = fournisseurs.data.pagedFournisseurs;
            fournisseurDeferred.resolve();
        }

        budgetService.deviseSuccess = function success(devises) {
            $scope.devises = devises.data.pagedDevises;
            deviseDeferred.resolve();
        }

        budgetService.taxeSuccess = function success(taxes) {
            $scope.taxes = taxes.data.pagedTaxes;
            taxeDeferred.resolve();
        }

        budgetService.engagementSuccess = function success(engagements) {
            $scope.engagements = engagements.data.pagedEngagements;
            engagementDeferred.resolve();
        }

        $scope.loadFournisseurs = function () {
            fournisseurDeferred = $q.defer();
            budgetService.getAllFournisseurs();
        }

        $scope.loadDevises = function () {
            deviseDeferred = $q.defer();
            budgetService.getAllDevises();
        }

        $scope.loadTaxes = function () {
            taxeDeferred = $q.defer();
            budgetService.getAllTaxes();
        }

        $scope.loadEngagements = function () {
            engagementDeferred = $q.defer();
            budgetService.getAllEngagements(null, $scope.currentBudgetItem.Id);
        }

        var initialize = function () {
            budgetService.onInvestSelected.push(function () {
                selectHandler(budgetService.selectedBudgetElement);
            });
            budgetService.onFraisSelected.push(function () {
                selectHandler(budgetService.selectedBudgetElement);
            });
        }

        var selectHandler = function (budgetItem) {

            $scope.currentBudgetItem = budgetItem //budgetService.selectedInvest;
            
            $scope.hideFAB = $scope.currentBudgetItem == null;
        }

        $scope.depenseAdd = function (depense) {
            depense.ElementBudgetId = $scope.currentBudgetItem.Id;
            depense.TypeId = $scope.createTarget.type;
            alert('creation');
        }

        $scope.showTabDialog = function (ev, item) {
            viewModelHelper.toggleEditDepense();
            budgetService.createDepenseType = item;

        };

        $scope.addMateriel = function () {
            $scope.depense.Materiels.push({
                Id:0,
		        DepenseId:0,
		        Designation:null,
		        Montant:0,
		        Remise:0,
		        TaxesId:null
            });
        }

        $scope.addLogiciel = function () {
            $scope.depense.Logiciels.push({
                Id: 0,
                DepenseId: null,
                Designation: null,
                Montant: 0,
                Remise: 0,
                TaxesId: null
            });
        }

        $scope.addFI = function () {
            $scope.depense.FraisInformatiques.push({
                Id:0,
		        DepenseId:null,
                PosteId:null,
                Description:null,
                Montant:0,
                Remise:0,
                TaxesId:null
            });
        }

        $scope.addFT = function () {
            $scope.depense.FraisTelecoms.push({
                Id: 0,
                DepenseId: null,
                PosteId: null,
                Description: null,
                Montant: 0,
                Remise: 0,
                TaxesId: null
            });
        }

        $scope.addFGI = function () {
            $scope.depense.FG_Invests.push({
                Id: 0,
                DepenseId: null,
                PosteId: null,
                Montant: 0,
                Remise: 0,
                TaxesId: null
            });
        }

        $scope.largeEditDialog = true;

        $scope.editDesignation = function (event, formModel) {
            event.stopPropagation(); // in case autoselect is enabled

            var editDialog = {
                modelValue: formModel.Designation,
                placeholder: 'Désignation',
                save: function (input) {
                    formModel.Designation = input.$modelValue;
                },
                targetEvent: event,
                title: 'Désignation',
                validators: {
                    'md-maxlength': 255
                }
            };

            var promise;

            if ($scope.largeEditDialog) {
                promise = $mdEditDialog.large(editDialog);
            } else {
                promise = $mdEditDialog.small(editDialog);
            }

            promise.then(function (ctrl) {
                var input = ctrl.getInput();

                input.$viewChangeListeners.push(function () {
                    input.$setValidity('test', input.$modelValue !== 'test');
                });
            });
        };

        $scope.editMontant = function (event, formModel) {
            event.stopPropagation(); // in case autoselect is enabled

            var editDialog = {
                modelValue: formModel.Montant,
                placeholder: 'Montant',
                save: function (input) {
                    formModel.Montant = input.$modelValue;
                },
                targetEvent: event,
                title: 'Montant',
                validators: {
                    'md-maxlength': 255
                }
            };

            var promise;

            if ($scope.largeEditDialog) {
                promise = $mdEditDialog.large(editDialog);
            } else {
                promise = $mdEditDialog.small(editDialog);
            }

            promise.then(function (ctrl) {
                var input = ctrl.getInput();

                input.$viewChangeListeners.push(function () {
                    input.$setValidity('test', input.$modelValue !== 0);
                });
            });
        };

        $scope.editRemise = function (event, formModel) {
            event.stopPropagation(); // in case autoselect is enabled

            var editDialog = {
                modelValue: formModel.Remise,
                placeholder: 'Remise',
                save: function (input) {
                    formModel.Remise = input.$modelValue;
                },
                targetEvent: event,
                title: 'Remise',
                validators: {
                    'md-maxlength': 255
                }
            };

            var promise;

            if ($scope.largeEditDialog) {
                promise = $mdEditDialog.large(editDialog);
            } else {
                promise = $mdEditDialog.small(editDialog);
            }

            promise.then(function (ctrl) {
                var input = ctrl.getInput();

                input.$viewChangeListeners.push(function () {
                    input.$setValidity('test', input.$modelValue !== 0);
                });
            });
        };

        initialize();

    });
}());
