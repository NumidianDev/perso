﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('depenseCreateCtrl', function ($scope, budgetService,depenseService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentInvest = null;
        $scope.bottom = false;
        $scope.hideFAB = $scope.currentInvest == null;
        $scope.isOpen = false;
        
        $scope.createItems = [
        { name: "Facture", icon: "img/icons/twitter.svg", direction: "bottom" },
        { name: "BDC", icon: "img/icons/facebook.svg", direction: "top" },
        { name: "Contrat", icon: "img/icons/hangout.svg", direction: "bottom" }
        ];

        var initialize = function () {
            budgetService.onInvestSelected.push(function () {
                $scope.currentInvest = budgetService.selectedInvest;
                $scope.hideFAB = $scope.currentInvest == null;
            });
        }

        initialize();

    });
}());
