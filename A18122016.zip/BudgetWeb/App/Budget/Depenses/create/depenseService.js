﻿(function (SgaApp) {
    var depenseService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.AllQuery = {
            order: '',
            limit: 0,
            page: 1
        };

        self.depenseAddSuccess = function (depense) {
            alert('created');
        }

        self.FISuccess = null;

        self.FTSuccess = null;

        self.PostDepense = function (depenseObj) {
            return viewModelHelper.apiPost('Depenses/Add', depenseObj, self.depenseAddSuccess);
        }

        self.getFraisInformatiquesPostes = function (query,currentbudget) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Depenses/FraisInformatiques/' + currentbudget.Id, { budget: currentbudget, params: query }, self.FISuccess);
        }

        self.getFraisTelecomPostes = function (query, currentbudget) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Depenses/FraisTelecom/' + currentbudget.Id, { budget: currentbudget, params: query }, self.FTSuccess);
        }

        return this;
    };

    SgaApp.depenseService = depenseService;

}(window.SgaApp));

