﻿(function (SgaApp) {
    var depenseService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        return this;
    };

    SgaApp.depenseService = depenseService;

}(window.SgaApp));

