﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.factory('depenseService', function ($rootScope, $http, $q, $location, viewModelHelper) {
        return SgaApp.depenseService($rootScope, $http, $q, $location, viewModelHelper);
    });

}());
