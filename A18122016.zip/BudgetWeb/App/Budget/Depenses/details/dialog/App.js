﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.factory('depenseDetailsService', function ($rootScope, $http, $q, $location, viewModelHelper) {
        return SgaApp.depenseDetailsService($rootScope, $http, $q, $location, viewModelHelper);
    });

}());
