﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('depenseDetailDialogCtrl', function ($scope, budgetService, depenseDetailsService, $http, $q, $window, $location, $mdToast, $timeout, $mdDialog, viewModelHelper) {
        
        $scope.selectedItem = null;

        var parent = $scope;

        $scope.showTabDialog = function (ev) {
            $mdDialog.show({
                controller: DialogController,
                controllerAs: 'ctrl',
                templateUrl: '../App/Budget/Depenses/details/dialog/depenseDialog.tmpl.html',
                parent: angular.element(document.body),
                targetEvent: ev,
                clickOutsideToClose: true
            })
                .then(function (answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function () {
                    $scope.status = 'You cancelled the dialog.';
                });
        };

        function DialogController($scope, $mdDialog) {

            $scope.selectedItem = parent.selectedItem;

            $scope.hide = function () {
                $mdDialog.hide();
            };

            $scope.cancel = function () {
                $mdDialog.cancel();
            };

            $scope.answer = function (answer) {
                $mdDialog.hide(answer);
            };
        }

        var initialize = function () {
            depenseDetailsService.onDepenseSelected.push(function () {
                $scope.selectedItem = depenseDetailsService.selectedDepense;
                $scope.showTabDialog();
            });
        }

        initialize();

    });
}());
