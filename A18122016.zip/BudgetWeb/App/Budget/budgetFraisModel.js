﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('budgetFraisListCtrl', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.tableHeader = "";
        $scope.budgetService = budgetService;
        $scope.viewModelHelper = viewModelHelper;
        $scope.bottom = false;

        $scope.selected = [];

        var deferred = null;

        $scope.fraisCollection = [];

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total:0
        };

        budgetService.onBudgetSelected.push(function () {
            $scope.tableHeader = "Frais généraux de l'exercice " + budgetService.selectedBudget.Exercice
            $scope.refreshFrais(true);
        })

        budgetService.fraisSuccess = function success(frais) {
            $scope.fraisCollection = frais.data.pagedFrais;
            $scope.query = frais.data.sortParam;
            deferred.resolve();
        }

        var initialize = function () {
            $scope.refreshFrais();
        }

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            budgetService.selectedFrais = item;
            budgetService.selectedBudgetElement = item;
            if (budgetService.onFraisSelected.length > 0) {
                angular.forEach(budgetService.onFraisSelected, function (handler) {
                    handler();
                });
            }
        }

        $scope.refreshFrais = function (force) {
            if (budgetService.selectedBudget && (force || $scope.fraisCollection.length == 0)) {
                deferred = $q.defer();
                $scope.promiseFrais = deferred.promise;
                budgetService.getFraisByBudget($scope.query);
            }
        }

        initialize();
    });
}());
