﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('budgetFraisListCtrl', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.budgetService = budgetService;
        $scope.viewModelHelper = viewModelHelper;
        $scope.bottom = false;

        $scope.selected = [];

        var deferred = null;

        $scope.fraisCollection = [];

        $scope.query = budgetService.query;

        budgetService.onBudgetSelected.push(function () {
            $scope.refreshFrais();
        })

        budgetService.fraisSuccess = function success(frais) {
            $scope.fraisCollection = frais;
            deferred.resolve();
        }

        var initialize = function () {
            $scope.refreshFrais();
        }

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            budgetService.selectedFrais = item;
        }

        $scope.refreshFrais = function () {
            if (budgetService.selectedBudget) {
                deferred = $q.defer();
                $scope.promise = deferred.promise;
                budgetService.getFraisByBudget();
            }
        }

        initialize();
    });
}());
