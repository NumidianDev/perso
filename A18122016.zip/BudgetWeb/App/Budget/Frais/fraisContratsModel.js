﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('fraisContratsListCtrl', function ($scope, budgetService, fraisService,depenseDetailsService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentFrais = null;

        $scope.selected = [];

        $scope.ContratsCollection = [];

        var deferred = null;

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            fraisService.selectedContrat = item;

            depenseDetailsService.selectedDepense = item;
            if (depenseDetailsService.onDepenseSelected.length > 0) {
                angular.forEach(depenseDetailsService.onDepenseSelected, function (handler) {
                    handler();
                });
            }

            if (fraisService.onContratSelected.length > 0) {
                angular.forEach(fraisService.onContratSelected, function (handler) {
                    handler();
                });
            }
        }

        fraisService.contratsSuccess = function success(contrats) {
            $scope.ContratsCollection = contrats.data.pagedContrats;
            $scope.query = contrats.data.sortParam;
            deferred.resolve();
        }

        $scope.refreshContrats = function () {
            if (fraisService.selectedFrais) {
                deferred = $q.defer();
                $scope.promiseContrat = deferred.promise;
                fraisService.getContratsByElementBudget($scope.query);
            }
        }

        var initialize = function () {
            budgetService.onFraisSelected.push(function () {
                $scope.currentFrais = budgetService.selectedFrais;
                fraisService.selectedFrais = budgetService.selectedFrais;
                $scope.refreshContrats();
            });
        }

        initialize();

    });

}());
