﻿(function (SgaApp) {
    var fraisService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.selectedFrais = null;

        self.facturesSuccess = null;

        self.bdcsSuccess = null;

        self.contratsSuccess = null;

        self.defaultQuery = {
            order: '',
            limit: 5,
            page: 1
        };

        self.getFacturesByElementBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('ElementBudget/Factures/' + self.selectedFrais.Id, { params: query }, self.facturesSuccess);
        }

        self.getBDCSByElementBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('ElementBudget/BDC/' + self.selectedFrais.Id, { params: query }, self.bdcsSuccess);
        }

        self.getContratsByElementBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('ElementBudget/Contrats/' + self.selectedFrais.Id, { params: query }, self.contratsSuccess);
        }

        return this;
    };

    SgaApp.fraisService = fraisService;

}(window.SgaApp));

