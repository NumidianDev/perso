﻿(function (SgaApp) {
    var fraisService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.success = null;

        self.fraisSuccess = null;

        self.selectedBudget = null;

        self.onBudgetSelected = [];

        self.defaultQuery = {
            order: '',
            limit: 5,
            page: 1
        };

        self.getAllBudgets = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets', { params: query }, self.success);
        }

        self.getFraisByBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets/Frais/' + self.selectedBudget.Id, { params: query }, self.fraisSuccess);
        }

        return this;
    };

    SgaApp.fraisService = fraisService;

}(window.SgaApp));

