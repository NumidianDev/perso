﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.factory('fraisService', function ($rootScope, $http, $q, $location, viewModelHelper) {
        return SgaApp.fraisService($rootScope, $http, $q, $location, viewModelHelper);
    });

}());
