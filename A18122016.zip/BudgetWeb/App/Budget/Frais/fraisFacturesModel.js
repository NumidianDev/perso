﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('fraisFacturesListCtrl', function ($scope, budgetService, fraisService, depenseDetailsService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentFrais = null;

        $scope.selected = [];

        $scope.facturesCollection = [];

        var deferred = null;

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            fraisService.selectedFacture = item;

            depenseDetailsService.selectedDepense = item;
            if (depenseDetailsService.onDepenseSelected.length > 0) {
                angular.forEach(depenseDetailsService.onDepenseSelected, function (handler) {
                    handler();
                });
            }

            if (fraisService.onFactureSelected.length > 0) {
                angular.forEach(fraisService.onFactureSelected, function (handler) {
                    handler();
                });
            }
        }

        fraisService.facturesSuccess = function success(factures) {
            $scope.facturesCollection = factures.data.pagedFactures;
            $scope.query = factures.data.sortParam;
            deferred.resolve();
        }

        $scope.refreshFactures = function () {
            if (fraisService.selectedFrais) {
                deferred = $q.defer();
                $scope.promiseFacture = deferred.promise;
                fraisService.getFacturesByElementBudget($scope.query);
            }
        }

        var initialize = function () {
            budgetService.onFraisSelected.push(function () {
                $scope.currentFrais = budgetService.selectedFrais;
                fraisService.selectedFrais = budgetService.selectedFrais;
                $scope.refreshFactures();
            });
        }

        initialize();

    });

}());
