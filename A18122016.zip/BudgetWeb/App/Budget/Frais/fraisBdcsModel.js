﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('fraisBDCSListCtrl', function ($scope, budgetService, fraisService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentFrais = null;

        $scope.BDCSCollection = [];

        var deferred = null;

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        fraisService.bdcsSuccess = function success(bdcs) {
            $scope.BDCSCollection = bdcs.data.pagedBDCS;
            $scope.query = bdcs.data.sortParam;
            deferred.resolve();
        }

        $scope.refreshBDCS = function () {
            if (fraisService.selectedFrais) {
                deferred = $q.defer();
                $scope.promiseBdc = deferred.promise;
                fraisService.getBDCSByElementBudget($scope.query);
            }
        }

        var initialize = function () {
            budgetService.onFraisSelected.push(function () {
                $scope.currentFrais = budgetService.selectedFrais;
                fraisService.selectedFrais = budgetService.selectedFrais;
                $scope.refreshBDCS();
            });
        }

        initialize();

    });

}());
