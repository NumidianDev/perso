﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('investissementsHeaderModel', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentBudget = budgetService.selectedBudget;
        $scope.viewModelHelper = viewModelHelper;

        budgetService.onBudgetSelected.push(function () {
            $scope.currentBudget = budgetService.selectedBudget;
        })

        $scope.selected = [];

    });
}());
