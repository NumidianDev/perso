﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('investBDCSListCtrl', function ($scope, budgetService, investissementsService, depenseDetailsService, $http, $q, $window, $location, $mdToast, $timeout, $mdDialog, viewModelHelper) {

        $scope.currentInvest = null;

        $scope.selected = [];

        $scope.BDCSCollection = [];

        var deferred = null;

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            investissementsService.selectedBDC = item;

            depenseDetailsService.selectedDepense = item;
            if (depenseDetailsService.onDepenseSelected.length > 0) {
                angular.forEach(depenseDetailsService.onDepenseSelected, function (handler) {
                    handler();
                });
            }

            if (investissementsService.onBDCSelected.length > 0) {
                angular.forEach(investissementsService.onBDCSelected, function (handler) {
                    handler();
                });
            }

            

        }

        investissementsService.bdcsSuccess = function success(bdcs) {
            $scope.BDCSCollection = bdcs.data.pagedBDCS;
            $scope.query = bdcs.data.sortParam;
            deferred.resolve();
        }

        $scope.refreshBDCS = function () {
            if (investissementsService.selectedInvest) {
                deferred = $q.defer();
                $scope.promiseBdc = deferred.promise;
                investissementsService.getBDCSByElementBudget($scope.query);
            }
        }

        var initialize = function () {

            budgetService.onInvestSelected.push(function () {
                $scope.currentInvest = budgetService.selectedInvest;
                investissementsService.selectedInvest = budgetService.selectedInvest;
                $scope.refreshBDCS();
            });


        }

        initialize();

    });

}());
