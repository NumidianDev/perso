﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('investBDCSListCtrl', function ($scope, budgetService, investissementsService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentInvest = null;

        $scope.BDCSCollection = [];

        var deferred = null;

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        investissementsService.bdcsSuccess = function success(bdcs) {
            $scope.BDCSCollection = bdcs.data.pagedBDCS;
            $scope.query = bdcs.data.sortParam;
            deferred.resolve();
        }

        $scope.refreshBDCS = function () {
            if (investissementsService.selectedInvest) {
                deferred = $q.defer();
                $scope.promiseBdc = deferred.promise;
                investissementsService.getBDCSByElementBudget($scope.query);
            }
        }

        var initialize = function () {

            budgetService.onInvestSelected.push(function () {
                $scope.currentInvest = budgetService.selectedInvest;
                investissementsService.selectedInvest = budgetService.selectedInvest;
                $scope.refreshBDCS();
            });


        }

        initialize();

    });

}());
