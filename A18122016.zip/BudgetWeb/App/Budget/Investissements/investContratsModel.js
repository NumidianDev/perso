﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('investContratsListCtrl', function ($scope, budgetService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentInvest = null;

        var initialize = function () {

            budgetService.onInvestSelected.push(function () {
                $scope.currentInvest = budgetService.selectedInvest;
            });

        }

        initialize();

    });

}());
