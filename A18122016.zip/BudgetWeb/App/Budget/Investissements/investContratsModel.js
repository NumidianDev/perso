﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('investContratsListCtrl', function ($scope, budgetService, investissementsService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentInvest = null;

        $scope.selected = [];

        $scope.ContratsCollection = [];

        var deferred = null;

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            investissementsService.selectedContrat = item;
            if (investissementsService.onContratSelected.length > 0) {
                angular.forEach(investissementsService.onContratSelected, function (handler) {
                    handler();
                });
            }
        }

        investissementsService.contratsSuccess = function success(contrats) {
            $scope.ContratsCollection = contrats.data.pagedContrats;
            $scope.query = contrats.data.sortParam;
            deferred.resolve();
        }

        $scope.refreshContrats = function () {
            if (investissementsService.selectedInvest) {
                deferred = $q.defer();
                $scope.promiseContrat = deferred.promise;
                investissementsService.getContratsByElementBudget($scope.query);
            }
        }

        var initialize = function () {

            budgetService.onInvestSelected.push(function () {
                $scope.currentInvest = budgetService.selectedInvest;
                investissementsService.selectedInvest = budgetService.selectedInvest;
                $scope.refreshContrats();
            });


        }

        initialize();

    });

}());
