﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('investFacturesListCtrl', function ($scope, budgetService, investissementsService,depenseDetailsService, $http, $q, $window, $location, $mdToast, $timeout, viewModelHelper) {

        $scope.currentInvest = null;

        $scope.selected = [];

        $scope.facturesCollection = [];

        var deferred = null;

        $scope.query = {
            order: '',
            limit: 5,
            page: 1,
            total: 0
        };

        $scope.selectItem = function (item) {
            $scope.selected = [];
            $scope.selected.push(item);
            investissementsService.selectedFacture = item;
            depenseDetailsService.selectedDepense = item;
            if (depenseDetailsService.onDepenseSelected.length > 0) {
                angular.forEach(depenseDetailsService.onDepenseSelected, function (handler) {
                    handler();
                });
            }
            if (investissementsService.onFactureSelected.length > 0) {
                angular.forEach(investissementsService.onFactureSelected, function (handler) {
                    handler();
                });
            }
        }

        investissementsService.facturesSuccess = function success(factures) {
            $scope.facturesCollection = factures.data.pagedFactures;
            $scope.query = factures.data.sortParam;
            deferred.resolve();
        }

        $scope.refreshFactures = function () {
            if (investissementsService.selectedInvest) {
                deferred = $q.defer();
                $scope.promiseFacture = deferred.promise;
                investissementsService.getFacturesByElementBudget($scope.query);
            }
        }

        var initialize = function () {

            budgetService.onInvestSelected.push(function () {
                $scope.currentInvest = budgetService.selectedInvest;
                investissementsService.selectedInvest = budgetService.selectedInvest;
                $scope.refreshFactures();
            });

            
        }

        initialize();

    });

}());
