﻿(function (SgaApp) {
    var investissementsService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.selectedInvest = null;

        self.bdcsSuccess = null;

        self.facturesSuccess = null;
        
        self.contratsSuccess = null;

        self.defaultQuery = {
            order: '',
            limit: 5,
            page: 1
        };

        self.getFacturesByElementBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('ElementBudget/Factures/' + self.selectedInvest.Id, { params: query }, self.facturesSuccess);
        }

        self.getBDCSByElementBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('ElementBudget/BDC/' + self.selectedInvest.Id, { params: query }, self.bdcsSuccess);
        }

        self.getContratsByElementBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('ElementBudget/Contrats/' + self.selectedInvest.Id, { params: query }, self.contratsSuccess);
        }

        return this;
    };

    SgaApp.investissementsService = investissementsService;

}(window.SgaApp));

