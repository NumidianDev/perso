﻿(function (SgaApp) {
    var budgetService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;
        
        self.selectedBudget = null;

        self.success = null;

        self.fraisSuccess = null;

        self.onBudgetSelected = [];

        self.query = {
            order: 'Exercice',
            limit: 5,
            page: 1
        };

        self.getAllBudgets = function () {
            return viewModelHelper.apiGet('api/BudgetService', { params: self.query }, self.success);
        }

        self.getFraisByBudget = function () {
            return viewModelHelper.apiGet('api/GetFraisByBudgets/' + self.selectedBudget.Id, { params: self.query }, self.success);
        }

        return this;
    };

    SgaApp.budgetService = budgetService;

}(window.SgaApp));

