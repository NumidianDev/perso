﻿(function (SgaApp) {
    var budgetService = function ($rootScope, $http, $q, $location,  viewModelHelper) {

        var self = this;
        
        self.selectedBudget = null;

        self.success = null;

        self.fraisSuccess = null;

        self.investSuccess = null;

        self.fournisseurSuccess = null;

        self.deviseSuccess = null;

        self.taxeSuccess = null;

        self.engagementSuccess = null;

        self.createDepenseType = null;

        self.onBudgetSelected = [];

        self.onInvestSelected = [];

        self.onFraisSelected = [];

        self.defaultQuery = {
            order: '',
            limit: 5,
            page: 1
        };

        self.AllQuery = {
            order: '',
            limit: 0,
            page: 1
        };

        self.getAllBudgets = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets', { params: query }, self.success);
        }

        self.getFraisByBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets/Frais/' + self.selectedBudget.Id, { params: query }, self.fraisSuccess);
        }

        self.getInvestByBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets/Investissements/' + self.selectedBudget.Id, { params: query }, self.investSuccess);
        }

        self.getAllFournisseurs = function (query) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Fournisseurs' , { params: query }, self.fournisseurSuccess);
        }

        self.getAllDevises = function (query) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Devises', { params: query }, self.deviseSuccess);
        }

        self.getAllTaxes = function (query) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Taxes', { params: query }, self.taxeSuccess);
        }

        self.getAllEngagements = function (query, elementBudgetId) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Engagements/' + elementBudgetId, { params: query }, self.engagementSuccess);
        }

        return this;
    };

    SgaApp.budgetService = budgetService;

}(window.SgaApp));

