﻿(function (SgaApp) {
    var budgetService = function ($rootScope, $http, $q, $location,  viewModelHelper) {

        var self = this;

        self.currentUser = {Id:1, Matricule:2171, Nom:"Amazigh Goudjil"};
        self.currentDirection = null;

        self.selectedBudget = null;

        self.success = null;

        self.DirectionSuccess = null;

        self.PrioritySuccess = null;

        self.fraisSuccess = null;

        self.investSuccess = null;

        self.fournisseurSuccess = null;

        self.deviseSuccess = null;

        self.taxeSuccess = null;

        self.engagementSuccess = null;

        self.budgetAddSuccess = null;

        self.createDepenseType = null;

        self.onBudgetSelected = [];

        self.onInvestSelected = [];

        self.onFraisSelected = [];

        self.defaultQuery = {
            order: '',
            limit: 5,
            page: 1
        };

        self.AllQuery = {
            order: '',
            limit: 0,
            page: 1
        };


        self.getAllBudgets = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets', { params: query }, self.success);
        }

        self.getFraisByBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets/Frais/' + self.selectedBudget.Id, { params: query }, self.fraisSuccess);
        }

        self.getInvestByBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets/Investissements/' + self.selectedBudget.Id, { params: query }, self.investSuccess);
        }

        self.getAllFournisseurs = function (query) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Fournisseurs' , { params: query }, self.fournisseurSuccess);
        }

        self.getAllDevises = function (query) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Devises', { params: query }, self.deviseSuccess);
        }

        self.getAllTaxes = function (query) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Taxes', { params: query }, self.taxeSuccess);
        }

        self.getAllEngagements = function (query, elementBudgetId) {
            query = (query != null) ? query : self.AllQuery;
            return viewModelHelper.apiGet('Engagements/' + elementBudgetId, { params: query }, self.engagementSuccess);
        }

        self.GetCurrentDirection = function () {
            return viewModelHelper.apiGet('Directions/' + self.currentUser.Id, null, self.DirectionSuccess);
        }

        self.GetPostesByStructure = function () {
            return viewModelHelper.apiGet('Postes/' + self.currentDirection.Id, null, self.PostesSuccess);
        }

        self.GetInvestPriority = function () {
            return viewModelHelper.apiGet('Priorities', null, self.PrioritySuccess);
        }

        self.PostBudget = function (newBudgetVM) {
            return viewModelHelper.apiPost('Budgets/Add', newBudgetVM, self.budgetAddSuccess);
        }

        return this;
    };

    SgaApp.budgetService = budgetService;

}(window.SgaApp));

