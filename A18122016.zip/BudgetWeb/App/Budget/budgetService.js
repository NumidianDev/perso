﻿(function (SgaApp) {
    var budgetService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;
        
        self.selectedBudget = null;

        self.success = null;

        self.fraisSuccess = null;

        self.investSuccess = null;

        self.onBudgetSelected = [];

        self.defaultQuery = {
            order: '',
            limit: 5,
            page: 1
        };

        self.getAllBudgets = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets', { params: query }, self.success);
        }

        self.getFraisByBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets/Frais/' + self.selectedBudget.Id, { params: query }, self.fraisSuccess);
        }

        self.getInvestByBudget = function (query) {
            query = (query != null) ? query : self.defaultQuery;
            return viewModelHelper.apiGet('Budgets/Investissements/' + self.selectedBudget.Id, { params: query }, self.investSuccess);
        }

        return this;
    };

    SgaApp.budgetService = budgetService;

}(window.SgaApp));

