﻿(function (SgaApp) {
    var loginService = function ($rootScope, $http, $q, $location, viewModelHelper) {

        var self = this;

        self.currentUser = { Id: 1, Matricule: 2171, Nom: "Amazigh Goudjil" };
        
        self.defaultQuery = {
            order: '',
            limit: 5,
            page: 1
        };

        self.AllQuery = {
            order: '',
            limit: 0,
            page: 1
        };

        return this;
    };

    SgaApp.loginService = loginService;

}(window.SgaApp));

