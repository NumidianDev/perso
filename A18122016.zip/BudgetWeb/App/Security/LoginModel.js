﻿(function () {
    'use strict';

    var mainModule = angular.module('mainApp');

    mainModule.controller('loginCtrl', function ($scope, loginService, $filter, $http, $q, $window, $location, $mdToast, $mdDialog, $mdEditDialog, $timeout, viewModelHelper) {

        $scope.Title = "Authentification SGA";
        $scope.userName = '';
        $scope.pwd = '';
        
        var initialize = function () {

        }

        $scope.connect = function () {
            
        }

        initialize();

    });
}());
