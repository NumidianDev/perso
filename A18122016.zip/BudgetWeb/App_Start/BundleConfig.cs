﻿using System.Web;
using System.Web.Optimization;

namespace BudgetWeb
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery/jquery.js"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap/bootstrap.js",
                      "~/Scripts/tiers/respond.js"));

            bundles.Add(new ScriptBundle("~/bundles/angular").Include(
                      "~/Scripts/angular/angular.js",
                      "~/Scripts/angular/angular-locale_fr-fr.js",
                      "~/Scripts/angular/angular-sanitize.js",
                      "~/Scripts/angular/angular-animate.js",
                      "~/Scripts/angular/angular-aria.js"));

            bundles.Add(new ScriptBundle("~/bundles/material").Include(
                      "~/Scripts/angularMaterial/angular-material.js",
                      "~/Scripts/angularMaterial/angular-material-icons.min.js"));

            //
            bundles.Add(new ScriptBundle("~/bundles/tiers").Include(
                      "~/Scripts/tiers/underscore.js",
                      "~/Scripts/tiers/lodash.js"));

            //"~/Scripts/angularMaterial/nagy/md-data-table-templates.js",
                      
            bundles.Add(new ScriptBundle("~/bundles/mdDataTable").Include(
                      "~/Scripts/angularMaterial/nagy/md-data-table.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap/bootstrap.css",
                      "~/Content/site.css",
                      "~/Content/theme/red-theme.css"));

            //,
            //          "~/Content/angular/angular-material-icons.css"
            bundles.Add(new StyleBundle("~/Content/angularMaterial").Include(
                      "~/Content/angular/angular-material.css",
                      "~/Content/angular/nagy/md-data-table.css",
                      "~/Content/Site.css"));

        }
    }
}
