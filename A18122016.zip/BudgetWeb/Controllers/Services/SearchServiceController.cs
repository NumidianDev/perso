﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using BudgetData.Models;
using BudgetWeb.Models;

namespace BudgetWeb.Controllers.Services
{
    public class SearchServiceController : ApiController
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        [ResponseType(typeof(SearchModel))]
        [Route("Search/All")]
        public IHttpActionResult PostBudget(SearchModel budget)
        {
            
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SearchResult sr = new SearchResult();

            budget.result = sr;

            if (!String.IsNullOrEmpty(budget.query)) {
                sr.factures = db.Depenses.Where(d => d.TypeId == 1 && (d.Numero.ToUpper().Contains(budget.query.ToUpper()) || 
                                                                       (!String.IsNullOrEmpty(d.Observation) && d.Observation.ToUpper().Contains(budget.query.ToUpper())))).ToArray();
                sr.bdcs = db.Depenses.Where(d => d.TypeId == 2 && (d.Numero.ToUpper().Contains(budget.query.ToUpper()) ||
                                                                  (!String.IsNullOrEmpty(d.Observation) && d.Observation.ToUpper().Contains(budget.query.ToUpper())))).ToArray();
                sr.contrats = db.Depenses.Where(d => d.TypeId == 3 && (
                                                    (d.Numero.ToUpper().Contains(budget.query.ToUpper())) ||
                                                    (!String.IsNullOrEmpty(d.Avenant) && (d.Avenant.ToUpper().Contains(budget.query.ToUpper()))) ||
                                                     (!String.IsNullOrEmpty(d.Observation) && d.Observation.ToUpper().Contains(budget.query.ToUpper()))
                                                    )).ToArray();
                sr.projets = db.ElementsBudget.OfType<Investissement>().Where(I => (I.Nom.ToUpper().Contains(budget.query.ToUpper()) ||
                                                                                   (!String.IsNullOrEmpty(I.Description) && I.Description.ToUpper().Contains(budget.query.ToUpper())) ||
                                                                                   (!String.IsNullOrEmpty(I.Objectif) && I.Objectif.ToUpper().Contains(budget.query.ToUpper())))).ToArray();

                sr.fournisseurs = db.Organisations.Where(o => o.TypeId == 1 && (o.Nom.ToUpper().Contains(budget.query.ToUpper()))).ToArray();
            }

            return Ok(budget);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}