﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using BudgetData.Models;
using BudgetWeb.Models;

namespace BudgetWeb.Controllers.Services
{
    public class DepenseServiceController : ApiController
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        [Route("ElementBudget/Factures/{id}")]
        public async Task<HttpResponseMessage> GetFacturesByElementBudget(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam) {

            ElementBudget elementBudget = await db.ElementsBudget.FindAsync(id);

            if (elementBudget == null) {
                return request.CreateResponse<Depense[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var allFacturesByElementBudgetId = db.Depenses
                            .Where(f => f.TypeId == 1 && f.ElementBudgetId == id).ToList();

            sortParam.total = allFacturesByElementBudgetId.Count();

            var pagedFactures = allFacturesByElementBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(f => f.DateCreation).ToArray();

            var result = new { pagedFactures, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("ElementBudget/BDC/{id}")]
        public async Task<HttpResponseMessage> GetBDCSByElementBudget(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam)
        {

            ElementBudget elementBudget = await db.ElementsBudget.FindAsync(id);

            if (elementBudget == null)
            {
                return request.CreateResponse<Depense[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var allBDCSByElementBudgetId = db.Depenses
                            .Where(f => f.TypeId == 2 && f.ElementBudgetId == id).ToList();

            sortParam.total = allBDCSByElementBudgetId.Count();

            var pagedBDCS = allBDCSByElementBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(f => f.DateEmission).ToArray();

            var result = new { pagedBDCS , sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("ElementBudget/Contrats/{id}")]
        public async Task<HttpResponseMessage> GetContratsByElementBudget(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam)
        {

            ElementBudget elementBudget = await db.ElementsBudget.FindAsync(id);

            if (elementBudget == null)
            {
                return request.CreateResponse<Depense[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var allContratsByElementBudgetId = db.Depenses
                            .Where(f => f.TypeId == 3 && f.ElementBudgetId == id).ToList();

            sortParam.total = allContratsByElementBudgetId.Count();

            var pagedContrats = allContratsByElementBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(f => f.DateEmission).ToArray();

            var result = new { pagedContrats, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("Engagements/{id}")]
        public async Task<HttpResponseMessage> GetEngagementssByElementBudget(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam) {

            ElementBudget elementBudget = await db.ElementsBudget.FindAsync(id);

            if (elementBudget == null) {
                return request.CreateResponse<Depense[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
                }

            var allEngagementsByElementBudgetId = db.Depenses
                            .Where(f => (f.TypeId == 3 ||f.TypeId == 2) && f.ElementBudgetId == id).ToList();


            sortParam.total = allEngagementsByElementBudgetId.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : sortParam.total;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedEngagements = allEngagementsByElementBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(f => f.DateEmission).ToArray();

            var result = new { pagedEngagements, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
            }

        [ResponseType(typeof(Depense))]
        [Route("Depenses/Add")]
        public async Task<IHttpActionResult> PostDepense(Depense depense) {
            if (!ModelState.IsValid) {
                return BadRequest(ModelState);
                }

            db.Depenses.Add(depense);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = depense.Id }, depense);
            }


        [Route("Depenses/FraisInformatiques/{id}")]
        public async Task<HttpResponseMessage> GetPostesFIByBudget(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam) {

            Budget currentBudget = await db.Budgets.FindAsync(id);

            if (currentBudget == null) {
                return request.CreateResponse<Depense[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
                }

            var allPostesFI = db.ElementsBudget.OfType<BudgetData.Models.FraisGeneraux>().Where(fg => fg.Poste.DirectionId == currentBudget.DirectionId
                                && (fg.Poste.Chapitre.StartsWith("629") || fg.Poste.Chapitre.StartsWith("626"))).ToList();
            
            sortParam.total = allPostesFI.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : sortParam.total;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedPostesFI = allPostesFI.Skip(rows * (page - 1)).Take(rows).OrderByDescending(eb => eb.Poste.Compte).ToArray();

            var result = new { pagedPostesFI, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
            }

        [Route("Depenses/FraisTelecom/{id}")]
        public async Task<HttpResponseMessage> GetPostesFTByBudget(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam) {

            Budget currentBudget = await db.Budgets.FindAsync(id);

            if (currentBudget == null) {
                return request.CreateResponse<Depense[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
                }

            var allPostesFT = db.ElementsBudget.OfType<BudgetData.Models.FraisGeneraux>().Where(fg => fg.Poste.DirectionId == currentBudget.DirectionId
                                    && (fg.Poste.Chapitre.StartsWith("628"))).ToList();

            sortParam.total = allPostesFT.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : sortParam.total;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedPostesFT = allPostesFT.Skip(rows * (page - 1)).Take(rows).OrderByDescending(eb => eb.Poste.Compte).ToArray();

            var result = new { pagedPostesFT, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
            }











        // GET api/DepenseService
        public IQueryable<Depense> GetDepenses()
        {
            return db.Depenses;
        }

        // GET api/DepenseService/5
        [ResponseType(typeof(Depense))]
        public async Task<IHttpActionResult> GetDepense(int id)
        {
            Depense depense = await db.Depenses.FindAsync(id);
            if (depense == null)
            {
                return NotFound();
            }

            return Ok(depense);
        }

        // PUT api/DepenseService/5
        public async Task<IHttpActionResult> PutDepense(int id, Depense depense)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != depense.Id)
            {
                return BadRequest();
            }

            db.Entry(depense).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DepenseExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        

        // DELETE api/DepenseService/5
        [ResponseType(typeof(Depense))]
        public async Task<IHttpActionResult> DeleteDepense(int id)
        {
            Depense depense = await db.Depenses.FindAsync(id);
            if (depense == null)
            {
                return NotFound();
            }

            db.Depenses.Remove(depense);
            await db.SaveChangesAsync();

            return Ok(depense);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool DepenseExists(int id)
        {
            return db.Depenses.Count(e => e.Id == id) > 0;
        }
    }
}