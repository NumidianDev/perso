﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using BudgetData.Models;
using System.Threading;
using BudgetWeb.Models;
using System.Reflection;

namespace BudgetWeb.Controllers.Services
{
    public class BudgetServiceController : ApiController
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        // GET api/BudgetService
        [Route("Budgets")]
        public HttpResponseMessage GetBudgets(HttpRequestMessage request,[FromUri] SortAndOrderParam sortParam)
        {
            var allBudgets = db.Budgets.ToList(); 
            sortParam.total = allBudgets.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedBudgets = allBudgets.Skip(rows * (page - 1)).Take(rows).OrderByDescending(b => b.Exercice).ToArray();

            var result = new { pagedBudgets, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        // GET api/BudgetService
        [Route("Fournisseurs")]
        public HttpResponseMessage GetFournisseurs(HttpRequestMessage request, [FromUri] SortAndOrderParam sortParam) {
            var allFournisseurs = db.Organisations.Where(o => o.TypeId == 1).ToList();
            sortParam.total = allFournisseurs.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : sortParam.total;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedFournisseurs = allFournisseurs.Skip(rows * (page - 1)).Take(rows).ToArray();

            var result = new { pagedFournisseurs, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("Devises")]
        public HttpResponseMessage GetDevises(HttpRequestMessage request, [FromUri] SortAndOrderParam sortParam) {

            var allDevises = db.Devises.ToList();
            sortParam.total = allDevises.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : sortParam.total;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedDevises = allDevises.Skip(rows * (page - 1)).Take(rows).ToArray();

            var result = new { pagedDevises, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("Taxes")]
        public HttpResponseMessage GetTaxes(HttpRequestMessage request, [FromUri] SortAndOrderParam sortParam) {
            var allTaxes = db.Taxes.ToList();
            sortParam.total = allTaxes.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : sortParam.total;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedTaxes = allTaxes.Skip(rows * (page - 1)).Take(rows).ToArray();

            var result = new { pagedTaxes, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("Budgets/Frais/{id}")]
        public async Task<HttpResponseMessage> GetFraisByBudgets(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return request.CreateResponse<FraisGeneraux[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;
                      
            var allFraisByBudgetId = db.ElementsBudget.OfType<FraisGeneraux>()
                            .Where(el => el.Budget.Id == id ).ToList();

            sortParam.total = allFraisByBudgetId.Count();

            var pagedFrais = allFraisByBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(fg => fg.Budget.Exercice).ToArray();

            var result = new {pagedFrais , sortParam};

            return  request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("Budgets/Investissements/{id}")]
        public async Task<HttpResponseMessage> GetInvestByBudgets(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return request.CreateResponse<Investissement[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var allInvestByBudgetId = db.ElementsBudget.OfType<Investissement>()
                            .Where(el => el.Budget.Id == id).ToList();

            var pagedInvest = allInvestByBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(fg => fg.Budget.Exercice).ToArray();

            sortParam.total = allInvestByBudgetId.Count();

            var result = new { pagedInvest, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);

        }

        [Route("Directions/{id}")]
        public async Task<HttpResponseMessage> GetFraisByBudgets(HttpRequestMessage request, int id) {

            /* Récuperer la direction de l'utilisateur */

            Organisation direction = await db.Organisations.FindAsync(1);

            return request.CreateResponse<Organisation>(HttpStatusCode.OK, direction, Configuration.Formatters.JsonFormatter);
        }

        [Route("Postes/{id}")]
        public async Task<HttpResponseMessage> GetPostesByStructure(HttpRequestMessage request, int id) {

            /* Récuperer la direction de l'utilisateur */

            Organisation direction = await db.Organisations.FindAsync(1);

            if (direction == null) {
                return request.CreateResponse<Poste[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            Poste[] directionPostes = await db.Postes.Where(p => p.DirectionId == direction.Id).ToArrayAsync();

            return request.CreateResponse<Poste[]>(HttpStatusCode.OK, directionPostes, Configuration.Formatters.JsonFormatter);

        }

        


        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> GetBudget(int id)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return NotFound();
            }

            return Ok(budget);
        }

        // PUT api/BudgetService/5
        public async Task<IHttpActionResult> PutBudget(int id, Budget budget)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != budget.Id)
            {
                return BadRequest();
            }

            db.Entry(budget).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BudgetExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/BudgetService
        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> PostBudget(Budget budget)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Budgets.Add(budget);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = budget.Id }, budget);
        }

        // DELETE api/BudgetService/5
        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> DeleteBudget(int id)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return NotFound();
            }

            db.Budgets.Remove(budget);
            await db.SaveChangesAsync();

            return Ok(budget);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool BudgetExists(int id)
        {
            return db.Budgets.Count(e => e.Id == id) > 0;
        }
    }
}