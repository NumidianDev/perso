﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using BudgetData.Models;

namespace BudgetWeb.Controllers.Services
{
    public class BudgetServiceController : ApiController
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        // GET api/BudgetService
        public HttpResponseMessage GetBudgets(HttpRequestMessage request)
        {
            var bgs = db.Budgets;
            return request.CreateResponse<Budget[]>(HttpStatusCode.OK, bgs.ToArray(), Configuration.Formatters.JsonFormatter);
        }

        // GET api/BudgetService/5
        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> GetBudget(int id)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return NotFound();
            }

            return Ok(budget);
        }

        // PUT api/BudgetService/5
        public async Task<IHttpActionResult> PutBudget(int id, Budget budget)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != budget.Id)
            {
                return BadRequest();
            }

            db.Entry(budget).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BudgetExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/BudgetService
        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> PostBudget(Budget budget)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Budgets.Add(budget);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = budget.Id }, budget);
        }

        // DELETE api/BudgetService/5
        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> DeleteBudget(int id)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return NotFound();
            }

            db.Budgets.Remove(budget);
            await db.SaveChangesAsync();

            return Ok(budget);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool BudgetExists(int id)
        {
            return db.Budgets.Count(e => e.Id == id) > 0;
        }
    }
}