﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using BudgetData.Models;
using System.Threading;
using BudgetWeb.Models;
using System.Reflection;

namespace BudgetWeb.Controllers.Services
{
    public class BudgetServiceController : ApiController
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        // GET api/BudgetService
        [Route("Budgets")]
        public HttpResponseMessage GetBudgets(HttpRequestMessage request,[FromUri] SortAndOrderParam sortParam)
        {
            var allBudgets = db.Budgets.ToList(); 
            sortParam.total = allBudgets.Count();

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var pagedBudgets = allBudgets.Skip(rows * (page - 1)).Take(rows).OrderByDescending(b => b.Exercice).ToArray();

            var result = new { pagedBudgets, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("Budgets/Frais/{id}")]
        public async Task<HttpResponseMessage> GetFraisByBudgets(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return request.CreateResponse<FraisGeneraux[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;
                      
            var allFraisByBudgetId = db.ElementsBudget.OfType<FraisGeneraux>()
                            .Where(el => el.Budget.Id == id ).ToList();

            sortParam.total = allFraisByBudgetId.Count();

            var pagedFrais = allFraisByBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(fg => fg.Budget.Exercice).ToArray();

            var result = new {pagedFrais , sortParam};

            return  request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);
        }

        [Route("Budgets/Investissements/{id}")]
        public async Task<HttpResponseMessage> GetInvestByBudgets(HttpRequestMessage request, int id, [FromUri] SortAndOrderParam sortParam)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return request.CreateResponse<Investissement[]>(HttpStatusCode.BadRequest, null, Configuration.Formatters.JsonFormatter);
            }

            int rows = (sortParam != null && sortParam.limit != 0) ? sortParam.limit : 5;
            int page = (sortParam != null && sortParam.page != 0) ? sortParam.page : 1;

            var allInvestByBudgetId = db.ElementsBudget.OfType<Investissement>()
                            .Where(el => el.Budget.Id == id).ToList();

            var pagedInvest = allInvestByBudgetId.Skip(rows * (page - 1)).Take(rows).OrderByDescending(fg => fg.Budget.Exercice).ToArray();

            sortParam.total = allInvestByBudgetId.Count();

            var result = new { pagedInvest, sortParam };

            return request.CreateResponse<Object>(HttpStatusCode.OK, result, Configuration.Formatters.JsonFormatter);

        }


        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> GetBudget(int id)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return NotFound();
            }

            return Ok(budget);
        }

        // PUT api/BudgetService/5
        public async Task<IHttpActionResult> PutBudget(int id, Budget budget)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != budget.Id)
            {
                return BadRequest();
            }

            db.Entry(budget).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BudgetExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/BudgetService
        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> PostBudget(Budget budget)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Budgets.Add(budget);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = budget.Id }, budget);
        }

        // DELETE api/BudgetService/5
        [ResponseType(typeof(Budget))]
        public async Task<IHttpActionResult> DeleteBudget(int id)
        {
            Budget budget = await db.Budgets.FindAsync(id);
            if (budget == null)
            {
                return NotFound();
            }

            db.Budgets.Remove(budget);
            await db.SaveChangesAsync();

            return Ok(budget);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool BudgetExists(int id)
        {
            return db.Budgets.Count(e => e.Id == id) > 0;
        }
    }
}