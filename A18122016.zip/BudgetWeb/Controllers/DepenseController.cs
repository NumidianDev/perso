﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BudgetData.Models;

namespace BudgetWeb.Controllers
{
    public class DepenseController : Controller
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        // GET: /Depense/
        public ActionResult Index()
        {
            var depenses = db.Depenses.Include(d => d.Devise).Include(d => d.Type).Include(d => d.ElementBudget).Include(d => d.Fournisseur).Include(d => d.Engagement);
            return View(depenses.ToList());
        }

        // GET: /Depense/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Depense depense = db.Depenses.Find(id);
            if (depense == null)
            {
                return HttpNotFound();
            }
            return View(depense);
        }

        // GET: /Depense/Create
        public ActionResult Create()
        {
            ViewBag.DeviseId = new SelectList(db.Devises, "Id", "AlphaCode");
            ViewBag.TypeId = new SelectList(db.TypeDepenses, "Id", "Libelle");
            ViewBag.ElementBudgetId = new SelectList(db.ElementsBudget, "Id", "Description");
            ViewBag.FournisseurId = new SelectList(db.Organisations, "Id", "Nom");
            ViewBag.EngagementId = new SelectList(db.Depenses, "Id", "Observation");
            return View();
        }

        // POST: /Depense/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="Id,Montant,Observation,Numero,DateEmission,DateReceptionCible,DateEnvoieCF,Execute,TVA,RS,TTC,DeviseId,TypeId,ElementBudgetId,FournisseurId,DateCreation,EngagementId,Avenant,DISPLAY,Remise,Taux,DateDebut,DateFin")] Depense depense)
        {
            if (ModelState.IsValid)
            {
                db.Depenses.Add(depense);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DeviseId = new SelectList(db.Devises, "Id", "AlphaCode", depense.DeviseId);
            ViewBag.TypeId = new SelectList(db.TypeDepenses, "Id", "Libelle", depense.TypeId);
            ViewBag.ElementBudgetId = new SelectList(db.ElementsBudget, "Id", "Description", depense.ElementBudgetId);
            ViewBag.FournisseurId = new SelectList(db.Organisations, "Id", "Nom", depense.FournisseurId);
            ViewBag.EngagementId = new SelectList(db.Depenses, "Id", "Observation", depense.EngagementId);
            return View(depense);
        }

        // GET: /Depense/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Depense depense = db.Depenses.Find(id);
            if (depense == null)
            {
                return HttpNotFound();
            }
            ViewBag.DeviseId = new SelectList(db.Devises, "Id", "AlphaCode", depense.DeviseId);
            ViewBag.TypeId = new SelectList(db.TypeDepenses, "Id", "Libelle", depense.TypeId);
            ViewBag.ElementBudgetId = new SelectList(db.ElementsBudget, "Id", "Description", depense.ElementBudgetId);
            ViewBag.FournisseurId = new SelectList(db.Organisations, "Id", "Nom", depense.FournisseurId);
            ViewBag.EngagementId = new SelectList(db.Depenses, "Id", "Observation", depense.EngagementId);
            return View(depense);
        }

        // POST: /Depense/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,Montant,Observation,Numero,DateEmission,DateReceptionCible,DateEnvoieCF,Execute,TVA,RS,TTC,DeviseId,TypeId,ElementBudgetId,FournisseurId,DateCreation,EngagementId,Avenant,DISPLAY,Remise,Taux,DateDebut,DateFin")] Depense depense)
        {
            if (ModelState.IsValid)
            {
                db.Entry(depense).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DeviseId = new SelectList(db.Devises, "Id", "AlphaCode", depense.DeviseId);
            ViewBag.TypeId = new SelectList(db.TypeDepenses, "Id", "Libelle", depense.TypeId);
            ViewBag.ElementBudgetId = new SelectList(db.ElementsBudget, "Id", "Description", depense.ElementBudgetId);
            ViewBag.FournisseurId = new SelectList(db.Organisations, "Id", "Nom", depense.FournisseurId);
            ViewBag.EngagementId = new SelectList(db.Depenses, "Id", "Observation", depense.EngagementId);
            return View(depense);
        }

        // GET: /Depense/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Depense depense = db.Depenses.Find(id);
            if (depense == null)
            {
                return HttpNotFound();
            }
            return View(depense);
        }

        // POST: /Depense/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Depense depense = db.Depenses.Find(id);
            db.Depenses.Remove(depense);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
