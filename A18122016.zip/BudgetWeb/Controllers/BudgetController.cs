﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BudgetData.Models;

namespace BudgetWeb.Controllers
{
    public class BudgetController : Controller
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        // GET: /Budget/
        public ActionResult Index()
        {
            var budgets = db.Budgets.Include(b => b.Direction);
            return View(budgets.ToList());
        }

        public ActionResult Create() {
            return View();    
        }
        public ActionResult Frais()
        {
            return View();
        }

        public ActionResult Investissements() {
            return View();
        }
        
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
