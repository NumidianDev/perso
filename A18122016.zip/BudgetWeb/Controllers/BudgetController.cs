﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BudgetData.Models;

namespace BudgetWeb.Controllers
{
    public class BudgetController : Controller
    {
        private SGABUDGETENTITIES db = new SGABUDGETENTITIES();

        // GET: /Budget/
        public ActionResult Index()
        {
            var budgets = db.Budgets.Include(b => b.Direction);
            return View(budgets.ToList());
        }

        // GET: /Budget/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Budget budget = db.Budgets.Find(id);
            if (budget == null)
            {
                return HttpNotFound();
            }
            return View(budget);
        }

        // GET: /Budget/Create
        public ActionResult Create()
        {
            ViewBag.DirectionId = new SelectList(db.Organisations, "Id", "Nom");
            return View();
        }

        // POST: /Budget/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="Id,Exercice,Montant,Description,DirectionId,EInvest,Valide,DateValidation,MontantAuto,DateCreation,TotalFrais,TotalInvest,EFrais,RFrais,RInvest")] Budget budget)
        {
            if (ModelState.IsValid)
            {
                db.Budgets.Add(budget);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DirectionId = new SelectList(db.Organisations, "Id", "Nom", budget.DirectionId);
            return View(budget);
        }

        // GET: /Budget/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Budget budget = db.Budgets.Find(id);
            if (budget == null)
            {
                return HttpNotFound();
            }
            ViewBag.DirectionId = new SelectList(db.Organisations, "Id", "Nom", budget.DirectionId);
            return View(budget);
        }

        // POST: /Budget/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,Exercice,Montant,Description,DirectionId,EInvest,Valide,DateValidation,MontantAuto,DateCreation,TotalFrais,TotalInvest,EFrais,RFrais,RInvest")] Budget budget)
        {
            if (ModelState.IsValid)
            {
                db.Entry(budget).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DirectionId = new SelectList(db.Organisations, "Id", "Nom", budget.DirectionId);
            return View(budget);
        }

        // GET: /Budget/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Budget budget = db.Budgets.Find(id);
            if (budget == null)
            {
                return HttpNotFound();
            }
            return View(budget);
        }

        // POST: /Budget/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Budget budget = db.Budgets.Find(id);
            db.Budgets.Remove(budget);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
