﻿using BudgetData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BudgetWeb.Models {
    public class Budget_VM {
        public Budget budget { get; set; }
        public Investissement[] investissements { get; set; }
        public FraisGeneraux[] frais { get; set; }
    }
}