﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BudgetWeb.Models {
    public class SearchModel {
        public String query { get; set; }

        public SearchResult result { get; set; }

    }
}