﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BudgetData.Models;

namespace BudgetWeb.Models {
    public class SearchResult {

        public SearchResult() { 
            factures = new Depense[] {};
            bdcs = new Depense[] { };
            contrats = new Depense[] { };
            projets = new Investissement[] { };
            fgs = new FraisGeneraux[] { };
            fournisseurs = new Organisation[] { };
        }
        public Depense[] factures { get; set; }
        public Depense[] bdcs { get; set; }
        public Depense[] contrats { get; set; }
        public Investissement[] projets { get; set; }
        public FraisGeneraux[] fgs { get; set; }
        public Organisation[] fournisseurs { get; set; }

    }
}