﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BudgetWeb.Models
{
    public class SortAndOrderParam
    {
        public string order { get; set; }
        public int limit { get; set; }
        public int page { get; set; }

    }
}