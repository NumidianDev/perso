
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 12/03/2016 19:42:04
-- Generated from EDMX file: D:\Amazigh\Maison\BudgetData\Models\SgaBudget.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [SGABUDGET_DEBUG];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_PaysOrganisation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Organisations] DROP CONSTRAINT [FK_PaysOrganisation];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganisationTypeOrganisation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Organisations] DROP CONSTRAINT [FK_OrganisationTypeOrganisation];
GO
IF OBJECT_ID(N'[dbo].[FK_PosteOrganisation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Postes] DROP CONSTRAINT [FK_PosteOrganisation];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganisationBudget]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Budgets] DROP CONSTRAINT [FK_OrganisationBudget];
GO
IF OBJECT_ID(N'[dbo].[FK_Priorite_InvestissementInvestissement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ElementsBudget_Investissement] DROP CONSTRAINT [FK_Priorite_InvestissementInvestissement];
GO
IF OBJECT_ID(N'[dbo].[FK_InvestissementOrganisation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ElementsBudget_Investissement] DROP CONSTRAINT [FK_InvestissementOrganisation];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseDevise]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Depenses] DROP CONSTRAINT [FK_DepenseDevise];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseTypeDepense]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Depenses] DROP CONSTRAINT [FK_DepenseTypeDepense];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseElementBudget]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Depenses] DROP CONSTRAINT [FK_DepenseElementBudget];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseOrganisation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Depenses] DROP CONSTRAINT [FK_DepenseOrganisation];
GO
IF OBJECT_ID(N'[dbo].[FK_TypeMaterielMateriel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Materiels] DROP CONSTRAINT [FK_TypeMaterielMateriel];
GO
IF OBJECT_ID(N'[dbo].[FK_MarqueMaterielMateriel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Materiels] DROP CONSTRAINT [FK_MarqueMaterielMateriel];
GO
IF OBJECT_ID(N'[dbo].[FK_LogicielTypeLogiciel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Logiciels] DROP CONSTRAINT [FK_LogicielTypeLogiciel];
GO
IF OBJECT_ID(N'[dbo].[FK_LogicielMarqueLogiciel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Logiciels] DROP CONSTRAINT [FK_LogicielMarqueLogiciel];
GO
IF OBJECT_ID(N'[dbo].[FK_FraisTelecomTaxes]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FraisTelecoms] DROP CONSTRAINT [FK_FraisTelecomTaxes];
GO
IF OBJECT_ID(N'[dbo].[FK_LogicielTaxes]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Logiciels] DROP CONSTRAINT [FK_LogicielTaxes];
GO
IF OBJECT_ID(N'[dbo].[FK_TaxesFraisInformatique]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FraisInformatiques] DROP CONSTRAINT [FK_TaxesFraisInformatique];
GO
IF OBJECT_ID(N'[dbo].[FK_MaterielTaxes]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Materiels] DROP CONSTRAINT [FK_MaterielTaxes];
GO
IF OBJECT_ID(N'[dbo].[FK_OrganisationOrganisation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Organisations] DROP CONSTRAINT [FK_OrganisationOrganisation];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseMateriel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Materiels] DROP CONSTRAINT [FK_DepenseMateriel];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseFraisInformatique]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FraisInformatiques] DROP CONSTRAINT [FK_DepenseFraisInformatique];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseFraisTelecom]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FraisTelecoms] DROP CONSTRAINT [FK_DepenseFraisTelecom];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseLogiciel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Logiciels] DROP CONSTRAINT [FK_DepenseLogiciel];
GO
IF OBJECT_ID(N'[dbo].[FK_BudgetElementBudget]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ElementsBudget] DROP CONSTRAINT [FK_BudgetElementBudget];
GO
IF OBJECT_ID(N'[dbo].[FK_FraisGenerauxPoste]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ElementsBudget_FraisGeneraux] DROP CONSTRAINT [FK_FraisGenerauxPoste];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseDepense]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Depenses] DROP CONSTRAINT [FK_DepenseDepense];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseFG_Invest]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FG_Invest] DROP CONSTRAINT [FK_DepenseFG_Invest];
GO
IF OBJECT_ID(N'[dbo].[FK_FG_InvestTaxes]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FG_Invest] DROP CONSTRAINT [FK_FG_InvestTaxes];
GO
IF OBJECT_ID(N'[dbo].[FK_PosteFG_Invest]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[FG_Invest] DROP CONSTRAINT [FK_PosteFG_Invest];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseFraisGeneraux_Depense]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DepenseFraisGeneraux] DROP CONSTRAINT [FK_DepenseFraisGeneraux_Depense];
GO
IF OBJECT_ID(N'[dbo].[FK_DepenseFraisGeneraux_FraisGeneraux]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[DepenseFraisGeneraux] DROP CONSTRAINT [FK_DepenseFraisGeneraux_FraisGeneraux];
GO
IF OBJECT_ID(N'[dbo].[FK_Investissement_inherits_ElementBudget]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ElementsBudget_Investissement] DROP CONSTRAINT [FK_Investissement_inherits_ElementBudget];
GO
IF OBJECT_ID(N'[dbo].[FK_FraisGeneraux_inherits_ElementBudget]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ElementsBudget_FraisGeneraux] DROP CONSTRAINT [FK_FraisGeneraux_inherits_ElementBudget];
GO
IF OBJECT_ID(N'[dbo].[FK_TypeMaterielDefault_inherits_TypeMateriel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TypeMateriels_TypeMaterielDefault] DROP CONSTRAINT [FK_TypeMaterielDefault_inherits_TypeMateriel];
GO
IF OBJECT_ID(N'[dbo].[FK_MarqueMaterielDefault_inherits_MarqueMateriel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MarquesMateriel_MarqueMaterielDefault] DROP CONSTRAINT [FK_MarqueMaterielDefault_inherits_MarqueMateriel];
GO
IF OBJECT_ID(N'[dbo].[FK_TypeLogicielDefault_inherits_TypeLogiciel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TypeLogiciels_TypeLogicielDefault] DROP CONSTRAINT [FK_TypeLogicielDefault_inherits_TypeLogiciel];
GO
IF OBJECT_ID(N'[dbo].[FK_MarqueLogicielDefault_inherits_MarqueLogiciel]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[MarquesLogiciel_MarqueLogicielDefault] DROP CONSTRAINT [FK_MarqueLogicielDefault_inherits_MarqueLogiciel];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Pays]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Pays];
GO
IF OBJECT_ID(N'[dbo].[Organisations]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Organisations];
GO
IF OBJECT_ID(N'[dbo].[OrganisationTypes]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OrganisationTypes];
GO
IF OBJECT_ID(N'[dbo].[Postes]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Postes];
GO
IF OBJECT_ID(N'[dbo].[Budgets]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Budgets];
GO
IF OBJECT_ID(N'[dbo].[Priorites_Investissement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Priorites_Investissement];
GO
IF OBJECT_ID(N'[dbo].[ElementsBudget]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ElementsBudget];
GO
IF OBJECT_ID(N'[dbo].[Depenses]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Depenses];
GO
IF OBJECT_ID(N'[dbo].[Devises]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Devises];
GO
IF OBJECT_ID(N'[dbo].[TypeDepenses]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TypeDepenses];
GO
IF OBJECT_ID(N'[dbo].[Materiels]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Materiels];
GO
IF OBJECT_ID(N'[dbo].[TypeMateriels]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TypeMateriels];
GO
IF OBJECT_ID(N'[dbo].[MarquesMateriel]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MarquesMateriel];
GO
IF OBJECT_ID(N'[dbo].[FraisInformatiques]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FraisInformatiques];
GO
IF OBJECT_ID(N'[dbo].[FraisTelecoms]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FraisTelecoms];
GO
IF OBJECT_ID(N'[dbo].[Logiciels]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Logiciels];
GO
IF OBJECT_ID(N'[dbo].[TypeLogiciels]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TypeLogiciels];
GO
IF OBJECT_ID(N'[dbo].[MarquesLogiciel]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MarquesLogiciel];
GO
IF OBJECT_ID(N'[dbo].[Taxes]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Taxes];
GO
IF OBJECT_ID(N'[dbo].[FG_Invest]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FG_Invest];
GO
IF OBJECT_ID(N'[dbo].[ElementsBudget_Investissement]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ElementsBudget_Investissement];
GO
IF OBJECT_ID(N'[dbo].[ElementsBudget_FraisGeneraux]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ElementsBudget_FraisGeneraux];
GO
IF OBJECT_ID(N'[dbo].[TypeMateriels_TypeMaterielDefault]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TypeMateriels_TypeMaterielDefault];
GO
IF OBJECT_ID(N'[dbo].[MarquesMateriel_MarqueMaterielDefault]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MarquesMateriel_MarqueMaterielDefault];
GO
IF OBJECT_ID(N'[dbo].[TypeLogiciels_TypeLogicielDefault]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TypeLogiciels_TypeLogicielDefault];
GO
IF OBJECT_ID(N'[dbo].[MarquesLogiciel_MarqueLogicielDefault]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MarquesLogiciel_MarqueLogicielDefault];
GO
IF OBJECT_ID(N'[dbo].[DepenseFraisGeneraux]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DepenseFraisGeneraux];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Pays'
CREATE TABLE [dbo].[Pays] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Code] int  NOT NULL,
    [Alpha2] nvarchar(2)  NOT NULL,
    [Alpha3] nvarchar(3)  NOT NULL,
    [Nom] nvarchar(60)  NULL,
    [Convention] bit  NOT NULL
);
GO

-- Creating table 'Organisations'
CREATE TABLE [dbo].[Organisations] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nom] nvarchar(max)  NOT NULL,
    [Code] nvarchar(max)  NOT NULL,
    [Statut] bit  NOT NULL,
    [TypeId] int  NOT NULL,
    [PaysId] int  NOT NULL,
    [ParentId] int  NULL
);
GO

-- Creating table 'OrganisationTypes'
CREATE TABLE [dbo].[OrganisationTypes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nom] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Postes'
CREATE TABLE [dbo].[Postes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Chapitre] nvarchar(max)  NOT NULL,
    [Compte] nvarchar(max)  NOT NULL,
    [Intitule] nvarchar(max)  NOT NULL,
    [Grp_1] nvarchar(max)  NULL,
    [Grp_2] nvarchar(max)  NULL,
    [Grp_3] nvarchar(max)  NULL,
    [DirectionId] int  NOT NULL
);
GO

-- Creating table 'Budgets'
CREATE TABLE [dbo].[Budgets] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Exercice] int  NOT NULL,
    [Montant] decimal(18,2)  NULL,
    [Description] nvarchar(max)  NULL,
    [DirectionId] int  NOT NULL,
    [EInvest] decimal(18,2)  NULL,
    [Valide] bit  NULL,
    [DateValidation] datetime  NULL,
    [MontantAuto] bit  NULL,
    [DateCreation] datetime  NULL,
    [TotalFrais] decimal(18,2)  NULL,
    [TotalInvest] decimal(18,2)  NULL,
    [EFrais] decimal(18,2)  NULL,
    [RFrais] decimal(18,2)  NULL,
    [RInvest] decimal(18,2)  NULL
);
GO

-- Creating table 'Priorites_Investissement'
CREATE TABLE [dbo].[Priorites_Investissement] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Designation] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'ElementsBudget'
CREATE TABLE [dbo].[ElementsBudget] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Description] nvarchar(max)  NULL,
    [Montant] decimal(18,2)  NOT NULL,
    [BudgetId] int  NOT NULL,
    [Realise] decimal(18,2)  NULL,
    [Engage] decimal(18,2)  NULL
);
GO

-- Creating table 'Depenses'
CREATE TABLE [dbo].[Depenses] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Montant] decimal(18,2)  NULL,
    [Observation] nvarchar(max)  NOT NULL,
    [Numero] varchar(150)  NOT NULL,
    [DateEmission] datetime  NOT NULL,
    [DateReceptionCible] datetime  NULL,
    [DateEnvoieCF] datetime  NULL,
    [Execute] bit  NOT NULL,
    [TVA] decimal(18,2)  NULL,
    [RS] decimal(18,2)  NULL,
    [TTC] decimal(18,2)  NULL,
    [DeviseId] int  NOT NULL,
    [TypeId] int  NOT NULL,
    [ElementBudgetId] int  NOT NULL,
    [FournisseurId] int  NOT NULL,
    [DateCreation] datetime  NOT NULL,
    [EngagementId] int  NULL,
    [Avenant] varchar(150)  NULL,
    [DISPLAY] varchar(250)  NULL,
    [Remise] decimal(18,2)  NULL,
    [Taux] decimal(18,2)  NULL,
    [DateDebut] datetime  NULL,
    [DateFin] datetime  NULL
);
GO

-- Creating table 'Devises'
CREATE TABLE [dbo].[Devises] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [AlphaCode] nvarchar(max)  NOT NULL,
    [NumCode] nvarchar(max)  NOT NULL,
    [Libelle] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'TypeDepenses'
CREATE TABLE [dbo].[TypeDepenses] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Libelle] nvarchar(max)  NOT NULL,
    [Description] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Materiels'
CREATE TABLE [dbo].[Materiels] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Designation] nvarchar(max)  NOT NULL,
    [Montant] decimal(18,2)  NULL,
    [TTC] decimal(18,2)  NULL,
    [TypeId] int  NULL,
    [MarqueId] int  NULL,
    [TaxesId] int  NOT NULL,
    [DepenseId] int  NOT NULL,
    [TVA] decimal(18,2)  NULL,
    [RS] decimal(18,2)  NULL,
    [Remise] decimal(18,2)  NULL
);
GO

-- Creating table 'TypeMateriels'
CREATE TABLE [dbo].[TypeMateriels] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Libelle] nvarchar(max)  NOT NULL,
    [Description] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'MarquesMateriel'
CREATE TABLE [dbo].[MarquesMateriel] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nom] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'FraisInformatiques'
CREATE TABLE [dbo].[FraisInformatiques] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Montant] decimal(18,2)  NULL,
    [TTC] decimal(18,2)  NULL,
    [Fin] datetime  NULL,
    [Debut] datetime  NULL,
    [Description] nvarchar(max)  NULL,
    [TaxesId] int  NOT NULL,
    [DepenseId] int  NOT NULL,
    [TVA] decimal(18,2)  NULL,
    [RS] decimal(18,2)  NULL,
    [Remise] decimal(18,2)  NULL,
    [PosteId] int  NULL
);
GO

-- Creating table 'FraisTelecoms'
CREATE TABLE [dbo].[FraisTelecoms] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Montant] decimal(18,2)  NULL,
    [TTC] decimal(18,2)  NULL,
    [Description] nvarchar(max)  NULL,
    [Debut] datetime  NULL,
    [Fin] datetime  NULL,
    [TaxesId] int  NOT NULL,
    [DepenseId] int  NOT NULL,
    [TVA] decimal(18,2)  NULL,
    [RS] decimal(18,2)  NULL,
    [Remise] decimal(18,2)  NULL,
    [PosteId] int  NULL
);
GO

-- Creating table 'Logiciels'
CREATE TABLE [dbo].[Logiciels] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Designation] nvarchar(max)  NOT NULL,
    [Version] nvarchar(max)  NULL,
    [Montant] decimal(18,2)  NULL,
    [TTC] decimal(18,2)  NULL,
    [TypeId] int  NULL,
    [MarqueId] int  NULL,
    [TaxesId] int  NOT NULL,
    [DepenseId] int  NOT NULL,
    [TVA] decimal(18,2)  NULL,
    [RS] decimal(18,2)  NULL,
    [Remise] decimal(18,2)  NULL
);
GO

-- Creating table 'TypeLogiciels'
CREATE TABLE [dbo].[TypeLogiciels] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Libelle] nvarchar(max)  NOT NULL,
    [Description] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'MarquesLogiciel'
CREATE TABLE [dbo].[MarquesLogiciel] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nom] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Taxes'
CREATE TABLE [dbo].[Taxes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nom] nvarchar(max)  NOT NULL,
    [Description] nvarchar(max)  NOT NULL,
    [Taux] float  NOT NULL,
    [RetenuSource] bit  NOT NULL
);
GO

-- Creating table 'FG_Invest'
CREATE TABLE [dbo].[FG_Invest] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [DepenseId] int  NOT NULL,
    [Montant] decimal(18,2)  NOT NULL,
    [TaxesId] int  NOT NULL,
    [PosteId] int  NOT NULL,
    [RS] decimal(18,2)  NULL,
    [TTC] decimal(18,2)  NULL,
    [TVA] decimal(18,2)  NULL,
    [Remise] decimal(18,2)  NULL
);
GO

-- Creating table 'ElementsBudget_Investissement'
CREATE TABLE [dbo].[ElementsBudget_Investissement] (
    [Nom] nvarchar(max)  NOT NULL,
    [Objectif] nvarchar(max)  NULL,
    [Charge] nvarchar(max)  NOT NULL,
    [Licences] decimal(18,2)  NULL,
    [Prestations] decimal(18,2)  NULL,
    [Aquisitions] decimal(18,2)  NULL,
    [PrioriteId] int  NULL,
    [DepartementId] int  NOT NULL,
    [Id] int  NOT NULL
);
GO

-- Creating table 'ElementsBudget_FraisGeneraux'
CREATE TABLE [dbo].[ElementsBudget_FraisGeneraux] (
    [PosteId] int  NOT NULL,
    [Id] int  NOT NULL
);
GO

-- Creating table 'TypeMateriels_TypeMaterielDefault'
CREATE TABLE [dbo].[TypeMateriels_TypeMaterielDefault] (
    [Id] int  NOT NULL
);
GO

-- Creating table 'MarquesMateriel_MarqueMaterielDefault'
CREATE TABLE [dbo].[MarquesMateriel_MarqueMaterielDefault] (
    [Id] int  NOT NULL
);
GO

-- Creating table 'TypeLogiciels_TypeLogicielDefault'
CREATE TABLE [dbo].[TypeLogiciels_TypeLogicielDefault] (
    [Id] int  NOT NULL
);
GO

-- Creating table 'MarquesLogiciel_MarqueLogicielDefault'
CREATE TABLE [dbo].[MarquesLogiciel_MarqueLogicielDefault] (
    [Id] int  NOT NULL
);
GO

-- Creating table 'DepenseFraisGeneraux'
CREATE TABLE [dbo].[DepenseFraisGeneraux] (
    [DepenseFraisGeneraux_FraisGeneraux_Id] int  NOT NULL,
    [FraisGeneraux_Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Pays'
ALTER TABLE [dbo].[Pays]
ADD CONSTRAINT [PK_Pays]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Organisations'
ALTER TABLE [dbo].[Organisations]
ADD CONSTRAINT [PK_Organisations]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'OrganisationTypes'
ALTER TABLE [dbo].[OrganisationTypes]
ADD CONSTRAINT [PK_OrganisationTypes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Postes'
ALTER TABLE [dbo].[Postes]
ADD CONSTRAINT [PK_Postes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Budgets'
ALTER TABLE [dbo].[Budgets]
ADD CONSTRAINT [PK_Budgets]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Priorites_Investissement'
ALTER TABLE [dbo].[Priorites_Investissement]
ADD CONSTRAINT [PK_Priorites_Investissement]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ElementsBudget'
ALTER TABLE [dbo].[ElementsBudget]
ADD CONSTRAINT [PK_ElementsBudget]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Depenses'
ALTER TABLE [dbo].[Depenses]
ADD CONSTRAINT [PK_Depenses]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Devises'
ALTER TABLE [dbo].[Devises]
ADD CONSTRAINT [PK_Devises]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TypeDepenses'
ALTER TABLE [dbo].[TypeDepenses]
ADD CONSTRAINT [PK_TypeDepenses]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Materiels'
ALTER TABLE [dbo].[Materiels]
ADD CONSTRAINT [PK_Materiels]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TypeMateriels'
ALTER TABLE [dbo].[TypeMateriels]
ADD CONSTRAINT [PK_TypeMateriels]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'MarquesMateriel'
ALTER TABLE [dbo].[MarquesMateriel]
ADD CONSTRAINT [PK_MarquesMateriel]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'FraisInformatiques'
ALTER TABLE [dbo].[FraisInformatiques]
ADD CONSTRAINT [PK_FraisInformatiques]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'FraisTelecoms'
ALTER TABLE [dbo].[FraisTelecoms]
ADD CONSTRAINT [PK_FraisTelecoms]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Logiciels'
ALTER TABLE [dbo].[Logiciels]
ADD CONSTRAINT [PK_Logiciels]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TypeLogiciels'
ALTER TABLE [dbo].[TypeLogiciels]
ADD CONSTRAINT [PK_TypeLogiciels]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'MarquesLogiciel'
ALTER TABLE [dbo].[MarquesLogiciel]
ADD CONSTRAINT [PK_MarquesLogiciel]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Taxes'
ALTER TABLE [dbo].[Taxes]
ADD CONSTRAINT [PK_Taxes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'FG_Invest'
ALTER TABLE [dbo].[FG_Invest]
ADD CONSTRAINT [PK_FG_Invest]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ElementsBudget_Investissement'
ALTER TABLE [dbo].[ElementsBudget_Investissement]
ADD CONSTRAINT [PK_ElementsBudget_Investissement]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ElementsBudget_FraisGeneraux'
ALTER TABLE [dbo].[ElementsBudget_FraisGeneraux]
ADD CONSTRAINT [PK_ElementsBudget_FraisGeneraux]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TypeMateriels_TypeMaterielDefault'
ALTER TABLE [dbo].[TypeMateriels_TypeMaterielDefault]
ADD CONSTRAINT [PK_TypeMateriels_TypeMaterielDefault]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'MarquesMateriel_MarqueMaterielDefault'
ALTER TABLE [dbo].[MarquesMateriel_MarqueMaterielDefault]
ADD CONSTRAINT [PK_MarquesMateriel_MarqueMaterielDefault]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TypeLogiciels_TypeLogicielDefault'
ALTER TABLE [dbo].[TypeLogiciels_TypeLogicielDefault]
ADD CONSTRAINT [PK_TypeLogiciels_TypeLogicielDefault]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'MarquesLogiciel_MarqueLogicielDefault'
ALTER TABLE [dbo].[MarquesLogiciel_MarqueLogicielDefault]
ADD CONSTRAINT [PK_MarquesLogiciel_MarqueLogicielDefault]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [DepenseFraisGeneraux_FraisGeneraux_Id], [FraisGeneraux_Id] in table 'DepenseFraisGeneraux'
ALTER TABLE [dbo].[DepenseFraisGeneraux]
ADD CONSTRAINT [PK_DepenseFraisGeneraux]
    PRIMARY KEY CLUSTERED ([DepenseFraisGeneraux_FraisGeneraux_Id], [FraisGeneraux_Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [PaysId] in table 'Organisations'
ALTER TABLE [dbo].[Organisations]
ADD CONSTRAINT [FK_PaysOrganisation]
    FOREIGN KEY ([PaysId])
    REFERENCES [dbo].[Pays]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_PaysOrganisation'
CREATE INDEX [IX_FK_PaysOrganisation]
ON [dbo].[Organisations]
    ([PaysId]);
GO

-- Creating foreign key on [TypeId] in table 'Organisations'
ALTER TABLE [dbo].[Organisations]
ADD CONSTRAINT [FK_OrganisationTypeOrganisation]
    FOREIGN KEY ([TypeId])
    REFERENCES [dbo].[OrganisationTypes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganisationTypeOrganisation'
CREATE INDEX [IX_FK_OrganisationTypeOrganisation]
ON [dbo].[Organisations]
    ([TypeId]);
GO

-- Creating foreign key on [DirectionId] in table 'Postes'
ALTER TABLE [dbo].[Postes]
ADD CONSTRAINT [FK_PosteOrganisation]
    FOREIGN KEY ([DirectionId])
    REFERENCES [dbo].[Organisations]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_PosteOrganisation'
CREATE INDEX [IX_FK_PosteOrganisation]
ON [dbo].[Postes]
    ([DirectionId]);
GO

-- Creating foreign key on [DirectionId] in table 'Budgets'
ALTER TABLE [dbo].[Budgets]
ADD CONSTRAINT [FK_OrganisationBudget]
    FOREIGN KEY ([DirectionId])
    REFERENCES [dbo].[Organisations]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganisationBudget'
CREATE INDEX [IX_FK_OrganisationBudget]
ON [dbo].[Budgets]
    ([DirectionId]);
GO

-- Creating foreign key on [PrioriteId] in table 'ElementsBudget_Investissement'
ALTER TABLE [dbo].[ElementsBudget_Investissement]
ADD CONSTRAINT [FK_Priorite_InvestissementInvestissement]
    FOREIGN KEY ([PrioriteId])
    REFERENCES [dbo].[Priorites_Investissement]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Priorite_InvestissementInvestissement'
CREATE INDEX [IX_FK_Priorite_InvestissementInvestissement]
ON [dbo].[ElementsBudget_Investissement]
    ([PrioriteId]);
GO

-- Creating foreign key on [DepartementId] in table 'ElementsBudget_Investissement'
ALTER TABLE [dbo].[ElementsBudget_Investissement]
ADD CONSTRAINT [FK_InvestissementOrganisation]
    FOREIGN KEY ([DepartementId])
    REFERENCES [dbo].[Organisations]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_InvestissementOrganisation'
CREATE INDEX [IX_FK_InvestissementOrganisation]
ON [dbo].[ElementsBudget_Investissement]
    ([DepartementId]);
GO

-- Creating foreign key on [DeviseId] in table 'Depenses'
ALTER TABLE [dbo].[Depenses]
ADD CONSTRAINT [FK_DepenseDevise]
    FOREIGN KEY ([DeviseId])
    REFERENCES [dbo].[Devises]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseDevise'
CREATE INDEX [IX_FK_DepenseDevise]
ON [dbo].[Depenses]
    ([DeviseId]);
GO

-- Creating foreign key on [TypeId] in table 'Depenses'
ALTER TABLE [dbo].[Depenses]
ADD CONSTRAINT [FK_DepenseTypeDepense]
    FOREIGN KEY ([TypeId])
    REFERENCES [dbo].[TypeDepenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseTypeDepense'
CREATE INDEX [IX_FK_DepenseTypeDepense]
ON [dbo].[Depenses]
    ([TypeId]);
GO

-- Creating foreign key on [ElementBudgetId] in table 'Depenses'
ALTER TABLE [dbo].[Depenses]
ADD CONSTRAINT [FK_DepenseElementBudget]
    FOREIGN KEY ([ElementBudgetId])
    REFERENCES [dbo].[ElementsBudget]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseElementBudget'
CREATE INDEX [IX_FK_DepenseElementBudget]
ON [dbo].[Depenses]
    ([ElementBudgetId]);
GO

-- Creating foreign key on [FournisseurId] in table 'Depenses'
ALTER TABLE [dbo].[Depenses]
ADD CONSTRAINT [FK_DepenseOrganisation]
    FOREIGN KEY ([FournisseurId])
    REFERENCES [dbo].[Organisations]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseOrganisation'
CREATE INDEX [IX_FK_DepenseOrganisation]
ON [dbo].[Depenses]
    ([FournisseurId]);
GO

-- Creating foreign key on [TypeId] in table 'Materiels'
ALTER TABLE [dbo].[Materiels]
ADD CONSTRAINT [FK_TypeMaterielMateriel]
    FOREIGN KEY ([TypeId])
    REFERENCES [dbo].[TypeMateriels]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_TypeMaterielMateriel'
CREATE INDEX [IX_FK_TypeMaterielMateriel]
ON [dbo].[Materiels]
    ([TypeId]);
GO

-- Creating foreign key on [MarqueId] in table 'Materiels'
ALTER TABLE [dbo].[Materiels]
ADD CONSTRAINT [FK_MarqueMaterielMateriel]
    FOREIGN KEY ([MarqueId])
    REFERENCES [dbo].[MarquesMateriel]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_MarqueMaterielMateriel'
CREATE INDEX [IX_FK_MarqueMaterielMateriel]
ON [dbo].[Materiels]
    ([MarqueId]);
GO

-- Creating foreign key on [TypeId] in table 'Logiciels'
ALTER TABLE [dbo].[Logiciels]
ADD CONSTRAINT [FK_LogicielTypeLogiciel]
    FOREIGN KEY ([TypeId])
    REFERENCES [dbo].[TypeLogiciels]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_LogicielTypeLogiciel'
CREATE INDEX [IX_FK_LogicielTypeLogiciel]
ON [dbo].[Logiciels]
    ([TypeId]);
GO

-- Creating foreign key on [MarqueId] in table 'Logiciels'
ALTER TABLE [dbo].[Logiciels]
ADD CONSTRAINT [FK_LogicielMarqueLogiciel]
    FOREIGN KEY ([MarqueId])
    REFERENCES [dbo].[MarquesLogiciel]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_LogicielMarqueLogiciel'
CREATE INDEX [IX_FK_LogicielMarqueLogiciel]
ON [dbo].[Logiciels]
    ([MarqueId]);
GO

-- Creating foreign key on [TaxesId] in table 'FraisTelecoms'
ALTER TABLE [dbo].[FraisTelecoms]
ADD CONSTRAINT [FK_FraisTelecomTaxes]
    FOREIGN KEY ([TaxesId])
    REFERENCES [dbo].[Taxes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_FraisTelecomTaxes'
CREATE INDEX [IX_FK_FraisTelecomTaxes]
ON [dbo].[FraisTelecoms]
    ([TaxesId]);
GO

-- Creating foreign key on [TaxesId] in table 'Logiciels'
ALTER TABLE [dbo].[Logiciels]
ADD CONSTRAINT [FK_LogicielTaxes]
    FOREIGN KEY ([TaxesId])
    REFERENCES [dbo].[Taxes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_LogicielTaxes'
CREATE INDEX [IX_FK_LogicielTaxes]
ON [dbo].[Logiciels]
    ([TaxesId]);
GO

-- Creating foreign key on [TaxesId] in table 'FraisInformatiques'
ALTER TABLE [dbo].[FraisInformatiques]
ADD CONSTRAINT [FK_TaxesFraisInformatique]
    FOREIGN KEY ([TaxesId])
    REFERENCES [dbo].[Taxes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_TaxesFraisInformatique'
CREATE INDEX [IX_FK_TaxesFraisInformatique]
ON [dbo].[FraisInformatiques]
    ([TaxesId]);
GO

-- Creating foreign key on [TaxesId] in table 'Materiels'
ALTER TABLE [dbo].[Materiels]
ADD CONSTRAINT [FK_MaterielTaxes]
    FOREIGN KEY ([TaxesId])
    REFERENCES [dbo].[Taxes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_MaterielTaxes'
CREATE INDEX [IX_FK_MaterielTaxes]
ON [dbo].[Materiels]
    ([TaxesId]);
GO

-- Creating foreign key on [ParentId] in table 'Organisations'
ALTER TABLE [dbo].[Organisations]
ADD CONSTRAINT [FK_OrganisationOrganisation]
    FOREIGN KEY ([ParentId])
    REFERENCES [dbo].[Organisations]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_OrganisationOrganisation'
CREATE INDEX [IX_FK_OrganisationOrganisation]
ON [dbo].[Organisations]
    ([ParentId]);
GO

-- Creating foreign key on [DepenseId] in table 'Materiels'
ALTER TABLE [dbo].[Materiels]
ADD CONSTRAINT [FK_DepenseMateriel]
    FOREIGN KEY ([DepenseId])
    REFERENCES [dbo].[Depenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseMateriel'
CREATE INDEX [IX_FK_DepenseMateriel]
ON [dbo].[Materiels]
    ([DepenseId]);
GO

-- Creating foreign key on [DepenseId] in table 'FraisInformatiques'
ALTER TABLE [dbo].[FraisInformatiques]
ADD CONSTRAINT [FK_DepenseFraisInformatique]
    FOREIGN KEY ([DepenseId])
    REFERENCES [dbo].[Depenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseFraisInformatique'
CREATE INDEX [IX_FK_DepenseFraisInformatique]
ON [dbo].[FraisInformatiques]
    ([DepenseId]);
GO

-- Creating foreign key on [DepenseId] in table 'FraisTelecoms'
ALTER TABLE [dbo].[FraisTelecoms]
ADD CONSTRAINT [FK_DepenseFraisTelecom]
    FOREIGN KEY ([DepenseId])
    REFERENCES [dbo].[Depenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseFraisTelecom'
CREATE INDEX [IX_FK_DepenseFraisTelecom]
ON [dbo].[FraisTelecoms]
    ([DepenseId]);
GO

-- Creating foreign key on [DepenseId] in table 'Logiciels'
ALTER TABLE [dbo].[Logiciels]
ADD CONSTRAINT [FK_DepenseLogiciel]
    FOREIGN KEY ([DepenseId])
    REFERENCES [dbo].[Depenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseLogiciel'
CREATE INDEX [IX_FK_DepenseLogiciel]
ON [dbo].[Logiciels]
    ([DepenseId]);
GO

-- Creating foreign key on [BudgetId] in table 'ElementsBudget'
ALTER TABLE [dbo].[ElementsBudget]
ADD CONSTRAINT [FK_BudgetElementBudget]
    FOREIGN KEY ([BudgetId])
    REFERENCES [dbo].[Budgets]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_BudgetElementBudget'
CREATE INDEX [IX_FK_BudgetElementBudget]
ON [dbo].[ElementsBudget]
    ([BudgetId]);
GO

-- Creating foreign key on [PosteId] in table 'ElementsBudget_FraisGeneraux'
ALTER TABLE [dbo].[ElementsBudget_FraisGeneraux]
ADD CONSTRAINT [FK_FraisGenerauxPoste]
    FOREIGN KEY ([PosteId])
    REFERENCES [dbo].[Postes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_FraisGenerauxPoste'
CREATE INDEX [IX_FK_FraisGenerauxPoste]
ON [dbo].[ElementsBudget_FraisGeneraux]
    ([PosteId]);
GO

-- Creating foreign key on [EngagementId] in table 'Depenses'
ALTER TABLE [dbo].[Depenses]
ADD CONSTRAINT [FK_DepenseDepense]
    FOREIGN KEY ([EngagementId])
    REFERENCES [dbo].[Depenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseDepense'
CREATE INDEX [IX_FK_DepenseDepense]
ON [dbo].[Depenses]
    ([EngagementId]);
GO

-- Creating foreign key on [DepenseId] in table 'FG_Invest'
ALTER TABLE [dbo].[FG_Invest]
ADD CONSTRAINT [FK_DepenseFG_Invest]
    FOREIGN KEY ([DepenseId])
    REFERENCES [dbo].[Depenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseFG_Invest'
CREATE INDEX [IX_FK_DepenseFG_Invest]
ON [dbo].[FG_Invest]
    ([DepenseId]);
GO

-- Creating foreign key on [TaxesId] in table 'FG_Invest'
ALTER TABLE [dbo].[FG_Invest]
ADD CONSTRAINT [FK_FG_InvestTaxes]
    FOREIGN KEY ([TaxesId])
    REFERENCES [dbo].[Taxes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_FG_InvestTaxes'
CREATE INDEX [IX_FK_FG_InvestTaxes]
ON [dbo].[FG_Invest]
    ([TaxesId]);
GO

-- Creating foreign key on [PosteId] in table 'FG_Invest'
ALTER TABLE [dbo].[FG_Invest]
ADD CONSTRAINT [FK_PosteFG_Invest]
    FOREIGN KEY ([PosteId])
    REFERENCES [dbo].[Postes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_PosteFG_Invest'
CREATE INDEX [IX_FK_PosteFG_Invest]
ON [dbo].[FG_Invest]
    ([PosteId]);
GO

-- Creating foreign key on [DepenseFraisGeneraux_FraisGeneraux_Id] in table 'DepenseFraisGeneraux'
ALTER TABLE [dbo].[DepenseFraisGeneraux]
ADD CONSTRAINT [FK_DepenseFraisGeneraux_Depense]
    FOREIGN KEY ([DepenseFraisGeneraux_FraisGeneraux_Id])
    REFERENCES [dbo].[Depenses]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [FraisGeneraux_Id] in table 'DepenseFraisGeneraux'
ALTER TABLE [dbo].[DepenseFraisGeneraux]
ADD CONSTRAINT [FK_DepenseFraisGeneraux_FraisGeneraux]
    FOREIGN KEY ([FraisGeneraux_Id])
    REFERENCES [dbo].[ElementsBudget_FraisGeneraux]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_DepenseFraisGeneraux_FraisGeneraux'
CREATE INDEX [IX_FK_DepenseFraisGeneraux_FraisGeneraux]
ON [dbo].[DepenseFraisGeneraux]
    ([FraisGeneraux_Id]);
GO

-- Creating foreign key on [PosteId] in table 'FraisInformatiques'
ALTER TABLE [dbo].[FraisInformatiques]
ADD CONSTRAINT [FK_FraisGenerauxFraisInformatique]
    FOREIGN KEY ([PosteId])
    REFERENCES [dbo].[ElementsBudget_FraisGeneraux]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_FraisGenerauxFraisInformatique'
CREATE INDEX [IX_FK_FraisGenerauxFraisInformatique]
ON [dbo].[FraisInformatiques]
    ([PosteId]);
GO

-- Creating foreign key on [PosteId] in table 'FraisTelecoms'
ALTER TABLE [dbo].[FraisTelecoms]
ADD CONSTRAINT [FK_FraisGenerauxFraisTelecom]
    FOREIGN KEY ([PosteId])
    REFERENCES [dbo].[ElementsBudget_FraisGeneraux]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_FraisGenerauxFraisTelecom'
CREATE INDEX [IX_FK_FraisGenerauxFraisTelecom]
ON [dbo].[FraisTelecoms]
    ([PosteId]);
GO

-- Creating foreign key on [Id] in table 'ElementsBudget_Investissement'
ALTER TABLE [dbo].[ElementsBudget_Investissement]
ADD CONSTRAINT [FK_Investissement_inherits_ElementBudget]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[ElementsBudget]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Id] in table 'ElementsBudget_FraisGeneraux'
ALTER TABLE [dbo].[ElementsBudget_FraisGeneraux]
ADD CONSTRAINT [FK_FraisGeneraux_inherits_ElementBudget]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[ElementsBudget]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Id] in table 'TypeMateriels_TypeMaterielDefault'
ALTER TABLE [dbo].[TypeMateriels_TypeMaterielDefault]
ADD CONSTRAINT [FK_TypeMaterielDefault_inherits_TypeMateriel]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[TypeMateriels]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Id] in table 'MarquesMateriel_MarqueMaterielDefault'
ALTER TABLE [dbo].[MarquesMateriel_MarqueMaterielDefault]
ADD CONSTRAINT [FK_MarqueMaterielDefault_inherits_MarqueMateriel]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[MarquesMateriel]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Id] in table 'TypeLogiciels_TypeLogicielDefault'
ALTER TABLE [dbo].[TypeLogiciels_TypeLogicielDefault]
ADD CONSTRAINT [FK_TypeLogicielDefault_inherits_TypeLogiciel]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[TypeLogiciels]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Id] in table 'MarquesLogiciel_MarqueLogicielDefault'
ALTER TABLE [dbo].[MarquesLogiciel_MarqueLogicielDefault]
ADD CONSTRAINT [FK_MarqueLogicielDefault_inherits_MarqueLogiciel]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[MarquesLogiciel]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------