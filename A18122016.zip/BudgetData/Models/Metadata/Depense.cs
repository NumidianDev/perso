﻿//using Newtonsoft.Json;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BudgetData.Models
//{
//    [MetadataType(typeof(DepenseMetadata))]
//    public partial class Depense
//    {

//    }

//    public class DepenseMetadata
//    {
//        public virtual Nullable<decimal> MontantApresRemise { get {  return Montant - Remise ; } }
//    }

//}
