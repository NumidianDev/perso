﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BudgetData.Models
{

    [MetadataType(typeof(BudgetMetadata))]
    public partial class Budget
    {

    }

    public class BudgetMetadata
    {
        [JsonIgnore]
        public virtual ICollection<ElementBudget> ElementBudgets { get; set; }
    }

}