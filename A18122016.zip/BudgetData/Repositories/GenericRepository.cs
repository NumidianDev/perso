﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace BudgetData.Repositories
{
    public abstract class GenericRepository<C, T> : IGenericRepository<T>  where T : class where C : DbContext, new()
    {

        private C _entities = new C();

        public C Context {
            get { return _entities; }
            set { _entities = value; }
        }

        public virtual async Task<IList<T>> GetAll()
        {
            return await _entities.Set<T>().ToListAsync();
        }

        public async Task<T> GetById(int? Id)
        {
            return await _entities.Set<T>().FindAsync(Id);
        }

        public async Task<IList<T>> FindBy(Expression<Func<T, bool>> predicate)
        {
            return await _entities.Set<T>().Where(predicate).ToListAsync();
        }

        public virtual async Task<T> Add(T entity)
        {
            T savedEntity = _entities.Set<T>().Add(entity);
            await _entities.SaveChangesAsync();
            return savedEntity;
        }

        public virtual void Delete(T entity)
        {
            _entities.Set<T>().Remove(entity);
            _entities.SaveChangesAsync();
        }

        public virtual async Task<T> Edit(T entity)
        {
            _entities.Entry(entity).State = EntityState.Modified;
            await _entities.SaveChangesAsync();
            return entity;
        }

        public virtual void Save()
        {
            _entities.SaveChanges();
        }

        public void Dispose()
        {
            _entities.Dispose();
        }
    }
}
