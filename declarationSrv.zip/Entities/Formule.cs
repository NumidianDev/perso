namespace WebApi.Entities {
    public class Formule {
        public int Id { get; set; }
        public string OPERATEUR { get; set; }

        public string CODE_PAYS { get; set; }

        public string RUBRIQUE { get; set; }

        public string DESIGNATION_PAYS { get; set; }

        public string TARIF_DOUANIER { get; set; }

        public string DESIGNATION_OPERATION { get; set; }

        public string CODE_OPERATION { get; set; }

        public string NUM_DOMICILIATION { get; set; }

        public string DESIGNATION_OPERATEUR { get; set; }

        public string CODE_OPERATEUR { get; set; }

        public string DESIGNATION_DOB { get; set; }

        public string REFERENCE_BANQUE { get; set; }

        public decimal MONTANT { get; set; }

        public decimal COURS_F { get; set; }

        public decimal CONTRE_VALEUR_F { get; set; }

        public string FORMULE { get; set; }

        public string MODE_REGLEMENT { get; set; }
    }
}