﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApi.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Accounts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Matricule = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Prenom = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nom = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AcceptTerms = table.Column<bool>(type: "bit", nullable: false),
                    Role = table.Column<int>(type: "int", nullable: false),
                    VerificationToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Verified = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ResetToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResetTokenExpires = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PasswordReset = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accounts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Bordereaux",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TYPE_DECLARATION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SENS_FLUX = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BANQUE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MONNAIE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MONTANT_GLOBAL = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    NBR_ENREGISTREMENT = table.Column<int>(type: "int", nullable: false),
                    DATE_VALEUR = table.Column<DateTime>(type: "datetime2", nullable: true),
                    COURS = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CONTRE_VALEUR = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bordereaux", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FichiersXml",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NBR_ENREGISTREMENT = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FichiersXml", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RefreshToken",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccountId = table.Column<int>(type: "int", nullable: false),
                    Token = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Expires = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedByIp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Revoked = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RevokedByIp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReplacedByToken = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RefreshToken", x => new { x.AccountId, x.Id });
                    table.ForeignKey(
                        name: "FK_RefreshToken_Accounts_AccountId",
                        column: x => x.AccountId,
                        principalTable: "Accounts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Declarations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    bordereauId = table.Column<int>(type: "int", nullable: false),
                    FichierXmlId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Declarations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Declarations_Bordereaux_bordereauId",
                        column: x => x.bordereauId,
                        principalTable: "Bordereaux",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Declarations_FichiersXml_FichierXmlId",
                        column: x => x.FichierXmlId,
                        principalTable: "FichiersXml",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Formules",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OPERATEUR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CODE_PAYS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RUBRIQUE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DESIGNATION_PAYS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TARIF_DOUANIER = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DESIGNATION_OPERATION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CODE_OPERATION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NUM_DOMICILIATION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DESIGNATION_OPERATEUR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CODE_OPERATEUR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DESIGNATION_DOB = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    REFERENCE_BANQUE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MONTANT = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    COURS_F = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CONTRE_VALEUR_F = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    FORMULE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MODE_REGLEMENT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeclarationId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Formules", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Formules_Declarations_DeclarationId",
                        column: x => x.DeclarationId,
                        principalTable: "Declarations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Declarations_bordereauId",
                table: "Declarations",
                column: "bordereauId");

            migrationBuilder.CreateIndex(
                name: "IX_Declarations_FichierXmlId",
                table: "Declarations",
                column: "FichierXmlId");

            migrationBuilder.CreateIndex(
                name: "IX_Formules_DeclarationId",
                table: "Formules",
                column: "DeclarationId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Formules");

            migrationBuilder.DropTable(
                name: "RefreshToken");

            migrationBuilder.DropTable(
                name: "Declarations");

            migrationBuilder.DropTable(
                name: "Accounts");

            migrationBuilder.DropTable(
                name: "Bordereaux");

            migrationBuilder.DropTable(
                name: "FichiersXml");
        }
    }
}
