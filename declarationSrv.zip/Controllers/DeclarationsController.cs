using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using WebApi.Helpers;
using WebApi.Models.BA;
using WebApi.Services;

namespace WebApi.Controllers {

    [ApiController]
    [Route ("[controller]")]
    public class DeclarationsController : BaseController {
        private readonly IDeclarationService _declarationService;
        private readonly IMapper _mapper;

        public DeclarationsController (
            IDeclarationService declarationService,
            IMapper mapper,
            DataContext context) {
            _declarationService = declarationService;
            _mapper = mapper;
        }

        [Authorize]
        [HttpGet ("formules")]
        public ActionResult<IEnumerable<FormuleDTO>> GetAllFormules () {
            var formules = _declarationService.GetAllFormules ();
            return Ok (formules);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<FormuleDTO> GetFormuleById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var formule = _declarationService.GetFormuleById (id);
            return Ok (formule);
        }

        [Authorize]
        [HttpGet ("declarations")]
        public ActionResult<DeclarationDTO> GetAllDeclarations () {
            var response = _declarationService.GetAllDeclarations ();
            return Ok (response);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<DeclarationDTO> GetDeclarationById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var declaration = _declarationService.GetDeclarationById (id);
            return Ok (declaration);
        }

        [Authorize]
        [HttpGet ("fichiersXml")]
        public ActionResult<FichierXmlDTO> GetAllXML () {
            var response = _declarationService.GetAllXML ();
            return Ok (response);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<FichierXmlDTO> GetXmlById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var fichierXml = _declarationService.GetXMLById (id);
            return Ok (fichierXml);
        }

        [Authorize]
        [HttpGet ("bordereaux")]
        public ActionResult<BordereauDTO> GetAllBordreaux () {
            var response = _declarationService.GetAllBordreaux ();
            return Ok (response);
        }

        [Authorize]
        [HttpGet ("{id:int}")]
        public ActionResult<BordereauDTO> GetBordereauById (int id) {
            // Vérifier le role
            // Account.
            // return Unauthorized (new { message = "Unauthorized" });
            var bordereaux = _declarationService.GetBordereauById (id);
            return Ok (bordereaux);
        }
    }

}