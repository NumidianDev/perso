namespace WebApi.Models.Accounts
{
    public class RevokeTokenRequest
    {
        public string Token { get; set; }
    }
}