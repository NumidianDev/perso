using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace WebApi.Models.BA {

    [XmlType]
    public class FormuleDTO {

        [XmlIgnore]
        public int Id { get; set; }

        [XmlElement]
        public string OPERATEUR { get; set; }

        [XmlElement]
        public string CODE_PAYS { get; set; }

        [XmlElement]
        public string RUBRIQUE { get; set; }

        [XmlElement]
        public string DESIGNATION_PAYS { get; set; }

        [XmlElement]
        public string TARIF_DOUANIER { get; set; }

        [XmlElement]
        public string DESIGNATION_OPERATION { get; set; }

        [XmlElement]
        public string CODE_OPERATION { get; set; }

        [XmlElement]
        public string NUM_DOMICILIATION { get; set; }

        [XmlElement]
        public string DESIGNATION_OPERATEUR { get; set; }

        [XmlElement]
        public string CODE_OPERATEUR { get; set; }

        [XmlElement]
        public string DESIGNATION_DOB { get; set; }

        [XmlElement]
        public string REFERENCE_BANQUE { get; set; }

        [XmlElement]
        public decimal MONTANT { get; set; }

        [XmlElement]
        public decimal COURS_F { get; set; }

        [XmlElement]
        public decimal CONTRE_VALEUR_F { get; set; }

        [XmlElement]
        public string FORMULE { get; set; }

        [XmlElement]
        public string MODE_REGLEMENT { get; set; }
    }
}