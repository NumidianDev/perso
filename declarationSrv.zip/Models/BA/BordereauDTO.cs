using System;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace WebApi.Models.BA {

    [XmlType]
    public class BordereauDTO {

        [XmlIgnore]
        public int Id { get; set; }

        [XmlElement]
        public string TYPE_DECLARATION { get; set; }

        [XmlElement]

        public string SENS_FLUX { get; set; }

        [XmlElement]

        public string BANQUE { get; set; }

        [XmlElement]

        public string MONNAIE { get; set; }

        [XmlElement]

        public decimal MONTANT_GLOBAL { get; set; }

        [XmlElement]

        public int NBR_ENREGISTREMENT { get; set; }

        [XmlElement]

        public DateTime? DATE_VALEUR { get; set; }

        [XmlElement]

        public decimal COURS { get; set; }

        [XmlElement]

        public decimal CONTRE_VALEUR { get; set; }
    }
}