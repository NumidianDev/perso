﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web.Mvc
Imports System.Web.Mvc.Ajax
Imports System.Web.Routing
Imports System.Runtime.CompilerServices
Imports ROC.BaseController

Namespace HtmlHelpers
    Public Module HtmlHelperExtensions

        <Extension()> _
        Public Function AutorizedActionLink(ByVal html As HtmlHelper, ByVal linkText As String, ByVal user As String, ByVal actionName As String, ByVal controllerName As String, ByVal routeValues As Object, ByVal htmlAttributes As Object) As MvcHtmlString
            Dim check As Boolean = IsAllowedActionUser(user, actionName)
            If (check) Then
                Dim url As UrlHelper = New UrlHelper(html.ViewContext.RequestContext)
                Dim attributes As RouteValueDictionary = New RouteValueDictionary(htmlAttributes)
                Dim linkTag As TagBuilder = New TagBuilder("a")
                linkTag.MergeAttributes(attributes)
                linkTag.Attributes.Add("href", url.Action(actionName, controllerName, routeValues))
                linkTag.InnerHtml = System.Web.HttpUtility.HtmlDecode(linkText)
                Return MvcHtmlString.Create(linkTag.ToString(TagRenderMode.Normal))
            End If
            Return Nothing
        End Function
        <Extension()> _
        Public Function AutorizedActionAjaxLink(ajaxHelper As AjaxHelper, ByVal user As String, ByVal linkText As String, ByVal actionName As String, ByVal controllerName As String, ByVal routeValues As Object, ByVal ajaxOptions As AjaxOptions, ByVal htmlAttributes As Object) As MvcHtmlString
            If (IsAllowedActionUser(user, actionName)) Then
                Dim urlHelper As UrlHelper = New UrlHelper(ajaxHelper.ViewContext.RequestContext)
                Dim builder As TagBuilder = New TagBuilder("a")
                builder.InnerHtml = linkText
                builder.MergeAttribute("href", urlHelper.Action(actionName, controllerName, routeValues))
                builder.MergeAttributes(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes))
                builder.MergeAttributes((IIf(IsNothing(ajaxOptions), New AjaxOptions(), ajaxOptions)).ToUnobtrusiveHtmlAttributes())
               return MvcHtmlString.Create(builder.ToString(TagRenderMode.Normal))
            End If
            Return Nothing
        End Function
         
       
    End Module
End Namespace
