﻿
Imports System.Data.Entity
<Authorize>
  Public Class HomeController
    Inherits BaseController
    <OutputCache(Duration:=0, VaryByParam:="none")> _
    Function Index() As ActionResult
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid).ToString()
        Dim incident = db.Incident
        Select Case role
            Case "D"
                Dim Usr = db.Utilisateur.Where(Function(u) u.Fullname.Equals(uid)).FirstOrDefault()
                incident = db.Incident.Where(Function(i) i.Matricule_Creation.Equals(Usr.Matricule))
            Case "CRO"
                incident = db.Incident.Where(Function(i) i.Statut_Final > 2)
            Case "GRO"
                incident = db.Incident.Where(Function(i) i.Statut_Final > 7)
        End Select
        Return View(incident.ToList())
    End Function







End Class
