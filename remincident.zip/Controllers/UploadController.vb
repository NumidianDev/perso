﻿Imports System.IO


Public Class UploadController
    Inherits BaseController

    '
    ' GET: /Dossier
    Private ReadOnly Property StorageRoot(ByVal IdDossier As String, ByVal type As String) As String

        Get
            Dim filePath = ""
            If type = "I" Then
                filePath = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathIncident")).FirstOrDefault().Value & IdDossier))
            Else
                If type = "A" Then
                    filePath = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathAction")).FirstOrDefault().Value & IdDossier))
                End If
            End If
            If (Not System.IO.Directory.Exists(filePath)) Then
                MkDir(filePath)
            End If
            Return filePath
        End Get
    End Property

    Function Document(ByVal Id As Integer?) As ActionResult
        If (Id.HasValue) Then
            ViewBag.evt = Id
        Else
            ViewBag.evt = 0
        End If

        Return PartialView("~/Views/Upload/Upload.vbhtml")
    End Function
    Function PiecesJointesAction(ByVal Id As Integer?) As ActionResult
        If (Id.HasValue) Then
            ViewBag.act = Id
        Else
            ViewBag.act = 0
        End If

        Return PartialView("~/Views/Upload/PiecesJointesAction.vbhtml")
    End Function
    <HttpGet>
    Sub Delete(ByVal IdIncident As String, ByVal id As String)
        Dim filePath = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathIncident")).FirstOrDefault().Value), IdIncident, id)
        If (System.IO.File.Exists(filePath)) Then

            System.IO.File.Delete(filePath)
        End If
    End Sub
    <HttpGet>
    Sub DeleteAction(ByVal IdAction As String, ByVal id As String)
        Dim filePath = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathAction")).FirstOrDefault().Value), IdAction, id)
        If (System.IO.File.Exists(filePath)) Then

            System.IO.File.Delete(filePath)
        End If
    End Sub
    <HttpGet>
    Sub Download(ByVal IdIncident As String, ByVal id As String)
        Dim filename = id
        Dim filePath = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathIncident")).FirstOrDefault().Value), IdIncident, id)
        Dim context = HttpContext
        If (System.IO.File.Exists(filePath)) Then
            context.Response.AddHeader("Content-Disposition", "attachment; filename=""" & filename & """")
            context.Response.ContentType = "application/octet-stream"
            context.Response.ClearContent()
            context.Response.WriteFile(filePath)
        Else
            context.Response.StatusCode = 404
        End If
    End Sub
    <HttpGet>
    Sub DownloadAction(ByVal IdAction As String, ByVal id As String)
        Dim filename = id
        Dim filePath = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathAction")).FirstOrDefault().Value), IdAction, id)
        Dim context = HttpContext
        If (System.IO.File.Exists(filePath)) Then
            context.Response.AddHeader("Content-Disposition", "attachment; filename=""" & filename & """")
            context.Response.ContentType = "application/octet-stream"
            context.Response.ClearContent()
            context.Response.WriteFile(filePath)
        Else
            context.Response.StatusCode = 404
        End If
    End Sub
    Private Function EncodeFile(fileName As String) As String

        Return Convert.ToBase64String(System.IO.File.ReadAllBytes(fileName))
    End Function
    <HttpPost>
    Public Function UploadFiles(ByVal IdIncident As String) As ActionResult

        Dim r = New List(Of ViewDataUploadFilesResult)()
        For Each f In Request.Files
            Dim statuses = New List(Of ViewDataUploadFilesResult)()
            Dim headers = Request.Headers

            If (String.IsNullOrEmpty(headers("X-File-Name"))) Then
                UploadWholeFile(Request, IdIncident, statuses, "I")

            Else
                UploadPartialFile(headers("X-File-Name"), Request, IdIncident, statuses, "I")
            End If
            Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
            result.ContentType = "text/plain"
            Return result
        Next

        Return Json(r)
    End Function
    <HttpPost>
    Public Function UploadFilesAction(ByVal IdAction As String) As ActionResult

        Dim r = New List(Of ViewDataUploadFilesResult)()
        For Each f In Request.Files
            Dim statuses = New List(Of ViewDataUploadFilesResult)()
            Dim headers = Request.Headers

            If (String.IsNullOrEmpty(headers("X-File-Name"))) Then
                UploadWholeFile(Request, IdAction, statuses, "A")

            Else
                UploadPartialFile(headers("X-File-Name"), Request, IdAction, statuses, "A")
            End If
            Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
            result.ContentType = "text/plain"
            Return result
        Next

        Return Json(r)
    End Function
    Function UploadList(ByVal Id As Integer) As ActionResult
        ViewBag.evt = Id
        Return PartialView()
    End Function
    <HttpPost>
    Public Function FilesUploaded(ByVal IdIncident As String) As ActionResult

        Dim statuses = New List(Of ViewDataUploadFilesResult)()
        Dim Chemin As String, Fichier As String
        Chemin = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathIncident")).FirstOrDefault().Value), IdIncident)
        Fichier = Dir(Chemin & "\*.*")
        Do While Len(Fichier) > 0
            statuses.Add(New ViewDataUploadFilesResult() With
        {
            .name = Fichier,
            .size = Fichier.Length,
            .IdDossier = IdIncident
        })
            Fichier = Dir()
        Loop
        Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
        result.ContentType = "text/plain"
        Return result


        Return Json(statuses, JsonRequestBehavior.AllowGet)
    End Function
    <HttpPost>
    Public Function FilesActionUploaded(ByVal IdAction As String) As ActionResult

        Dim statuses = New List(Of ViewDataUploadFilesResult)()
        Dim Chemin As String, Fichier As String
        Chemin = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathAction")).FirstOrDefault().Value), IdAction)
        Fichier = Dir(Chemin & "\*.*")
        Do While Len(Fichier) > 0
            statuses.Add(New ViewDataUploadFilesResult() With
        {
            .name = Fichier,
            .size = Fichier.Length,
            .IdDossier = IdAction
        })
            Fichier = Dir()
        Loop
        Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
        result.ContentType = "text/plain"
        Return result
        Return Json(statuses, JsonRequestBehavior.AllowGet)
    End Function

    <HttpGet>
    Public Function FilesUploadded(ByVal IdIncident As String) As ActionResult

        Dim statuses = New List(Of ViewDataUploadFilesResult)()
        Dim Chemin As String, Fichier As String
        Chemin = Path.Combine(Server.MapPath(db.Parametres.Where(Function(p) p.Cle.Equals("PathIncident")).FirstOrDefault().Value), IdIncident)
        Fichier = Dir(Chemin & "\*.*")
        Do While Len(Fichier) > 0
            statuses.Add(New ViewDataUploadFilesResult() With
        {
            .name = Fichier,
            .size = Fichier.Length,
            .IdDossier = IdIncident
        })
            Fichier = Dir()
        Loop
        Dim result As JsonResult = Json(New With {.files = statuses}, JsonRequestBehavior.AllowGet)
        result.ContentType = "text/plain"
        Return result


        Return Json(statuses, JsonRequestBehavior.AllowGet)
    End Function
    Private Sub UploadPartialFile(fileName As String, request As HttpRequestBase, IdDossier As String, statuses As List(Of ViewDataUploadFilesResult), type As String)

        If (Not request.Files.Count = 1) Then
            Throw New HttpRequestValidationException("Attempt to upload chunked file containing more than one fragment per request")
        End If
        Dim file = request.Files(0)
        Dim inputStream = file.InputStream

        Dim fullName = Path.Combine(StorageRoot(IdDossier, type), Path.GetFileName(fileName))
        Dim fs = New FileStream(fullName, FileMode.Append, FileAccess.Write)
        Using (fs)
            Dim buffer = New Byte(1024) {}
            Dim l = inputStream.Read(buffer, 0, 1024)
            While (l > 0)

                fs.Write(buffer, 0, l)
                l = inputStream.Read(buffer, 0, 1024)
            End While
            fs.Flush()
            fs.Close()
        End Using
        statuses.Add(New ViewDataUploadFilesResult() With
        {
            .name = fileName,
            .size = file.ContentLength,
            .IdDossier = IdDossier,
            .type = file.ContentType,
            .url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & "/Dossier/Download/" & fileName,
            .delete_url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & "/Dossier/Delete/" & fileName,
            .thumbnail = "data:image/png;base64," & EncodeFile(fullName),
        .delete_type = "GET"
        })
    End Sub

    Private Sub UploadWholeFile(request As HttpRequestBase, IdDossier As String, statuses As List(Of ViewDataUploadFilesResult), type As String)
        For i As Integer = 0 To request.Files.Count - 1
            Dim file = request.Files(i)
            Dim fullPath = Path.Combine(StorageRoot(IdDossier, Type), Path.GetFileName(file.FileName))
            file.SaveAs(fullPath)
            statuses.Add(New ViewDataUploadFilesResult() With
            {
                .name = file.FileName,
                .size = file.ContentLength,
                .IdDossier = IdDossier,
                .type = file.ContentType,
                .url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & "/Upload/Download/" & file.FileName,
                .delete_url = request.Url.GetLeftPart(UriPartial.Authority) & IIf("/".Equals(request.ApplicationPath), String.Empty, request.ApplicationPath) & Url.Action("Delete", "Upload", New With {.id = file.FileName}),
                .thumbnail = "data:image/png;base64," & EncodeFile(fullPath),
                .delete_type = "GET"
            })
        Next
    End Sub
    Function Index() As ActionResult
        Return View()
    End Function

End Class