﻿
Imports System.Data.Entity
<Authorize>
Public Class PlanActionController
    Inherits BaseController
   
    
    Function Index(ByVal IdIncident? As Int32) As ActionResult
        If (IdIncident.HasValue) Then
            IdIncident = IdIncident
        Else
            IdIncident = 0
        End If
        Return PartialView(db.Act.Where(Function(a) a.Id_Incident = IdIncident).ToList())
    End Function
    Function IndexPaging(ByVal IdIncident? As Int32) As ActionResult
        If (IdIncident.HasValue) Then
            IdIncident = IdIncident
        Else
            IdIncident = 0
        End If
        Return PartialView(db.Act.Where(Function(a) a.Id_Incident = IdIncident).ToList())
    End Function
    Function IndexDetails(ByVal IdIncident? As Int32) As ActionResult
        If (IdIncident.HasValue) Then
            IdIncident = IdIncident
        Else
            IdIncident = 0
        End If
        Return PartialView(db.Act.Where(Function(a) a.Id_Incident = IdIncident).ToList())
    End Function
    Function Create() As ActionResult
        ViewBag.Code_str_responsable = New SelectList(db.Structures, "code", "Nom")
        Return PartialView()
    End Function
    <HttpPost()> _
   <ValidateAntiForgeryToken()> _
    Function Create(ByVal Act As Act) As JsonResult

        If ModelState.IsValid Then
            Try
                Act.Statut_Act = 9
                db.Act.Add(Act)
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Action/Edit/5

    Function Edit(ByVal id As Int32) As ActionResult
        Dim Action As Act = db.Act.Find(id)
        ViewBag.Code_str_responsable = New SelectList(db.Structures, "code", "Nom", Action.Code_str_responsable)
        If IsNothing(Action) Then
            Return HttpNotFound()
        End If

        Return PartialView(Action)
    End Function
    Function Details(ByVal id As Int32) As ActionResult
        Dim Action As Act = db.Act.Find(id)
        If IsNothing(Action) Then
            Return HttpNotFound()
        End If

        Return PartialView(Action)
    End Function

    '
    ' POST: /Action/Edit/5

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal Act As Act) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Entry(Act).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Action/Delete/5

    Function Delete(ByVal id As Int32) As ActionResult
        Dim Action As Act = db.Act.Find(id)
        If IsNothing(Action) Then
            Return HttpNotFound()
        End If
        Return PartialView(Action)
    End Function

    '
    ' POST: /Action/Delete/5

    <HttpPost()> _
    <ActionName("Delete")> _
    <ValidateAntiForgeryToken()> _
    Function DeleteConfirmed(ByVal id As Int32) As JsonResult
        Try
            Dim Action As Act = db.Act.Find(id)
            db.Act.Remove(Action)
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La suppression est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "no", .message = "Echec de suppression."}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(Nothing, JsonRequestBehavior.AllowGet)
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub
End Class
