﻿Imports System.Data.Entity
<RoleFilter()> _
Public Class StructureController
    Inherits BaseController

    Function Index() As ActionResult
        Dim _s = db.Structures.ToList()
        Return View(_s)
    End Function

    '

    '
    ' GET: /Structures/Create

    Function Create() As ActionResult
        ViewBag.Matricule_resp = New SelectList(db.Utilisateur, "Matricule", "Fullname")
        ViewBag.Correcspondant_principal = New SelectList(db.RoleUtilisateur.Where(Function(u) u.Role.Libelle.Contains("CRO")).Select(Function(u) u.Utilisateur), "Matricule", "Fullname")
        ViewBag.Correspondant_secondaire = New SelectList(db.RoleUtilisateur.Where(Function(u) u.Role.Libelle.Contains("CRO")).Select(Function(u) u.Utilisateur), "Matricule", "Fullname")
        Return PartialView()
    End Function

    '
    ' POST: /Structures/Create

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Create(ByVal Structures As Structures) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Structures.Add(Structures)
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Structures/Edit/5
    <HttpGet()> _
    Function Edit(ByVal id As String) As ActionResult
        Dim Structures As Structures = db.Structures.FirstOrDefault(Function(s) s.Code.Contains(id))
        If IsNothing(Structures) Then
            Return HttpNotFound()
        End If
        Dim sm = db.Structures.Where(Function(m) m.Type < Structures.Type)
        ViewBag.Type = New SelectList(db.TypeStructure, "Id", "Libelle", Structures.Type)
        ViewBag.Code_STR_Mere = New SelectList(sm, "Code", "Nom", Structures.Code_STR_Mere)
        ViewBag.Correcspondant_principal = New SelectList(db.RoleUtilisateur.Where(Function(u) u.Role.Libelle.Contains("CRO")).Select(Function(u) u.Utilisateur), "Matricule", "Fullname", Structures.Correcspondant_principal)
        ViewBag.Correspondant_secondaire = New SelectList(db.RoleUtilisateur.Where(Function(u) u.Role.Libelle.Contains("CRO")).Select(Function(u) u.Utilisateur), "Matricule", "Fullname", Structures.Correspondant_secondaire)
        Return PartialView("~/Views/Structure/Edit.vbhtml", Structures)
    End Function

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal Structures As Structures) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Entry(Structures).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function

    Function Delete(ByVal id As String) As ActionResult
        Dim Structures As Structures = db.Structures.FirstOrDefault(Function(s) s.Code.Contains(id))
        If IsNothing(Structures) Then
            Return HttpNotFound()
        End If
        Return PartialView("~/Views/Structur/Delete.vbhtml", Structures)
    End Function

    '
    ' POST: /Metier/Delete/5

    <HttpPost()> _
    <ActionName("Delete")> _
    <ValidateAntiForgeryToken()> _
    Function DeleteConfirmed(ByVal id As String) As JsonResult
        Try
            Dim str As Structures = db.Structures.FirstOrDefault(Function(s) s.Matricule_resp.Contains(id))
            db.Structures.Remove(str)
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La suppression est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "no", .message = "Echec de suppression."}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(Nothing, JsonRequestBehavior.AllowGet)
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class
