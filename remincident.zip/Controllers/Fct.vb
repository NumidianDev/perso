﻿Imports System
Imports System.IO
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Web.Helpers
Imports System.Net.Mime.MediaTypeNames


Public Class Fct

    Public Shared Function Deltaconnect() As String
        Return System.Configuration.ConfigurationManager.ConnectionStrings("Delta").ConnectionString
    End Function
    Public Shared Function getConnectionString() As String
        Return System.Configuration.ConfigurationManager.ConnectionStrings("Dev").ConnectionString
    End Function
   
   
  

    Public Shared Function getValue(champ As String, table As String, params As String, val As String) As String
        If champ Is Nothing Or table Is Nothing Or params Is Nothing Then
            Return Nothing
        Else
            Dim conn As New SqlConnection
            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = Fct.getConnectionString
            End If
            Dim queryString = "select " & champ & " from " & table & " Where " & params & " = '" & val & "'"
            Dim command = New SqlCommand(queryString, conn)
            Try
                conn.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()
                While reader.Read()
                    Return String.Format("{0}", reader(0))
                End While
            Catch ex As Exception
                Return Nothing
            End Try
        End If
        Return Nothing
    End Function

    Public Shared Function IsValideMail(ByVal str_mail As String) As Boolean
        If (str_mail <> "") Then
            Dim RegexpEmail As New Regex("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")
            Dim bEmailValid As Boolean = RegexpEmail.IsMatch(str_mail)
            Return bEmailValid
        Else
            Return False
        End If
    End Function

    Public Shared Function EnvoiMail(ByVal destinataire As String, ByVal Expediteur As String, ByVal sujet As String, ByVal text As String) As Boolean
        Dim objMessage As System.Net.Mail.MailMessage
        Dim objAdrExp As System.Net.Mail.MailAddress
        Dim objAdrRec As System.Net.Mail.MailAddress
        Dim objSMTPClient As System.Net.Mail.SmtpClient
        Dim smtp As String = ConfigurationManager.AppSettings("smtp")
        Dim ListEmail As Array = destinataire.Split(";")
        Try
            For Each A In ListEmail
                objMessage = New System.Net.Mail.MailMessage()
                objAdrExp = New System.Net.Mail.MailAddress(Expediteur.Trim)
                objAdrRec = New System.Net.Mail.MailAddress(A.Trim)
                ' ADRESSE MAIL DE L EXPEDITEUR
                objMessage.From = objAdrExp
                ' ADRESSE MAIL DU DESTINATAIRE
                objMessage.To.Add(objAdrRec)
                objMessage.IsBodyHtml = True
                objMessage.Subject = sujet
                objMessage.Body = text
                objSMTPClient = New System.Net.Mail.SmtpClient(smtp)
                objSMTPClient.EnableSsl = False
                objSMTPClient.Send(objMessage)
            Next
        Catch ex As Exception
            Return Nothing
        End Try
        Return True
    End Function

  

    Public Shared Function Template(ByVal uri As String) As String
        Dim body As String = String.Empty
        Using sr As StreamReader = New StreamReader(System.Web.HttpContext.Current.Server.MapPath(uri))
            body = sr.ReadToEnd()
        End Using
        Return HttpUtility.HtmlDecode(body)
    End Function

    Public Shared Function setDecimal(value As String) As String
        Dim output As Decimal
        If (Decimal.TryParse(value.ToString(), output)) Then
            Return Replace(output, ",", ".").ToString
        Else
            Return value.ToString()
        End If
    End Function
    Public Shared Function DiffDate(d1 As Date, d2 As Date) As Long
        Dim date2 As Date = Date.Parse(d2)
        Dim date1 As Date = Date.Parse(d1)
        Return DateDiff(DateInterval.Day, date1, date2)
    End Function
    Public Shared Function rmdir(d As String) As Boolean
        Dim dir As New DirectoryInfo(d)
        For Each myFile In dir.GetFiles("*.*")
            If DateDiff("d", myFile.LastWriteTime, Now) > 0 Then
                myFile.Delete()
            End If
        Next myFile
        Return True
    End Function
    Private Shared Function Adaptateur(p1 As String) As Object
        Throw New NotImplementedException
    End Function

End Class
