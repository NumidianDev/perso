﻿Public Class AdministrateurController
    Inherits System.Web.Mvc.Controller

    '
    ' GET: /Administrateur
    Function Index() As ActionResult
        Return Redirect("Utilisateur/Index")
        'Return View()
    End Function

End Class