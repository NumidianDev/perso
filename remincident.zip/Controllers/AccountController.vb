﻿Imports System.Diagnostics.CodeAnalysis
Imports System.Security.Principal
Imports System.Web.Routing
Imports WebMatrix.WebData
Imports ROC.LDAP

<Authorize()> _
Public Class AccountController
    Inherits BaseController

    '
    ' GET: /Account/Login

    <AllowAnonymous()> _
    Public Function Login(ByVal returnUrl As String) As ActionResult
        ViewData("ReturnUrl") = returnUrl
        Return View()
    End Function

    '
    ' POST: /Account/Login

    <HttpPost()> _
    <AllowAnonymous()> _
    <ValidateAntiForgeryToken()> _
    Public Function Login(ByVal model As LoginModel, ByVal returnUrl As String) As ActionResult

        If ModelState.IsValid Then
            'If LdapAuthentication.GetInstance.IsAuthenticated(model.UserName, model.Password) Then
            If WebSecurity.Login(model.UserName, model.Password, persistCookie:=model.RememberMe) Then
                If Url.IsLocalUrl(returnUrl) AndAlso returnUrl.Length > 1 AndAlso returnUrl.StartsWith("/") _
                   AndAlso Not returnUrl.StartsWith("//") AndAlso Not returnUrl.StartsWith("/\\") Then
                    Return Redirect(returnUrl)
                Else
                    Return RedirectToAction("Index", "Incident")
                End If
            Else
                ModelState.AddModelError("", "Vous n'êtes pas autorisé à utiliser cette application ")

            End If
            'Else
            'ModelState.AddModelError("", "Echec d'authentification sur le domaine SGA pour l'utilisateur " & model.UserName)
            'End If

        End If

        Return View(model)

    End Function

    '
    ' POST: /Account/LogOff

    '<ValidateAntiForgeryToken()> _
    Public Function LogOff() As ActionResult
        WebSecurity.Logout()
        'FormsAuthentication.SignOut()
        Return RedirectToAction("Index", "Incident")
    End Function

    Public Function IsAuthenticated(ByVal username As String, ByVal pwd As String) As Boolean



        Try
            Dim result = db.Utilisateur.Where(Function(u) u.Matricule.Equals(username)).FirstOrDefault()
            If (result Is Nothing) Then
                Return False
            End If

            Return True
        Catch ex As Exception

            Return False

        End Try

    End Function

    '
    ' GET: /Account/Manage

    Public Function Manage(ByVal mat As String) As ActionResult
        Return View()
    End Function

    <ChildActionOnly()>
    Public Function getInfos() As String
        Dim mat As String = User.Identity.Name
        If Not mat Is Nothing Then
            Return Fct.getValue("Prenom", "RI_Utilisateur", "Matricule", mat)
        End If
        Return "Anonumous"
    End Function



#Region "Helpers"
    Private Function RedirectToLocal(ByVal returnUrl As String) As ActionResult
        If Url.IsLocalUrl(returnUrl) Then
            Return Redirect(returnUrl)
        Else
            Return RedirectToAction("Index", "Home")
        End If
    End Function

    Public Enum ManageMessageId
        ChangePasswordSuccess
        SetPasswordSuccess
        RemoveLoginSuccess
    End Enum



    Public Function ErrorCodeToString(ByVal createStatus As MembershipCreateStatus) As String
        ' See http://go.microsoft.com/fwlink/?LinkID=177550 for
        ' a full list of status codes.
        Select Case createStatus
            Case MembershipCreateStatus.DuplicateUserName
                Return "User name already exists. Please enter a different user name."

            Case MembershipCreateStatus.DuplicateEmail
                Return "A user name for that e-mail address already exists. Please enter a different e-mail address."

            Case MembershipCreateStatus.InvalidPassword
                Return "The password provided is invalid. Please enter a valid password value."

            Case MembershipCreateStatus.InvalidEmail
                Return "The e-mail address provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidAnswer
                Return "The password retrieval answer provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidQuestion
                Return "The password retrieval question provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.InvalidUserName
                Return "The user name provided is invalid. Please check the value and try again."

            Case MembershipCreateStatus.ProviderError
                Return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator."

            Case MembershipCreateStatus.UserRejected
                Return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator."

            Case Else
                Return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator."
        End Select
    End Function
#End Region

End Class
