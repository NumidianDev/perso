﻿Imports System.Data.Entity
<RoleFilter()> _
Public Class CategorieController
    Inherits BaseController
    '
    ' GET: /Categorie/

    Function Index() As ActionResult
        Return View(db.Categorie.ToList())
    End Function

    '
    ' GET: /Categorie/Details/5

    Function Details(ByVal id As String) As ActionResult
        Dim Categorie As Categorie = db.Categorie.Find(id)
        If IsNothing(Categorie) Then
            Return HttpNotFound()
        End If
        Return View(Categorie)
    End Function

    '
    ' GET: /Categorie/Create

    Function Create() As ActionResult
     
        Return PartialView()
    End Function

    '
    ' POST: /Categorie/Create

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Create(ByVal Categorie As Categorie) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Categorie.Add(Categorie)
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Categorie/Edit/5

    Function Edit(ByVal id As Int32) As ActionResult
        Dim Categorie As Categorie = db.Categorie.Find(id)
        If IsNothing(Categorie) Then
            Return HttpNotFound()
        End If

        Return PartialView(Categorie)
    End Function

    '
    ' POST: /Metier/Edit/5

    <HttpPost()> _
    <ValidateAntiForgeryToken()> _
    Function Edit(ByVal Categorie As Categorie) As JsonResult
        If ModelState.IsValid Then
            Try
                db.Entry(Categorie).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .message = "La modification est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de modification."}, JsonRequestBehavior.AllowGet)
    End Function

    '
    ' GET: /Metier/Delete/5

    Function Delete(ByVal id As int32) As ActionResult
        Dim Categorie As Categorie = db.Categorie.Find(id)
        If IsNothing(Categorie) Then
            Return HttpNotFound()
        End If
        Return PartialView(Categorie)
    End Function

    '
    ' POST: /Metier/Delete/5

    <HttpPost()> _
    <ActionName("Delete")> _
    <ValidateAntiForgeryToken()> _
    Function DeleteConfirmed(ByVal id As Int32) As JsonResult
        Try
            Dim catégories As Categorie = db.Categorie.Find(id)
            db.Categorie.Remove(catégories)
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La suppression est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "no", .message = "Echec de suppression."}, JsonRequestBehavior.AllowGet)
        End Try
        Return Json(Nothing, JsonRequestBehavior.AllowGet)
    End Function

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        db.Dispose()
        MyBase.Dispose(disposing)
    End Sub

End Class