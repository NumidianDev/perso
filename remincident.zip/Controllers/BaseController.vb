﻿Imports System.IO

Public Class BaseController
    Inherits System.Web.Mvc.Controller

    Protected Friend db As DB

    Protected Overrides Sub Initialize(requestContext As RequestContext)
        MyBase.Initialize(requestContext)
        db = New DB()
    End Sub
    Public Shared Function IsAllowedActionUser(ByVal user As String, ByVal action As String) As Boolean
        Dim db = New DB()
        Dim check = False
        If (IsNothing(user)) Then
            check = False
        Else
            Dim act = db.Action.Where(Function(r) r.Libelle.ToLower().Equals(action.ToLower())).FirstOrDefault()
            If (Not IsNothing(act)) Then
                Dim RoleUser = Roles.GetRolesForUser(user)
                For Each Role In RoleUser
                    Dim actionRoles = db.ActionRole.FirstOrDefault(Function(r) r.Role.Libelle.ToLower().Equals(Role.ToLower()) And r.Id_Action.Equals(act.Id))
                    If Not IsNothing(actionRoles) Then
                        check = True
                        Exit For
                    End If
                Next
            End If
        End If
        Return check

    End Function
 
    Public Function GetCounter(CounterPath As String) As String
        Dim sr = New StreamReader(CounterPath)
        Dim line As String = sr.ReadLine()
        Dim counter As Integer = Convert.ToInt16(line.Split("|"c)(0))
        Dim year As Integer = Convert.ToInt16(line.Split("|"c)(1))
        sr.Close()
        If DateTime.Now.Year <> year Then
            Return "0001"
        Else
            counter += 1
            Dim NewCounter As String = String.Format("{0:0000}", counter)
            Dim sw = New StreamWriter(CounterPath)
            Dim text As String = NewCounter & "|" & DateTime.Now.[Date].Year.ToString()
            sw.WriteLine(text)
            sw.Close()
            Return NewCounter
        End If

    End Function
End Class
