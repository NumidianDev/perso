﻿
Imports System.Data.Entity
<Authorize>
Public Class SuiviPlanActionController
    Inherits BaseController
    <OutputCache(Duration:=0, VaryByParam:="none")> _
    Function IndexSuivi() As ActionResult
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid)
        Dim incident = New List(Of Incident)()
        Dim incident1 = New List(Of Incident)()
        Dim incident2 = New List(Of Incident)()
        Dim inc = New List(Of Incident)()
        If role.Contains("CRO") Then
            incident = db.Incident.Where(Function(i) i.Statut_Final = 7 And (i.Utilisateur.str.Correcspondant_principal.Equals(uid) Or i.Utilisateur.str.Correspondant_secondaire.Equals(uid))).ToList()
        End If
        If role.Contains("CON") Then
            incident1 = db.Incident.Where(Function(i) i.Statut_Final = 7 And i.Conformite = True).ToList()
        End If
        If role.Contains("GRO") Or role.Contains("Consultation") Then
            incident2 = db.Incident.Where(Function(i) i.Statut_Final = 7).ToList()
        End If     
        ViewBag.role = role.ToList()
        inc = incident.Union(incident1).Union(incident2).ToList()
        Return View(inc.OrderByDescending(Function(u) u.Id))
    End Function
    <HttpGet()> _
    Function DetailsInfoImpactEvenement(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)
    End Function
    Function Details(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)
    End Function
    Function Edit(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)

    End Function
    Function IndexAction(ByVal id? As Int32) As ActionResult
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid)
        Dim Action = New List(Of Act)()
        Dim Action1 = New List(Of Act)()
        Dim Action2 = New List(Of Act)()
        Dim Action3 = New List(Of Act)()
        If (role.Contains("CRO") Or role.Contains("CON")) Then
            Action1 = db.Act.Where(Function(i) i.Id_Incident = id And i.Statut_Act > 8).ToList()
        End If
        If Role.Contains("GRO") Then
            Action2 = db.Act.Where(Function(i) i.Id_Incident = id And i.Statut_Act >= 9).ToList()
        End If
        If role.Contains("Consultation") Then
            Action3 = db.Act.Where(Function(i) i.Id_Incident = id).ToList()
        End If
        ViewBag.role = role.ToList()
        Action = Action1.Union(Action2).Union(Action3).ToList()
        Return PartialView(Action)
    End Function
    <HttpGet()> _
    Function DemandeCloture(ByVal id As Int32) As ActionResult
        Dim Act = db.Act.Find(id)
        ViewBag.titre = "Demande de clôture"
        Return PartialView(Act)
    End Function
    '--- close evt
    <HttpPost()> _
    Function DemandeCloture(ByVal fc As FormCollection) As ActionResult
        Dim id = Convert.ToInt32(fc("Id"))
        Dim uid As String = User.Identity.Name
        Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim role = Roles.GetRolesForUser(uid)
        Dim Act = db.Act.Find(id)
        Act.date_Cloture = Date.Now
        Dim usrreceiv = db.RoleUtilisateur.Where(Function(u) u.Role.Libelle.Contains("GRO")).Select(Function(u) u.Utilisateur)
        'Dim usrreceiv = db.RoleUtilisateur.Where(Function(u) u.RoleId.Equals(3)).ToList().Select(Function(u) u.Utilisateur).ToArray
        ADDStatutHis(id, 10, fc("Commentaire"))
        Act.Statut_Act = 10
        db.Entry(Act).State = EntityState.Modified
        db.SaveChanges()
        Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Action_a_cloturer.htm"
        Dim mailObjet = "Objet : OUTIL DECLARATION INCIDENTS RO : Action à clôturer "
        If Not usr Is Nothing Then
            Dim text As String = (String.Format(Fct.Template(path), Act.Id_Incident, System.Web.HttpUtility.HtmlEncode(fc("Commentaire"))))
            For Each _mail In usrreceiv
                If Not usr.Email Is Nothing Then
                    Fct.EnvoiMail(_mail.Email, usr.Email, mailObjet, text)
                End If
            Next
        End If

        Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
    End Function
    <HttpGet()> _
    Function RejeterAction(ByVal id As Int32) As ActionResult
        Dim Act = db.Act.Find(id)
        Return PartialView(Act)
    End Function
    <HttpPost()> _
    Function RejeterAction(ByVal fc As FormCollection) As ActionResult
        Dim id = Convert.ToInt32(fc("Id"))
        Dim uid As String = User.Identity.Name
        Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim role = Roles.GetRolesForUser(uid)
        Dim Act = db.Act.Find(id)
        Act.date_Cloture = Date.Now
        If Act.Incident.Conformite Then
            usrreceiv = db.RoleUtilisateur.FirstOrDefault(Function(u) u.Role.Libelle.Contains("GRO")).Utilisateur
        Else
            usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(Act.Incident.Utilisateur.str.Correcspondant_principal))
        End If
        ADDStatutHis(id, 12, fc("Commentaire"))
        Act.Statut_Act = 12
        db.Entry(Act).State = EntityState.Modified
        db.SaveChanges()
        Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Rejet_demande_cloture_incident.htm"
        Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO : Validation clôture incident"
        If Not usr Is Nothing Then
            Dim text As String = (String.Format(Fct.Template(path), Act.Id_Incident, System.Web.HttpUtility.HtmlEncode(fc("Commentaire"))))
            If Not usr.Email Is Nothing Then
                Fct.EnvoiMail(usrreceiv.Email, usr.Email, mailObjet, text)
            End If
        End If
        'Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Return Redirect("~/SuiviPlanAction/IndexAction/" & Act.Id_Incident)
    End Function
    Sub ADDStatutHis(ByVal Id As Int32, ByVal IdStatut As Int32, commentaire As String)
        Dim statut_his = New StatutHis
        statut_his.Date_heure = DateTime.Now()
        statut_his.Id_Inc_Act = Id
        statut_his.Id_Statut = IdStatut
        statut_his.Commentaire = commentaire
        db.StatutHis.Add(statut_his)
        db.SaveChanges()
    End Sub
    Sub ClotureIncident(ByVal evt As Incident)
        Dim act = db.Act.Where(Function(i) i.Id_Incident = evt.Id).Count
        Dim act_clotu = db.Act.Where(Function(i) i.Id_Incident = evt.Id And {11, 12, 13}.Contains(i.Statut_Act)).Count
        If (act = act_clotu) Then
            Dim _i As Incident = db.Incident.Find(evt.Id)
            ADDStatutHis(evt.Id, 5, "Clôture automatique")
            _i.Statut_Final = "15"
            db.Entry(_i).State = EntityState.Modified
            db.SaveChanges()
        End If
    End Sub
    <HttpGet()> _
    Function ValiderAction(ByVal Id As Int32) As ActionResult
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid)
        Dim Act = db.Act.Find(Id)
        Dim usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(Act.Incident.Utilisateur.str.Correcspondant_principal))
        If Act.Incident.Conformite Then
            usrreceiv = db.RoleUtilisateur.FirstOrDefault(Function(u) u.Role.Libelle.Contains("GRO")).Utilisateur
        End If
        ADDStatutHis(Id, 11, "")
        Act.Statut_Act = 11
        db.Entry(Act).State = EntityState.Modified
        db.SaveChanges()
        ClotureIncident(Act.Incident)
        ' Deleted by lmulud le 
        'Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        ' modified by lmulud
        Dim usr = db.Utilisateur.Where(Function(u) u.Matricule.Equals(uid)).ToArray
        Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Validation_cloture_incident.htm"
        Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO : Validation clôture incident"
        If Not usr Is Nothing Then
            Dim text As String = (String.Format(Fct.Template(path), Act.Id_Incident, "de clôture"))
            For Each _u In usr
                If Not _u.Email Is Nothing Then
                    Fct.EnvoiMail(usrreceiv.Email, _u.Email, mailObjet, text)
                End If
            Next
        End If
        'Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Return Redirect("~/SuiviPlanAction/IndexAction/" & Act.Id_Incident)
    End Function
    <HttpGet()> _
    Function AbandonnerAction(ByVal Id As Int32) As ActionResult
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid)
        Dim Act = db.Act.Find(Id)
        Dim usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(Act.Incident.Utilisateur.str.Correcspondant_principal))
        If Act.Incident.Conformite Then
            usrreceiv = db.RoleUtilisateur.FirstOrDefault(Function(u) u.Role.Libelle.Contains("CON")).Utilisateur
        End If
        ADDStatutHis(Id, 13, "")
        Act.Statut_Act = 13
        db.Entry(Act).State = EntityState.Modified
        db.SaveChanges()
        ClotureIncident(Act.Incident)
        Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Demande_abandon.htm"
        Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO : Action à clôturer "
        If Not usr Is Nothing Then
            Dim text As String = (String.Format(Fct.Template(path), Act.Id_Incident, "d'abandon"))
            If Not usr.Email Is Nothing Then
                Fct.EnvoiMail(usrreceiv.Email, usr.Email, mailObjet, text)
            End If
        End If
        'Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Return Redirect("~/SuiviPlanAction/IndexAction/" & Act.Id_Incident)
    End Function
    <HttpGet()> _
    Function EditInfoImpactEvenement(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        ViewBag.Id_Cat = New SelectList(db.Categorie, "Id", "Libelle", incident.sous_Cat.Id_cat)
        ViewBag.Id_sous_Cat = New SelectList(db.Sous_Categorie, "Id", "Libelle", incident.Id_sous_Cat)
        Return PartialView(incident)
    End Function
    <HttpPost()> _
    Function EditInfoImpactEvenement(ByVal evt As Incident, ByVal fc As FormCollection) As ActionResult
        Try
            Dim idInciden = Convert.ToInt32(fc("Id"))
            Dim incident = db.Incident.Find(idInciden)
            'incident.Conformite = evt.Conformite
            'incident.ref_caroline = evt.ref_caroline
            'incident.perte_credit = evt.perte_credit
            'incident.Id_sous_Cat = evt.Id_sous_Cat
            incident.Proprietaire = User.Identity.Name.ToString()
            db.Entry(incident).State = EntityState.Modified
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            ModelState.AddModelError("", ex.Message)
            Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
        End Try
    End Function
    <HttpGet()> _
    Function DemandeAbandon(ByVal id As Int32) As ActionResult
        Dim Act = db.Act.Find(id)
        ViewBag.titre = "Demande d'abandon"
        Return PartialView(Act)
    End Function
    <HttpPost()> _
    Function DemandeAbandon(ByVal fc As FormCollection) As ActionResult
        Dim id = Convert.ToInt32(fc("Id"))
        Dim uid As String = User.Identity.Name
        Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim role = Roles.GetRolesForUser(uid)
        Dim Act = db.Act.Find(id)
        Dim usrreceiv = db.RoleUtilisateur.FirstOrDefault(Function(u) u.Role.Libelle.Contains("GRO")).Utilisateur
        ADDStatutHis(id, 14, fc("Commentaire"))
        Act.Statut_Act = 14
        db.Entry(Act).State = EntityState.Modified
        db.SaveChanges()
        Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Demande_abandon.htm"
        Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO : Demande d'abandon "
        If Not usr Is Nothing Then
            Dim text As String = (String.Format(Fct.Template(path), Act.Id_Incident, "d'abandon"))
            If Not usr.Email Is Nothing Then
                Fct.EnvoiMail(usrreceiv.Email, usr.Email, mailObjet, text)
            End If
        End If
        Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
    End Function
    Function EditAction(ByVal id As Int32) As ActionResult
        Dim Action As Act = db.Act.Find(id)
        ViewBag.Code_str_responsable = New SelectList(db.Structures, "code", "Nom", Action.Code_str_responsable)
        If IsNothing(Action) Then
            Return HttpNotFound()
        End If

        Return PartialView(Action)
    End Function
    Sub ActionDateEcheance()
        Dim jours = db.Parametres.Where(Function(p) p.Cle.Equals("DateEcheance")).FirstOrDefault().Value
        Dim delai = Convert.ToDouble(jours)
        Dim da_te = DateTime.Now.AddDays(delai)
        'Dim actions = db.Act.Where(Function(a) a.Date_realisation)
    End Sub

    
End Class
