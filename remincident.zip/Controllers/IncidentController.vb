﻿
Imports System.Data.Entity
<Authorize>
Public Class IncidentController
    Inherits BaseController
    '---
    <OutputCache(VaryByParam:="*", Duration:=0, NoStore:=True)> _
    Function Index() As ActionResult
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid)
        Dim incident = New List(Of Incident)()
        Dim incident1 = New List(Of Incident)()
        Dim incident2 = New List(Of Incident)()
        Dim incident3 = New List(Of Incident)()
        Dim incident4 = New List(Of Incident)()
        Dim inc = New List(Of Incident)()
        If role.Contains("D") Then
            incident = db.Incident.Where(Function(i) i.Matricule_Creation.Equals(uid) And Not {4, 8}.Contains(i.Statut_Final)).ToList()
        End If
        If role.Contains("CRO") Then
            incident1 = db.Incident.Where(Function(i) i.Statut_Final > 1 And Not {4, 8}.Contains(i.Statut_Final) And (i.Utilisateur.str.Correcspondant_principal.Equals(uid) Or i.Utilisateur.str.Correspondant_secondaire.Equals(uid))).ToList()
        End If
        If role.Contains("GRO") Then
            incident2 = db.Incident.Where(Function(i) {5, 6, 15}.Contains(i.Statut_Final)).ToList()
        End If
        If role.Contains("CON") Then
            incident3 = db.Incident.Where(Function(i) {16, 17}.Contains(i.Statut_Final)).ToList()
        End If
        If role.Contains("Consultation") Then
            incident4 = db.Incident.ToList()
        End If
        inc = incident.Union(incident1).Union(incident2).Union(incident3).Union(incident4).ToList()
        ViewBag.role = role.ToList()
        Return View(inc.ToList().OrderByDescending(Function(u) u.Id))
    End Function
    Function Create() As ActionResult
        Return PartialView()
    End Function
    Function Confirmation(ByVal Id As Integer) As ActionResult
        ViewBag.IdIncident = Id
        Return PartialView()
    End Function
    Function Edit(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)

    End Function
    <HttpGet()> _
    Function CreateEvenement() As ActionResult
        ViewBag.Id_Origine = New SelectList(db.Origine.OrderByDescending(Function(O) O.Id), "Id", "Libelle")
        ViewBag.Id_Process = New SelectList(db.Process, "Id", "Libelle")
        ViewBag.Id_Sous_Process = New SelectList(db.SousProcess, "Id", "Libelle")
        ViewBag.Id_SourceRemonte = New SelectList(db.SourceRemonte, "Id", "Libelle")
        Dim r = Roles.GetRolesForUser(User.Identity.Name).ToList()
        If r.IndexOf("GRO") = -1 Then
            Return PartialView()
        Else
            Return PartialView("~/Views/Incident/GRO/CreateEvenement.vbhtml")
        End If

    End Function
    Sub ADDStatutHis(ByVal Id As Int32, ByVal IdStatut As Int32, commentaire As String)
        Dim statut_his = New StatutHis
        statut_his.Date_heure = DateTime.Now()
        statut_his.Id_Inc_Act = Id
        statut_his.Id_Statut = IdStatut
        statut_his.Commentaire = commentaire
        db.StatutHis.Add(statut_his)
        db.SaveChanges()
    End Sub
    <HttpPost()> _
    Function CreateEvenement(ByVal evt As Incident) As ActionResult
        If ModelState.IsValid Then
            Try
                Dim uid As String = User.Identity.Name.ToString()
                '__get Code_Str from User
                Dim _codeStr As String = db.Utilisateur.Where(Function(m) m.Matricule.Equals(uid)).FirstOrDefault().Code_Str

                evt.Id_Origine = If(IsNothing(evt.Id_Origine), 5, evt.Id_Origine)
                evt.Matricule_Creation = uid
                evt.Proprietaire = uid
                evt.Statut_Final = 1
                evt.Code_Str = _codeStr
                evt.Date_declaration = Date.Now()
                db.Incident.Add(evt)
                db.SaveChanges()
                ADDStatutHis(evt.Id, 1, "")
                Return Json(New With {.result = "ok", .Id = evt.Id, .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                ModelState.AddModelError("", ex.StackTrace)
                ModelState.AddModelError("", ex.Message)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
    End Function
    <HttpGet()> _
    Function CreateActionCorrect() As ActionResult
        Return PartialView()
    End Function
    <HttpPost()> _
    Function CreateActionCorrect(ByVal evt As Incident, ByVal fc As FormCollection) As ActionResult
        Try
            Dim idInciden = Convert.ToInt32(fc("IdVal"))
            Dim incident = db.Incident.Find(idInciden)
            db.Entry(incident).State = EntityState.Modified
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            ModelState.AddModelError("", ex.Message)
            Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
        End Try
    End Function
    <HttpGet()> _
    Function CreateInfoImpact() As ActionResult
        ViewBag.Nature_Impact = New SelectList(db.Nature_Impact.OrderByDescending(Function(O) O.Id), "Id", "Libelle")
        Return PartialView()
    End Function
    <HttpPost()> _
    Function CreateInfoImpact(ByVal evt As Incident, ByVal fc As FormCollection) As ActionResult
        Try
            Dim idInciden = Convert.ToInt32(fc("IdValeur"))
            Dim incident = db.Incident.Find(idInciden)
            incident.Impact_financier = evt.Impact_financier
            incident.Nature_Impact = evt.Nature_Impact
            incident.Montant_declarer = evt.Montant_declarer
            incident.ref_debit = evt.ref_debit
            incident.ref_credit = evt.ref_credit
            incident.Montant_estime = evt.Montant_estime
            incident.Montant_effectif = evt.Montant_effectif
            incident.ref_credit_eff = evt.ref_credit_eff
            incident.ref_debit_eff = evt.ref_debit_eff
            db.Entry(incident).State = EntityState.Modified
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            ModelState.AddModelError("", ex.Message)
            Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
        End Try
    End Function
    <HttpGet()>
    Function EditEvenement(ByVal id As Int32) As ActionResult

        Dim incident = db.Incident.Find(id)
        Dim r = Roles.GetRolesForUser(User.Identity.Name).ToList()
        Try
            ViewBag.Statut_Final = incident.Statut_Final
            ViewBag.Proprietaire = incident.Proprietaire
            ViewBag.Matricule_Creation = incident.Matricule_Creation
            ViewBag.Id_Origine = New SelectList(db.Origine.OrderByDescending(Function(O) O.Id), "Id", "Libelle", incident.Id_Origine)
            ViewBag.Id_SourceRemonte = New SelectList(db.SourceRemonte, "Id", "Libelle", incident.Id_SourceRemonte)
        Catch ex As Exception
            'ModelState.AddModelError("", ex.Message)
            ViewBag.Id_Origine = New SelectList(db.Origine.OrderByDescending(Function(O) O.Id), "Id", "Libelle")
            ViewBag.Id_SourceRemonte = New SelectList(db.SourceRemonte, "Id", "Libelle")
        End Try
        Try
            ViewBag.Id_Process = New SelectList(db.Process, "Id", "Libelle", incident.SousProcess.Process.Id)
            ViewBag.Id_Sous_Process = New SelectList(db.SousProcess, "Id", "Libelle", incident.Id_Sous_Process)
        Catch ex As Exception
            ViewBag.Id_Process = New SelectList(db.Process, "Id", "Libelle")
            ViewBag.Id_Sous_Process = New SelectList(db.SousProcess, "Id", "Libelle")
        End Try
        If r.IndexOf("GRO") = -1 Then
            Return PartialView(incident)
        Else
            Return PartialView("~/Views/Incident/GRO/EditEvenement.vbhtml", incident)
        End If
    End Function
    <HttpPost()> _
    Function EditEvenement(ByVal evt As Incident) As ActionResult
        If ModelState.IsValid Then
            Try

                Dim incident = db.Incident.Find(evt.Id)
                incident.Date_declaration = evt.Date_declaration
                incident.Date_debut = evt.Date_debut
                incident.Date_decouverte = evt.Date_decouverte
                incident.Id_Sous_Process = evt.Id_Sous_Process
                incident.Id_Origine = evt.Id_Origine
                incident.Origine_Detction = evt.Origine_Detction
                incident.Detail = evt.Detail
                incident.NatureCause = evt.NatureCause
                incident.Id_SourceRemonte = evt.Id_SourceRemonte
                incident.Regle_int_ext = evt.Regle_int_ext
                incident.Proprietaire = User.Identity.Name.ToString()

                db.Entry(incident).State = EntityState.Modified
                db.SaveChanges()
                Return Json(New With {.result = "ok", .Id = evt.Id, .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
            Catch ex As Exception
                Return Json(New With {.result = "no", .message = "Echec de création," & ex.StackTrace}, JsonRequestBehavior.AllowGet)
            End Try
        End If
        Return Json(New With {.result = "no", .message = "Echec de création,"}, JsonRequestBehavior.AllowGet)
    End Function
    <HttpGet()> _
    Function EditActionCorrect(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)
    End Function
    <HttpPost()> _
    Function EditActionCorrect(ByVal evt As Incident, ByVal fc As FormCollection) As ActionResult
        Try
            Dim idInciden = Convert.ToInt32(fc("IdVal"))
            Dim incident = db.Incident.Find(idInciden)
            db.Entry(incident).State = EntityState.Modified
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            ModelState.AddModelError("", ex.Message)
            Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
        End Try
    End Function
    <HttpGet()> _
    Function EditInfoImpact(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        ViewBag.Nature_Impact = New SelectList(db.Nature_Impact.OrderByDescending(Function(O) O.Id), "Id", "Libelle", incident.Nature_Impact)
        Return PartialView(incident)
    End Function
    <HttpPost()> _
    Function EditImpact(ByVal evt As Incident, ByVal fc As FormCollection) As ActionResult
        Try
            Dim idInciden = Convert.ToInt32(fc("IdValeur"))
            Dim incident = db.Incident.Find(idInciden)
            incident.Impact_financier = evt.Impact_financier
            incident.Nature_Impact = evt.Nature_Impact
            incident.Montant_declarer = evt.Montant_declarer
            incident.ref_debit = evt.ref_debit
            incident.ref_credit = evt.ref_credit
            incident.Montant_estime = evt.Montant_estime
            incident.Montant_effectif = evt.Montant_effectif
            incident.ref_credit_eff = evt.ref_credit_eff
            incident.ref_debit_eff = evt.ref_debit_eff
            db.Entry(incident).State = EntityState.Modified
            db.SaveChanges()
            Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            ModelState.AddModelError("", ex.Message)
            Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
        End Try
    End Function

    <HttpPost()>
    Function SoumettreValidation(ByVal IdIncident As Int32) As ActionResult
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid)
        Dim incident = db.Incident.Find(IdIncident)
        Dim usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim A As String = usrreceiv.Email
        Try
            If role.Contains("GRO") Then
            Else
                If role.Contains("D") Then
                    ADDStatutHis(IdIncident, 2, "")
                    incident.Statut_Final = 2
                    Dim cs = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid)).Code_Str
                    Dim str = db.Structures.FirstOrDefault(Function(u) u.Code.Equals(cs))
                    usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(str.Correcspondant_principal))
                    Dim uCS = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(str.Correspondant_secondaire))
                    A = usrreceiv.Email.ToString() ' + ";" + uCS.Email.ToString()
                End If
                If role.Contains("CRO") Then
                    If incident.Conformite.Equals(True) Then
                        ADDStatutHis(IdIncident, 16, "")
                        incident.Statut_Final = 16
                        Dim ugro = db.RoleUtilisateur.Include(Function(u) u.Role).Where(Function(r) r.Role.Libelle.Contains("CON")).ToList().Select(Function(u) u.Utilisateur.Email)
                        Dim _s As String = ""
                        For Each i In ugro
                            _s += i + ";"
                        Next
                        A = _s
                    Else
                        ADDStatutHis(IdIncident, 5, "")
                        incident.Statut_Final = 5
                        Dim ugro = db.RoleUtilisateur.Include(Function(u) u.Role).Where(Function(r) r.Role.Libelle.Contains("GRO")).ToList().Select(Function(u) u.Utilisateur.Email)
                        Dim _s As String = ""
                        For Each i In ugro
                            _s += i + ";"
                        Next
                        A = _s
                    End If
                End If
                Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
                Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Incident_a_valider.htm"
                Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO :  Incident à valider"
                If Not usr Is Nothing Then
                    Dim text As String = (String.Format(Fct.Template(path), incident.Id))
                    If Not A Is Nothing Then
                        Fct.EnvoiMail(A, usr.Email, mailObjet, text)
                    End If
                End If
            End If
            db.Entry(incident).State = EntityState.Modified
            db.SaveChanges()
            If role.Contains("GRO") Then
                Return Json(New With {.result = "GRO", .message = "L'événement est modifié."}, JsonRequestBehavior.AllowGet)
            End If
            '------------
            'Return RedirectToAction("Index", "Incident")
            Return Json(New With {.result = "ok", .message = "L'événement est soumis à la validation."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            Return Json(New With {.result = "ko", .message = ex.Message}, JsonRequestBehavior.AllowGet)
        End Try
    End Function
    <HttpGet()> _
    Function Rejeter(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)
    End Function
    <HttpPost()> _
    Function Rejeter(ByVal fc As FormCollection) As ActionResult
        Dim id = Convert.ToInt32(fc("Id"))
        Dim uid As String = User.Identity.Name
        Dim role = Roles.GetRolesForUser(uid)
        Dim incident = db.Incident.Find(id)
        Dim usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        If role.Contains("CRO") Then
            usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(incident.Matricule_Creation))
            ADDStatutHis(id, 4, fc("Commentaire"))
            incident.Statut_Final = 4
        End If
        If role.Contains("GRO") Or role.Contains("CON") Then
            usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(incident.Utilisateur.str.Correcspondant_principal))
            ADDStatutHis(id, 8, fc("Commentaire"))
            incident.Statut_Final = 8
        End If
        incident.Statut_ROC = "N"
        incident.Proprietaire = User.Identity.Name.ToString()
        db.Entry(incident).State = EntityState.Modified
        db.SaveChanges()
        Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Incident_rejete.htm"
        Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO : Incident rejeté"
        If Not usr Is Nothing Then
            Dim text As String = (String.Format(Fct.Template(path), incident.Id, System.Web.HttpUtility.HtmlEncode(fc("Commentaire"))))
            If Not usr.Email Is Nothing Then
                Fct.EnvoiMail(usrreceiv.Email, usr.Email, mailObjet, text)
            End If
        End If
        Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
    End Function
    <HttpGet()> _
    Function ComplementInfo(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)
    End Function
    <HttpPost()> _
    Function ComplementInfo(ByVal fc As FormCollection) As ActionResult
        Dim id = Convert.ToInt32(fc("Id"))
        Dim uid As String = User.Identity.Name
        Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        Dim role = Roles.GetRolesForUser(uid)
        Dim incident = db.Incident.Find(id)
        Dim usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
        If role.Contains("CRO") Then
            usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(incident.Matricule_Creation))
            ADDStatutHis(id, 3, fc("Commentaire"))
            incident.Statut_Final = 3
        End If
        If role.Contains("GRO") Then
            usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(incident.Utilisateur.str.Correcspondant_principal))
            ADDStatutHis(id, 6, fc("Commentaire"))
            incident.Statut_Final = 6
        End If
        If role.Contains("CON") Then
            usrreceiv = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(incident.Utilisateur.str.Correcspondant_principal))
            ADDStatutHis(id, 17, fc("Commentaire"))
            incident.Statut_Final = 17
        End If
        incident.Proprietaire = User.Identity.Name.ToString()
        db.Entry(incident).State = EntityState.Modified
        db.SaveChanges()
         Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Demande_complements_dinformations.htm"
        Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO : Demande compléments d'informations"
        If Not usr Is Nothing Then
            Dim text As String = (String.Format(Fct.Template(path), incident.Id, System.Web.HttpUtility.HtmlEncode(fc("Commentaire"))))
            If Not usr.Email Is Nothing Then
                Fct.EnvoiMail(usrreceiv.Email, usr.Email, mailObjet, text)
            End If
        End If

        Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
    End Function
    Function Details(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)

        Return PartialView(incident)
    End Function
    <HttpGet()> _
    Function DetailsEvenement(ByVal id As Int32) As ActionResult
        Dim r = Roles.GetRolesForUser(User.Identity.Name).ToList()
        Dim incident = db.Incident.Find(id)
        If r.IndexOf("GRO") = -1 Then
            Return PartialView(incident)
        Else
            Return PartialView("~/Views/Incident/GRO/DetailsEvenement.vbhtml", incident)
        End If
    End Function
    <HttpGet()> _
    Function DetailsActionCorrect(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Try
            ViewBag.Commentaire = db.StatutHis.Where(Function(s) s.Id_Inc_Act = id And s.Id_Statut = incident.Statut_Final).OrderByDescending(Function(i) i.Id).FirstOrDefault().Commentaire
        Catch ex As Exception
            ViewBag.Commentaire = Nothing
        End Try
              Return PartialView(incident)
    End Function
    <HttpGet()> _
    Function DetailsInfoImpact(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        Return PartialView(incident)
    End Function
    <HttpGet()> _
    Function Valider(ByVal id As Int32) As ActionResult
        Dim incident = db.Incident.Find(id)
        ViewBag.Id_Cat = New SelectList(db.Categorie, "Id", "Libelle")
        ViewBag.Id_sous_Cat = New SelectList(db.Sous_Categorie, "Id", "Libelle")
        Dim r = Roles.GetRolesForUser(User.Identity.Name).ToList()
        'If r.IndexOf("CON") = -1 Then
        Return PartialView(incident)
        ' Else
        'Return PartialView("~/Views/Incident/ValiderCON.vbhtml")
        'End If
    End Function
    <HttpPost()>
    Function Valider(ByVal evt As Incident, ByVal fc As FormCollection) As ActionResult
        If (evt.RORC.Equals(True) And evt.RORM.Equals(True)) Then
            Return Json(New With {.result = "ko", .message = "La perte opérationnelle ne doit pas être liée au risque de crédit et de marché à la fois."}, JsonRequestBehavior.AllowGet)
        End If
        Try
            Dim idInciden = Convert.ToInt32(fc("Id"))
            Dim incident = db.Incident.Find(idInciden)
            Dim uid As String = User.Identity.Name
            Dim role = Roles.GetRolesForUser(uid)
            incident.Conformite = evt.Conformite
            incident.Statut_ROC = "O"
            incident.ref_caroline = evt.ref_caroline
            incident.RORC = evt.RORC
            incident.RORM = evt.RORM
            incident.Date_Validation = DateTime.Now
            incident.Id_sous_Cat = evt.Id_sous_Cat
            incident.ref = GetCounter(Server.MapPath("~/Content/template/counter.txt"))
            Dim path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Incident_valide.htm"
            Dim mailObjet = "OUTIL DECLARATION INCIDENTS RO : Incident validé"
            '----------------
            'Dim usr = db.Utilisateur.FirstOrDefault(Function(u) u.Matricule.Equals(uid))
            Dim usrs = New List(Of Utilisateur)()
            Dim Ur = New List(Of RoleUtilisateur)()
            '----------------
            If incident.Conformite = True And role.Contains("GRO") Then
                mailObjet = "OUTIL DECLARATION INCIDENTS RO : Dysfonctionnement conformité à valider"
                path = db.Parametres.Where(Function(p) p.Cle.Equals("PathTemplate")).FirstOrDefault().Value & "Dysfonctionnement_conformite_a_valider.htm"
                ADDStatutHis(idInciden, 16, "")
                incident.Statut_Final = 16
                Ur = db.RoleUtilisateur.Include(Function(u) u.Role).Where(Function(r) r.Role.Libelle.Equals("CON")).ToList()
                usrs = Ur.Select(Function(u) u.Utilisateur).ToList()
            Else
                If role.Contains("CRO") Then
                    ADDStatutHis(idInciden, 5, "")
                    incident.Statut_Final = 5
                    Ur = db.RoleUtilisateur.Include(Function(u) u.Role).Where(Function(r) r.Role.Libelle.Contains("GRO")).ToList()
                    usrs = Ur.Select(Function(u) u.Utilisateur).ToList()
                Else
                    ADDStatutHis(idInciden, 7, "")
                    incident.Statut_Final = 7
                    usrs = db.Utilisateur.Where(Function(u) u.Matricule.Equals(incident.Utilisateur.str.Correcspondant_principal)).ToList()
                End If
            End If
            '------------------
            incident.Proprietaire = User.Identity.Name.ToString()
            db.Entry(incident).State = EntityState.Modified
            db.SaveChanges()
            '--- Sent mailling
            If Not usrs Is Nothing Then
                For Each usr In usrs
                    If Not usr Is Nothing Then
                        Dim text As String = (String.Format(Fct.Template(path), incident.Id, System.Web.HttpUtility.HtmlEncode(fc("Commentaire"))))
                        If Not usr.Email Is Nothing Then
                            Fct.EnvoiMail(usr.Email, usr.Email, mailObjet, text)
                        End If
                    End If
                Next
            End If
            '--- appliquer
            'validation_action_auto(incident.Id)
            '----------
            Return Json(New With {.result = "ok", .message = "La création est faite avec succès."}, JsonRequestBehavior.AllowGet)
        Catch ex As Exception
            ModelState.AddModelError("", ex.Message)
            Return Json(New With {.result = "no", .message = "Echec de création."}, JsonRequestBehavior.AllowGet)
        End Try
    End Function
    <HttpGet>
    Function ValidationCRO(ByVal Id As Integer) As ActionResult
        Dim incident = db.Incident.Find(Id)
        Return PartialView(incident)
    End Function
    Function SousCategorieByCategorie(ByVal categorieId As Integer) As ActionResult

        ViewBag.SelectedSousCat = 0
        Dim SousCategorie = db.Sous_Categorie.Where(Function(s) s.Id_cat = categorieId).ToList()

        Return PartialView(SousCategorie)
    End Function
    Sub validation_action_auto(ByVal id As Integer)
        If id Then
            Dim act = db.Act.Where(Function(a) a.Id_Incident.Equals(id)).ToList()
            For Each ida In act
                If Date.Compare(CDate(ida.Date_realisation), CDate(Date.Today)) <= 0 Then
                    Dim _o = db.Act.Find(ida.Id)
                    _o.Statut_Act = "11"
                    'ADDStatutHis(_o.Id, 11, "Clôture automatique")
                    'db.SaveChanges()
                End If
            Next
        End If
    End Sub
    '-------------------------------
    Function SelectSousProcess(ByVal id As Int32) As String
        Dim sp As List(Of SousProcess) = New List(Of SousProcess)
        Try
            sp = db.SousProcess.Where(Function(m) m.Id_Process.Equals(id)).ToList()
        Catch ex As Exception
            sp = db.SousProcess.ToList()
        End Try
        Dim options As String = "<option value=''>Choisissez</option>"
        For Each i In sp
            options = options + "<option value='" & i.Id & "'>" & HttpUtility.HtmlEncode(i.Libelle) & "</option>"
        Next

        Return options
    End Function




End Class
