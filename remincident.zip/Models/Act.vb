﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_Act")>
Public Class Act

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
     Public Property Action() As String
        Get
            Return m_action
        End Get
        Set(value As String)
            m_action = value
        End Set
    End Property
    Private m_action As String
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True )>
        <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Date_realisation() As DateTime
        Get
            Return m_date_realisation
        End Get
        Set(value As DateTime)
            m_date_realisation = value
        End Set
    End Property
    Private m_date_realisation As DateTime
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True )>
    Public Property date_Ouverture() As DateTime?
        Get
            Return m_date_Ouverture
        End Get
        Set(value As DateTime?)
            m_date_Ouverture = value
        End Set
    End Property
    Private m_date_Ouverture As DateTime?
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True )>
    Public Property date_Cloture() As DateTime?
        Get
            Return m_date_Cloture
        End Get
        Set(value As DateTime?)
            m_date_Cloture = value
        End Set
    End Property
    Private m_date_Cloture As DateTime?

    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Responsable() As String
        Get
            Return m_responsable
        End Get
        Set(value As String)
            m_responsable = value
        End Set
    End Property
    Private m_responsable As String

    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Code_str_responsable() As String
        Get
            Return m_code_str_responsabl
        End Get
        Set(value As String)
            m_code_str_responsabl = value
        End Set
    End Property
    Private m_code_str_responsabl As String

    <ForeignKey("Code_str_responsable")>
    Public Overridable Property Structures() As Structures
        Get
            Return m_str
        End Get
        Set(value As Structures)
            m_str = value
        End Set
    End Property
    Private m_str As Structures
    Public Property Id_Incident() As Int32
        Get
            Return m_Id_Incident
        End Get
        Set(value As Int32)
            m_Id_Incident = value
        End Set
    End Property
    Private m_Id_Incident As Int32

    <ForeignKey("Id_Incident")>
    Public Overridable Property Incident() As Incident
        Get
            Return m_Incident
        End Get
        Set(value As Incident)
            m_Incident = value
        End Set
    End Property
    Private m_Incident As Incident
    Public Property Statut_Act() As Int32
        Get
            Return m_Statut_Act
        End Get
        Set(value As Int32)
            m_Statut_Act = value
        End Set
    End Property
    Private m_Statut_Act As Int32

    <ForeignKey("Statut_Act")>
    Public Overridable Property Statut_Action() As Statut
        Get
            Return m_Statut_Action
        End Get
        Set(value As Statut)
            m_Statut_Action = value
        End Set
    End Property
    Private m_Statut_Action As Statut
End Class
