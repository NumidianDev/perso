﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_Structure")>
Public Class Structures

    <Key()>
    Public Property Code() As String
        Get
            Return m_code
        End Get
        Set(value As String)
            m_code = value
        End Set
    End Property
    Private m_code As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
     Public Property Nom() As String
        Get
            Return m_nom
        End Get
        Set(value As String)
            m_nom = value
        End Set
    End Property
    Private m_nom As String

    Public Property Matricule_resp() As String
        Get
            Return m_matricule_resp
        End Get
        Set(value As String)
            m_matricule_resp = value
        End Set
    End Property
    Private m_matricule_resp As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Correcspondant_principal() As String
        Get
            Return m_Correcspondant_principal
        End Get
        Set(value As String)
            m_Correcspondant_principal = value
        End Set
    End Property
    Private m_Correcspondant_principal As String
    Public Property Correspondant_secondaire() As String
        Get
            Return m_Correspondant_secondaire
        End Get
        Set(value As String)
            m_Correspondant_secondaire = value
        End Set
    End Property
    Private m_Correspondant_secondaire As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
     Public Property Type As String
        Get
            Return m_type
        End Get
        Set(value As String)
            m_type = value
        End Set
    End Property
    Private m_type As String
    <ForeignKey("Type")>
    Public Overridable Property TS() As TypeStructure
        Get
            Return m_ts
        End Get
        Set(value As TypeStructure)
            m_ts = value
        End Set
    End Property
    Private m_ts As TypeStructure
    Public Property Code_STR_Mere() As String
        Get
            Return m_code_str_mere
        End Get
        Set(value As String)
            m_code_str_mere = value
        End Set
    End Property
    Private m_code_str_mere As String
    <ForeignKey("Code_STR_Mere")>
    Public Overridable Property STR_Mere() As Structures
        Get
            Return m_Structure_Mere
        End Get
        Set(value As Structures)
            m_Structure_Mere = value
        End Set
    End Property
    Private m_Structure_Mere As Structures
    <NotMapped()> _
    Public ReadOnly Property getSTRmere As String
        Get
            Using db As New DB
                Dim dm = db.Structures.Where(Function(u) u.Code.Equals(Code_STR_Mere))
                If dm.Any() Then
                    strmere = dm.FirstOrDefault().Nom
                End If

            End Using
            Return strmere
        End Get
    End Property
    Private strmere As String
    <NotMapped()> _
    Public ReadOnly Property getUser As String
        Get
            Using db As New DB
                Dim dm = db.Utilisateur.Where(Function(u) u.Matricule.Equals(Matricule_resp))
                If dm.Any() Then
                    fullname = dm.FirstOrDefault().Fullname
                End If

            End Using
            Return fullname
        End Get
    End Property
    Private fullname As String
    <NotMapped()> _
    Public ReadOnly Property getCS As String
        Get
            Using db As New DB
                Dim dm = db.Utilisateur.Where(Function(u) u.Matricule.Equals(Correspondant_secondaire))
                If dm.Any() Then
                    gcs = dm.FirstOrDefault().Fullname
                End If

            End Using
            Return gcs
        End Get
    End Property
    Private gcs As String
    <NotMapped()> _
    Public ReadOnly Property getCp As String
        Get
            Using db As New DB
                Dim dm = db.Utilisateur.Where(Function(u) u.Matricule.Equals(Correcspondant_principal))
                If dm.Any() Then
                    gcp = dm.FirstOrDefault().Fullname
                End If

            End Using
            Return gcp
        End Get
    End Property
    Private gcp As String

End Class
