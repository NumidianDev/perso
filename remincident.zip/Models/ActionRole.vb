﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("RI_ActionRole")>
Public Class ActionRole
    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32
    Public Property Id_Action() As Int32
        Get
            Return m_action_Id
        End Get
        Set(value As Int32)
            m_action_Id = value
        End Set
    End Property
    Private m_action_Id As Int32

    <ForeignKey("Id_Action")>
    Public Overridable Property Action() As Action
        Get
            Return m_action
        End Get
        Set(value As Action)
            m_action = value
        End Set
    End Property
    Private m_action As Action
    Public Property Id_Role() As String
        Get
            Return m_role_Id
        End Get
        Set(value As String)
            m_role_Id = value
        End Set
    End Property
    Private m_role_Id As String

    <ForeignKey("Id_Role")>
    Public Overridable Property Role() As Role
        Get
            Return m_role
        End Get
        Set(value As Role)
            m_role = value
        End Set
    End Property
    Private m_role As Role



End Class
