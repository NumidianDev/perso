﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations


Public Class Etat

    <Key()> _
    Public Property col1 As String
    Public Property col2 As String
    Public Property col3 As String
    Public Property col4 As String
    Public Property col5 As String
    Public Property col6 As String
    Public Property col7 As String
    Public Property col8 As String
    Public Property col9 As String
    Public Property col10 As String
    Public Property col11 As String
    Public Property col12 As String
    Public Property col13 As String
    Public Property col14 As String
    Public Property col15 As String
    Public Property col16 As String
    Public Property col17 As String
    Public Property col18 As String
    Public Property col19 As String
    Public Property col20 As String
    Public Property col21 As String
    Public Property col22 As String
    Public Property col23 As String
    Public Property col24 As String
    Public Property col25 As String
    Public Property col26 As String
    Public Property col27 As String
    Public Property col28 As String
    Public Property col29 As String
End Class
