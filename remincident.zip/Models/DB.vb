﻿Imports System.Data.Entity
Imports System.Configuration
Imports System.Data.Entity.ModelConfiguration.Conventions


Public Class DB
    Inherits DbContext

    Public Sub New()
        MyBase.New(ConfigurationManager.ConnectionStrings("Dev").ToString)
    End Sub

    Public Property Utilisateur() As DbSet(Of Utilisateur)
        Get
            Return m_Utilisateur
        End Get
        Set(ByVal value As DbSet(Of Utilisateur))
            m_Utilisateur = value
        End Set
    End Property
    Private m_Utilisateur As DbSet(Of Utilisateur)
    Public Property Parametres() As DbSet(Of Parametres)
        Get
            Return m_Parametres
        End Get
        Set(ByVal value As DbSet(Of Parametres))
            m_Parametres = value
        End Set
    End Property
    Private m_Parametres As DbSet(Of Parametres)
    Public Property Roles As DbSet(Of Role)
    Public Property Action() As DbSet(Of Action)
        Get
            Return m_action
        End Get
        Set(value As DbSet(Of Action))
            m_action = value
        End Set
    End Property
    Private m_action As DbSet(Of Action)
    Public Property ActionRole() As DbSet(Of ActionRole)
        Get
            Return m_action_role
        End Get
        Set(value As DbSet(Of ActionRole))
            m_action_role = value
        End Set
    End Property
    Private m_action_role As DbSet(Of ActionRole)
    Public Property RoleUtilisateur() As DbSet(Of RoleUtilisateur)
        Get
            Return m_RoleUtilisateur
        End Get
        Set(ByVal value As DbSet(Of RoleUtilisateur))
            m_RoleUtilisateur = value
        End Set
    End Property
    Private m_RoleUtilisateur As DbSet(Of RoleUtilisateur)
    Public Property Structures() As DbSet(Of Structures)
        Get
            Return m_structure
        End Get
        Set(value As DbSet(Of Structures))
            m_structure = value
        End Set
    End Property
    Private m_structure As DbSet(Of Structures)
    Public Property Origine() As DbSet(Of Origine)
        Get
            Return m_origine
        End Get
        Set(value As DbSet(Of Origine))
            m_origine = value
        End Set
    End Property
    Private m_origine As DbSet(Of Origine)
    Public Property Incident() As DbSet(Of Incident)
        Get
            Return m_incident
        End Get
        Set(value As DbSet(Of Incident))
            m_incident = value
        End Set
    End Property
    Private m_incident As DbSet(Of Incident)
    Public Property Nature_Impact() As DbSet(Of Nature_Impact)
        Get
            Return m_impact
        End Get
        Set(value As DbSet(Of Nature_Impact))
            m_impact = value
        End Set
    End Property
    Private m_impact As DbSet(Of Nature_Impact)
    Public Property Activite() As DbSet(Of Activite)
        Get
            Return m_processus
        End Get
        Set(value As DbSet(Of Activite))
            m_processus = value
        End Set
    End Property
    Private m_processus As DbSet(Of Activite)
    Public Property Categorie() As DbSet(Of Categorie)
        Get
            Return m_categorie
        End Get
        Set(value As DbSet(Of Categorie))
            m_categorie = value
        End Set
    End Property
    Private m_categorie As DbSet(Of Categorie)
    Public Property Sous_Categorie() As DbSet(Of Sous_Categorie)
        Get
            Return m_sous_Categorie
        End Get
        Set(value As DbSet(Of Sous_Categorie))
            m_sous_Categorie = value
        End Set
    End Property
    Private m_sous_Categorie As DbSet(Of Sous_Categorie)
    Public Property Statut_Incident() As DbSet(Of Statut)
        Get
            Return m_Statut_Incident
        End Get
        Set(value As DbSet(Of Statut))
            m_Statut_Incident = value
        End Set
    End Property
    Private m_Statut_Incident As DbSet(Of Statut)
    Public Property StatutHis() As DbSet(Of StatutHis)
        Get
            Return m_StatutHis
        End Get
        Set(value As DbSet(Of StatutHis))
            m_StatutHis = value
        End Set
    End Property
    Private m_StatutHis As DbSet(Of StatutHis)
    Public Property PieceJointe() As DbSet(Of PieceJointe)
        Get
            Return m_PieceJointe
        End Get
        Set(value As DbSet(Of PieceJointe))
            m_PieceJointe = value
        End Set
    End Property
    Private m_PieceJointe As DbSet(Of PieceJointe)
    Public Property Act() As DbSet(Of Act)
        Get
            Return m_Act
        End Get
        Set(value As DbSet(Of Act))
            m_Act = value
        End Set
    End Property
    Private m_Act As DbSet(Of Act)
    Public Property TypeStructure() As DbSet(Of TypeStructure)
        Get
            Return m_Ts
        End Get
        Set(value As DbSet(Of TypeStructure))
            m_Ts = value
        End Set
    End Property
    Private m_Ts As DbSet(Of TypeStructure)

    Public Property Process() As DbSet(Of Process)
        Get
            Return m_Process
        End Get
        Set(value As DbSet(Of Process))
            m_Process = value
        End Set
    End Property
    Private m_Process As DbSet(Of Process)

    Public Property SousProcess() As DbSet(Of SousProcess)
        Get
            Return m_SousProcess
        End Get
        Set(value As DbSet(Of SousProcess))
            m_SousProcess = value
        End Set
    End Property
    Private m_SousProcess As DbSet(Of SousProcess)

    Public Property SourceRemonte() As DbSet(Of SourceRemonte)
        Get
            Return m_SourceRemonte
        End Get
        Set(value As DbSet(Of SourceRemonte))
            m_SourceRemonte = value
        End Set
    End Property
    Private m_SourceRemonte As DbSet(Of SourceRemonte)

End Class
