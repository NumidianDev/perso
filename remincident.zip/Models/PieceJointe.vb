﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_PieceJointe")>
Public Class PieceJointe

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property Id_Inc_Act() As Int32
        Get
            Return m_Id_Inc_Act
        End Get
        Set(value As Int32)
            m_Id_Inc_Act = value
        End Set
    End Property
    Private m_Id_Inc_Act As Int32

   
    Public Property INC_ACT() As String
        Get
            Return m_INC_ACT
        End Get
        Set(value As String)
            m_INC_ACT = value
        End Set
    End Property
    Private m_INC_ACT As String

    Public Property Nom_Fichier() As String
        Get
            Return m_Nom_Fichier
        End Get
        Set(value As String)
            m_Nom_Fichier = value
        End Set
    End Property
    Private m_Nom_Fichier As String

End Class
