﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_Incident")>
Public Class Incident

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True)>
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Date_declaration() As DateTime
        Get
            Return m_date_declaration
        End Get
        Set(value As DateTime)
            m_date_declaration = value
        End Set
    End Property
    Private m_date_declaration As DateTime
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True)>
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Date_debut() As DateTime
        Get
            Return m_date_debut
        End Get
        Set(value As DateTime)
            m_date_debut = value
        End Set
    End Property
    Private m_date_debut As DateTime
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True)>
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Date_decouverte() As DateTime
        Get
            Return m_date_decouverte
        End Get
        Set(value As DateTime)
            m_date_decouverte = value
        End Set
    End Property
    Private m_date_decouverte As DateTime
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Detail() As String
        Get
            Return m_detail
        End Get
        Set(value As String)
            m_detail = value
        End Set
    End Property
    Private m_detail As String
    Public Property NatureCause() As String
        Get
            Return m_natureCause
        End Get
        Set(value As String)
            m_natureCause = value
        End Set
    End Property
    Private m_natureCause As String

    Public Property Origine_Detction() As String
        Get
            Return m_origine_Detction
        End Get
        Set(value As String)
            m_origine_Detction = value
        End Set
    End Property
    Private m_origine_Detction As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Regle_int_ext() As Boolean
        Get
            Return m_Regle_int_ext
        End Get
        Set(value As Boolean)
            m_Regle_int_ext = value
        End Set
    End Property
    Private m_Regle_int_ext As Boolean
    Public Property Montant_declarer() As Decimal?
        Get
            Return m_montant_declarer
        End Get
        Set(value As Decimal?)
            m_montant_declarer = value
        End Set
    End Property
    Private m_montant_declarer As Decimal?
    Public Property Montant_estime() As Decimal?
        Get
            Return m_montant_estime
        End Get
        Set(value As Decimal?)
            m_montant_estime = value
        End Set
    End Property
    Private m_montant_estime As Decimal?
    Public Property Montant_effectif() As Decimal?
        Get
            Return m_montant_effectif
        End Get
        Set(value As Decimal?)
            m_montant_effectif = value
        End Set
    End Property
    Private m_montant_effectif As Decimal?
   
    Public Property ref_credit() As String
        Get
            Return m_ref_credit
        End Get
        Set(value As String)
            m_ref_credit = value
        End Set
    End Property
    Private m_ref_credit As String
    Public Property ref_debit() As String
        Get
            Return m_ref_debit
        End Get
        Set(value As String)
            m_ref_debit = value
        End Set
    End Property
    Private m_ref_debit As String
    Public Property ref_credit_eff() As String
        Get
            Return m_ref_credit_eff
        End Get
        Set(value As String)
            m_ref_credit_eff = value
        End Set
    End Property
    Private m_ref_credit_eff As String
    Public Property ref_debit_eff() As String
        Get
            Return m_ref_debit_eff
        End Get
        Set(value As String)
            m_ref_debit_eff = value
        End Set
    End Property
    Private m_ref_debit_eff As String

    Public Property ref_caroline() As String
        Get
            Return m_ref_caroline
        End Get
        Set(value As String)
            m_ref_caroline = value
        End Set
    End Property
    Private m_ref_caroline As String
    Public Property ref() As String
        Get
            Return m_ref
        End Get
        Set(value As String)
            m_ref = value
        End Set
    End Property
    Private m_ref As String
    Public Property Statut_ROC() As String
        Get
            Return m_statut
        End Get
        Set(value As String)
            m_statut = value
        End Set
    End Property
    Private m_statut As String
    Public Property Impact_financier() As Boolean?
        Get
            Return m_Impact_financier
        End Get
        Set(value As Boolean?)
            m_Impact_financier = value
        End Set
    End Property
    Private m_Impact_financier As Boolean?

    Public Property RORC() As Boolean?
        Get
            Return m_RORC
        End Get
        Set(value As Boolean?)
            m_RORC = value
        End Set
    End Property
    Private m_RORC As Boolean?

    Public Property RORM() As Boolean?
        Get
            Return m_RORM
        End Get
        Set(value As Boolean?)
            m_RORM = value
        End Set
    End Property
    Private m_RORM As Boolean?

    Public Property Conformite() As Boolean?
        Get
            Return m_conformite
        End Get
        Set(value As Boolean?)
            m_conformite = value
        End Set
    End Property
    Private m_conformite As Boolean?

    Public Property Matricule_Creation() As String
        Get
            Return m_matricule_creation
        End Get
        Set(value As String)
            m_matricule_creation = value
        End Set
    End Property
    Private m_matricule_creation As String

    

    Public Property Proprietaire() As String
        Get
            Return m_proprietaire
        End Get
        Set(value As String)
            m_proprietaire = value
        End Set
    End Property
    Private m_proprietaire As String

    <ForeignKey("Matricule_Creation")>
    Public Overridable Property Utilisateur() As Utilisateur
        Get
            Return m_user
        End Get
        Set(value As Utilisateur)
            m_user = value
        End Set
    End Property
    Private m_user As Utilisateur
    Public Property Id_Origine() As Int32?
        Get
            Return m_id_Origine
        End Get
        Set(value As Int32?)
            m_id_Origine = value
        End Set
    End Property
    Private m_id_Origine As Int32?

    <ForeignKey("Id_Origine")>
    Public Overridable Property Origine() As Origine
        Get
            Return m_origine
        End Get
        Set(value As Origine)
            m_origine = value
        End Set
    End Property
    Private m_origine As Origine

    Public Property Id_Sous_Process() As Int32?
        Get
            Return m_id_Sous_Process
        End Get
        Set(value As Int32?)
            m_id_Sous_Process = value
        End Set
    End Property
    Private m_id_Sous_Process As Int32?

    <ForeignKey("Id_Sous_Process")>
    Public Overridable Property SousProcess() As SousProcess
        Get
            Return m_SousProcess
        End Get
        Set(value As SousProcess)
            m_SousProcess = value
        End Set
    End Property
    Private m_SousProcess As SousProcess

    Public Property Nature_Impact() As Int32?
        Get
            Return m_id_Impact
        End Get
        Set(value As Int32?)
            m_id_Impact = value
        End Set
    End Property
    Private m_id_Impact As Int32?
    <ForeignKey("Nature_Impact")>
    Public Overridable Property Impact() As Nature_Impact
        Get
            Return m_Nature_Impact
        End Get
        Set(value As Nature_Impact)
            m_Nature_Impact = value
        End Set
    End Property
    Private m_Nature_Impact As Nature_Impact

    Public Property Id_sous_Cat() As Int32?
        Get
            Return m_Id_sous_Cat
        End Get
        Set(value As Int32?)
            m_Id_sous_Cat = value
        End Set
    End Property
    Private m_Id_sous_Cat As Int32?
    <ForeignKey("Id_sous_Cat")>
    Public Overridable Property sous_Cat() As Sous_Categorie
        Get
            Return m_sous_Cat
        End Get
        Set(value As Sous_Categorie)
            m_sous_Cat = value
        End Set
    End Property
    Private m_sous_Cat As Sous_Categorie

    Public Property Statut_Final() As Int32?
        Get
            Return m_Statut_Final
        End Get
        Set(value As Int32?)
            m_Statut_Final = value
        End Set
    End Property
    Private m_Statut_Final As Int32?

    <ForeignKey("Statut_Final")>
    Public Overridable Property Statut_Incident() As Statut
        Get
            Return m_Statut_Incident
        End Get
        Set(value As Statut)
            m_Statut_Incident = value
        End Set
    End Property
    Private m_Statut_Incident As Statut

    Public Property Code_Str() As String
        Get
            Return m_Code_Str
        End Get
        Set(value As String)
            m_Code_Str = value
        End Set
    End Property
    Private m_Code_Str As String

    <ForeignKey("Code_Str")>
    Public Overridable Property structStructures() As Structures
        Get
            Return m_Structures
        End Get
        Set(value As Structures)
            m_Structures = value
        End Set
    End Property
    Private m_Structures As Structures

    Public Property Id_SourceRemonte() As Int32?
        Get
            Return m_Id_SourceRemonte
        End Get
        Set(value As Int32?)
            m_Id_SourceRemonte = value
        End Set
    End Property
    Private m_Id_SourceRemonte As Int32?

    <ForeignKey("Id_SourceRemonte")>
    Public Overridable Property SourceRemonte() As SourceRemonte
        Get
            Return m_SourceRemonte
        End Get
        Set(value As SourceRemonte)
            m_SourceRemonte = value
        End Set
    End Property
    Private m_SourceRemonte As SourceRemonte

    Public Property Date_Validation() As DateTime?
        Get
            Return m_Date_Validation
        End Get
        Set(value As DateTime?)
            m_Date_Validation = value
        End Set
    End Property
    Private m_Date_Validation As DateTime?

    <NotMapped()> _
    Public ReadOnly Property getProprietaire As String
        Get
            Using db As New DB
                dm = db.Utilisateur.Where(Function(u) u.Matricule.Equals(Proprietaire)).FirstOrDefault().Fullname
            End Using
            Return dm.ToString()
        End Get
    End Property
    Private dm As String
End Class
