﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("RI_SourceRemonte")>
Public Class SourceRemonte
    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32
    <Required(ErrorMessage:="Veuillez compléter ce champ.")>
    Public Property Libelle() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String
End Class
