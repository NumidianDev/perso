import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SgaFileUploadComponent } from './sga-file-upload.component';

describe('SgaFileUploadComponent', () => {
  let component: SgaFileUploadComponent;
  let fixture: ComponentFixture<SgaFileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SgaFileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SgaFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
