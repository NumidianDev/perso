import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  MatToolbarModule,
  MatIconModule,
  MatCardModule,
  MatButtonModule,
  MatProgressBarModule,
  MatDialogModule,
  MatListModule,
  MatInputModule,
  MatTableModule,
  MatTooltipModule,
  MatSidenavModule
} from '@angular/material';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatProgressBarModule,
    MatDialogModule,
    MatListModule,
    MatInputModule,
    MatTableModule,
    MatTooltipModule,
    MatSidenavModule
  ],
  exports: [
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatProgressBarModule,
    MatDialogModule,
    MatListModule,
    MatInputModule,
    MatTableModule,
    MatTooltipModule,
    MatSidenavModule
  ]
})
export class MaterialModule { }
