import 'hammerjs';

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
registerLocaleData(localeFr);
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';

import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { MaterialModule } from './material.module';
import { SgaToolbarComponent } from './sga-toolbar/sga-toolbar.component';
import { SgaFileUploadComponent } from './sga-file-upload/sga-file-upload.component';
import { DndDirective } from './directives/dnd.directive';
import { SgaProgressComponent } from './sga-progress/sga-progress.component';
import { VirementComponent } from './virement/virement.component';

@NgModule({
   declarations: [
      AppComponent,
      SgaToolbarComponent,
      SgaFileUploadComponent,
      DndDirective,
      SgaProgressComponent,
      VirementComponent
   ],
   imports: [
      BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
      HttpClientModule,
      FormsModule,
      AppRoutingModule,
      BrowserAnimationsModule,
      MaterialModule,
      FlexLayoutModule
   ],
   providers: [{
      provide: LOCALE_ID,
      useValue: 'fr-FR'
   }],
   bootstrap: [AppComponent]
})
export class AppModule { }
