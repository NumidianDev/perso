import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-sga-progress',
  templateUrl: './sga-progress.component.html',
  styleUrls: ['./sga-progress.component.css']
})
export class SgaProgressComponent implements OnInit {
  @Input() progress = 0;
  constructor() { }

  ngOnInit() {
  }

}
