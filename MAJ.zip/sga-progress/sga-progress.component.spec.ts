import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SgaProgressComponent } from './sga-progress.component';

describe('SgaProgressComponent', () => {
  let component: SgaProgressComponent;
  let fixture: ComponentFixture<SgaProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SgaProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SgaProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
