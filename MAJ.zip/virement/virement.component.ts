import { Component, OnInit } from '@angular/core';
import { VirementService } from '../services/virement.service';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-virement',
  templateUrl: './virement.component.html',
  styleUrls: ['./virement.component.css']
})
export class VirementComponent implements OnInit {

  virement: any = null;
  displayedColumns: string[] = ['ligne', 'sanitizedName', 'banque', 'agence', 'compte', 'cle', 'montant', 'libelle'];
  dataSource: MatTableDataSource<any>;

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.toLowerCase();
  }

  constructor(private virementService: VirementService) {
    this.dataSource = new MatTableDataSource([]);
    this.dataSource.filterPredicate = (data: any, filter) => {
      const dataStr = JSON.stringify(data).toLowerCase();
      return dataStr.indexOf(filter) !== -1;
    };
  }

  ngOnInit() {
    this.virementService.sharedVirement.subscribe(virement => this.refreshData(virement));
  }

  refreshData(virement: any) {
    this.virement = virement;
    if (null != virement) {
      this.dataSource.data = virement.beneficiares;
    } else { this.dataSource.data = []; }
  }

  montantDifferent() {
    const totalBeneficiaire = this.virement.beneficiares.reduce(function (prev, cur) {
      return prev + cur.montant;
    }, 0).toFixed(2);
    return this.virement.entete.montantTotal !== Number(totalBeneficiaire);
  }

}
