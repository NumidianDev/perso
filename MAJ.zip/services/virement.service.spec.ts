/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { VirementService } from './virement.service';

describe('Service: Virement', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VirementService]
    });
  });

  it('should ...', inject([VirementService], (service: VirementService) => {
    expect(service).toBeTruthy();
  }));
});
