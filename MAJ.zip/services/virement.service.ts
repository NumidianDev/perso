import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VirementService {

  private virement = new BehaviorSubject<any>('');
  sharedVirement = this.virement.asObservable();

  constructor() { }

  updateVirement(virement: any) {
    this.virement.next(virement);
  }

  removeVirement(){
    this.virement.next(null);
  }
}
