/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { Mt101Service } from './mt101.service';

describe('Service: Mt101', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Mt101Service]
    });
  });

  it('should ...', inject([Mt101Service], (service: Mt101Service) => {
    expect(service).toBeTruthy();
  }));
});
