import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse} from '@angular/common/http';

import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class Mt101Service {

  SERVER_URL = 'https://localhost:5001/api/MT101';

  constructor(private http: HttpClient) { }

  downloadFile(_virement): Observable<any> {
    const options = {responseType: 'blob' as 'json'};
    return this.http.post<any>(this.SERVER_URL, _virement, options);
  }

  errorHandler(error: HttpErrorResponse) {
    console.log(error.message);
  }

}
