import { Component, OnInit } from '@angular/core';
import { VirementService } from '../services/virement.service';
import { Mt101Service } from '../services/mt101.service';
import { saveAs } from 'file-saver';
import { DatePipe } from '@angular/common';
import { error } from 'protractor';

@Component({
  selector: 'app-sga-toolbar',
  templateUrl: './sga-toolbar.component.html',
  styleUrls: ['./sga-toolbar.component.css'],
  providers: [DatePipe]
})
export class SgaToolbarComponent implements OnInit {

  virement: any = null;

  constructor(private virementService: VirementService, private mt101Service: Mt101Service, public datepipe: DatePipe) { }

  ngOnInit() {
    this.virementService.sharedVirement.subscribe(virement => this.refreshData(virement));
  }

  refreshData(virement: any) {
    this.virement = virement;
  }

  downloadMT101() {
    this.mt101Service.downloadFile(this.virement).subscribe(res => {
      const virDate = this.virement.entete.executionDate;
      const nomMT101 = 'VRT_' + this.virement.entete.nombreVirements + '_' + this.datepipe.transform(virDate, 'ddMMyyyy_hhmm') + '.swf';
      console.log(nomMT101);
      // const blob = new Blob([res.arrayBuffer()], { type: contentType });
      saveAs(res, nomMT101);
    });
  }
}
