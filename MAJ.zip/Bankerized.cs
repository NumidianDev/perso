using System;
using SgaConverter.Interfaces;

namespace SgaConverter.model
{
    public class Bankerized : IBankerized
    {
        public Bankerized()
        {
        }

        public Bankerized(int ligne, string name, string banque, string agence, string compte, string cle)
        {
            this.ligne = ligne;
            this.name = name;
            this.banque = banque;
            this.agence = agence;
            this.compte = compte;
            this.cle = cle;
        }

        public bool hasError{
            get{
                return errorOnName || errorOnBanque || errorOnAgence || errorOnCompte || errorOnCle || !isValidRIB;
            }
        }
        public int ligne{get; set;}
        public string name { get; set; }
        public bool errorOnName {
            get{
                return string.IsNullOrEmpty(this.sanitizedName);
            }
        }
        public string errName {get{ return "Le nom/raison social ne peut être vide"; }}
        public string banque { get; set; }
        public bool errorOnBanque {
            get {
                return string.IsNullOrEmpty(this.banque) || string.IsNullOrEmpty(this.banque.Trim()) || this.banque.Trim().Length != 3 || !int.TryParse(this.banque.Trim(), out int n);
            }
        }
        public string errBanque {
            get{
                if (string.IsNullOrEmpty(this.banque) ||  string.IsNullOrEmpty(this.banque.Trim())) {
                    return "Le code banque ne peut être vide";
                }else {
                    if(this.banque.Trim().Length != 3) return "Le code banque doit être sur 3 positions numériques";
                    else if(!int.TryParse(this.banque.Trim(), out int n)) return "Le code banque doit être numérique";
                    else return "";
                }
            }
        }

        public string banque3digits {
            get{
                int outBanque;
                return (int.TryParse(this.banque, out outBanque)) ? outBanque.ToString("000") : "000";
            }
        }

        public string agence { get; set; }
        public bool errorOnAgence {
            get {
                return string.IsNullOrEmpty(this.agence) || string.IsNullOrEmpty(this.agence.Trim()) || this.agence.Trim().Length != 5 || !int.TryParse(this.agence.Trim(), out int n);
            }
        }
        public string errAgence {
            get{
                if (string.IsNullOrEmpty(this.agence) || string.IsNullOrEmpty(this.agence.Trim())) {
                    return "Le code agence ne peut être vide";
                }else {
                    if(this.agence.Trim().Length != 5) return "Le code agence doit être sur 5 positions numériques";
                    else if(!int.TryParse(this.agence.Trim(), out int n)) return "Le code agence doit être numérique";
                    else return "";
                }
            }
        }
        public string compte { get; set; }
        public bool errorOnCompte {
            get {
                return string.IsNullOrEmpty(this.compte) || string.IsNullOrEmpty(this.compte.Trim()) || this.compte.Trim().Length != 10 || !parseCompte(this.compte);
            }
        }
        public string errCompte {
            get{
                if (string.IsNullOrEmpty(this.compte) || string.IsNullOrEmpty(this.compte.Trim())) {
                    return "Le numéro de compte ne peut être vide";
                }else {
                    if(this.compte.Trim().Length != 10) return "Le numéro de compte doit être sur 10 positions numériques";
                    else if(!parseCompte(this.compte)) return "Le numéro de compte doit être numérique"; 
                    else return "";
                }
            }
        }
        private bool parseCompte(string compte){
            long long_compte;
            return Int64.TryParse(compte.Trim(), out long_compte);
        }
        public string cle { get; set; }
        public bool errorOnCle {
            get {
                return string.IsNullOrEmpty(this.cle) || string.IsNullOrEmpty(this.cle.Trim()) || this.cle.Trim().Length != 2 || !int.TryParse(this.cle.Trim(), out int n);
            }
        }
        public string errCle {
            get{
                if (string.IsNullOrEmpty(this.cle) || string.IsNullOrEmpty(this.cle.Trim())) {
                    return "La clé RIB ne peut être vide";
                }else {
                    if(this.compte.Trim().Length != 2) return "La clé RIB doit être sur 2 positions numériques";
                    else if(!Int64.TryParse(this.compte.Trim(), out long n)) return "La clé RIB doit être numérique";
                    else return "";
                }
            }
        }
        public string errRIB{
            get{ return "Le clé du RIB est érronée, merci de corriger la ligne N° " + this.ligne; }
        }
        public string sanitizedName{
            get{
                return utils.UtilFunctions.DeleteAccentAndSpecialsChar(this.name);
            }
        } 
        public string rib{
            get{
                return this.getRIB();
            }
        } 
        public bool isValidRIB{
            get{
                return this.validateRIB();
            }
        }
        private string getRIB()
        {
            return this.banque + this.agence + this.compte + this.cle;
        }
        private bool validateRIB()
        {
            if (string.IsNullOrEmpty(this.agence) || string.IsNullOrEmpty(this.compte) || string.IsNullOrEmpty(this.cle)) {
                return false;
            }

            try
            {
                long longInteger = Int64.Parse(this.agence + this.compte + "00");
                int clcalculee =  (int) Math.Abs(((longInteger % 97) - 97));
                
                return int.Parse(this.cle) == clcalculee;
            }
            catch (System.Exception)
            {
                return false;
            }
        }
    }
}