export const environment = {
  production: true,
  apiUrl: 'http://localhost:4000',
};
