import { Component, HostListener } from '@angular/core';

import { AccountService } from './_services';
import { User } from './_models';
import { Observable, of } from 'rxjs';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'sga-ui';
  mode = new FormControl('push');
  user!: User;

  isLoggedIn$: Observable<boolean> = of(false);

  constructor(private accountService: AccountService) {
    this.accountService.user.subscribe((x) => (this.user = x));
    this.isLoggedIn$ = this.accountService.isLoggedIn;
    this.logout();
  }

  // tslint:disable-next-line:typedef
  logout() {
    this.accountService.logout();
  }

  @HostListener('window:onbeforeunload', ['$event'])
  onWindowClose(event: any): void {
    // Do something
    alert('Fermeture');
    event.preventDefault();
    event.returnValue = false;
  }
}
