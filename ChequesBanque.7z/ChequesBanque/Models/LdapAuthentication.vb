﻿Imports System
Imports System.Text
Imports System.Collections
Imports System.DirectoryServices


Namespace LDAP
    Public Class LdapAuthentication
        Private Const DEFAULT_LDAP_PATH As String = "LDAP://sga-dc001"
        Private Const DEFAULT_DOMAIN_NAME As String = "Sga"
        Dim _path As String = DEFAULT_LDAP_PATH
        Dim _domain As String = DEFAULT_DOMAIN_NAME
        Dim _filterAttribute As String
        Shared instanceLock As Object = New Object()
        Shared instance As LdapAuthentication = Nothing

        Private Sub New()
            Dim pathFromConfigFile As String = ConfigurationManager.AppSettings("ldapPath")
            Dim domainFromConfigFile As String = ConfigurationManager.AppSettings("domainName")
            If Not String.IsNullOrEmpty(pathFromConfigFile) Then
                _path = pathFromConfigFile
            Else
                _path = DEFAULT_LDAP_PATH
            End If
            If Not String.IsNullOrEmpty(domainFromConfigFile) Then
                _domain = domainFromConfigFile
            Else
                _domain = DEFAULT_DOMAIN_NAME
            End If
        End Sub

        Public Shared Function GetInstance() As LdapAuthentication
            SyncLock instanceLock
                If instance Is Nothing Then
                    instance = New LdapAuthentication()
                End If
                Return instance
            End SyncLock
        End Function

        Public Function IsAuthenticated(ByVal username As String, ByVal pwd As String) As Boolean

            If username.Contains("\") Then
                Dim domainInUserName As String = username.Split("\")(0)
                username = username.Split("\")(1)

                If Not domainInUserName.ToLower.Equals(_domain.ToLower) Then
                    Throw New Exception("Error d'authentification de l'utilisateur " & username & " Details: Domaine invalide ( " & domainInUserName & " )")
                End If
            End If

            Dim domainAndUsername As String = _domain & "\" & username
            Dim entry As DirectoryEntry = New DirectoryEntry(_path, domainAndUsername, pwd)

            Try
                'Bind to the native AdsObject to force authentication.			
                Dim obj As Object = entry.NativeObject
                Dim search As DirectorySearcher = New DirectorySearcher(entry)

                search.Filter = "(SAMAccountName=" & username & ")"
                search.PropertiesToLoad.Add("cn")
                Dim result As SearchResult = search.FindOne()

                If (result Is Nothing) Then
                    Return False
                End If

                'Update the new path to the user in the directory.
                '_path = result.Path
                '_filterAttribute = CType(result.Properties("cn")(0), String)
                Return True
            Catch ex As Exception
                Throw New Exception("Error d'authentification de l'utilisateur " & username & " Details: " & ex.Message)
            End Try


        End Function

        Public Function GetLdapUser(ByVal username As String) As LdapUser

            If username.Contains("\") Then
                Dim domainInUserName As String = username.Split("\")(0)
                username = username.Split("\")(1)

                If Not domainInUserName.ToLower.Equals(_domain.ToLower) Then
                    Throw New Exception("Error d'authentification de l'utilisateur " & username & " Details: Domaine invalide ( " & domainInUserName & " )")
                End If
            End If

            Dim domainAndUsername As String = _domain & "\" & username
            Dim entry As DirectoryEntry = New DirectoryEntry(_path, "sgaappadm", "echo99")

            Try
                'Bind to the native AdsObject to force authentication.			
                Dim obj As Object = entry.NativeObject
                Dim search As DirectorySearcher = New DirectorySearcher(entry)

                search.Filter = "(SAMAccountName=" & username & ")"
                search.PropertiesToLoad.Add("cn")
                search.PropertiesToLoad.Add("sn")
                search.PropertiesToLoad.Add("givenName")

                Dim result As SearchResult = search.FindOne()

                If (result Is Nothing) Then
                    Return Nothing
                End If

                'Update the new path to the user in the directory.
                '_path = result.Path
                '_filterAttribute = CType(result.Properties("cn")(0), String)
                Return New LdapUser With {.Matricule = username, .Nom = result.Properties("sn").Item(0).ToString, .Prenom = result.Properties("givenName").Item(0).ToString}
            Catch ex As Exception
                Throw New Exception("Error d'authentification de l'utilisateur " & username & " Details: " & ex.Message)
            End Try

        End Function

        Public Function GetGroups() As String
            Dim search As DirectorySearcher = New DirectorySearcher(_path)
            search.Filter = "(cn=" & _filterAttribute & ")"
            search.PropertiesToLoad.Add("memberOf")
            Dim groupNames As StringBuilder = New StringBuilder()

            Try
                Dim result As SearchResult = search.FindOne()
                Dim propertyCount As Integer = result.Properties("memberOf").Count

                Dim dn As String
                Dim equalsIndex, commaIndex

                Dim propertyCounter As Integer

                For propertyCounter = 0 To propertyCount - 1
                    dn = CType(result.Properties("memberOf")(propertyCounter), String)

                    equalsIndex = dn.IndexOf("=", 1)
                    commaIndex = dn.IndexOf(",", 1)
                    If (equalsIndex = -1) Then
                        Return Nothing
                    End If

                    groupNames.Append(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1))
                    groupNames.Append("|")
                Next

            Catch ex As Exception
                Throw New Exception("Error obtaining group names. " & ex.Message)
            End Try

            Return groupNames.ToString()
        End Function

    End Class
End Namespace