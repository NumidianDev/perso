﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Web.Security
Imports WebMatrix.WebData

Public Class ChequeMembershipProvider
    Inherits ExtendedMembershipProvider

    Public Overrides Property ApplicationName As String
        Get
            Throw New NotImplementedException()
        End Get
        Set(value As String)
            Throw New NotImplementedException()
        End Set
    End Property

    Public Overrides Function ChangePassword(username As String, oldPassword As String, newPassword As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides Function ChangePasswordQuestionAndAnswer(username As String, password As String, newPasswordQuestion As String, newPasswordAnswer As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function ConfirmAccount(accountConfirmationToken As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function ConfirmAccount(userName As String, accountConfirmationToken As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function CreateAccount(userName As String, password As String, requireConfirmationToken As Boolean) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function CreateUser(username As String, password As String, email As String, passwordQuestion As String, passwordAnswer As String, isApproved As Boolean, _
        providerUserKey As Object, ByRef status As MembershipCreateStatus) As MembershipUser
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function CreateUserAndAccount(userName As String, password As String, requireConfirmation As Boolean, values As System.Collections.Generic.IDictionary(Of String, Object)) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function DeleteAccount(userName As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides Function DeleteUser(username As String, deleteAllRelatedData As Boolean) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides ReadOnly Property EnablePasswordReset() As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides ReadOnly Property EnablePasswordRetrieval As Boolean
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides Function FindUsersByEmail(emailToMatch As String, pageIndex As Integer, pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
        Throw New NotImplementedException()
    End Function

    Public Overrides Function FindUsersByName(usernameToMatch As String, pageIndex As Integer, pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function GeneratePasswordResetToken(userName As String, tokenExpirationInMinutesFromNow As Integer) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetAccountsForUser(userName As String) As System.Collections.Generic.ICollection(Of WebMatrix.WebData.OAuthAccountData)
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetAllUsers(pageIndex As Integer, pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetCreateDate(userName As String) As Date
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetLastPasswordFailureDate(userName As String) As Date
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetNumberOfUsersOnline() As Integer
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetPassword(username As String, answer As String) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetPasswordChangedDate(userName As String) As Date
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetPasswordFailuresSinceLastSuccess(userName As String) As Integer
        Throw New NotImplementedException()
    End Function

    Public Overloads Overrides Function GetUser(providerUserKey As Object, userIsOnline As Boolean) As System.Web.Security.MembershipUser
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetUser(username As String, userIsOnline As Boolean) As MembershipUser

        'Dim usersContext As DB = New DB()

        'Dim user = usersContext.COABS.Where(Function(ca) ca.Email.Equals(username)).FirstOrDefault
        'If user IsNot Nothing Then
        '    Dim memUser = New MembershipUser("EtradeMembershipProvider", username, user.Id, user.Email, String.Empty, String.Empty, _
        '     True, False, DateTime.MinValue, DateTime.MinValue, DateTime.MinValue, DateTime.Now, _
        '     DateTime.Now)
        '    Return memUser
        'End If
        Return Nothing

    End Function

    Public Overrides Function GetUserIdFromPasswordResetToken(token As String) As Integer
        Throw New NotImplementedException()
    End Function

    Public Overrides Function GetUserNameByEmail(email As String) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function IsConfirmed(userName As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides ReadOnly Property MaxInvalidPasswordAttempts As Integer
        Get
            Return 6
        End Get
    End Property

    Public Overrides ReadOnly Property MinRequiredNonAlphanumericCharacters As Integer
        Get
            Return 1
        End Get
    End Property

    Public Overrides ReadOnly Property MinRequiredPasswordLength As Integer
        Get
            Return 6
        End Get
    End Property

    Public Overrides ReadOnly Property PasswordAttemptWindow As Integer
        Get
            Return 6
        End Get
    End Property

    Public Overrides ReadOnly Property PasswordFormat As System.Web.Security.MembershipPasswordFormat
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides ReadOnly Property PasswordStrengthRegularExpression As String
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides ReadOnly Property RequiresQuestionAndAnswer As Boolean
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Overrides ReadOnly Property RequiresUniqueEmail As Boolean
        Get
            Return True
        End Get
    End Property

    Public Overrides Function ResetPassword(username As String, answer As String) As String
        Throw New NotImplementedException()
    End Function

    Public Overrides Function ResetPasswordWithToken(token As String, newPassword As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides Function UnlockUser(userName As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Public Overrides Sub UpdateUser(user As System.Web.Security.MembershipUser)
        Throw New NotImplementedException()
    End Sub

    Public Overrides Function ValidateUser(username As String, password As String) As Boolean
        ' Implementer l'authentification AD
        'Return True
        Return LDAP.LdapAuthentication.GetInstance.IsAuthenticated(username, password)
    End Function


End Class
