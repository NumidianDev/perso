﻿Public Class Cheque

    Public Property uti As String
        Get
            Return _uti
        End Get
        Set(value As String)
            _uti = value
        End Set
    End Property
    Private _uti As String

    Public Property nom As String
        Get
            Return _nom
        End Get
        Set(value As String)
            _nom = value
        End Set
    End Property
    Private _nom As String

    Public Property num_cheque As String
        Get
            Return _num_cheque
        End Get
        Set(value As String)
            _num_cheque = value
        End Set
    End Property
    Private _num_cheque As String

    Public Property benef As String
        Get
            Return _benef
        End Get
        Set(value As String)
            _benef = value
        End Set
    End Property
    Private _benef As String

    Public Property montant As Double
        Get
            Return _montant
        End Get
        Set(value As Double)
            _montant = value
        End Set
    End Property
    Private _montant As Double

    Public Property agence As String
        Get
            Return _agence
        End Get
        Set(value As String)
            _agence = value
        End Set
    End Property
    Private _agence As String

    Public Property libagence As String
        Get
            Return _libagence
        End Get
        Set(value As String)
            _libagence = value
        End Set
    End Property
    Private _libagence As String

    Public Property montantLettres As String
        Get
            Return _montantLettres
        End Get
        Set(value As String)
            _montantLettres = value
        End Set
    End Property
    Private _montantLettres As String
End Class
