﻿Imports System.Security.Principal

Public Class LogUtils

    Private Shared instance As LogUtils

    Private Sub New()

    End Sub

    Public Shared Function getInstance() As LogUtils
        If instance Is Nothing Then
            instance = New LogUtils()
        End If
        Return instance
    End Function

    Public Sub LogSecurityViolation(ByVal User As IPrincipal)
        log4net.LogManager.GetLogger(MyBase.GetType).Warn("Messages | Tentative d'accès à un dossier non authorisé | " & " | " & User.Identity.Name)
    End Sub

    Public Sub LogException(ByVal message As String, ByVal User As IPrincipal)
        log4net.LogManager.GetLogger(MyBase.GetType).Warn("Messages | " & message & " | " & User.Identity.Name)
    End Sub

    Public Sub LogInfo(ByVal message As String, ByVal User As IPrincipal)
        log4net.LogManager.GetLogger(MyBase.GetType).Info("Messages | " & message & " | " & User.Identity.Name)
    End Sub
End Class
