﻿Imports System.Linq
Imports GridMvc.Pagination
Imports GridMvc


Public Class ChequesGrid
    Inherits Grid(Of Cheque)

    Public Sub New(ByVal cheques As IQueryable(Of Cheque))
        MyBase.New(cheques)
        Language = "fr"
    End Sub
End Class
