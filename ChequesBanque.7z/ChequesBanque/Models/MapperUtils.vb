﻿Public Class MapperUtils
    Public Shared Sub EntityToDataSet(Of TEntity)(ByRef ds As DataSet, ByVal MyEntities As List(Of TEntity), Optional ByVal tableName As String = "")
        Dim strTableName As String
        Dim drNewRow As DataRow
        For Each POCO In MyEntities
            Dim EntityFields = POCO.GetType.GetProperties.Where(Function(a) a.CanRead)
            If Not POCO.GetType.Assembly.IsDynamic Then
                strTableName = POCO.GetType.Name
            Else
                strTableName = POCO.GetType.BaseType.Name
            End If

            If Not strTableName.EndsWith("s") Then
                strTableName = strTableName & "s"
            End If

            If Not String.IsNullOrEmpty(tableName) Then
                strTableName = tableName
            End If
            drNewRow = ds.Tables(strTableName).NewRow
            For Each field In EntityFields
                If drNewRow.Table.Columns.Contains(field.Name) Then
                    drNewRow(field.Name) = If(field.GetValue(POCO, Nothing), DBNull.Value)
                End If
            Next
            ds.Tables(strTableName).Rows.Add(drNewRow)
        Next POCO
    End Sub

    Public Shared Function DataTableToDto(ByVal dt As DataTable) As IList(Of Cheque)

        Dim cheques As IList(Of Cheque) = New List(Of Cheque)

        For Each dr As DataRow In dt.Rows
            cheques.Add(New Cheque With { _
                    .uti = dr("uti"), _
                    .nom = dr("nom"), _
                    .num_cheque = dr("num_cheque"), _
                    .montantLettres = dr("montantLettres"), _
                    .montant = dr("montant"), _
                    .libagence = dr("libagence"), _
                    .benef = dr("benef"), _
                    .agence = dr("agence")
                })
        Next
        Return cheques
    End Function

    Public Shared Function ChiffresEnLettres(ByVal inD As Double) As String
        Dim outString As String = String.Empty
        Dim centaine, dizaine, unite, y As Double
        Dim dix As Boolean = False
        Dim reste As Double = inD
        Dim i As Int32 = 1000000000

        Do While i >= 1

            y = (reste - reste Mod i) / i

            If y <> 0 Then
                centaine = (y - y Mod 100) / 100
                dizaine = ((y - centaine * 100) - (y - centaine * 100) Mod 10) / 10
                unite = y - (centaine * 100) - (dizaine * 10)

                Select Case centaine
                    Case 0
                        Exit Select
                    Case 1
                        outString = outString & "Cent "
                    Case 2
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Deux cents "
                        Else
                            outString = outString & "Deux cent "
                        End If
                    Case 3
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Trois cents "
                        Else
                            outString = outString & "Trois cent "
                        End If
                    Case 4
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Quatre cents "
                        Else
                            outString = outString & "Quatre cent "
                        End If
                    Case 5
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Cinq cents "
                        Else
                            outString = outString & "Cinq cent "
                        End If
                    Case 6
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Six cents "
                        Else
                            outString = outString & "Six cent "
                        End If
                    Case 7
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Sept cents "
                        Else
                            outString = outString & "Sept cent "
                        End If
                    Case 8
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Huit cents "
                        Else
                            outString = outString & "Huit cent "
                        End If
                    Case 9
                        If (dizaine = 0 AndAlso unite = 0) Then
                            outString = outString & "Neuf cents "
                        Else
                            outString = outString & "Neuf cent "
                        End If
                End Select
                Select Case dizaine
                    Case 0
                        Exit Select
                    Case 1
                        dix = True
                    Case 2
                        outString = outString & "Vingt "
                    Case 3
                        outString = outString & "Trente "
                    Case 4
                        outString = outString & "Quarante "
                    Case 5
                        outString = outString & "Cinquante "
                    Case 6
                        outString = outString & "Soixante "
                    Case 7
                        dix = True
                        outString = outString & "Soixante "
                    Case 8
                        outString = outString & "Quatre-Vingt "
                    Case 9
                        dix = True
                        outString = outString & "Quatre-Vingt "
                End Select
                Select Case unite
                    Case 0
                        If dix Then
                            outString = outString & "Dix "
                        End If
                    Case 1
                        If dix Then
                            outString = outString & "Onze "
                        Else
                            outString = outString & "Un "
                        End If
                    Case 2
                        If dix Then
                            outString = outString & "Douze "
                        Else
                            outString = outString & "Deux "
                        End If
                    Case 3
                        If dix Then
                            outString = outString & "Treize "
                        Else
                            outString = outString & "Trois "
                        End If
                    Case 4
                        If dix Then
                            outString = outString & "Quatorze "
                        Else
                            outString = outString & "Quatre "
                        End If
                    Case 5
                        If dix Then
                            outString = outString & "Quinze "
                        Else
                            outString = outString & "Cinq "
                        End If
                    Case 6
                        If dix Then
                            outString = outString & "Seize "
                        Else
                            outString = outString & "Six "
                        End If
                    Case 7
                        If dix Then
                            outString = outString & "Dix-Sept "
                        Else
                            outString = outString & "Sept "
                        End If
                    Case 8
                        If dix Then
                            outString = outString & "Dix-Huit "
                        Else
                            outString = outString & "Huit "
                        End If
                    Case 9
                        If dix Then
                            outString = outString & "Dix-Neuf "
                        Else
                            outString = outString & "Neuf "
                        End If
                End Select

                Select Case i
                    Case 1000000000
                        If y > 1 Then
                            outString = outString & "Milliards "
                        Else
                            outString = outString & "Milliard "
                        End If
                    Case 1000000
                        If y > 1 Then
                            outString = outString & "Millions "
                        Else
                            outString = outString & "Million "
                        End If
                    Case 1000
                        outString = outString & "Mille "
                End Select
            End If

            reste = reste - y * i
            dix = False
            Console.Write(i)
            i = i / 1000
        Loop

        Dim outCentimes As String = String.Empty
        Dim centimes As Double = Math.Round(reste, 2) * 100

        If centimes <> 0 Then
            dizaine = (centimes - centimes Mod 10) / 10
            unite = centimes - (dizaine * 10)
            dix = False

            Select Case dizaine
                Case 0
                    Exit Select
                Case 1
                    dix = True
                Case 2
                    outCentimes = outCentimes & "Vingt "
                Case 3
                    outCentimes = outCentimes & "Trente "
                Case 4
                    outCentimes = outCentimes & "Quarante "
                Case 5
                    outCentimes = outCentimes & "Cinquante "
                Case 6
                    outCentimes = outCentimes & "Soixante "
                Case 7
                    dix = True
                    outCentimes = outCentimes & "Soixante "
                Case 8
                    outCentimes = outCentimes & "Quatre-Vingt "
                Case 9
                    dix = True
                    outCentimes = outCentimes & "Quatre-Vingt "
            End Select
            Select Case unite
                Case 0
                    If dix Then
                        outCentimes = outCentimes & "Dix "
                    End If
                Case 1
                    If dix Then
                        outCentimes = outCentimes & "Onze "
                    Else
                        outCentimes = outCentimes & "Un "
                    End If
                Case 2
                    If dix Then
                        outCentimes = outCentimes & "Douze "
                    Else
                        outCentimes = outCentimes & "Deux "
                    End If
                Case 3
                    If dix Then
                        outCentimes = outCentimes & "Treize "
                    Else
                        outCentimes = outCentimes & "Trois "
                    End If
                Case 4
                    If dix Then
                        outCentimes = outCentimes & "Quatorze "
                    Else
                        outCentimes = outCentimes & "Quatre "
                    End If
                Case 5
                    If dix Then
                        outCentimes = outCentimes & "Quinze "
                    Else
                        outCentimes = outCentimes & "Cinq "
                    End If
                Case 6
                    If dix Then
                        outCentimes = outCentimes & "Seize "
                    Else
                        outCentimes = outCentimes & "Six "
                    End If
                Case 7
                    If dix Then
                        outCentimes = outCentimes & "Dix-Sept "
                    Else
                        outCentimes = outCentimes & "Sept "
                    End If
                Case 8
                    If dix Then
                        outCentimes = outCentimes & "Dix-Huit "
                    Else
                        outCentimes = outCentimes & "Huit "
                    End If
                Case 9
                    If dix Then
                        outCentimes = outCentimes & "Dix-Neuf "
                    Else
                        outCentimes = outCentimes & "Neuf "
                    End If
            End Select

        End If

        Return outString & " Dinars Algériens " & IIf(String.IsNullOrEmpty(outCentimes), String.Empty, " et " & outCentimes & " centimes ")

    End Function

End Class
