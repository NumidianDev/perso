﻿Public Class LdapUser

    Public Property Matricule() As String
        Get
            Return _matricule
        End Get
        Set(value As String)
            _matricule = value
        End Set
    End Property
    Private _matricule As String

    Public Property Nom() As String
        Get
            Return _nom
        End Get
        Set(value As String)
            _nom = value
        End Set
    End Property
    Private _nom As String

    Public Property Prenom() As String
        Get
            Return _prenom
        End Get
        Set(value As String)
            _prenom = value
        End Set
    End Property
    Private _prenom As String

End Class
