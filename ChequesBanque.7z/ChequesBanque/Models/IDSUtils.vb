﻿Imports log4net
Imports System.Data.OleDb
Imports System.IO

Public Class IDSUtils

    Private Shared instance As IDSUtils
    Private Shared connectionString As String

    Private dirtyQuery As String = "set isolation to dirty read"

    Private Shared ReadOnly logger As ILog = log4net.LogManager.GetLogger(GetType(IDSUtils))

    Private Sub New()

        Try
            Dim csName As String = ConfigurationManager.AppSettings("csName")
            If String.IsNullOrEmpty(csName) Then
                logger.Fatal("Le nom de la chaine de connection n'est pas spécifié")
                csName = "Delta"
            End If
            connectionString = ConfigurationManager.ConnectionStrings(csName).ConnectionString
            logger.Debug(connectionString)
        Catch ex As Exception
            logger.Debug("erreur chaine de connection ")
        End Try

    End Sub

    Public Shared Function getInstance() As IDSUtils
        If instance Is Nothing Then
            logger.Debug("New instance ids")
            instance = New IDSUtils()
        End If
        Return instance
    End Function

    Public Function ProcessQuery(ByVal scriptFileName As String) As DataTable

        logger.Debug("ProcessQuery - begin ")

        Dim result As DataTable = New DataTable()

        Dim file As FileInfo = New FileInfo(GetScriptDirectory() & scriptFileName & ".sql")

        Dim script As String = file.OpenText().ReadToEnd()

        Dim commandStrings As IEnumerable(Of String) = Regex.Split(script, "^\s*GO\s*$", RegexOptions.Multiline Or RegexOptions.IgnoreCase)

        Try

            Using con As OleDbConnection = New OleDbConnection(connectionString)

                con.Open()

                logger.Debug("connection opened")

                Dim command As OleDbCommand = con.CreateCommand()
                command.CommandTimeout = 1000000000
                command.CommandType = CommandType.Text

                For i As Int32 = 0 To commandStrings.Count - 2
                    command.CommandText = commandStrings(i)
                    command.ExecuteNonQuery()
                Next

                command.CommandText = String.Format(commandStrings.Last, HttpContext.Current.User.Identity.Name)
                'command.CommandText = commandStrings.Last
                logger.Debug(command.CommandText)

                Dim da As OleDbDataAdapter = New OleDbDataAdapter(command)
                da.Fill(result)

                logger.Debug("Process " & scriptFileName & " END - " & result.Rows.Count)

            End Using

            Return result

        Catch ex As Exception
            logger.Warn(ex.Message)
            If ex.InnerException IsNot Nothing Then
                logger.Warn(ex.InnerException.Message)
            End If
            Throw ex
        End Try

    End Function

    Public Shared Function GetScriptDirectory() As String

        Dim scriptDirectory As String = ConfigurationManager.AppSettings("ScriptDir")

        If String.IsNullOrEmpty(scriptDirectory) Then
            scriptDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Query")
        Else
            scriptDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, scriptDirectory)
            If Not scriptDirectory.EndsWith("\") Then
                scriptDirectory += "\"
            End If
        End If

        Return scriptDirectory

    End Function
End Class
