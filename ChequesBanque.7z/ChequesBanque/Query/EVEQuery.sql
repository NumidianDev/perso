﻿select 
	uti, 
	nom1 as nom, 
	ncff as num_cheque, 
	nomb as benef,  
	mnat as montant, 
	agsa as agence,
	(select trim(nvl(lib1,'')) from bknom where ctab = '001' and cacc = agsa) as libagence
from bkeve
where ncpe='2615000000' and nat='CHQBAN' and eta in ('VA','VF')
and uti = '{0}'
