﻿select distinct 
	nom1 as nom
from bkeve
where ncpe='2615000000' and nat='CHQBAN' and eta in ('VA','VF')
and uti = '{0}'