﻿Imports System.Web
Imports System.Web.Optimization

Public Class BundleConfig
    ' For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
    Public Shared Sub RegisterBundles(ByVal bundles As BundleCollection)
        bundles.Add(New ScriptBundle("~/bundles/jquery").Include(
                   "~/Scripts/jquery-{version}.js"))

        bundles.Add(New ScriptBundle("~/bundles/metro").Include(
                   "~/Scripts/metro.js",
                   "~/Scripts/bootbox.js",
                   "~/Scripts/select/select2.js",
                   "~/Scripts/select/i18n/fr.js",
                   "~/Scripts/async-include-extra.js"))

        bundles.Add(New ScriptBundle("~/bundles/grid").Include(
                   "~/Scripts/gridmvc.js",
                   "~/Scripts/gridmvc.lang.fr.js",
                   "~/Scripts/gridmvc.benefwidgets.js",
                   "~/Scripts/gridmvc.emetteurswidgets.js"))


        bundles.Add(New StyleBundle("~/Content/gridcss").Include("~/Content/Gridmvc.css"))

        bundles.Add(New StyleBundle("~/Content/css").Include("~/Content/metro.css",
                                                             "~/Content/metro-icons.css",
                                                             "~/Content/site.css",
                                                             "~/Content/metro-responsive.css",
                                                             "~/Content/metro-schemes.css"))

    End Sub
End Class