﻿Imports CrystalDecisions.CrystalReports.Engine

Public Class ChequeController
    Inherits System.Web.Mvc.Controller

    '
    ' GET: /Cheque

    Function Index() As ActionResult
        Return View()
    End Function

    Function Grid() As ActionResult

        Try
            'Dim scriptFileName As String = ConfigurationManager.AppSettings("scriptFileName")
            'Dim dt As DataTable = IDSUtils.getInstance.ProcessQuery(scriptFileName)
            'dt.TableName = "Cheques"
            'dt.Columns.Add("montantLettres", Type.GetType("System.String"))
            'dt.AcceptChanges()

            'For Each dr As DataRow In dt.Rows
            '    Dim montantLettres As String = MapperUtils.ChiffresEnLettres(dr("montant")).ToLower()
            '    dr("montantLettres") = Char.ToUpper(montantLettres(0)) & montantLettres.Substring(1)
            'Next

            'dt.AcceptChanges()

            Dim dt As DataTable = New DataTable()
            dt.ReadXml("D:\eve.xml")

            For Each dr As DataRow In dt.Rows
                Dim montantLettres As String = MapperUtils.ChiffresEnLettres(dr("montant")).ToLower()
                dr("montantLettres") = Char.ToUpper(montantLettres(0)) & montantLettres.Substring(1)
            Next

            dt.AcceptChanges()

            Dim cheques As IList(Of Cheque) = MapperUtils.DataTableToDto(dt)
            Return PartialView("_ChequesGrid", New ChequesGrid(cheques.AsQueryable))

        Catch ex As Exception
            LogException(ex.Message)
        End Try
        

    End Function

    Function ListBeneficiaires() As JsonResult
        Try
            Dim scriptFileName As String = ConfigurationManager.AppSettings("BenefScriptFileName")
            Dim dt As DataTable = IDSUtils.getInstance.ProcessQuery(scriptFileName)
            Dim benefs As IList(Of String) = (From dr As DataRow In dt.Rows
                         Select dr.Field(Of String)("benef")).ToList
            Return Json(New With {.Items = benefs})
        Catch ex As Exception
            LogException(ex.Message)
        End Try
        
    End Function

    Function ListEmetteurs() As JsonResult
        Try
            Dim scriptFileName As String = ConfigurationManager.AppSettings("EmetteurScriptFileName")
            Dim dt As DataTable = IDSUtils.getInstance.ProcessQuery(scriptFileName)
            Dim benefs As IList(Of String) = (From dr As DataRow In dt.Rows
                         Select dr.Field(Of String)("nom")).ToList
            Return Json(New With {.Items = benefs})
        Catch ex As Exception
            LogException(ex.Message)
        End Try
       
    End Function

    Function Download(ByVal uti As String, ByVal num_cheque As String, ByVal agence As String, ByVal libagence As String, _
                      ByVal nom As String, ByVal benef As String, ByVal montant As Double, ByVal montantLettres As String) As ActionResult

        Try
            Dim listCheques As IList(Of Cheque) = New List(Of Cheque)
            listCheques.Add(New Cheque With { _
                                                .uti = uti, _
                                                .num_cheque = num_cheque, _
                                                .agence = agence, _
                                                .libagence = libagence, _
                                                .nom = nom, _
                                                .benef = benef, _
                                                .montant = montant, _
                                                .montantLettres = montantLettres
                                            })


            Dim ds As DataSet = New DataSet

            ds.ReadXmlSchema(Server.MapPath("~\Report\ChequeDataSet.xsd"))
            MapperUtils.EntityToDataSet(Of Cheque)(ds, listCheques)

            Dim report As ReportDocument = Nothing

            Try
                report = New ReportDocument
                report.Load(Server.MapPath("~\Report\Cheques.rpt"))
                report.SetDataSource(ds)

                Dim filePath As String = Server.MapPath("~\cheques.pdf")

                report.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, System.Web.HttpContext.Current.Response, True, "Cheque_N_" & num_cheque.ToString() & Date.Now.ToString("ddMMyyyy") & ".pdf")

            Catch ex As Exception
                LogUtils.getInstance.LogException(ex.Message, User)
            End Try
        Catch ex As Exception
            LogException(ex.Message)
        End Try

        

    End Function


    Function PrintItem(ByVal c As Cheque) As ActionResult

        Dim listCheques As IList(Of Cheque) = New List(Of Cheque)
        listCheques.Add(c)
        'listCheques.Add(New Cheque With { _
        '                                    .uti = uti, _
        '                                    .num_cheque = num_cheque, _
        '                                    .agence = agence, _
        '                                    .libagence = libagence, _
        '                                    .nom = nom, _
        '                                    .benef = benef, _
        '                                    .montant = montant, _
        '                                    .montantLettres = montantLettres
        '                                })


        Dim ds As DataSet = New DataSet

        ds.ReadXmlSchema(Server.MapPath("~\Report\ChequeDataSet.xsd"))
        MapperUtils.EntityToDataSet(Of Cheque)(ds, listCheques)

        Dim report As ReportDocument = Nothing

        Try

            report = New ReportDocument
            report.Load(Server.MapPath("~\Report\Cheques.rpt"))
            report.SetDataSource(ds)

            Dim filePath As String = Server.MapPath("~\cheques.pdf")

            'report.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, System.Web.HttpContext.Current.Response, True, "Cheque_N_" & c.num_cheque.ToString() & Date.Now.ToString("ddMMyyyy") & ".pdf")

            'Dim filePath As String = Server.MapPath("~\cession.pdf")
            report.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, System.Web.HttpContext.Current.Response, False, c.num_cheque & ".pdf")
            LogInfo("aperçu rendu")
        Catch ex As Exception
            LogException(ex.Message)
            LogException(ex.StackTrace)
            If ex.InnerException IsNot Nothing Then
                LogException(ex.InnerException.Message)
            End If
        Finally
            report.Close()
            report.Dispose()
            report = Nothing
            GC.Collect()
        End Try

    End Function

    Protected Friend Sub LogSecurityViolation()
        log4net.LogManager.GetLogger(MyBase.GetType).Warn("Messages | Tentative d'accès à un dossier non authorisé | " & User.Identity.Name)
    End Sub

    Protected Friend Sub LogException(ByVal message As String)
        log4net.LogManager.GetLogger(MyBase.GetType).Warn("Messages | " & message & " | " & User.Identity.Name)
    End Sub

    Protected Friend Sub LogInfo(ByVal message As String)
        log4net.LogManager.GetLogger(MyBase.GetType).Info("Messages | " & message & " | " & User.Identity.Name)
    End Sub

End Class