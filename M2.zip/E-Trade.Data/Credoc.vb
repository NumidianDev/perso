﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("Credoc")>
Public Class Credoc

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    <DisplayName("Numéro du credoc")>
    Public Property CDI() As String
        Get
            Return m_CDI
        End Get
        Set(value As String)
            m_CDI = value
        End Set
    End Property
    Private m_CDI As String

    <DisplayName("Référence workflow")>
    Public Property REFWF() As String
        Get
            Return m_REFWF
        End Get
        Set(value As String)
            m_REFWF = value
        End Set
    End Property
    Private m_REFWF As String
    <Required(ErrorMessage:="Veuillez renseigner la référence Pré-domiciliation")> _
     <RegularExpression("([0-9]){9}", ErrorMessage:="Réference pré-domiciliation invalide, doit être sur 9 positions numérique")>
    Public Property RefPreDom() As String
        Get
            Return m_RefPreDom
        End Get
        Set(value As String)
            m_RefPreDom = value
        End Set
    End Property
    Private m_RefPreDom As String

    Public Property Id_StatutCredoc() As Int32
        Get
            Return m_Id_StatutCredoc
        End Get
        Set(value As Int32)
            m_Id_StatutCredoc = value
        End Set
    End Property
    Private m_Id_StatutCredoc As Int32

    <ForeignKey("Id_StatutCredoc")>
    Public Overridable Property StatutCredoc() As StatutCredoc
        Get
            Return m_StatutCredoc
        End Get
        Set(value As StatutCredoc)
            m_StatutCredoc = value
        End Set
    End Property
    Private m_StatutCredoc As StatutCredoc

    <DisplayName("Date de création")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property DateCreation() As DateTime?
        Get
            Return m_DateCreation
        End Get
        Set(value As DateTime?)
            m_DateCreation = value
        End Set
    End Property
    Private m_DateCreation As DateTime?

    Public Property Radical_Client() As String
        Get
            Return m_radical_client
        End Get
        Set(value As String)
            m_radical_client = value
        End Set
    End Property
    Private m_radical_client As String

    <ForeignKey("Radical_Client")>
    Public Overridable Property Client() As Client
        Get
            Return m_client
        End Get
        Set(value As Client)
            m_client = value
        End Set
    End Property
    Private m_client As Client

    <DisplayName("Agence")>
    <Required(ErrorMessage:="Veuillez séléctionnez une agence dans la liste")> _
    Public Property Age_Agence() As String
        Get
            Return m_age_agence
        End Get
        Set(value As String)
            m_age_agence = value
        End Set
    End Property
    Private m_age_agence As String

    <ForeignKey("Age_Agence")>
    Public Overridable Property Agence() As Agence
        Get
            Return m_agence
        End Get
        Set(value As Agence)
            m_agence = value
        End Set
    End Property
    Private m_agence As Agence

    ' A gérer la liste des comptes filtrée par l'agence 
    <DisplayName("N° Compte ")>
    <Required(ErrorMessage:="Veuillez séléctionnez un compte dans la liste")> _
    Public Property Ncp_Compte() As String
        Get
            Return m_Ncp_Compte
        End Get
        Set(value As String)
            m_Ncp_Compte = value
        End Set
    End Property
    Private m_Ncp_Compte As String

    <DisplayName("Bénéficiaire")>
    <Required(ErrorMessage:="Veuillez renseigner le nom du bénéficaire")> _
    Public Property NomBeneficiaire() As String
        Get
            Return m_NomBeneficiaire
        End Get
        Set(value As String)
            m_NomBeneficiaire = value
        End Set
    End Property
    Private m_NomBeneficiaire As String

    <DisplayName("Adresse")>
    <Required(ErrorMessage:="Veuillez renseigner l'adresse du bénéficaire")> _
    Public Property AdresseBeneficiaire() As String
        Get
            Return m_AdresseBeneficiaire
        End Get
        Set(value As String)
            m_AdresseBeneficiaire = value
        End Set
    End Property
    Private m_AdresseBeneficiaire As String

    <DisplayName("Téléphone")>
    <Required(ErrorMessage:="Veuillez renseigner le téléphone du bénéficaire")> _
    Public Property TelBeneficiaire() As String
        Get
            Return m_TelBeneficiaire
        End Get
        Set(value As String)
            m_TelBeneficiaire = value
        End Set
    End Property
    Private m_TelBeneficiaire As String

    <DisplayName("Fax")>
    <Required(ErrorMessage:="Veuillez renseigner le fax du bénéficaire")> _
    Public Property FaxBeneficiaire() As String
        Get
            Return m_FaxBeneficiaire
        End Get
        Set(value As String)
            m_FaxBeneficiaire = value
        End Set
    End Property
    Private m_FaxBeneficiaire As String

    <Required(ErrorMessage:="Veuillez renseigner le nom de la banque du bénéficaire")>
    <DisplayName("Banque du bénéficiaire")>
    Public Property BanqueBeneficiaire() As String
        Get
            Return m_BanqueBeneficiaire
        End Get
        Set(value As String)
            m_BanqueBeneficiaire = value
        End Set
    End Property
    Private m_BanqueBeneficiaire As String

    <NotMapped()>
    Public ReadOnly Property MaxExpiration() As DateTime?
        Get
            Return IIf(m_EmbExpAuPlusTard.HasValue, m_EmbExpAuPlusTard.Value.AddDays(31), DateTime.MinValue)
        End Get
    End Property
    
    <DisplayName("Date d’expiration")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    <Required(ErrorMessage:="La date d'expiration est obligatoire")> _
    <RequiredIf("DateExpCredit < MaxExpiration And DateExpCredit > EmbExpAuPlusTard", ErrorMessage:="La date d'expiration doit être ultérieur d'un mois à la date maximum d'embarquement / expédition")> _
    Public Property DateExpCredit() As DateTime?
        Get
            Return m_DateExpCredit
        End Get
        Set(value As DateTime?)
            m_DateExpCredit = value
        End Set
    End Property
    Private m_DateExpCredit As DateTime?

    <DisplayName("Lieu d'expiration")>
    <Required(ErrorMessage:="Veuillez renseigner le lieu d'expiration")> _
    Public Property LieuExpCredit() As String
        Get
            Return m_LieuExpCredit
        End Get
        Set(value As String)
            m_LieuExpCredit = value
        End Set
    End Property
    Private m_LieuExpCredit As String

    <DisplayName("Irrévocable")>
    Public Property Irrevocable() As Boolean
        Get
            Return m_Irrevocable
        End Get
        Set(value As Boolean)
            m_Irrevocable = value
            m_IrrevocableConfirme = Not value
        End Set
    End Property
    Private m_Irrevocable As Boolean

    <DisplayName("Irrévocable & confirmé")>
    Public Property IrrevocableConfirme() As Boolean
        Get
            Return m_IrrevocableConfirme
        End Get
        Set(value As Boolean)
            m_IrrevocableConfirme = value
            m_Irrevocable = Not value
        End Set
    End Property
    Private m_IrrevocableConfirme As Boolean

    <DisplayName("Crédit transférable")>
    Public Property Transferable() As Boolean
        Get
            Return m_Transferable
        End Get
        Set(value As Boolean)
            m_Transferable = value
        End Set
    End Property
    Private m_Transferable As Boolean

    <DisplayName("Assurance couverte par")>
    Public Property AssuranceACharge() As String
        Get
            Return m_AssuranceACharge
        End Get
        Set(value As String)
            m_AssuranceACharge = value
        End Set
    End Property
    Private m_AssuranceACharge As String

    <DisplayName("Expédition partielle")>
    Public Property ExpPartielleAutorisee() As Boolean
        Get
            Return m_ExpPartielleAutorisee
        End Get
        Set(value As Boolean)
            m_ExpPartielleAutorisee = value
        End Set
    End Property
    Private m_ExpPartielleAutorisee As Boolean

    <DisplayName("Transbordement")>
    Public Property TransbordementAutorise() As Boolean
        Get
            Return m_TransbordementAutorise
        End Get
        Set(value As Boolean)
            m_TransbordementAutorise = value
        End Set
    End Property
    Private m_TransbordementAutorise As Boolean

    <DisplayName("Prise en charge de")>
    <Required(ErrorMessage:="Indiquez l'origine de l'expédition / embarquement")> _
    Public Property EmbExpPriseCharge() As String
        Get
            Return m_EmbExpPriseCharge
        End Get
        Set(value As String)
            m_EmbExpPriseCharge = value
        End Set
    End Property
    Private m_EmbExpPriseCharge As String

    <DisplayName("A destination de")>
    <Required(ErrorMessage:="Indiquez la destination de l'expédition / débarquement")> _
    Public Property EmbExpDestination() As String
        Get
            Return m_EmbExpDestination
        End Get
        Set(value As String)
            m_EmbExpDestination = value
        End Set
    End Property
    Private m_EmbExpDestination As String

    <DisplayName("Au plus tard le")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    <Required(ErrorMessage:="Indiquez la date limite de l'expédition / embarquement")> _
    Public Property EmbExpAuPlusTard() As DateTime?
        Get
            Return m_EmbExpAuPlusTard
        End Get
        Set(value As DateTime?)
            m_EmbExpAuPlusTard = value
        End Set
    End Property
    Private m_EmbExpAuPlusTard As DateTime?

    <DisplayName("En chiffres")>
    <Required(ErrorMessage:="Veuillez renseigner le montant du crédit "), Range(1, Double.MaxValue, ErrorMessage:="Le montant doit être supérieur à zéro")> _
    Public Property MontantCDIChiffre() As Double
        Get
            Return m_MontantCDIChiffre
        End Get
        Set(value As Double)
            m_MontantCDIChiffre = value
        End Set
    End Property
    Private m_MontantCDIChiffre As Double
    <NotMapped()>
    <RegularExpression("^[0-9]+([.,][0-9]+)?$", ErrorMessage:="Veuillez saisir un montant")>
    <Required(ErrorMessage:="Ce champ est nécessaire."), Range(1, Double.MaxValue, ErrorMessage:="Le montant doit être supérieur à zéro")>
    Public Property MontantCDI() As String
        Get
            Return m_MontantCDI
        End Get
        Set(ByVal value As String)
            m_MontantCDI = value
        End Set
    End Property
    Private m_MontantCDI As String
    <DisplayName("En lettres")>
    Public Property MontantCDILettres() As String
        Get
            Return m_MontantCDILettres
        End Get
        Set(value As String)
            m_MontantCDILettres = value
        End Set
    End Property
    Private m_MontantCDILettres As String

    <Required(ErrorMessage:="La devise du dossier de crédit est obligatoire")> _
    Public Property Devise() As String
        Get
            Return m_Devise
        End Get
        Set(value As String)
            m_Devise = value
        End Set
    End Property
    Private m_Devise As String

    <ConditionalRequiered("TypeTolerence.Equals(""Environ"")", ErrorMessage:="La variation est obligatoire si le type est à << Environ >>")>
    <Range(0, 10, ErrorMessage:="La variation doit être supérieur à 0 et inférieur à 10 % !")>
    Public Property Tolerence() As Double
        Get
            Return m_Tolerence
        End Get
        Set(value As Double)
            m_Tolerence = value
        End Set
    End Property
    Private m_Tolerence As Double

    <DisplayName("Seuil de tolérance ")>
    <NotFilled(_emptyString:="Z", ErrorMessage:="La variation doit être renseignée !")> _
    Public Property TypeTolerence() As String
        Get
            Return m_TypeTolerence
        End Get
        Set(value As String)
            m_TypeTolerence = value
        End Set
    End Property
    Private m_TypeTolerence As String

    <DisplayName("A ouvrir  auprès")>
    Public Property OuvrirAuPres() As String
        Get
            Return m_OuvrirAuPres
        End Get
        Set(value As String)
            m_OuvrirAuPres = value
        End Set
    End Property
    Private m_OuvrirAuPres As String

    <DisplayName("Code swift")>
    <Required(ErrorMessage:="Veuillez renseigner le code swift ")> _
    Public Property BBCodeSwift() As String
        Get
            Return m_BBCodeSwift
        End Get
        Set(value As String)
            m_BBCodeSwift = value
        End Set
    End Property
    Private m_BBCodeSwift As String

    <DisplayName("Mode de paiement")>
    <Required(ErrorMessage:="Veuillez renseigner le mode de paiement ")> _
    <NotFilled(_emptyString:="Z", ErrorMessage:="Le mode de paiement doit être renseigné !")> _
    Public Property ModePayement() As String
        Get
            Return m_ModePayement
        End Get
        Set(value As String)
            m_ModePayement = value
        End Set
    End Property
    Private m_ModePayement As String

    <DisplayName("Détails mode de paiement")>
    <ConditionalRequiered("Not ModePayement.Equals(""VUE"")", ErrorMessage:="Veuillez spécifier le détails du mode de paiement")>
    Public Property DetailsModePayement() As String
        Get
            Return m_DetailsModePayement
        End Get
        Set(value As String)
            m_DetailsModePayement = value
        End Set
    End Property
    Private m_DetailsModePayement As String

    <DisplayName("Description de la marchandise")>
    <Required(ErrorMessage:="Veuillez renseigner la description de la marchandise ")> _
    Public Property DescriptionMarchandise() As String
        Get
            Return m_DescriptionMarchandise
        End Get
        Set(value As String)
            m_DescriptionMarchandise = value
        End Set
    End Property
    Private m_DescriptionMarchandise As String

    <DisplayName("Type de pli")>
    <NotFilled(_emptyString:="Z", ErrorMessage:="Le type de pli doit être renseignée !")> _
    Public Property TypePli() As String
        Get
            Return m_TypePli
        End Get
        Set(value As String)
            m_TypePli = value
        End Set
    End Property
    Private m_TypePli As String

    <DisplayName("Tarif douanier")>
    <Required(ErrorMessage:="Veuillez renseigner le tarif douanier ")> _
    <RegularExpression("([0-9]){10}", ErrorMessage:="Tarif douanier invalide, doit être sur 10 positions numérique")>
    Public Property TarifDouanier() As String
        Get
            Return m_TarifDouanier
        End Get
        Set(value As String)
            m_TarifDouanier = value
        End Set
    End Property
    Private m_TarifDouanier As String

    <DisplayName("Conforme facture proformat N°")>
    <Required(ErrorMessage:="Veuillez renseigner le numéro de la facture ")> _
    Public Property Facture() As String
        Get
            Return m_Facture
        End Get
        Set(value As String)
            m_Facture = value
        End Set
    End Property
    Private m_Facture As String

    <DisplayName("Du")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    <Required(ErrorMessage:="Veuillez renseigner la date de la facture ")> _
    Public Property DateFacture() As DateTime?
        Get
            Return m_DateFacture
        End Get
        Set(value As DateTime?)
            m_DateFacture = value
        End Set
    End Property
    Private m_DateFacture As DateTime?

    <DisplayName("Contrat de vente")>
    Public Property Incoterm() As String
        Get
            Return m_Incoterm
        End Get
        Set(value As String)
            m_Incoterm = value
        End Set
    End Property
    Private m_Incoterm As String

    <DisplayName("Détails")>
    <ConditionalRequiered("Incoterm.Equals(""AUTRE"")", ErrorMessage:="Veuillez spécifier le détails")>
    Public Property DetailsIncoterm() As String
        Get
            Return m_DetailsIncoterm
        End Get
        Set(value As String)
            m_DetailsIncoterm = value
        End Set
    End Property
    Private m_DetailsIncoterm As String

    <DisplayName("Frais et commissions en dehors de l’Algérie sont à la charge du")>
    <NotFilled(_emptyString:="Z", ErrorMessage:="Information manquante (Frais de commission à charge ...) !")> _
    Public Property ChargeFraisComm() As String
        Get
            Return m_ChargeFraisComm
        End Get
        Set(value As String)
            m_ChargeFraisComm = value
        End Set
    End Property
    Private m_ChargeFraisComm As String

    <DisplayName("Caution de restitution d'acompte")>
    <Range(0, 15, ErrorMessage:="La caution de restitution doit être entre 1 et 15 % au maximum, 0 si pas de caution !")>
    Public Property CautionRestAcompte() As Double
        Get
            Return m_CautionRestAcompte
        End Get
        Set(value As Double)
            m_CautionRestAcompte = value
        End Set
    End Property
    Private m_CautionRestAcompte As Double

    <DisplayName("Caution de bonne fin d'exécutions")>
    <Range(0, 10, ErrorMessage:="La caution de bonne fin d'exécution doit être entre 1 et 10 % au maximum, 0 si pas de caution !")>
    Public Property CautionFinExec() As Double
        Get
            Return m_CautionFinExec
        End Get
        Set(value As Double)
            m_CautionFinExec = value
        End Set
    End Property
    Private m_CautionFinExec As Double

    <DisplayName("Opération entrant dans le cadre de")>
    <RegularExpression("^(?i:true|false)$", ErrorMessage:="Le cadre de l'opération doit être à <<Production>> ou <<Revente en l'état>> !")>
    <NotFilled(_emptyString:="A renseigner", ErrorMessage:="Veuillez renseigner le cadre de l'opération !")> _
    Public Property Production() As Boolean
        Get
            Return m_Production
        End Get
        Set(value As Boolean)
            m_Production = value
        End Set
    End Property
    Private m_Production As Boolean

    <DisplayName("Quantité")>
    Public Property Qte() As String
        Get
            Return m_Qte
        End Get
        Set(value As String)
            m_Qte = value
        End Set
    End Property
    Private m_Qte As String

    <DisplayName("Prix unitaire")>
    Public Property PrixUnit() As String
        Get
            Return m_PrixUnit
        End Get
        Set(value As String)
            m_PrixUnit = value
        End Set
    End Property
    Private m_PrixUnit As String

    <ConditionalRequiered("Production", ErrorMessage:="Le signataire est requis pour l'engagement")>
    Public Property Signataire() As String
        Get
            Return m_Signataire
        End Get
        Set(value As String)
            m_Signataire = value
        End Set
    End Property
    Private m_Signataire As String

    <DisplayName("Qualité du signataire")>
    <ConditionalRequiered("Production", ErrorMessage:="La qualité du signataire est requise pour l'engagement")>
    Public Property QualtSignataire() As String
        Get
            Return m_QualtSignataire
        End Get
        Set(value As String)
            m_QualtSignataire = value
        End Set
    End Property
    Private m_QualtSignataire As String

    '<ConditionalRequiered("Production", ErrorMessage:="La civilité du signataire est requise pour l'engagement")>
    Public Property Civilite() As String
        Get
            Return m_Civilite
        End Get
        Set(value As String)
            m_Civilite = value
        End Set
    End Property
    Private m_Civilite As String

    <ConditionalRequiered("Production", ErrorMessage:="L'activité du signataire est requise pour l'engagement")>
    <DisplayName("Activite de l'entreprise")>
    Public Property Activite() As String
        Get
            Return m_Activite
        End Get
        Set(value As String)
            m_Activite = value
        End Set
    End Property
    Private m_Activite As String

    Public Property DOM() As String
        Get
            Return m_DOM
        End Get
        Set(value As String)
            m_DOM = value
        End Set
    End Property
    Private m_DOM As String

    <DisplayName("Montant DZD")>
    Public Property MontantDZD() As Double
        Get
            Return m_MontantDZD
        End Get
        Set(value As Double)
            m_MontantDZD = value
        End Set
    End Property
    Private m_MontantDZD As Double

    <DisplayName("Date d'ouverture")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property DateOuverture() As DateTime?
        Get
            Return m_DateOuverture
        End Get
        Set(value As DateTime?)
            m_DateOuverture = value
        End Set
    End Property
    Private m_DateOuverture As DateTime?

    <DisplayName("Montant réglement")>
    Public Property MontantReglement() As Double
        Get
            Return m_MontantReglement
        End Get
        Set(value As Double)
            m_MontantReglement = value
        End Set
    End Property
    Private m_MontantReglement As Double

    <DisplayName("Total réglement")>
    Public Property TotalReglement() As Double
        Get
            Return m_TotalReglement
        End Get
        Set(value As Double)
            m_TotalReglement = value
        End Set
    End Property
    Private m_TotalReglement As Double

    <DisplayName("Pourcentage réglement")>
    Public Property PCTReglement() As Double
        Get
            Return m_PCTReglement
        End Get
        Set(value As Double)
            m_PCTReglement = value
        End Set
    End Property
    Private m_PCTReglement As Double

    <DisplayName("Date réglement")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property DateReglement() As DateTime?
        Get
            Return m_DateReglement
        End Get
        Set(value As DateTime?)
            m_DateReglement = value
        End Set
    End Property
    Private m_DateReglement As DateTime?


    Public Property Id_Souscription() As Int32
        Get
            Return m_Id_Souscription
        End Get
        Set(value As Int32)
            m_Id_Souscription = value
        End Set
    End Property
    Private m_Id_Souscription As Int32

    <ForeignKey("Id_Souscription")>
    Public Overridable Property Souscription() As Souscription
        Get
            Return m_Souscription
        End Get
        Set(value As Souscription)
            m_Souscription = value
        End Set
    End Property
    Private m_Souscription As Souscription

    Public Property Etrade() As Boolean
        Get
            Return m_etrade
        End Get
        Set(value As Boolean)
            m_etrade = value
        End Set
    End Property
    Private m_etrade As Boolean
    Public Property Preciser() As String
        Get
            Return m_Preciser
        End Get
        Set(value As String)
            m_Preciser = value
        End Set
    End Property
    Private m_Preciser As String
    <NotMapped()>
    Public ReadOnly Property NatureProduit() As String
        Get
            Return m_DescriptionMarchandise
        End Get
    End Property

    Public Overridable Property DocumentsCredocs() As ICollection(Of DocumentsCredoc)
    Public Overridable Property DocumentsCredocsBancaire() As ICollection(Of DocumentsCredocsBancaire)
    Public Overridable Property DocumentsCredocsPlis() As ICollection(Of DocumentsCredocsPli)
    

    Public Sub New()
        MyBase.New()
        Me.DocumentsCredocs = New List(Of DocumentsCredoc)
        Me.DocumentsCredocsBancaire = New List(Of DocumentsCredocsBancaire)
        Me.DocumentsCredocsPlis = New List(Of DocumentsCredocsPli)
    End Sub

End Class
