﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("Souscription")>
Public Class Souscription

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property USaisie() As String
        Get
            Return m_USaisie
        End Get
        Set(value As String)
            m_USaisie = value
        End Set
    End Property
    Private m_USaisie As String

    <ForeignKey("USaisie")>
    Public Overridable Property Createur() As Utilisateur
        Get
            Return m_createur
        End Get
        Set(value As Utilisateur)
            m_createur = value
        End Set
    End Property
    Private m_createur As Utilisateur

    <DisplayName("Date de création")> _
    <DisplayFormat(DataFormatString:="{0:dd/M/yyyy}")>
    Public Property DateSaisie() As System.Nullable(Of DateTime)
        Get
            Return m_DateSaisie
        End Get
        Set(value As System.Nullable(Of DateTime))
            m_DateSaisie = value
        End Set
    End Property
    Private m_DateSaisie As System.Nullable(Of DateTime)

    Public Property UValidation() As String
        Get
            Return m_UValidation
        End Get
        Set(value As String)
            m_UValidation = value
        End Set
    End Property
    Private m_UValidation As String

    <ForeignKey("UValidation")>
    Public Overridable Property Valideur() As Utilisateur
        Get
            Return m_valideur
        End Get
        Set(value As Utilisateur)
            m_valideur = value
        End Set
    End Property
    Private m_valideur As Utilisateur

    <DisplayName("Date de validation")> _
    <DisplayFormat(DataFormatString:="{0:dd/M/yyyy}")>
    Public Property DateValidation() As System.Nullable(Of DateTime)
        Get
            Return m_DateValidation
        End Get
        Set(value As System.Nullable(Of DateTime))
            m_DateValidation = value
        End Set
    End Property
    Private m_DateValidation As System.Nullable(Of DateTime)

    Public Property UModif() As String
        Get
            Return m_UModif
        End Get
        Set(value As String)
            m_UModif = value
        End Set
    End Property
    Private m_UModif As String

    <ForeignKey("UModif")>
    Public Overridable Property Modificateur() As Utilisateur
        Get
            Return m_Modificateur
        End Get
        Set(value As Utilisateur)
            m_Modificateur = value
        End Set
    End Property
    Private m_Modificateur As Utilisateur

    <DisplayName("Date de modification")> _
    <DisplayFormat(DataFormatString:="{0:dd/M/yyyy}")>
    Public Property DateModif() As System.Nullable(Of DateTime)
        Get
            Return m_DateModif
        End Get
        Set(value As System.Nullable(Of DateTime))
            m_DateModif = value
        End Set
    End Property
    Private m_DateModif As System.Nullable(Of DateTime)

    Public Property UValidationModif() As String
        Get
            Return m_UValidationModif
        End Get
        Set(value As String)
            m_UValidationModif = value
        End Set
    End Property
    Private m_UValidationModif As String

    <ForeignKey("UValidationModif")>
    Public Overridable Property ValideurModificateur() As Utilisateur
        Get
            Return m_ValideurModificateur
        End Get
        Set(value As Utilisateur)
            m_ValideurModificateur = value
        End Set
    End Property
    Private m_ValideurModificateur As Utilisateur

    <DisplayName("Date de validation de la modification")> _
    <DisplayFormat(DataFormatString:="{0:dd/M/yyyy}")>
    Public Property DateValidationModif() As System.Nullable(Of DateTime)
        Get
            Return m_DateValidationModif
        End Get
        Set(value As System.Nullable(Of DateTime))
            m_DateValidationModif = value
        End Set
    End Property
    Private m_DateValidationModif As System.Nullable(Of DateTime)

    Public Property Radical_Client() As String
        Get
            Return m_radical_client
        End Get
        Set(value As String)
            m_radical_client = value
        End Set
    End Property
    Private m_radical_client As String

    <ForeignKey("Radical_Client")>
    Public Overridable Property Client() As Client
        Get
            Return m_client
        End Get
        Set(value As Client)
            m_client = value
        End Set
    End Property
    Private m_client As Client

    Public Property Id_StatutSouscription() As Int32
        Get
            Return m_Id_StatutSouscription
        End Get
        Set(value As Int32)
            m_Id_StatutSouscription = value
        End Set
    End Property
    Private m_Id_StatutSouscription As Int32

    <ForeignKey("Id_StatutSouscription")>
    Public Overridable Property StatutSouscription() As StatutSouscription
        Get
            Return m_StatutSouscription
        End Get
        Set(value As StatutSouscription)
            m_StatutSouscription = value
        End Set
    End Property
    Private m_StatutSouscription As StatutSouscription

    Public Property Id_Package() As Int32
        Get
            Return m_Id_Package
        End Get
        Set(value As Int32)
            m_Id_Package = value
        End Set
    End Property
    Private m_Id_Package As Int32

    <ForeignKey("Id_Package")>
    Public Overridable Property Package() As Package
        Get
            Return m_Package
        End Get
        Set(value As Package)
            m_Package = value
        End Set
    End Property
    Private m_Package As Package

End Class
