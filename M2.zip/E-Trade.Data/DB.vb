﻿Imports System.Data.Entity
Imports System.Configuration
Imports System.Data.Entity.ModelConfiguration.Conventions

Public Class DB
    Inherits DbContext

    Public Sub New()
        MyBase.New(ConfigurationManager.ConnectionStrings("ETRADE").ToString)
    End Sub

    Protected Overrides Sub OnModelCreating(modelBuilder As System.Data.Entity.DbModelBuilder)
        MyBase.OnModelCreating(modelBuilder)
        MyBase.Configuration.ProxyCreationEnabled = False
        MyBase.Configuration.LazyLoadingEnabled = False
        modelBuilder.Conventions.Remove(Of PluralizingTableNameConvention)()
        modelBuilder.Entity(Of Package)().
                                HasMany(Function(c) c.Modules).
                                WithMany(Function(c) c.Packages).
                                Map(Sub(m)
                                        m.ToTable("PackageModule")
                                        m.MapLeftKey("Id_Package")
                                        m.MapRightKey("Id_Module")
                                    End Sub)
        modelBuilder.Entity(Of QProposition)().
                                HasRequired(Of QQuestion)(Function(prop) prop.QQuestion).
                                WithMany(Function(questions) questions.Propositions).
                                HasForeignKey(Of Int32)(Function(prop) prop.Question)
    End Sub

    Public Property COABS() As DbSet(Of COAB)
        Get
            Return m_COABS
        End Get
        Set(value As DbSet(Of COAB))
            m_COABS = value
        End Set
    End Property
    Private m_COABS As DbSet(Of COAB)

    Public Property COAB_Profils() As DbSet(Of COAB_Profil)
        Get
            Return m_COAB_Profils
        End Get
        Set(value As DbSet(Of COAB_Profil))
            m_COAB_Profils = value
        End Set
    End Property
    Private m_COAB_Profils As DbSet(Of COAB_Profil)

    Public Property Clients() As DbSet(Of Client)
        Get
            Return m_Clients
        End Get
        Set(value As DbSet(Of Client))
            m_Clients = value
        End Set
    End Property
    Private m_Clients As DbSet(Of Client)

    Public Property Souscriptions() As DbSet(Of Souscription)
        Get
            Return m_Souscriptions
        End Get
        Set(value As DbSet(Of Souscription))
            m_Souscriptions = value
        End Set
    End Property
    Private m_Souscriptions As DbSet(Of Souscription)

    Public Property Utilisateurs() As DbSet(Of Utilisateur)
        Get
            Return m_Utilisateurs
        End Get
        Set(ByVal value As DbSet(Of Utilisateur))
            m_Utilisateurs = value
        End Set
    End Property
    Private m_Utilisateurs As DbSet(Of Utilisateur)

    Public Property Agences() As DbSet(Of Agence)
        Get
            Return m_Agences
        End Get
        Set(value As DbSet(Of Agence))
            m_Agences = value
        End Set
    End Property
    Private m_Agences As DbSet(Of Agence)

    Public Property Comptes() As DbSet(Of Compte)
        Get
            Return m_Comptes
        End Get
        Set(value As DbSet(Of Compte))
            m_Comptes = value
        End Set
    End Property
    Private m_Comptes As DbSet(Of Compte)

    Public Property PreDom_Compte() As DbSet(Of Predom_Compte)
        Get
            Return m_PreDom_Compte
        End Get
        Set(value As DbSet(Of Predom_Compte))
            m_PreDom_Compte = value
        End Set
    End Property
    Private m_PreDom_Compte As DbSet(Of Predom_Compte)

    Public Property Credoc() As DbSet(Of Credoc)
        Get
            Return m_Credoc
        End Get
        Set(value As DbSet(Of Credoc))
            m_Credoc = value
        End Set
    End Property
    Private m_Credoc As DbSet(Of Credoc)

    Public Property StatutCredocs() As DbSet(Of StatutCredoc)
        Get
            Return m_StatutCredoc
        End Get
        Set(value As DbSet(Of StatutCredoc))
            m_StatutCredoc = value
        End Set
    End Property
    Private m_StatutCredoc As DbSet(Of StatutCredoc)

    Public Property Remdoc() As DbSet(Of Remdoc)
        Get
            Return m_Remdoc
        End Get
        Set(value As DbSet(Of Remdoc))
            m_Remdoc = value
        End Set
    End Property
    Private m_Remdoc As DbSet(Of Remdoc)

    Public Property StatutRemdocs() As DbSet(Of StatutRemdoc)
        Get
            Return m_StatutRemdoc
        End Get
        Set(value As DbSet(Of StatutRemdoc))
            m_StatutRemdoc = value
        End Set
    End Property
    Private m_StatutRemdoc As DbSet(Of StatutRemdoc)

    Public Property Parametres() As DbSet(Of Parametres)
        Get
            Return m_Parametres
        End Get
        Set(value As DbSet(Of Parametres))
            m_Parametres = value
        End Set
    End Property
    Private m_Parametres As DbSet(Of Parametres)

    Public Property StatutSouscription() As DbSet(Of StatutSouscription)
        Get
            Return m_StatutSouscription
        End Get
        Set(ByVal value As DbSet(Of StatutSouscription))
            m_StatutSouscription = value
        End Set
    End Property
    Private m_StatutSouscription As DbSet(Of StatutSouscription)

    Public Property DocumentTypes() As DbSet(Of DocumentTypes)
        Get
            Return m_DocumentTypes
        End Get
        Set(ByVal value As DbSet(Of DocumentTypes))
            m_DocumentTypes = value
        End Set
    End Property
    Private m_DocumentTypes As DbSet(Of DocumentTypes)

    Public Property DocumentsCredoc() As DbSet(Of DocumentsCredoc)
        Get
            Return m_DocumentsCredoc
        End Get
        Set(ByVal value As DbSet(Of DocumentsCredoc))
            m_DocumentsCredoc = value
        End Set
    End Property
    Private m_DocumentsCredoc As DbSet(Of DocumentsCredoc)

    Public Property Commentaires() As DbSet(Of Commentaires)
        Get
            Return m_Commentaires
        End Get
        Set(value As DbSet(Of Commentaires))
            m_Commentaires = value
        End Set
    End Property
    Private m_Commentaires As DbSet(Of Commentaires)

    Public Property Roles() As DbSet(Of Role)
        Get
            Return m_Roles
        End Get
        Set(value As DbSet(Of Role))
            m_Roles = value
        End Set
    End Property
    Private m_Roles As DbSet(Of Role)

    Public Property Packages As DbSet(Of Package)

    Public Property PreDom_Client() As DbSet(Of PreDom_Client)
        Get
            Return m_PreDom_Client
        End Get
        Set(value As DbSet(Of PreDom_Client))
            m_PreDom_Client = value
        End Set
    End Property
    Private m_PreDom_Client As DbSet(Of PreDom_Client)

    ''' <summary>
    ''' Partie Questionnaire 
    ''' </summary>
    ''' <returns></returns>
    Public Property Categories() As DbSet(Of QCategorie)
        Get
            Return m_categorie
        End Get
        Set(value As DbSet(Of QCategorie))
            m_categorie = value
        End Set
    End Property
    Private m_categorie As DbSet(Of QCategorie)

    Public Property Compagnes() As DbSet(Of QCompangne)
        Get
            Return m_compagne
        End Get
        Set(value As DbSet(Of QCompangne))
            m_compagne = value
        End Set
    End Property
    Private m_compagne As DbSet(Of QCompangne)

    Public Property Propositions() As DbSet(Of QProposition)
        Get
            Return m_proposition
        End Get
        Set(value As DbSet(Of QProposition))
            m_proposition = value
        End Set
    End Property
    Private m_proposition As DbSet(Of QProposition)

    Public Property Questions() As DbSet(Of QQuestion)
        Get
            Return m_questions
        End Get
        Set(value As DbSet(Of QQuestion))
            m_questions = value
        End Set
    End Property
    Private m_questions As DbSet(Of QQuestion)

    Public Property Reponses() As DbSet(Of QReponse)
        Get
            Return m_reponses
        End Get
        Set(value As DbSet(Of QReponse))
            m_reponses = value
        End Set
    End Property
    Private m_reponses As DbSet(Of QReponse)

    Public Property TypesQuestion() As DbSet(Of QType)
        Get
            Return m_types
        End Get
        Set(value As DbSet(Of QType))
            m_types = value
        End Set
    End Property
    Private m_types As DbSet(Of QType)

    Public Property PreDom_Dossier() As DbSet(Of PreDom_Dossier)
    Public Property PreDom_Activite() As DbSet(Of PreDom_Activite)
    Public Property PreDom_AgenceCPT() As DbSet(Of PreDom_AgenceCPT)
    Public Property PreDom_Commentaires() As DbSet(Of PreDom_Commentaires)
    Public Property PreDom_Condition() As DbSet(Of PreDom_Condition)
    Public Property PreDom_Devise() As DbSet(Of PreDom_Devise)
    Public Property PreDom_Facture() As DbSet(Of PreDom_Facture)
    Public Property PreDom_Inderdit() As DbSet(Of PreDom_Inderdit)
    Public Property PreDom_ModalitePaiement() As DbSet(Of PreDom_ModalitePaiement)
    Public Property PreDom_Nature() As DbSet(Of PreDom_Nature)
    Public Property PreDom_Statut() As DbSet(Of PreDom_Statut)
    Public Property PreDom_Pays() As DbSet(Of PreDom_Pays)
    Public Property PreDom_Documents() As DbSet(Of PreDom_Documents)
    Public Property PreDom_DocumentTypes() As DbSet(Of PreDom_DocumentTypes)
End Class
