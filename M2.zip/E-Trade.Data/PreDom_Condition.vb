Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_Condition")> _
Partial Public Class PreDom_Condition
    <Key()>
    Public Property Code As String
    Public Property Libelle As String


End Class
