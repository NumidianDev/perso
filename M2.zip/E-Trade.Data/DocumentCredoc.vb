﻿Public Interface DocumentCredoc

    Property Id() As Int32

    Property Nom() As String

    Property Exemplaires() As Int32

    Property Circuit() As String

    Property DeleteDocument() As Boolean

    Property Id_Credoc() As Int32

    Property Credoc() As Credoc
    
End Interface
