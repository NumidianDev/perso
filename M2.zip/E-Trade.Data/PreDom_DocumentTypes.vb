Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_DocumentTypes")>
Partial Public Class PreDom_DocumentTypes
    <Key()>
    Public Property Code As Integer
    Public Property Libelle As String
    Public Property Code_mp As String
    <ForeignKey("Code_mp")>
    Public Property PreDom_modalitepaiment As PreDom_ModalitePaiement
End Class
