﻿Imports System.ComponentModel.DataAnnotations

Public Class Parametres

    <Key()>
    Public Property Param() As String
        Get
            Return m_param
        End Get
        Set(value As String)
            m_param = value
        End Set
    End Property
    Private m_param As String

    Public Property Value() As String
        Get
            Return m_value
        End Get
        Set(value As String)
            m_value = value
        End Set
    End Property
    Private m_value As String

End Class
