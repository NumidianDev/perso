Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_Devise")>
Partial Public Class PreDom_Devise
    <Key()>
    Public Property Code As String
    Public Property Libelle As String
    Public Property Poids As Int32
End Class
