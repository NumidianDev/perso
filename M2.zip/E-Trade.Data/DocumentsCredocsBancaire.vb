﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("DocumentsCredocBancaire")>
Public Class DocumentsCredocsBancaire
    Implements DocumentCredoc

    <Key()>
    Public Property Id() As Int32 Implements DocumentCredoc.Id
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property Nom() As String Implements DocumentCredoc.Nom
        Get
            Return m_nom
        End Get
        Set(value As String)
            m_nom = value
        End Set
    End Property
    Private m_nom As String

    Public Property Circuit() As String Implements DocumentCredoc.Circuit
        Get
            Return m_Circuit
        End Get
        Set(value As String)
            m_Circuit = value
        End Set
    End Property
    Private m_Circuit As String

    Public Property Exemplaires() As Int32 Implements DocumentCredoc.Exemplaires
        Get
            Return m_Exemplaires
        End Get
        Set(value As Int32)
            m_Exemplaires = value
        End Set
    End Property
    Private m_Exemplaires As Int32

    <NotMapped()>
    Public Property DeleteDocument() As Boolean Implements DocumentCredoc.DeleteDocument
        Get
            Return m_DeleteDocument
        End Get
        Set(value As Boolean)
            m_DeleteDocument = value
        End Set
    End Property
    Private m_DeleteDocument As Boolean

    Public Property Id_Credoc() As Int32 Implements DocumentCredoc.Id_Credoc
        Get
            Return m_Id_Credoc
        End Get
        Set(value As Int32)
            m_Id_Credoc = value
        End Set
    End Property
    Private m_Id_Credoc As Int32

    <ForeignKey("Id_Credoc")>
    Public Overridable Property Credoc() As Credoc Implements DocumentCredoc.Credoc
        Get
            Return m_Credoc
        End Get
        Set(value As Credoc)
            m_Credoc = value
        End Set
    End Property
    Private m_Credoc As Credoc

End Class
