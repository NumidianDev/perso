﻿Imports System.ComponentModel.DataAnnotations

Public Class NotFilledAttribute
    Inherits ValidationAttribute

    Public _emptyString As String = String.Empty

    Public Sub NotFilledAttribute(ByVal emptyString As String)
        _emptyString = emptyString
    End Sub

    Protected Overrides Function IsValid(value As Object, validationContext As System.ComponentModel.DataAnnotations.ValidationContext) As System.ComponentModel.DataAnnotations.ValidationResult

        Dim stringValue As String = String.Empty
        Try
            stringValue = DirectCast(value, String)
        Catch ex As Exception
            If TypeOf (value) Is Boolean Then
                stringValue = value.ToString
            End If
        End Try

        If Not String.IsNullOrEmpty(stringValue) Then
            If Not stringValue.ToLower().Equals(_emptyString.ToLower) Then
                Return ValidationResult.Success
            End If
        End If

        Return New ValidationResult(ErrorMessageString)

    End Function

End Class
