﻿Imports System.ComponentModel.DataAnnotations
Imports System.Linq.Expressions

Public Class ConditionalRequiered
    Inherits ValidationAttribute

    Private ReadOnly _condition As String

    Public Sub New(condition As String)
        _condition = condition
    End Sub

    Protected Overrides Function IsValid(value As Object, validationContext As System.ComponentModel.DataAnnotations.ValidationContext) As System.ComponentModel.DataAnnotations.ValidationResult

        Dim conditionFunction As [Delegate] = CreateExpressionDelegate(validationContext.ObjectType, _condition)

        Dim conditionMet As Boolean = CBool(conditionFunction.DynamicInvoke(validationContext.ObjectInstance))

        If conditionMet Then
            If value Is Nothing OrElse String.IsNullOrEmpty(value) Then
                Return New ValidationResult(ErrorMessageString)
            End If
        End If

        Return ValidationResult.Success

    End Function

    Private Function CreateExpressionDelegate(objectType As Type, expression As String) As [Delegate]
        ' TODO - add caching
        Dim lambdaExpression = CreateExpression(objectType, expression)
        Dim func As [Delegate] = lambdaExpression.Compile()
        Return func
    End Function

    Private Function CreateExpression(objectType As Type, expression As String) As LambdaExpression
        ' TODO - add caching
        Dim lambdaExpression As LambdaExpression = System.Linq.Dynamic.DynamicExpression.ParseLambda(objectType, GetType(Boolean), expression)
        Return lambdaExpression
    End Function

End Class
