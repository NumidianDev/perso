﻿'Imports System.Collections.ObjectModel
'Imports System.Linq.Expressions
'Imports System.Reflection
'Imports System.Text
'Imports System.Web.Script.Serialization


'Public Class JavascriptExpressionVisitor
'    Inherits ExpressionVisitor
'    Private _buf As StringBuilder

'    Private ReadOnly _javaScriptSerializer As New JavaScriptSerializer()

'    Public Function Translate(expression As Expression) As String
'        _buf = New StringBuilder()
'        Visit(expression)
'        Return _buf.ToString().Trim()
'    End Function

'    Protected Overrides Function VisitMember(node As MemberExpression) As Expression
'        Dim expression = ConvertMemberExpression(node)
'        _buf.Append(expression)
'        Return node
'    End Function

'    Private Function ConvertMemberExpression(memberExpression As MemberExpression) As String
'        If memberExpression.Expression Is Nothing Then
'            ' only support DateTime static properties for now
'            If memberExpression.Member.DeclaringType <> GetType(DateTime) AndAlso memberExpression.Member.MemberType <> MemberTypes.[Property] Then
'                Throw New ArgumentException("Member access must either be against the model or static properties such as DateTime.Now")
'            End If
'            Dim value = GetDatePropertyValue(memberExpression)
'            Dim serialisedValue = SerializeDate(value)
'            Return serialisedValue
'        Else
'            Dim propertyName = memberExpression.Member.Name
'            ' TODO - should verify that it's the model...
'            Return String.Format("gv('*.{0}')", propertyName)
'        End If
'        Throw New InvalidOperationException("Shouldn't reach here!")
'    End Function

'    Private Function GetDatePropertyValue(memberExpression As MemberExpression) As DateTime
'        Dim propertyInfo As PropertyInfo = DirectCast(memberExpression.Member, PropertyInfo)
'        Dim value As DateTime = CType(propertyInfo.GetValue(Nothing, Nothing), DateTime)
'        Return value
'    End Function


'    Private Function SerializeDate(value As DateTime) As String
'        Return String.Format("new Date({0},{1},{2},{3},{4},{5})", value.Year, value.Month - 1, value.Day, value.Hour, value.Minute, _
'         value.Second)
'    End Function

'    Protected Overrides Function VisitUnary(node As UnaryExpression) As Expression
'        Select Case node.NodeType
'            Case ExpressionType.[Not]
'                _buf.Append("!")
'                Return MyBase.VisitUnary(node)
'        End Select
'        Throw New NotSupportedException()
'    End Function

'    Protected Overrides Function VisitBinary(node As BinaryExpression) As Expression
'        Dim operatorString As String = Nothing
'        Select Case node.NodeType
'            Case ExpressionType.[AndAlso]
'                operatorString = "&&"
'                Exit Select
'            Case ExpressionType.[OrElse]
'                operatorString = "||"
'                Exit Select
'            Case ExpressionType.[And]
'                operatorString = "&"
'                Exit Select
'            Case ExpressionType.[Or]
'                operatorString = "|"
'                Exit Select
'            Case ExpressionType.LessThan
'                operatorString = "<"
'                Exit Select
'            Case ExpressionType.LessThanOrEqual
'                operatorString = "<="
'                Exit Select
'            Case ExpressionType.GreaterThan
'                operatorString = ">"
'                Exit Select
'            Case ExpressionType.GreaterThanOrEqual
'                operatorString = ">="
'                Exit Select
'            Case ExpressionType.Equal
'                operatorString = "=="
'                Exit Select
'            Case ExpressionType.NotEqual
'                operatorString = "!="
'                Exit Select
'            Case Else
'                Throw New NotSupportedException()
'        End Select

'        Visit(node.Left)
'        _buf.Append(" ")
'        _buf.Append(operatorString)
'        _buf.Append(" ")
'        Visit(node.Right)

'        Return node
'    End Function
'    Protected Overrides Function VisitConstant(node As ConstantExpression) As Expression
'        Dim value = node.Value
'        If TypeOf value Is DateTime Then
'            _buf.Append(SerializeDate(CType(value, DateTime)))
'        Else
'            _javaScriptSerializer.Serialize(value, _buf)
'        End If

'        Return MyBase.VisitConstant(node)
'    End Function

'    Protected Overrides Function VisitNew(node As NewExpression) As Expression
'        If node.Constructor.DeclaringType = GetType(DateTime) Then
'            Dim args As Object() = GetConstArgumentValues(node.Arguments)
'            Dim dateTime As DateTime = CType(node.Constructor.Invoke(args), DateTime)
'            _buf.Append(SerializeDate(dateTime))
'            Return node
'        End If
'        Throw New NotSupportedException()
'    End Function

'    Private Function GetConstArgumentValues(argumentExpressions As ReadOnlyCollection(Of Expression)) As Object()
'        Dim args As Object() = New Object(argumentExpressions.Count - 1) {}
'        For i As Integer = 0 To argumentExpressions.Count - 1
'            Dim expression As Expression = argumentExpressions(i)
'            args(i) = GetConstArgumentValue(expression)
'        Next
'        Return args
'    End Function

'    Private Function GetConstArgumentValue(expression As Expression) As Object
'        If expression.NodeType <> ExpressionType.Constant Then
'            Throw New ArgumentException("expression must be a constant expression")
'        End If
'        Dim constantExpression As ConstantExpression = DirectCast(expression, ConstantExpression)
'        Return constantExpression.Value
'    End Function

'    Protected Overrides Function VisitBlock(node As BlockExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitCatchBlock(node As CatchBlock) As CatchBlock
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitConditional(node As ConditionalExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitDebugInfo(node As DebugInfoExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitDefault(node As DefaultExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitDynamic(node As DynamicExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitElementInit(node As ElementInit) As ElementInit
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitExtension(node As Expression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitGoto(node As GotoExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitIndex(node As IndexExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitInvocation(node As InvocationExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitLabel(node As LabelExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitLabelTarget(node As LabelTarget) As LabelTarget
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitListInit(node As ListInitExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitMemberAssignment(node As MemberAssignment) As MemberAssignment
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitLoop(node As LoopExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitMemberBinding(node As MemberBinding) As MemberBinding
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitMemberInit(node As MemberInitExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitMemberListBinding(node As MemberListBinding) As MemberListBinding
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitMemberMemberBinding(node As MemberMemberBinding) As MemberMemberBinding
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitMethodCall(node As MethodCallExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitNewArray(node As NewArrayExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitRuntimeVariables(node As RuntimeVariablesExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitSwitch(node As SwitchExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitSwitchCase(node As SwitchCase) As SwitchCase
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitTry(node As TryExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'    Protected Overrides Function VisitTypeBinary(node As TypeBinaryExpression) As Expression
'        Throw New NotSupportedException()
'    End Function
'End Class

