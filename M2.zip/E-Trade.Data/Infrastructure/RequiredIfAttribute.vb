﻿Imports System.Collections.Generic
Imports System.Linq.Expressions
Imports System.ComponentModel.DataAnnotations
Imports System.Web.Mvc


Public Class RequiredIfAttribute
    Inherits ValidationAttribute

    Private ReadOnly _condition As String

    Public Sub New(condition As String)
        _condition = condition
    End Sub

    Protected Overrides Function IsValid(value As Object, validationContext As ValidationContext) As ValidationResult

        Dim conditionFunction As [Delegate] = CreateExpressionDelegate(validationContext.ObjectType, _condition)

        Dim conditionMet As Boolean = CBool(conditionFunction.DynamicInvoke(validationContext.ObjectInstance))

        If conditionMet Then
            If value Is Nothing Then
                Return New ValidationResult(ErrorMessageString)
            End If
            Return ValidationResult.Success
        Else
            Return New ValidationResult(ErrorMessageString)
        End If

    End Function

    Private Function CreateExpressionDelegate(objectType As Type, expression As String) As [Delegate]
        ' TODO - add caching
        Dim lambdaExpression = CreateExpression(objectType, expression)
        Dim func As [Delegate] = lambdaExpression.Compile()
        Return func
    End Function

    Private Function CreateExpression(objectType As Type, expression As String) As LambdaExpression
        ' TODO - add caching
        Dim lambdaExpression As LambdaExpression = System.Linq.Dynamic.DynamicExpression.ParseLambda(objectType, GetType(Boolean), expression)
        Return lambdaExpression
    End Function

    'Public Function GetClientValidationRules(metadata As System.Web.Mvc.ModelMetadata, context As System.Web.Mvc.ControllerContext) As System.Collections.Generic.IEnumerable(Of System.Web.Mvc.ModelClientValidationRule) Implements System.Web.Mvc.IClientValidatable.GetClientValidationRules

    '    Dim errorMessage As String = FormatErrorMessage(metadata.GetDisplayName())

    '    Dim expression As Expression = CreateExpression(metadata.ContainerType, _condition)
    '    Dim visitor = New JavascriptExpressionVisitor()
    '    Dim javascriptExpression As String = visitor.Translate(expression)

    '    Dim clientRule = New ModelClientValidationRule() With { _
    '        .ErrorMessage = errorMessage, _
    '        .ValidationType = "requiredif"
    '        }

    '    'With { _
    '    ' .ErrorMessage = errorMessage, _
    '    ' .ValidationType = "requiredif", _
    '    ' .ValidationParameters = {{"expression", javascriptExpression}} _
    '    '}
    '    clientRule.ValidationParameters.Add("expression", javascriptExpression)

    '    Dim ret As IList(Of ModelClientValidationRule) = New List(Of ModelClientValidationRule)

    '    ret.Add(clientRule)


    '    Return ret


    'End Function

End Class

