Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("PreDom_Activite")> _
Public Class PreDom_Activite
    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(ByVal value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As String
    Public Property Libelle() As String
        Get
            Return m_Libelle
        End Get
        Set(ByVal value As String)
            m_Libelle = value
        End Set
    End Property
    Private m_Libelle As String
End Class
