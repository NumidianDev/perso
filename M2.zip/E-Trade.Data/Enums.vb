﻿Public Class Enums
    Public Enum CommissionCharge
        D
        B
    End Enum
End Class
