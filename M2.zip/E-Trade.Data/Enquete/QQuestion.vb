﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("QQuestion")>
Public Class QQuestion

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_Id
        End Get
        Set(value As Int32)
            m_Id = value
        End Set
    End Property
    Private m_Id As Int32

    Public Property Libelle() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String

    Public Property Numero() As Int32
        Get
            Return m_numero
        End Get
        Set(value As Int32)
            m_numero = value
        End Set
    End Property
    Private m_numero As Int32

    Public Property Compagne() As Int32
        Get
            Return m_id_coçmpagne
        End Get
        Set(value As Int32)
            m_id_coçmpagne = value
        End Set
    End Property
    Private m_id_coçmpagne As Int32

    <ForeignKey("Compagne")>
    Public Overridable Property QCoçmpagne() As QCompangne
        Get
            Return m_coçmpagne
        End Get
        Set(ByVal value As QCompangne)
            m_coçmpagne = value
        End Set
    End Property
    Private m_coçmpagne As QCompangne

    Public Property Categorie() As Int32
        Get
            Return m_id_categorie
        End Get
        Set(value As Int32)
            m_id_categorie = value
        End Set
    End Property
    Private m_id_categorie As Int32

    <ForeignKey("Categorie")>
    Public Overridable Property QCategorie() As QCategorie
        Get
            Return m_categorie
        End Get
        Set(ByVal value As QCategorie)
            m_categorie = value
        End Set
    End Property
    Private m_categorie As QCategorie

    Public Property Type() As Int32
        Get
            Return m_id_type
        End Get
        Set(value As Int32)
            m_id_type = value
        End Set
    End Property
    Private m_id_type As Int32

    <ForeignKey("Type")>
    Public Overridable Property QType() As QType
        Get
            Return m_type
        End Get
        Set(ByVal value As QType)
            m_type = value
        End Set
    End Property
    Private m_type As QType

    <NotMapped()>
    Public Property selectedProposition() As Int32

    Public Overridable Property Propositions() As ICollection(Of QProposition)

    Public Sub New()
        MyBase.New()
        Me.Propositions = New List(Of QProposition)
    End Sub

End Class
