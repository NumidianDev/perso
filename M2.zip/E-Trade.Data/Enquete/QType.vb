﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("QType")>
Public Class QType

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_Id
        End Get
        Set(value As Int32)
            m_Id = value
        End Set
    End Property
    Private m_Id As Int32

    Public Property Libelle() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String

End Class
