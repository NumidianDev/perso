﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("QReponse")>
Public Class QReponse

    <Key()>
    <Column(Order:=1)>
    Public Property IdCOAB() As Int32
        Get
            Return m_id_coab
        End Get
        Set(value As Int32)
            m_id_coab = value
        End Set
    End Property
    Private m_id_coab As Int32

    <ForeignKey("IdCOAB")>
    Public Overridable Property COAB() As COAB
        Get
            Return m_coab
        End Get
        Set(ByVal value As COAB)
            m_coab = value
        End Set
    End Property
    Private m_coab As COAB

    <Key()>
    <Column(Order:=2)>
    Public Property IdProposition() As Int32
        Get
            Return m_id_propositions
        End Get
        Set(value As Int32)
            m_id_propositions = value
        End Set
    End Property
    Private m_id_propositions As Int32

    <ForeignKey("IdProposition")>
    Public Overridable Property Proposition() As QProposition
        Get
            Return m_proposition
        End Get
        Set(ByVal value As QProposition)
            m_proposition = value
        End Set
    End Property
    Private m_proposition As QProposition


    Public Property AltText() As String
        Get
            Return m_alt_text
        End Get
        Set(value As String)
            m_alt_text = value
        End Set
    End Property
    Private m_alt_text As String

    Public Property AltInt() As Int32
        Get
            Return m_alt_int
        End Get
        Set(value As Int32)
            m_alt_int = value
        End Set
    End Property
    Private m_alt_int As Int32

    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property RDate() As DateTime?
        Get
            Return m_rdate
        End Get
        Set(value As DateTime?)
            m_rdate = value
        End Set
    End Property
    Private m_rdate As DateTime?

End Class
