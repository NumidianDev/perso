﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("QProposition")>
Public Class QProposition

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_Id
        End Get
        Set(value As Int32)
            m_Id = value
        End Set
    End Property
    Private m_Id As Int32

    Public Property Libelle() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String

    Public Property Question() As Int32
        Get
            Return m_id_question
        End Get
        Set(value As Int32)
            m_id_question = value
        End Set
    End Property
    Private m_id_question As Int32

    <ForeignKey("Question")>
    Public Overridable Property QQuestion() As QQuestion
        Get
            Return m_question
        End Get
        Set(ByVal value As QQuestion)
            m_question = value
        End Set
    End Property
    Private m_question As QQuestion

    <NotMapped()>
    Public Property YesNo() As Boolean
        Get
            Return m_yesNo
        End Get
        Set(value As Boolean)
            m_yesNo = value
        End Set
    End Property
    Private m_yesNo As Boolean

    <NotMapped()>
    Public Property Note() As Int32
        Get
            Return m_note
        End Get
        Set(value As Int32)
            m_note = value
        End Set
    End Property
    Private m_note As Int32

    <NotMapped()>
    Public Property AltText() As String
        Get
            Return m_alt_text
        End Get
        Set(value As String)
            m_alt_text = value
        End Set
    End Property
    Private m_alt_text As String

    <NotMapped()>
    Public Property AltInt() As Int32
        Get
            Return m_alt_int
        End Get
        Set(value As Int32)
            m_alt_int = value
        End Set
    End Property
    Private m_alt_int As Int32

End Class
