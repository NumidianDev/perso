﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("QCompangne")>
Public Class QCompangne

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_Id
        End Get
        Set(value As Int32)
            m_Id = value
        End Set
    End Property
    Private m_Id As Int32

    Public Property Libelle() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String

    Public Property Description() As String
        Get
            Return m_description
        End Get
        Set(value As String)
            m_description = value
        End Set
    End Property
    Private m_description As String

    <DisplayName("Date debut")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property Debut() As DateTime?
        Get
            Return m_debut
        End Get
        Set(value As DateTime?)
            m_debut = value
        End Set
    End Property
    Private m_debut As DateTime?

    <DisplayName("Date de fin")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property Fin() As DateTime?
        Get
            Return m_fin
        End Get
        Set(value As DateTime?)
            m_fin = value
        End Set
    End Property
    Private m_fin As DateTime?

End Class
