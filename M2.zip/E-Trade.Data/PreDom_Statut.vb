Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("PreDom_Statut")>
Partial Public Class PreDom_Statut
    <Key()>
    Public Property Id As Integer
    Public Property Libelle As String

End Class
