Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("PreDom_Nature")>
Partial Public Class PreDom_Nature
    <Key()>
    Public Property Id As Integer
    Public Property Libelle As String

End Class
