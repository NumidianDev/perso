Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_Inderdit")>
Partial Public Class PreDom_Inderdit
    <Key()>
    Public Property Id As Integer
    Public Property NIF As String
    Public Property RC As String
    Public Property Type As String

End Class
