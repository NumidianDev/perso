﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("Predom_Client")>
Public Class PreDom_Client

    <Key()>
    Public Property Radical() As String
        Get
            Return m_radical
        End Get
        Set(value As String)
            m_radical = value
        End Set
    End Property
    Private m_radical As String


    Public Property RS() As String
        Get
            Return m_rs
        End Get
        Set(value As String)
            m_rs = value
        End Set
    End Property
    Private m_rs As String

    Public Property Adresse() As String
        Get
            Return m_adresse
        End Get
        Set(value As String)
            m_adresse = value
        End Set
    End Property
    Private m_adresse As String

    Public Property Tel() As String
        Get
            Return m_tel
        End Get
        Set(value As String)
            m_tel = value
        End Set
    End Property
    Private m_tel As String

    Public Property Email() As String
        Get
            Return m_email
        End Get
        Set(value As String)
            m_email = value
        End Set
    End Property
    Private m_email As String


    Public Property NIDF() As String
        Get
            Return m_nidf
        End Get
        Set(value As String)
            m_nidf = value
        End Set
    End Property
    Private m_nidf As String

    Public Property RC() As String
        Get
            Return m_rc
        End Get
        Set(value As String)
            m_rc = value
        End Set
    End Property
    Private m_rc As String
    Public Property NIN() As String
        Get
            Return m_NIN
        End Get
        Set(ByVal value As String)
            m_NIN = value
        End Set
    End Property
    Private m_NIN As String
    Public Property age() As String
        Get
            Return m_age
        End Get
        Set(value As String)
            m_age = value
        End Set
    End Property
    Private m_age As String
End Class

