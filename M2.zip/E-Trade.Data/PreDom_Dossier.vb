Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel
Imports System.Web.Mvc

<Table("PreDom_Dossier")>
Partial Public Class PreDom_Dossier
    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(ByVal value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32
    Public Property RefPreDOM() As String
        Get
            Return _RefPreDOM
        End Get
        Set(ByVal value As String)
            _RefPreDOM = value
        End Set
    End Property
    Private _RefPreDOM As String
    Public Property REFWF() As String
        Get
            Return _REFWF
        End Get
        Set(ByVal value As String)
            _REFWF = value
        End Set
    End Property
    Private _REFWF As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Radical() As String
        Get
            Return m_Radical
        End Get
        Set(ByVal value As String)
            m_Radical = value
        End Set
    End Property
    Private m_Radical As String
    <DisplayName("N� Compte ")>
    <Required(ErrorMessage:="Veuillez s�l�ctionnez un compte dans la liste")>
    Public Property Ncp_Compte() As String
        Get
            Return m_Ncp_Compte
        End Get
        Set(value As String)
            m_Ncp_Compte = value
        End Set
    End Property
    Private m_Ncp_Compte As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Agence() As String
        Get
            Return m_Agence
        End Get
        Set(ByVal value As String)
            m_Agence = value
        End Set
    End Property
    Private m_Agence As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property N_licence_imp() As String
        Get
            Return m_N_licence_imp
        End Get
        Set(ByVal value As String)
            m_N_licence_imp = value
        End Set
    End Property
    Private m_N_licence_imp As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Ref_agrement() As String
        Get
            Return m_Ref_agrement
        End Get
        Set(ByVal value As String)
            m_Ref_agrement = value
        End Set
    End Property
    Private m_Ref_agrement As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Activite() As Nullable(Of Int32)
        Get
            Return m_Activite
        End Get
        Set(ByVal value As Nullable(Of Int32))
            m_Activite = value
        End Set
    End Property
    Private m_Activite As Nullable(Of Int32)

    Public Property Activite_autre() As String
        Get
            Return m_Activite_autre
        End Get
        Set(ByVal value As String)
            m_Activite_autre = value
        End Set
    End Property
    Private m_Activite_autre As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Nature() As Nullable(Of Int32)
        Get
            Return m_Nature
        End Get
        Set(ByVal value As Nullable(Of Int32))
            m_Nature = value
        End Set
    End Property
    Private m_Nature As Nullable(Of Int32)
    <AllowHtml>
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    <RegularExpression("^[^\<\>]*$", ErrorMessage:="Ce champ ne peut pas contenir <,>")>
    Public Property Objet() As String
        Get
            Return m_Objet
        End Get
        Set(ByVal value As String)
            m_Objet = value
        End Set
    End Property
    Private m_Objet As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Nbr_facture() As Nullable(Of Int32)
        Get
            Return m_Nbr_facture
        End Get
        Set(ByVal value As Nullable(Of Int32))
            m_Nbr_facture = value
        End Set
    End Property
    Private m_Nbr_facture As Nullable(Of Int32)

    Public Property Montant() As Nullable(Of Decimal)
        Get
            Return m_Montant
        End Get
        Set(ByVal value As Nullable(Of Decimal))
            m_Montant = value
        End Set
    End Property
    Private m_Montant As Nullable(Of Decimal)
    <NotMapped()>
    <RegularExpression("^[0-9]+([.,][0-9]+)?$", ErrorMessage:="Veuillez saisir un montant")>
    <Required(ErrorMessage:="Ce champ est n�cessaire."), Range(1, Double.MaxValue, ErrorMessage:="Le montant doit �tre sup�rieur � z�ro")>
    Public Property Montant2() As String
        Get
            Return m_Montant2
        End Get
        Set(ByVal value As String)
            m_Montant2 = value
        End Set
    End Property
    Private m_Montant2 As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Devise() As String
        Get
            Return m_Devise
        End Get
        Set(ByVal value As String)
            m_Devise = value
        End Set
    End Property
    Private m_Devise As String
    '<Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Condition() As String
        Get
            Return m_Condition
        End Get
        Set(ByVal value As String)
            m_Condition = value
        End Set
    End Property
    Private m_Condition As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Modalite_paiement() As String
        Get
            Return m_Modalite_paiement
        End Get
        Set(ByVal value As String)
            m_Modalite_paiement = value
        End Set
    End Property
    Private m_Modalite_paiement As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Nom_fournisseur() As String
        Get
            Return m_Nom_fournisseur
        End Get
        Set(ByVal value As String)
            m_Nom_fournisseur = value
        End Set
    End Property
    Private m_Nom_fournisseur As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Pays_fournisseur() As String
        Get
            Return m_Pays_fournisseur
        End Get
        Set(ByVal value As String)
            m_Pays_fournisseur = value
        End Set
    End Property
    Private m_Pays_fournisseur As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    <RegularExpression("([0-9]){10}", ErrorMessage:="Tarif douanier invalide, doit �tre sur 10 positions num�rique")>
    Public Property Tarif_douanier() As String
        Get
            Return m_Tarif_douanier
        End Get
        Set(ByVal value As String)
            m_Tarif_douanier = value
        End Set
    End Property
    Private m_Tarif_douanier As String
    <AllowHtml>
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    <RegularExpression("^[^\<\>]*$", ErrorMessage:="Ce champ ne peut pas contenir <,>")>
    Public Property Desc_tarif_douanier() As String
        Get
            Return m_Desc_tarif_douanier
        End Get
        Set(ByVal value As String)
            m_Desc_tarif_douanier = value
        End Set
    End Property
    Private m_Desc_tarif_douanier As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Banque_fournisseur() As String
        Get
            Return m_Banque_fournisseur
        End Get
        Set(ByVal value As String)
            m_Banque_fournisseur = value
        End Set
    End Property
    Private m_Banque_fournisseur As String
    '<Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Port_embarquement() As String
        Get
            Return m_Port_embarquement
        End Get
        Set(ByVal value As String)
            m_Port_embarquement = value
        End Set
    End Property
    Private m_Port_embarquement As String
    '<Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Port_destination() As String
        Get
            Return m_Port_destination
        End Get
        Set(ByVal value As String)
            m_Port_destination = value
        End Set
    End Property
    Private m_Port_destination As String
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Origine_marchandise() As String
        Get
            Return m_Origine_marchandise
        End Get
        Set(ByVal value As String)
            m_Origine_marchandise = value
        End Set
    End Property
    Private m_Origine_marchandise As String

    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Pays_provenance() As String
        Get
            Return m_Pays_provenance
        End Get
        Set(ByVal value As String)
            m_Pays_provenance = value
        End Set
    End Property
    Private m_Pays_provenance As String

    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Pays_banque() As String
        Get
            Return m_Pays_banque
        End Get
        Set(ByVal value As String)
            m_Pays_banque = value
        End Set
    End Property
    Private m_Pays_banque As String
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property DateCreation() As Nullable(Of DateTime)
        Get
            Return m_DateCreation
        End Get
        Set(ByVal value As Nullable(Of DateTime))
            m_DateCreation = value
        End Set
    End Property
    Private m_DateCreation As Nullable(Of DateTime)
    <Required(ErrorMessage:="Ce champ est n�cessaire.")>
    Public Property Id_Souscription() As Int32
        Get
            Return m_Id_Souscription
        End Get
        Set(ByVal value As Int32)
            m_Id_Souscription = value
        End Set
    End Property
    Private m_Id_Souscription As Int32
    Public Property Statut As Integer
    <ForeignKey("Radical")>
    Public Overridable Property Client() As Client
        Get
            Return m_Client
        End Get
        Set(ByVal value As Client)
            m_Client = value
        End Set
    End Property
    Private m_Client As Client

    <ForeignKey("Agence")>
    Public Overridable Property Agences() As Agence
        Get
            Return m_Agences
        End Get
        Set(ByVal value As Agence)
            m_Agences = value
        End Set
    End Property
    Private m_Agences As Agence
    <ForeignKey("Activite")>
    Public Overridable Property PreDom_Activite() As PreDom_Activite
        Get
            Return m_PreDom_Activite
        End Get
        Set(ByVal value As PreDom_Activite)
            m_PreDom_Activite = value
        End Set
    End Property
    Private m_PreDom_Activite As PreDom_Activite
    <ForeignKey("Nature")>
    Public Overridable Property PreDom_Nature() As PreDom_Nature
        Get
            Return m_PreDom_Nature
        End Get
        Set(ByVal value As PreDom_Nature)
            m_PreDom_Nature = value
        End Set
    End Property
    Private m_PreDom_Nature As PreDom_Nature
    <ForeignKey("Condition")>
    Public Overridable Property PreDom_Condition() As PreDom_Condition
        Get
            Return m_PreDom_Condition
        End Get
        Set(ByVal value As PreDom_Condition)
            m_PreDom_Condition = value
        End Set
    End Property
    Private m_PreDom_Condition As PreDom_Condition
    <ForeignKey("Devise")>
    Public Overridable Property PreDom_Devise() As PreDom_Devise
        Get
            Return m_PreDom_Devise
        End Get
        Set(ByVal value As PreDom_Devise)
            m_PreDom_Devise = value
        End Set
    End Property
    Private m_PreDom_Devise As PreDom_Devise
    <ForeignKey("Modalite_paiement")>
    Public Overridable Property PreDom_ModalitePaiement() As PreDom_ModalitePaiement
        Get
            Return m_PreDom_ModalitePaiement
        End Get
        Set(ByVal value As PreDom_ModalitePaiement)
            m_PreDom_ModalitePaiement = value
        End Set
    End Property
    Private m_PreDom_ModalitePaiement As PreDom_ModalitePaiement

    <ForeignKey("Statut")>
    Public Overridable Property PreDom_Statut() As PreDom_Statut
        Get
            Return m_PreDom_Statut
        End Get
        Set(ByVal value As PreDom_Statut)
            m_PreDom_Statut = value
        End Set
    End Property
    Private m_PreDom_Statut As PreDom_Statut
    <ForeignKey("Id_Souscription")>
    Public Overridable Property Souscription() As Souscription
        Get
            Return m_Souscription
        End Get
        Set(ByVal value As Souscription)
            m_Souscription = value
        End Set
    End Property
    Private m_Souscription As Souscription

End Class
