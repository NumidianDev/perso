Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_ModalitePaiement")>
Partial Public Class PreDom_ModalitePaiement
    <Key()>
    Public Property Code As String
    Public Property Libelle As String

End Class
