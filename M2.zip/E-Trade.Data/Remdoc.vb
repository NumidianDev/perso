﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel
<Table("Remdoc")>
Public Class Remdoc
    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    <DisplayName("Date de Création")>
    Public Property DateCreation() As DateTime?
        Get
            Return m_DateCreation
        End Get
        Set(value As DateTime?)
            m_DateCreation = value
        End Set
    End Property
    Private m_DateCreation As DateTime?

    <DisplayName("Date de Valeur")>
    Public Property DateValeur() As DateTime?
        Get
            Return m_DateValeur
        End Get
        Set(value As DateTime?)
            m_DateValeur = value
        End Set
    End Property
    Private m_DateValeur As DateTime?

    <DisplayName("Numéro remdoc")>
    Public Property RDI() As String
        Get
            Return m_RDI
        End Get
        Set(value As String)
            m_RDI = value
        End Set
    End Property
    Private m_RDI As String

    <DisplayName("Référence workflow")>
    Public Property REFWF() As String
        Get
            Return m_REFWF
        End Get
        Set(value As String)
            m_REFWF = value
        End Set
    End Property
    Private m_REFWF As String
    Public Property RefPreDom() As String
        Get
            Return m_RefPreDom
        End Get
        Set(value As String)
            m_RefPreDom = value
        End Set
    End Property
    Private m_RefPreDom As String
    <DisplayName("Référence courrier")>
    Public Property REFCOUR() As String
        Get
            Return m_REFCOUR
        End Get
        Set(value As String)
            m_REFCOUR = value
        End Set
    End Property
    Private m_REFCOUR As String

    <DisplayName("Statut remdoc")>
    Public Property Id_StatutRemdoc() As Int32
        Get
            Return m_Id_StatutRemdoc
        End Get
        Set(value As Int32)
            m_Id_StatutRemdoc = value
        End Set
    End Property
    Private m_Id_StatutRemdoc As Int32

    <ForeignKey("Id_StatutRemdoc")>
    <DisplayName("Statut remdoc")>
    Public Overridable Property StatutRemdoc() As StatutRemdoc
        Get
            Return m_StatutRemdoc
        End Get
        Set(value As StatutRemdoc)
            m_StatutRemdoc = value
        End Set
    End Property
    Private m_StatutRemdoc As StatutRemdoc

    <DisplayName("Domiciliation")>
    Public Property DOM() As String
        Get
            Return m_DOM
        End Get
        Set(value As String)
            m_DOM = value
        End Set
    End Property
    Private m_DOM As String

    <DisplayName("Radical Client")>
     Public Property Radical_Client() As String
        Get
            Return m_radical_client
        End Get
        Set(value As String)
            m_radical_client = value
        End Set
    End Property
    Private m_radical_client As String

    <ForeignKey("Radical_Client")>
    <DisplayName("Client")>
    Public Overridable Property Client() As Client
        Get
            Return m_client
        End Get
        Set(value As Client)
            m_client = value
        End Set
    End Property
    Private m_client As Client

    <DisplayName("Code Agence")>
     Public Property Age_Agence() As String
        Get
            Return m_age_agence
        End Get
        Set(value As String)
            m_age_agence = value
        End Set
    End Property
    Private m_age_agence As String

    <ForeignKey("Age_Agence")>
    <DisplayName("Agence")>
    Public Overridable Property Agence() As Agence
        Get
            Return m_agence
        End Get
        Set(value As Agence)
            m_agence = value
        End Set
    End Property
    Private m_agence As Agence

    ' A gérer la liste des comptes filtrée par l'agence 
    <DisplayName("Numéro de compte")>
    Public Property Ncp_Compte() As String
        Get
            Return m_Ncp_Compte
        End Get
        Set(value As String)
            m_Ncp_Compte = value
        End Set
    End Property
    Private m_Ncp_Compte As String

    <DisplayName("Nom du bénéficiaire")>
    Public Property NomBeneficiaire() As String
        Get
            Return m_NomBeneficiaire
        End Get
        Set(value As String)
            m_NomBeneficiaire = value
        End Set
    End Property
    Private m_NomBeneficiaire As String

    <DisplayName("Adresse du bénéficiaire")>
    Public Property AdresseBeneficiaire() As String
        Get
            Return m_AdresseBeneficiaire
        End Get
        Set(value As String)
            m_AdresseBeneficiaire = value
        End Set
    End Property
    Private m_AdresseBeneficiaire As String

    <DisplayName("Téléphone du bénéficiaire")>
    Public Property TelBeneficiaire() As String
        Get
            Return m_TelBeneficiaire
        End Get
        Set(value As String)
            m_TelBeneficiaire = value
        End Set
    End Property
    Private m_TelBeneficiaire As String

    <DisplayName("Fax du bénéficiaire")>
    Public Property FaxBeneficiaire() As String
        Get
            Return m_FaxBeneficiaire
        End Get
        Set(value As String)
            m_FaxBeneficiaire = value
        End Set
    End Property
    Private m_FaxBeneficiaire As String

    <DisplayName("Type de Remise")>
    Public Property TypeRemise() As String
        Get
            Return m_TypeRemise
        End Get
        Set(value As String)
            m_TypeRemise = value
        End Set
    End Property
    Private m_TypeRemise As String

    <DisplayName("Description marchandise")>
    Public Property DescriptionMarchandise() As String
        Get
            Return m_DescriptionMarchandise
        End Get
        Set(value As String)
            m_DescriptionMarchandise = value
        End Set
    End Property
    Private m_DescriptionMarchandise As String

    <DisplayName("Tarif douanier")>
    <Required(ErrorMessage:="Veuillez renseigner le tarif douanier ")> _
    <RegularExpression("([0-9]){8}", ErrorMessage:="Tarif douanier invalide, doit être sur 8 positions numérique")>
    Public Property TarifDouanier() As String
        Get
            Return m_TarifDouanier
        End Get
        Set(value As String)
            m_TarifDouanier = value
        End Set
    End Property
    Private m_TarifDouanier As String

    <DisplayName("Nature Produit")>
    Public Property NatureProduit() As String
        Get
            Return m_NatureProduit
        End Get
        Set(value As String)
            m_NatureProduit = value
        End Set
    End Property
    Private m_NatureProduit As String

    <DisplayName("Facture")>
    Public Property Facture() As String
        Get
            Return m_Facture
        End Get
        Set(value As String)
            m_Facture = value
        End Set
    End Property
    Private m_Facture As String

    <DisplayName("Date Facture")>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property DateFacture() As DateTime?
        Get
            Return m_DateFacture
        End Get
        Set(value As DateTime?)
            If Not value Is Nothing Then
                m_DateFacture = value
            End If
        End Set
    End Property
    Private m_DateFacture As DateTime

    <DisplayName("Quantité")>
    Public Property Qte() As String
        Get
            Return m_Qte
        End Get
        Set(value As String)
            m_Qte = value
        End Set
    End Property
    Private m_Qte As String

    <DisplayName("Prix unitaire")>
    Public Property PrixUnit() As String
        Get
            Return m_PrixUnit
        End Get
        Set(value As String)
            m_PrixUnit = value
        End Set
    End Property
    Private m_PrixUnit As String

    <DisplayName("Montant")>
    Public Property Montant() As Double?
        Get
            Return m_Montant
        End Get
        Set(value As Double?)
            m_Montant = value
        End Set
    End Property
    Private m_Montant As String

    <DisplayName("Devise")>
    Public Property Devise() As String
        Get
            Return m_Devise
        End Get
        Set(value As String)
            m_Devise = value
        End Set
    End Property
    Private m_Devise As String

    <DisplayName("Signataire")>
    Public Property Signataire() As String
        Get
            Return m_Signataire
        End Get
        Set(value As String)
            m_Signataire = value
        End Set
    End Property
    Private m_Signataire As String

    <DisplayName("Qualité du signataire")>
    Public Property QualtSignataire() As String
        Get
            Return m_QualtSignataire
        End Get
        Set(value As String)
            m_QualtSignataire = value
        End Set
    End Property
    Private m_QualtSignataire As String

    <DisplayName("Civilité")>
    Public Property Civilite() As String
        Get
            Return m_Civilite
        End Get
        Set(value As String)
            m_Civilite = value
        End Set
    End Property
    Private m_Civilite As String

    <DisplayName("Activité")>
    Public Property Activite() As String
        Get
            Return m_Activite
        End Get
        Set(value As String)
            m_Activite = value
        End Set
    End Property
    Private m_Activite As String

    <DisplayName("Pays")>
    Public Property Pays() As String
        Get
            Return m_Pays
        End Get
        Set(value As String)
            m_Pays = value
        End Set
    End Property
    Private m_Pays As String

    <DisplayName("Montant du règlement")>
    Public Property MontantReglement() As Double?
        Get
            Return m_MontantReglement
        End Get
        Set(value As Double?)
            If Not value Is Nothing Then
                m_MontantReglement = value
            End If

        End Set
    End Property
    Private m_MontantReglement As Double

    <DisplayName("Totale des règlements")>
    Public Property TotalReglement() As Double?
        Get
            Return m_TotalReglement
        End Get
        Set(value As Double?)
            If Not value Is Nothing Then
                m_TotalReglement = value
            End If

        End Set
    End Property
    Private m_TotalReglement As Double

    <DisplayName("Pourcentage du règlement")>
    Public Property PCTReglement() As Double?
        Get
            Return m_PCTReglement
        End Get
        Set(value As Double?)
            If Not value Is Nothing Then
                m_PCTReglement = value
            End If
        End Set
    End Property
    Private m_PCTReglement As Double

    <DisplayName("Date d'échéance")>
    Public Property DateEcheance() As DateTime?
        Get
            Return m_DateEcheance
        End Get
        Set(value As DateTime?)
            m_DateEcheance = value
        End Set
    End Property
    Private m_DateEcheance As DateTime?

    <DisplayName("Réglement total")>
    Public Property ReglementTotal() As String
        Get
            Return m_ReglementTotal
        End Get
        Set(value As String)
            m_ReglementTotal = value
        End Set
    End Property
    Private m_ReglementTotal As String

    Public Property Id_Souscription() As Int32
        Get
            Return m_Id_Souscription
        End Get
        Set(value As Int32)
            m_Id_Souscription = value
        End Set
    End Property
    Private m_Id_Souscription As Int32

    <ForeignKey("Id_Souscription")>
    Public Overridable Property Souscription() As Souscription
        Get
            Return m_Souscription
        End Get
        Set(value As Souscription)
            m_Souscription = value
        End Set
    End Property
    Private m_Souscription As Souscription
End Class
