Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_Commentaires")> _
Partial Public Class PreDom_Commentaires
    <Key()>
    Public Property Id As Integer
    Public Property Operation As String
    <Required()>
     Public Property IdCible As Integer
    <Required()>
    Public Property Message As String
    Public Property DateSaisie As DateTime
    Public Property Source As String

End Class
