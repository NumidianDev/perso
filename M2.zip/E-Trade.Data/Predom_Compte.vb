﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("Predom_Compte")>
Public Class Predom_Compte

    <Key()>
    <Column(Order:=1)>
    Public Property Ncp() As String
        Get
            Return m_ncp
        End Get
        Set(value As String)
            m_ncp = value
        End Set
    End Property
    Private m_ncp As String

    <Key()>
    <Column(Order:=2)>
    Public Property Age_Agence() As String
        Get
            Return m_age_agence
        End Get
        Set(value As String)
            m_age_agence = value
        End Set
    End Property
    Private m_age_agence As String

    <Key()>
    <Column(Order:=3)>
    Public Property Devise() As String
        Get
            Return m_devise
        End Get
        Set(value As String)
            m_devise = value
        End Set
    End Property
    Private m_devise As String

    <ForeignKey("Age_Agence")>
    Public Overridable Property Agence() As Agence
        Get
            Return m_agence
        End Get
        Set(value As Agence)
            m_agence = value
        End Set
    End Property
    Private m_agence As Agence

    Public Property Radical_Client() As String
        Get
            Return m_radical_client
        End Get
        Set(value As String)
            m_radical_client = value
        End Set
    End Property
    Private m_radical_client As String


    Public Property cfe() As String
        Get
            Return m_cfe
        End Get
        Set(value As String)
            m_cfe = value
        End Set
    End Property
    Private m_cfe As String

    Public Property clc() As String
        Get
            Return m_clc
        End Get
        Set(value As String)
            m_clc = value
        End Set
    End Property
    Private m_clc As String

    <NotMapped()>
    Public ReadOnly Property DisplayString() As String
        Get
            Return Ncp & " Clé " & clc
        End Get
    End Property


End Class

