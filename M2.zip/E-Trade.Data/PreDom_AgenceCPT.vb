Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_AgenceCPT")> _
Public Class PreDom_AgenceCPT
    <Key()>
    Public Property Code As String
    Public Property Radical As String
    Public Property Nom As String
    <ForeignKey("Radical")>
    Public Overridable Property PreDom_Client() As PreDom_Client

End Class
