﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("PreDom_Documents")>
Public Class PreDom_Documents

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property FileName() As String
        Get
            Return m_fileName
        End Get
        Set(value As String)
            m_fileName = value
        End Set
    End Property
    Private m_fileName As String

    Public Property Path() As String
        Get
            Return m_path
        End Get
        Set(value As String)
            m_path = value
        End Set
    End Property
    Private m_path As String

    Public Property Dossier_Id() As Int32
        Get
            Return m_dossier_id
        End Get
        Set(value As Int32)
            m_dossier_id = value
        End Set
    End Property
    Private m_dossier_id As Int32

    <ForeignKey("Dossier_Id")>
    Public Overridable Property PreDom_Dossier() As PreDom_Dossier
        Get
            Return m_PreDom_Dossier
        End Get
        Set(value As PreDom_Dossier)
            m_PreDom_Dossier = value
        End Set
    End Property
    Private m_PreDom_Dossier As PreDom_Dossier

End Class
