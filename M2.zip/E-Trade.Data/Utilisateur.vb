﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations

<Table("Utilisateur")>
Public Class Utilisateur

    <Key()>
    Public Property Matricule() As String
        Get
            Return m_Matricule
        End Get
        Set(value As String)
            m_Matricule = value
        End Set
    End Property
    Private m_Matricule As String

    Public Property Nom() As String
        Get
            Return m_nom
        End Get
        Set(value As String)
            m_nom = value
        End Set
    End Property
    Private m_nom As String

    Public Property Prenom() As String
        Get
            Return m_prenom
        End Get
        Set(value As String)
            m_prenom = value
        End Set
    End Property
    Private m_prenom As String

    Public Property Actif() As Boolean
        Get
            Return m_actif
        End Get
        Set(value As Boolean)
            m_actif = value
        End Set
    End Property
    Private m_actif As Boolean

    Public Property Id_Role() As Int32
        Get
            Return m_Id_Role
        End Get
        Set(value As Int32)
            m_Id_Role = value
        End Set
    End Property
    Private m_Id_Role As Int32

    <ForeignKey("Id_Role")>
    Public Overridable Property Role() As Role
        Get
            Return m_role
        End Get
        Set(value As Role)
            m_role = value
        End Set
    End Property
    Private m_role As Role

End Class
