﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("Agence")>
Public Class Agence

    <Key()>
    <DisplayName("Code agence")>
    Public Property Age() As String
        Get
            Return m_age
        End Get
        Set(value As String)
            m_age = value
        End Set
    End Property
    Private m_age As String

    <DisplayName("Agence")>
    Public Property Libelle() As String
        Get
            Return m_libelle
        End Get
        Set(value As String)
            m_libelle = value
        End Set
    End Property
    Private m_libelle As String

    Public Property Emails() As String
        Get
            Return m_emails
        End Get
        Set(value As String)
            m_emails = value
        End Set
    End Property
    Private m_emails As String

End Class
