﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("COAB")>
Public Class COAB

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(ByVal value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property Nom() As String
        Get
            Return m_nom
        End Get
        Set(ByVal value As String)
            m_nom = value
        End Set
    End Property
    Private m_nom As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property NomAV() As String
        Get
            Return m_nomAV
        End Get
        Set(ByVal value As String)
            m_nomAV = value
        End Set
    End Property
    Private m_nomAV As String

    Public Property Prenom() As String
        Get
            Return m_prenom
        End Get
        Set(ByVal value As String)
            m_prenom = value
        End Set
    End Property
    Private m_prenom As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property PrenomAV() As String
        Get
            Return m_prenomAV
        End Get
        Set(ByVal value As String)
            m_prenomAV = value
        End Set
    End Property
    Private m_prenomAV As String

    Public Property Email() As String
        Get
            Return m_email
        End Get
        Set(ByVal value As String)
            m_email = value
        End Set
    End Property
    Private m_email As String
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    <RegularExpression("^[a-zA-Z0-9\._-]+@[a-zA-Z0-9\.-]{2,}[\.][a-zA-Z]{2,4}$", ErrorMessage:=" Il doit être une adresse e-mail")> _
    Public Property EmailAV() As String
        Get
            Return m_emailAV
        End Get
        Set(ByVal value As String)
            m_emailAV = value
        End Set
    End Property
    Private m_emailAV As String
    Public Property PWD() As String
        Get
            Return m_pwd
        End Get
        Set(ByVal value As String)
            m_pwd = value
        End Set
    End Property
    Private m_pwd As String

    Public Property Actif() As Boolean
        Get
            Return m_actif
        End Get
        Set(ByVal value As Boolean)
            m_actif = value
        End Set
    End Property
    Private m_actif As Boolean

    Public Property ActifAV() As Boolean
        Get
            Return m_actifAV
        End Get
        Set(ByVal value As Boolean)
            m_actifAV = value
        End Set
    End Property
    Private m_actifAV As Boolean

    Public Property Id_Souscription() As Int32
        Get
            Return m_id_souscription
        End Get
        Set(ByVal value As Int32)
            m_id_souscription = value
        End Set
    End Property
    Private m_id_souscription As Int32

    <ForeignKey("Id_Souscription")>
    Public Overridable Property Souscription() As Souscription
        Get
            Return m_souscription
        End Get
        Set(ByVal value As Souscription)
            m_souscription = value
        End Set
    End Property
    Private m_souscription As Souscription

    Public Property Id_COAB_Profil() As Int32
        Get
            Return m_id_COAB_Profil
        End Get
        Set(ByVal value As Int32)
            m_id_COAB_Profil = value
        End Set
    End Property
    Private m_id_COAB_Profil As Int32
    <UIHint("DropDownList")> _
    <Required(ErrorMessage:="Veuillez compléter ce champ.")> _
    Public Property Id_COAB_ProfilAV() As Int32
        Get
            Return m_id_COAB_ProfilAV
        End Get
        Set(ByVal value As Int32)
            m_id_COAB_ProfilAV = value
        End Set
    End Property
    Private m_id_COAB_ProfilAV As Int32

    <ForeignKey("Id_COAB_Profil")>
    Public Overridable Property COAB_Profil() As COAB_Profil
        Get
            Return m_COAB_Profil
        End Get
        Set(ByVal value As COAB_Profil)
            m_COAB_Profil = value
        End Set
    End Property
    Private m_COAB_Profil As COAB_Profil

    <ForeignKey("Id_COAB_ProfilAV")>
    Public Overridable Property COAB_ProfilAV() As COAB_Profil
        Get
            Return m_COAB_ProfilAV
        End Get
        Set(ByVal value As COAB_Profil)
            m_COAB_ProfilAV = value
        End Set
    End Property
    Private m_COAB_ProfilAV As COAB_Profil

    Public Property FirstUse() As Boolean
        Get
            Return m_FirstUse
        End Get
        Set(ByVal value As Boolean)
            m_FirstUse = value
        End Set
    End Property
    Private m_FirstUse As Boolean
    Public Property Notif() As Boolean
        Get
            Return m_Notif
        End Get
        Set(ByVal value As Boolean)
            m_Notif = value
        End Set
    End Property
    Private m_Notif As Boolean

    Public Property PWD_TMP() As String
        Get
            Return m_PWD_TMP
        End Get
        Set(ByVal value As String)
            m_PWD_TMP = value
        End Set
    End Property
    Private m_PWD_TMP As String

End Class
