Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("PreDom_Facture")>
Partial Public Class PreDom_Facture
    <Key(), Column(Order:=0)>
    Public Property Num As String
     <Key(), Column(Order:=1)>
    Public Property Dossier_Id As Integer
    <DataType(DataType.Date)>
    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property Date_Facture As Nullable(Of DateTime)

End Class
