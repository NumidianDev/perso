Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("PreDom_Pays")>
Partial Public Class PreDom_Pays
    <Key()>
    Public Property Code As String
    Public Property Libelle As String

End Class
