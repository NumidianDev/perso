﻿Imports System.Security.Cryptography
Imports System.Text

Public Class SecurityUtils

    Public Shared Function CreateRandomPassword() As String

        Dim db As Data.DB = New Data.DB()
        Dim _passwordLength As Int32 = db.Parametres.Find("PasswordLength").Value
        Dim _allowedChars As String = db.Parametres.Find("AllowedChars").Value
        Dim randomNumber As New Random()
        Dim chars(_passwordLength - 1) As Char
        Dim allowedCharCount As Integer = _allowedChars.Length
        For i As Integer = 0 To _passwordLength - 1
            chars(i) = _allowedChars.Chars(CInt(Fix((_allowedChars.Length) * randomNumber.NextDouble())))
        Next i
        Return New String(chars)

    End Function

    Public Shared Function GetSHA512Hash(value As String) As String
        Dim SHA512Hasher = SHA512.Create
        Dim data = SHA512Hasher.ComputeHash(Encoding.[Default].GetBytes(value))
        Dim sBuilder = New StringBuilder()
        For i As Int32 = 0 To data.Length - 1
            sBuilder.Append(data(i).ToString("x2"))
        Next
        Return sBuilder.ToString()
    End Function

End Class
