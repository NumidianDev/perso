﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel

<Table("Commentaires")>
Public Class Commentaires

    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(ByVal value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property Operation() As String
        Get
            Return m_Operation
        End Get
        Set(ByVal value As String)
            m_Operation = value
        End Set
    End Property
    Private m_Operation As String

    Public Property IdCible() As Int32
        Get
            Return m_IdCible
        End Get
        Set(ByVal value As Int32)
            m_IdCible = value
        End Set
    End Property
    Private m_IdCible As Int32

    Public Property Message() As String
        Get
            Return m_Message
        End Get
        Set(ByVal value As String)
            m_Message = value
        End Set
    End Property
    Private m_Message As String

    <DisplayFormat(DataFormatString:="{0:dd/MM/yyyy}", ApplyFormatInEditMode:=True, NullDisplayText:="01/01/1800")>
    Public Property DateSaisie() As Date?
        Get
            Return m_DateSaisie
        End Get
        Set(ByVal value As Date?)
            m_DateSaisie = value
        End Set
    End Property
    Private m_DateSaisie As Date?

    Public Property Source() As String
        Get
            Return m_Source
        End Get
        Set(ByVal value As String)
            m_Source = value
        End Set
    End Property
    Private m_Source As String


End Class
