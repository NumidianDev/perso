﻿Imports Newtonsoft.Json

Public Class TarifDouanier
    <JsonIgnore>
    Public ReadOnly Property id As String
        Get
            Return position
        End Get
    End Property
    <JsonIgnore>
    Public ReadOnly Property text As String
        Get
            Return [lib]
        End Get
    End Property

    Public Property id_tarif As Integer
    Public Property position As String
    Public Property [lib] As String
    Public Property intrants As Boolean
    Public Property autorisation_BA As Boolean
    Public Property interdit_imp As Boolean
    Public Property interdit_exp As Boolean
    Public Property obsolete As Boolean

End Class
