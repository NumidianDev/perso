package com.dz.sga.dto;

public class GestionnaireDto {
	
	private String cuti;
	private String age;
	private String libagence;
	private String ges;
	private String cge;
	private String sus;
	private String lib;
	
	public GestionnaireDto(String cuti, String age, String libagence, String ges, String cge, String sus, String lib) {
		super();
		this.cuti = cuti;
		this.age = age;
		this.libagence = libagence;
		this.ges = ges;
		this.cge = cge;
		this.sus = sus;
		this.lib = lib;
	}

	public String getCuti() {
		return cuti;
	}

	public String getAge() {
		return age;
	}

	public String getLibagence() {
		return libagence;
	}

	public String getGes() {
		return ges;
	}

	public String getCge() {
		return cge;
	}

	public String getSus() {
		return sus;
	}

	public String getLib() {
		return lib;
	}
	
	

}
