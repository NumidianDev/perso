package com.dz.sga.dao;

import java.io.Serializable;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


@Entity
@Table(name = "evuti")
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    private String cuti;
	private String lib;
	private String ges;
	private String cge;
	private String sus;
	private String age;
	
	public String getCuti() {
		return cuti;
	}
	
	public void setCuti(String cuti) {
		this.cuti = cuti;
	}
	public String getLib() {
		return lib;
	}
	public void setLib(String lib) {
		this.lib = lib;
	}
	public String getGes() {
		return ges;
	}
	public void setGes(String ges) {
		this.ges = ges;
	}
	public String getCge() {
		return cge;
	}
	public void setCge(String cge) {
		this.cge = cge;
	}
	public String getSus() {
		return sus;
	}
	public void setSus(String sus) {
		this.sus = sus;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "age", referencedColumnName = "age",insertable = false, updatable = false)
	@Fetch(FetchMode.JOIN)
	private Branch branch;
	
}
