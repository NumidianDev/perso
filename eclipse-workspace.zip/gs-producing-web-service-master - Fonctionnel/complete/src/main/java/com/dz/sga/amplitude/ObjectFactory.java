//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.7 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.05.07 à 05:34:06 PM WAT 
//


package com.dz.sga.amplitude;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.dz.sga.amplitude package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.dz.sga.amplitude
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetGestionnairesRequest }
     * 
     */
    public GetGestionnairesRequest createGetGestionnairesRequest() {
        return new GetGestionnairesRequest();
    }

    /**
     * Create an instance of {@link GetGestionnaireResponse }
     * 
     */
    public GetGestionnaireResponse createGetGestionnaireResponse() {
        return new GetGestionnaireResponse();
    }

    /**
     * Create an instance of {@link Gestionnaire }
     * 
     */
    public Gestionnaire createGestionnaire() {
        return new Gestionnaire();
    }

    /**
     * Create an instance of {@link GetEmployeursRequest }
     * 
     */
    public GetEmployeursRequest createGetEmployeursRequest() {
        return new GetEmployeursRequest();
    }

    /**
     * Create an instance of {@link GetGestionnaireRequest }
     * 
     */
    public GetGestionnaireRequest createGetGestionnaireRequest() {
        return new GetGestionnaireRequest();
    }

    /**
     * Create an instance of {@link CancelStoppageResponse }
     * 
     */
    public CancelStoppageResponse createCancelStoppageResponse() {
        return new CancelStoppageResponse();
    }

    /**
     * Create an instance of {@link StoppageResponse }
     * 
     */
    public StoppageResponse createStoppageResponse() {
        return new StoppageResponse();
    }

    /**
     * Create an instance of {@link GetGestionnairesResponse }
     * 
     */
    public GetGestionnairesResponse createGetGestionnairesResponse() {
        return new GetGestionnairesResponse();
    }

    /**
     * Create an instance of {@link GetEmployeurRequest }
     * 
     */
    public GetEmployeurRequest createGetEmployeurRequest() {
        return new GetEmployeurRequest();
    }

    /**
     * Create an instance of {@link GetEmployeurResponse }
     * 
     */
    public GetEmployeurResponse createGetEmployeurResponse() {
        return new GetEmployeurResponse();
    }

    /**
     * Create an instance of {@link Employeur }
     * 
     */
    public Employeur createEmployeur() {
        return new Employeur();
    }

    /**
     * Create an instance of {@link GetEmployeursResponse }
     * 
     */
    public GetEmployeursResponse createGetEmployeursResponse() {
        return new GetEmployeursResponse();
    }

    /**
     * Create an instance of {@link CancelStoppageRequest }
     * 
     */
    public CancelStoppageRequest createCancelStoppageRequest() {
        return new CancelStoppageRequest();
    }

    /**
     * Create an instance of {@link Stoppage }
     * 
     */
    public Stoppage createStoppage() {
        return new Stoppage();
    }

}
