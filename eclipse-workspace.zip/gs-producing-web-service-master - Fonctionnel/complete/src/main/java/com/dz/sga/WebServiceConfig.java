package com.dz.sga;

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

@EnableWs
@Configuration
public class WebServiceConfig extends WsConfigurerAdapter {
	@Bean
	public ServletRegistrationBean messageDispatcherServlet(ApplicationContext applicationContext) {
		MessageDispatcherServlet servlet = new MessageDispatcherServlet();
		servlet.setApplicationContext(applicationContext);
		servlet.setTransformWsdlLocations(true);
		return new ServletRegistrationBean(servlet, "/ws/*");
	}

	@Bean(name = "gestionnaires")
	public DefaultWsdl11Definition gestionnairetWsdl11Definition(XsdSchema gestionnairesSchema) {
		DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
		wsdl11Definition.setPortTypeName("GestionnairesPort");
		wsdl11Definition.setLocationUri("/ws");
		wsdl11Definition.setTargetNamespace("http://sga.dz.com/amplitude");
		wsdl11Definition.setSchema(gestionnairesSchema);
		return wsdl11Definition;
	}

	@Bean(name = "employeurs")
	public DefaultWsdl11Definition employeurdefaultWsdl11Definition(XsdSchema employeursSchema) {
		DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
		wsdl11Definition.setPortTypeName("EmployeursPort");
		wsdl11Definition.setLocationUri("/ws");
		wsdl11Definition.setTargetNamespace("http://sga.dz.com/amplitude");
		wsdl11Definition.setSchema(employeursSchema);
		return wsdl11Definition;
	}
	
	@Bean(name = "stoppages")
	public DefaultWsdl11Definition stoppagefaultWsdl11Definition(XsdSchema stoppagesSchema) {
		DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
		wsdl11Definition.setPortTypeName("StoppagesPort");
		wsdl11Definition.setLocationUri("/ws");
		wsdl11Definition.setTargetNamespace("http://soprabanking.com/amplitude");
		wsdl11Definition.setSchema(stoppagesSchema);
		return wsdl11Definition;
	}
	
	@Bean
	public XsdSchema gestionnairesSchema() {
		return new SimpleXsdSchema(new ClassPathResource("gestionnaires.xsd"));
	}
	
	@Bean
	public XsdSchema employeursSchema() {
		return new SimpleXsdSchema(new ClassPathResource("employeurs.xsd"));
	}
	
	@Bean
	public XsdSchema stoppagesSchema() {
		return new SimpleXsdSchema(new ClassPathResource("cancelStoppage.xsd"));
	}
}
