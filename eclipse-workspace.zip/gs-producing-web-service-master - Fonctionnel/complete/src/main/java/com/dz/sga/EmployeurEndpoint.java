package com.dz.sga;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.dz.sga.amplitude.Employeur;
import com.dz.sga.amplitude.GetEmployeurRequest;
import com.dz.sga.amplitude.GetEmployeurResponse;
import com.dz.sga.amplitude.GetEmployeursRequest;
import com.dz.sga.amplitude.GetEmployeursResponse;
import com.dz.sga.repositories.EmployeurRepository;
import com.dz.sga.utils.mappers.OrikaBeanMapper;

@Endpoint
public class EmployeurEndpoint {

	private static final String NAMESPACE_URI = "http://sga.dz.com/amplitude";
	
	@Autowired
	private EmployeurRepository employeurRepository;

	@Autowired
	OrikaBeanMapper mapper;
	
	@Autowired
	public EmployeurEndpoint(EmployeurRepository employeurRepository) {
		this.employeurRepository = employeurRepository;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getEmployeursRequest")
	@ResponsePayload
	public GetEmployeursResponse getCountry(@RequestPayload GetEmployeursRequest request) {
		GetEmployeursResponse response = new GetEmployeursResponse();
		employeurRepository.getEmployeursAll().forEach(employeur -> {
			response.getEmployeur().add(mapper.map(employeur, Employeur.class));
		});
		return response;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getEmployeurRequest")
	@ResponsePayload
	public GetEmployeurResponse getEmployeur(@RequestPayload GetEmployeurRequest request) {
		GetEmployeurResponse response = new GetEmployeurResponse();
		response.setEmployeur(mapper.map(employeurRepository.getEmployeurById(request.getEmp()), Employeur.class));
//		employeurRepository.getEmployeursAll().forEach(employeur -> {
//			response.getEmployeur().add(mapper.map(employeur, Employeur.class));
//		});
		return response;
	}
}
