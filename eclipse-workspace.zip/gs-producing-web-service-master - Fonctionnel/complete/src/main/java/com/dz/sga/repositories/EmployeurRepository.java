package com.dz.sga.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.dz.sga.dao.Employeur;

public interface EmployeurRepository extends CrudRepository<Employeur, String> {

	@Query("SELECT e FROM Employeur e")
	List<Employeur> getEmployeursAll();
	
	@Query("SELECT e FROM Employeur e where e.emp = :emp")
	Employeur getEmployeurById(String emp);
}
