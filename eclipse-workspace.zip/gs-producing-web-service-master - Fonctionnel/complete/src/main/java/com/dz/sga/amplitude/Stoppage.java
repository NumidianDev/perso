//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.7 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.05.07 à 05:34:06 PM WAT 
//


package com.dz.sga.amplitude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour Stoppage complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="Stoppage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="branch" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currency" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="account" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="suffix" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="stoppageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="stoppageEndReason" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Stoppage", propOrder = {
    "branch",
    "currency",
    "account",
    "suffix",
    "stoppageCode",
    "stoppageEndReason"
})
public class Stoppage {

    @XmlElement(required = true)
    protected String branch;
    @XmlElement(required = true)
    protected String currency;
    @XmlElement(required = true)
    protected String account;
    @XmlElement(required = true)
    protected String suffix;
    @XmlElement(required = true)
    protected String stoppageCode;
    @XmlElement(required = true)
    protected String stoppageEndReason;

    /**
     * Obtient la valeur de la propriété branch.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranch() {
        return branch;
    }

    /**
     * Définit la valeur de la propriété branch.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranch(String value) {
        this.branch = value;
    }

    /**
     * Obtient la valeur de la propriété currency.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Définit la valeur de la propriété currency.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
     * Obtient la valeur de la propriété account.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccount() {
        return account;
    }

    /**
     * Définit la valeur de la propriété account.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccount(String value) {
        this.account = value;
    }

    /**
     * Obtient la valeur de la propriété suffix.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Définit la valeur de la propriété suffix.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

    /**
     * Obtient la valeur de la propriété stoppageCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoppageCode() {
        return stoppageCode;
    }

    /**
     * Définit la valeur de la propriété stoppageCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoppageCode(String value) {
        this.stoppageCode = value;
    }

    /**
     * Obtient la valeur de la propriété stoppageEndReason.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoppageEndReason() {
        return stoppageEndReason;
    }

    /**
     * Définit la valeur de la propriété stoppageEndReason.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoppageEndReason(String value) {
        this.stoppageEndReason = value;
    }

}
