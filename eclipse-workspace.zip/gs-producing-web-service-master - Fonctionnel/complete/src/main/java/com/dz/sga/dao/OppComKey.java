package com.dz.sga.dao;

import java.io.Serializable;

public class OppComKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String age;
	private String dev;
	private String ncp;
	private String opp;
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getDev() {
		return dev;
	}
	public void setDev(String dev) {
		this.dev = dev;
	}
	public String getNcp() {
		return ncp;
	}
	public void setNcp(String ncp) {
		this.ncp = ncp;
	}
	public String getOpp() {
		return opp;
	}
	public void setOpp(String opp) {
		this.opp = opp;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
