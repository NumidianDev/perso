package com.dz.sga.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.dz.sga.dao.User;
import com.dz.sga.dto.GestionnaireDto;

public interface GestionnaireRepository extends CrudRepository<User, String>{

	@Query("select u from User u where u.cuti = :matricule")
	User getUserByMatricule(String matricule);
	
	@Query("select u from User u where u.age = :agence")
	List<User> getUsersByAgence(String agence);
	
	@Query("SELECT new com.dz.sga.dto.GestionnaireDto(u.cuti,u.age,b.lib,u.ges,u.cge,u.sus,u.lib) from User u JOIN u.branch b where u.cuti = :matricule")
	GestionnaireDto getGestionnaireByMatricule(String matricule);
	
	@Query("SELECT new com.dz.sga.dto.GestionnaireDto(u.cuti,u.age,b.lib,u.ges,u.cge,u.sus,u.lib) from User u JOIN u.branch b where u.age = :agence and u.ges = 'O'")
	List<GestionnaireDto> getGestionnairesByAgence(String agence);
	
	@Query("SELECT new com.dz.sga.dto.GestionnaireDto(u.cuti,u.age,b.lib,u.ges,u.cge,u.sus,u.lib) FROM User u JOIN u.branch b WHERE u.age = :age and u.ges = 'O'")
    List<GestionnaireDto> getGestionnairesSameBranch(String age);
	
	@Query("SELECT new com.dz.sga.dto.GestionnaireDto(u.cuti,u.age,b.lib,u.ges,u.cge,u.sus,u.lib) FROM User u JOIN u.branch b WHERE u.ges = 'O'")
	List<GestionnaireDto> getGestionnairesAll();
	
}
