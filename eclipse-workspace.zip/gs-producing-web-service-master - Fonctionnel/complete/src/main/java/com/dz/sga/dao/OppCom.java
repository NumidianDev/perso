package com.dz.sga.dao;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name = "bkoppcom")
@IdClass(OppComKey.class)
public class OppCom {

	@Id private String age;
	@Id private String dev;
	@Id private String ncp;
	@Id private String opp;
	
	@Temporal(TemporalType.DATE)
	private Date dlev;
	private String motifl;
	private String utl;
	private String eta;
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getDev() {
		return dev;
	}
	public void setDev(String dev) {
		this.dev = dev;
	}
	public String getNcp() {
		return ncp;
	}
	public void setNcp(String ncp) {
		this.ncp = ncp;
	}
	
	public String getOpp() {
		return opp;
	}
	public void setOpp(String opp) {
		this.opp = opp;
	}
	
	public Date getDlev() {
		return dlev;
	}
	public void setDlev(Date dlev) {
		this.dlev = dlev;
	}
	public String getMotifl() {
		return motifl;
	}
	public void setMotifl(String motifl) {
		this.motifl = motifl;
	}
	public String getUtl() {
		return utl;
	}
	public void setUtl(String utl) {
		this.utl = utl;
	}
	public String getEta() {
		return eta;
	}
	public void setEta(String eta) {
		this.eta = eta;
	}
	
}
