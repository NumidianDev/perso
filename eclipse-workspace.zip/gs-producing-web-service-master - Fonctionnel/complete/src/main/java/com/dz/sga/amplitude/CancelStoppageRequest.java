//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.7 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.05.07 à 05:34:06 PM WAT 
//


package com.dz.sga.amplitude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour anonymous complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Stoppage" type="{http://sga.dz.com/amplitude}Stoppage"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "stoppage"
})
@XmlRootElement(name = "cancelStoppageRequest")
public class CancelStoppageRequest {

    @XmlElement(name = "Stoppage", required = true)
    protected Stoppage stoppage;

    /**
     * Obtient la valeur de la propriété stoppage.
     * 
     * @return
     *     possible object is
     *     {@link Stoppage }
     *     
     */
    public Stoppage getStoppage() {
        return stoppage;
    }

    /**
     * Définit la valeur de la propriété stoppage.
     * 
     * @param value
     *     allowed object is
     *     {@link Stoppage }
     *     
     */
    public void setStoppage(Stoppage value) {
        this.stoppage = value;
    }

}
