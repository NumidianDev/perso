//package com.dz.sga.config;
//
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@ComponentScan(basePackages = { "com.dz.sga" })
//public class AppConfig {
//
//}
