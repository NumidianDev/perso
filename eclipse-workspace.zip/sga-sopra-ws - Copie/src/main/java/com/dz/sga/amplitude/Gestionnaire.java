//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.7 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.04.29 à 07:33:30 PM WAT 
//


package com.dz.sga.amplitude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour gestionnaire complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="gestionnaire">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cuti" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="age" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cge" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lib" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="libagence" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "gestionnaire", propOrder = {
    "cuti",
    "age",
    "cge",
    "lib",
    "libagence"
})
public class Gestionnaire {

    @XmlElement(required = true)
    protected String cuti;
    @XmlElement(required = true)
    protected String age;
    @XmlElement(required = true)
    protected String cge;
    @XmlElement(required = true)
    protected String lib;
    @XmlElement(required = true)
    protected String libagence;

    /**
     * Obtient la valeur de la propriété cuti.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuti() {
        return cuti;
    }

    /**
     * Définit la valeur de la propriété cuti.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuti(String value) {
        this.cuti = value;
    }

    /**
     * Obtient la valeur de la propriété age.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAge() {
        return age;
    }

    /**
     * Définit la valeur de la propriété age.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAge(String value) {
        this.age = value;
    }

    /**
     * Obtient la valeur de la propriété cge.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCge() {
        return cge;
    }

    /**
     * Définit la valeur de la propriété cge.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCge(String value) {
        this.cge = value;
    }

    /**
     * Obtient la valeur de la propriété lib.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLib() {
        return lib;
    }

    /**
     * Définit la valeur de la propriété lib.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLib(String value) {
        this.lib = value;
    }

    /**
     * Obtient la valeur de la propriété libagence.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibagence() {
        return libagence;
    }

    /**
     * Définit la valeur de la propriété libagence.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibagence(String value) {
        this.libagence = value;
    }

}
