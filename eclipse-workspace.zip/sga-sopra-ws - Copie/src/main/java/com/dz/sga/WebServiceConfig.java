//package com.dz.sga;
//
//import org.springframework.boot.web.servlet.ServletRegistrationBean;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.io.ClassPathResource;
//import org.springframework.ws.config.annotation.EnableWs;
//import org.springframework.ws.config.annotation.WsConfigurerAdapter;
//import org.springframework.ws.transport.http.MessageDispatcherServlet;
//import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
//import org.springframework.xml.xsd.SimpleXsdSchema;
//import org.springframework.xml.xsd.XsdSchema;
//
//@EnableWs
//@Configuration
//public class WebServiceConfig extends WsConfigurerAdapter {
//
//	@Bean
//	  public ServletRegistrationBean messageDispatcherServlet(ApplicationContext context) {
//	    MessageDispatcherServlet messageDispatcherServlet = new MessageDispatcherServlet();
//	    messageDispatcherServlet.setApplicationContext(context);
//	    messageDispatcherServlet.setTransformWsdlLocations(true);
//	    return new ServletRegistrationBean(messageDispatcherServlet, "/ws/*");
//	  }
//	
//	
//	@Bean(name = "gestionnaires")
//	public DefaultWsdl11Definition gestionnairesWsdl11Definition(XsdSchema gestionnairesSchema) {
//	  DefaultWsdl11Definition definition = new DefaultWsdl11Definition();
//	  definition.setPortTypeName("GestionnairesPort");
//	  definition.setTargetNamespace("http://sga.dz.com/amplitude");
//	  definition.setLocationUri("/ws");
//	  definition.setSchema(gestionnairesSchema);
//	  return definition;
//	}
//	
//	@Bean(name = "employeurs")
//	public DefaultWsdl11Definition employeursWsdl11Definition(XsdSchema employeursSchema) {
//	  DefaultWsdl11Definition definition = new DefaultWsdl11Definition();
//	  definition.setPortTypeName("EmployeursPort");
//	  definition.setTargetNamespace("http://sga.dz.com/amplitude");
//	  definition.setLocationUri("/ws");
//	  definition.setSchema(employeursSchema);
//	  return definition;
//	}
//	
//	@Bean(name = "cancelStoppage")
//	public DefaultWsdl11Definition cancelStoppageWsdl11Definition(XsdSchema cancelStoppageSchema) {
//	  DefaultWsdl11Definition definition = new DefaultWsdl11Definition();
//	  definition.setPortTypeName("CancelStoppagePort");
//	  definition.setTargetNamespace("http://soprabanking.com/amplitude");
//	  definition.setLocationUri("/ws");
//	  definition.setSchema(cancelStoppageSchema);
//	  return definition;
//	}
//
//	@Bean
//	public XsdSchema gestionnairesSchema() {
//		return new SimpleXsdSchema(new ClassPathResource("gestionnaires.xsd"));
//	}
//	
//	@Bean
//	public XsdSchema employeursSchema() {
//		return new SimpleXsdSchema(new ClassPathResource("employeurs.xsd"));
//	}
//	
//	@Bean
//	public XsdSchema cancelStoppageSchema() {
//		return new SimpleXsdSchema(new ClassPathResource("cancelStoppage.xsd"));
//	}
//}
