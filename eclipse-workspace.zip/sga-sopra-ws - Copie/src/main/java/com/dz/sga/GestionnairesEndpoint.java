package com.dz.sga;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.dz.sga.amplitude.Gestionnaire;
import com.dz.sga.amplitude.GetGestionnairesAsMeRequest;
import com.dz.sga.amplitude.GetGestionnairesRequest;
import com.dz.sga.amplitude.GetGestionnairesResponse;
import com.dz.sga.dto.GestionnaireDto;
import com.dz.sga.repositories.GestionnaireRepository;
import com.dz.sga.utils.mappers.OrikaBeanMapper;

@Endpoint
public class GestionnairesEndpoint {

	private static final String NAMESPACE_URI = "http://sga.dz.com/amplitude";
	
	@Autowired
	private GestionnaireRepository gestionnaireRepository;

	@Autowired
	OrikaBeanMapper mapper;
	
	@Autowired
	public GestionnairesEndpoint(GestionnaireRepository gestionnaireRepository) {
		this.gestionnaireRepository = gestionnaireRepository;
	}
	
	  @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getGestionnairesRequest")
	  @ResponsePayload
	  public GetGestionnairesResponse processGestionnaireRequest(@RequestPayload GetGestionnairesRequest request) {
		GetGestionnairesResponse response = new GetGestionnairesResponse();
		gestionnaireRepository.getGestionnairesAll().forEach(gestionnaire -> {
			response.getGestionnaire().add(mapper.map(gestionnaire, Gestionnaire.class));
		});
		
		return response;
	  }
	  
	  @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getGestionnairesAsMeRequest")
		@ResponsePayload
		public GetGestionnairesResponse getCountries(@RequestPayload GetGestionnairesAsMeRequest request) {
			GetGestionnairesResponse response = new GetGestionnairesResponse();
			
			GestionnaireDto connectedUser = gestionnaireRepository.getGestionnaireByMatricule(request.getCuti());
			
			
			if(null != connectedUser) {
				gestionnaireRepository.getGestionnairesByAgence(connectedUser.getAge()).forEach(gestionnaire -> {
					response.getGestionnaire().add(mapper.map(gestionnaire, Gestionnaire.class));
				});
			}
					
			return response;
		}
}
