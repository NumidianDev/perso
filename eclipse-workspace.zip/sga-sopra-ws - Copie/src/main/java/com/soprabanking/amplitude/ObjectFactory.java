//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.7 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.04.29 à 07:33:30 PM WAT 
//


package com.soprabanking.amplitude;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.soprabanking.amplitude package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ErrorResponseFlow_QNAME = new QName("http://soprabanking.com/amplitude", "errorResponseFlow");
    private final static QName _GetStatusRequestFlow_QNAME = new QName("http://soprabanking.com/amplitude", "getStatusRequestFlow");
    private final static QName _CancelStoppageResponseFlow_QNAME = new QName("http://soprabanking.com/amplitude", "cancelStoppageResponseFlow");
    private final static QName _GetStatusResponseFlow_QNAME = new QName("http://soprabanking.com/amplitude", "getStatusResponseFlow");
    private final static QName _CancelStoppageRequestFlow_QNAME = new QName("http://soprabanking.com/amplitude", "cancelStoppageRequestFlow");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.soprabanking.amplitude
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CancelStoppageResponseFlow }
     * 
     */
    public CancelStoppageResponseFlow createCancelStoppageResponseFlow() {
        return new CancelStoppageResponseFlow();
    }

    /**
     * Create an instance of {@link GetStatusResponseFlow }
     * 
     */
    public GetStatusResponseFlow createGetStatusResponseFlow() {
        return new GetStatusResponseFlow();
    }

    /**
     * Create an instance of {@link CancelStoppageRequestFlow }
     * 
     */
    public CancelStoppageRequestFlow createCancelStoppageRequestFlow() {
        return new CancelStoppageRequestFlow();
    }

    /**
     * Create an instance of {@link ErrorResponseFlow }
     * 
     */
    public ErrorResponseFlow createErrorResponseFlow() {
        return new ErrorResponseFlow();
    }

    /**
     * Create an instance of {@link GetStatusRequestFlow }
     * 
     */
    public GetStatusRequestFlow createGetStatusRequestFlow() {
        return new GetStatusRequestFlow();
    }

    /**
     * Create an instance of {@link ResponseStatusMessage }
     * 
     */
    public ResponseStatusMessage createResponseStatusMessage() {
        return new ResponseStatusMessage();
    }

    /**
     * Create an instance of {@link ResponseHeader }
     * 
     */
    public ResponseHeader createResponseHeader() {
        return new ResponseHeader();
    }

    /**
     * Create an instance of {@link InternalAccountKey }
     * 
     */
    public InternalAccountKey createInternalAccountKey() {
        return new InternalAccountKey();
    }

    /**
     * Create an instance of {@link Language }
     * 
     */
    public Language createLanguage() {
        return new Language();
    }

    /**
     * Create an instance of {@link GetStatusResponse }
     * 
     */
    public GetStatusResponse createGetStatusResponse() {
        return new GetStatusResponse();
    }

    /**
     * Create an instance of {@link ResponseStatus }
     * 
     */
    public ResponseStatus createResponseStatus() {
        return new ResponseStatus();
    }

    /**
     * Create an instance of {@link ResponseStatusMessages }
     * 
     */
    public ResponseStatusMessages createResponseStatusMessages() {
        return new ResponseStatusMessages();
    }

    /**
     * Create an instance of {@link CustomerOrAccount }
     * 
     */
    public CustomerOrAccount createCustomerOrAccount() {
        return new CustomerOrAccount();
    }

    /**
     * Create an instance of {@link ErrorInformation }
     * 
     */
    public ErrorInformation createErrorInformation() {
        return new ErrorInformation();
    }

    /**
     * Create an instance of {@link RequestHeader }
     * 
     */
    public RequestHeader createRequestHeader() {
        return new RequestHeader();
    }

    /**
     * Create an instance of {@link CancelStoppageRequest }
     * 
     */
    public CancelStoppageRequest createCancelStoppageRequest() {
        return new CancelStoppageRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ErrorResponseFlow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soprabanking.com/amplitude", name = "errorResponseFlow")
    public JAXBElement<ErrorResponseFlow> createErrorResponseFlow(ErrorResponseFlow value) {
        return new JAXBElement<ErrorResponseFlow>(_ErrorResponseFlow_QNAME, ErrorResponseFlow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatusRequestFlow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soprabanking.com/amplitude", name = "getStatusRequestFlow")
    public JAXBElement<GetStatusRequestFlow> createGetStatusRequestFlow(GetStatusRequestFlow value) {
        return new JAXBElement<GetStatusRequestFlow>(_GetStatusRequestFlow_QNAME, GetStatusRequestFlow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelStoppageResponseFlow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soprabanking.com/amplitude", name = "cancelStoppageResponseFlow")
    public JAXBElement<CancelStoppageResponseFlow> createCancelStoppageResponseFlow(CancelStoppageResponseFlow value) {
        return new JAXBElement<CancelStoppageResponseFlow>(_CancelStoppageResponseFlow_QNAME, CancelStoppageResponseFlow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStatusResponseFlow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soprabanking.com/amplitude", name = "getStatusResponseFlow")
    public JAXBElement<GetStatusResponseFlow> createGetStatusResponseFlow(GetStatusResponseFlow value) {
        return new JAXBElement<GetStatusResponseFlow>(_GetStatusResponseFlow_QNAME, GetStatusResponseFlow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelStoppageRequestFlow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soprabanking.com/amplitude", name = "cancelStoppageRequestFlow")
    public JAXBElement<CancelStoppageRequestFlow> createCancelStoppageRequestFlow(CancelStoppageRequestFlow value) {
        return new JAXBElement<CancelStoppageRequestFlow>(_CancelStoppageRequestFlow_QNAME, CancelStoppageRequestFlow.class, null, value);
    }

}
