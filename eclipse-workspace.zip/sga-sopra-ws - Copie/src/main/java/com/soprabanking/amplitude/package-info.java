//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.7 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2019.04.29 à 07:33:30 PM WAT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://soprabanking.com/amplitude", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.soprabanking.amplitude;
