﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace FP_TO_MT101
{
    class Program
    {
        
        static void Main(string[] args)
        {

            IList<ProcessResult> erreursList = new List<ProcessResult>();
            String outPutFile = String.Empty;
            string fileName = string.Empty;
            string destinationDirectory = string.Empty;

            if (args.Length > 1)
            {
                string firtsArgs = args[0];
                
                fileName = args[0];
                destinationDirectory = args[1];
                
                if (File.Exists(fileName))
                {
                    string archiveDGIDirectory = ConfigurationManager.AppSettings["archiveDGIDirectory"];

                    if ((!string.IsNullOrEmpty(destinationDirectory) && Directory.Exists(destinationDirectory)))
                    {
                        erreursList = parseFile(fileName, destinationDirectory, archiveDGIDirectory, out outPutFile);
                    }
                    else
                    {
                        erreursList.Add(new ProcessResult()
                        {
                            Controles = erreursList.Count() + 1,
                            Description = "Le dossier de destination n'existe pas",
                            Detail = "Les variables en entrée du programme somble incorrectes",
                            Resultat = false
                        });
                    }
                }
                else {
                    erreursList.Add(new ProcessResult()
                    {
                        Controles = erreursList.Count() + 1,
                        Description = "Le fichier spécifié en argument n'existe pas ",
                        Detail = "Les variables en entrée du programme somble incorrectes",
                        Resultat = false
                    });
                }
            }
            else
            {
                erreursList.Add(new ProcessResult()
                {
                    Controles = erreursList.Count() + 1,
                    Description = "Le programme est invoqué avec un nombres d'arguments insufisants : " + args.Length,
                    Detail = "Le programme doit être invoqué avec 2 arguments: Fichier_Source et Dossier_de_sortie",
                    Resultat = false
                });
            }

            if (erreursList.Count > 0)
            {
                try
                {
                    string errorsDir = ConfigurationManager.AppSettings["ErrorsDir"];
                    string errorFile = String.IsNullOrEmpty(fileName) ? "Erreurs.xlsx" : Path.GetFileNameWithoutExtension(fileName) + "_Erreurs.xlsx";
                    ExcelExportHelper.ByteArrayToObject(ExcelExportHelper.ExportExcel<ProcessResult>(erreursList, "Erreurs DGI"), errorsDir + "\\" + errorFile);

                }
                catch (Exception)
                {
                    
                    throw;
                }
                Console.WriteLine("ERROR");
            }
            else {
               Console.WriteLine(outPutFile);
            }
        }
        //private static void verifyInputDirectory(string sourceDirectory)
        //{
        //    if (string.IsNullOrEmpty(sourceDirectory))
        //    {
        //        Console.WriteLine("Le dossier source n'est pas paramétré ");
        //    }
        //    else
        //    {
        //        if (!Directory.Exists(sourceDirectory))
        //        {
        //            Console.WriteLine("Le dossier source n'existe pas ");
        //        }
        //    }
        //}

        //private static void verifyDirectories(string outputDirectory, string archiveDGIDirectory)
        //{
        //    if (string.IsNullOrEmpty(outputDirectory))
        //    {
        //        Console.WriteLine("Le dossier de destination n'est pas paramétré ");
        //    }
        //    else
        //    {
        //        if (!Directory.Exists(outputDirectory))
        //        {
        //            Console.WriteLine("Le dossier de destination n'existe pas ");
        //        }
        //    }
        //    if (string.IsNullOrEmpty(archiveDGIDirectory))
        //    {
        //        Console.WriteLine("Le dossier d'archive n'est pas paramétré ");
        //    }
        //    else
        //    {
        //        if (!Directory.Exists(archiveDGIDirectory))
        //        {
        //            Console.WriteLine("Le dossier d'archive n'existe pas ");
        //        }
        //    }
        //}

        //private static List<ProcessResult> parseFiles(string sourceDirectory, string outputDirectory, string archiveDGIDirectory)
        //{
        //    DirectoryInfo di = new DirectoryInfo(sourceDirectory);
        //    List<ProcessResult> erreursListFinale = new List<ProcessResult>();

        //    foreach (FileInfo fi in di.GetFiles("*.txt"))
        //    {
        //        IList<ProcessResult> erreurs = parseFile(fi.FullName, outputDirectory, archiveDGIDirectory);
        //        if (erreurs.Count > 0) {
        //            erreursListFinale.AddRange(erreurs.AsEnumerable());
        //        }
        //    }

        //    return erreursListFinale;
        //}

        private static IList<ProcessResult> parseFile(string fileName, string outputDirectory, string archiveDGIDirectory, out string fileOutput)
        {
            
            List<ProcessResult> erreursList = new List<ProcessResult>();

            InPutParser ip = new InPutParser();
            MT101 virement = new MT101();

            virement.tag_52A = ip.BicEmetteur;

            bool isDGI = true;
            bool firstPass = true;

            string text = System.IO.File.ReadAllText(fileName);

            string cleanedString = TextHelper.RemoveDiacritics(text);

            using (Microsoft.VisualBasic.FileIO.TextFieldParser MyReader = new Microsoft.VisualBasic.FileIO.TextFieldParser(fileName))
            {
                
                MyReader.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.FixedWidth;
                MyReader.FieldWidths = ip.BodyFormat;
                MyReader.TrimWhiteSpace = ip.TrimWhiteSpaces;
                IList<ColumnSpecs> csInUse = ip.BodySpecs;

                string[] currentRow = null;
                string devise = string.Empty;

                while (!MyReader.EndOfData)
                {
                    bool isBody = false;

                    try
                    {
                        MT101_DETAIL virementDetail = new MT101_DETAIL();

                        string rowType = MyReader.PeekChars(4);

                        string keyregex = @"[a-zA-Z\s]{4}";

                        Match keymatch = Regex.Match(rowType, keyregex, RegexOptions.IgnoreCase);
                        
                        if ((rowType != string.Empty && keymatch.Success && string.Compare(rowType, ip.HeaderKey) == 0) || !firstPass)
                        {

                            int[] fieldWidths = MyReader.FieldWidths;

                            csInUse = getColumnSpecsToUse(ref fieldWidths, ip, rowType, ref isBody);

                            MyReader.FieldWidths = fieldWidths;

                            currentRow = MyReader.ReadFields();

                            for (int i = 0; i < currentRow.Length; i++)
                            {
                                string regex = String.Empty;
                                string erreurMessage = string.Empty;

                                switch (csInUse.ElementAt(i).Type)
                                {
                                    case "A":
                                        regex = @"[a-zA-Z().\/\\\s]{" + csInUse.ElementAt(i).Size + "}";
                                        erreurMessage = "Ce champ doit être de type Alphabétique sur " + csInUse.ElementAt(i).Size + " positions";
                                        break;
                                    case "N":
                                        regex = @"[0-9]{" + csInUse.ElementAt(i).Size + "}";
                                        erreurMessage = "Ce champ doit être de type Numérique sur " + csInUse.ElementAt(i).Size + " positions";
                                        break;
                                    case "AN":
                                        regex = @"[\w\s]{" + csInUse.ElementAt(i).Size + "}";
                                        erreurMessage = "Ce champ doit être de type Alphanumérique sur " + csInUse.ElementAt(i).Size + " positions";
                                        break;
                                    case "ANE":
                                        regex = @"[\w().,-\/\\\s]{" + csInUse.ElementAt(i).Size + "}";
                                        erreurMessage = "Ce champ doit être de type Alphanumérique sur " + csInUse.ElementAt(i).Size + " positions";
                                        break;
                                    case "B":
                                        regex = @"[\s]{" + csInUse.ElementAt(i).Size + "}";
                                        erreurMessage = "Ce champ doit contenir uniquement " + csInUse.ElementAt(i).Size + " caractères d'espace";
                                        break;
                                    case "D":
                                        regex = @"[0-9]{" + csInUse.ElementAt(i).Size + "}";
                                        erreurMessage = "Ce champ doit être de type date sur " + csInUse.ElementAt(i).Size + " positions (yyyyMMdd) ";
                                        break;
                                    default:
                                        regex = @"";
                                        erreurMessage = "Type non connu ou non paramétré  ";
                                        break;
                                }

                                Match match = Regex.Match(currentRow[i], regex, RegexOptions.IgnoreCase);

                                if (!(currentRow[i] != string.Empty && match.Success))
                                {
                                    erreursList.Add(new ProcessResult()
                                    {
                                        Controles = erreursList.Count() + 1,
                                        Description = "Champs Invalide : " + erreurMessage,
                                        Detail = "Champ : " + currentRow[i],
                                        Resultat = false
                                    });
                                }
                                if (!string.IsNullOrEmpty(csInUse.ElementAt(i).Tag))
                                {
                                    switch (csInUse.ElementAt(i).Tag)
                                    {
                                        case "20":
                                            if (csInUse.ElementAt(i).TagIndex == 1)
                                            {
                                                virement.tag_20 = currentRow[i];
                                            }
                                            else if (csInUse.ElementAt(i).TagIndex == 2)
                                            {
                                                virement.tag_20 = virement.tag_20 + currentRow[i];
                                            }
                                            break;
                                        case "21R":
                                            if (csInUse.ElementAt(i).TagIndex == 1)
                                            {
                                                virement.tag_21R_1 = currentRow[i] + " du ";
                                            }
                                            else if (csInUse.ElementAt(i).TagIndex == 2)
                                            {
                                                virement.tag_21R_2 = currentRow[i];
                                                virement.tag_30 = virement.tag_21R_2.Substring(2, 6);
                                            }
                                            break;
                                        case "32B":
                                            if (csInUse.ElementAt(i).TagIndex == 1)
                                            {
                                                try
                                                {
                                                    int deviseNumber = Convert.ToInt32(currentRow[i]);
                                                    if (deviseNumber == 0)
                                                    {
                                                        devise = "DZD";
                                                    }
                                                    else
                                                    {
                                                        erreursList.Add(new ProcessResult()
                                                        {
                                                            Controles = erreursList.Count() + 1,
                                                            Description = "Champs Invalide : La nature des fonds doit être égale à zéro  conformément à la spécification de la DGI ",
                                                            Detail = "Champ : " + currentRow[i],
                                                            Resultat = false
                                                        });
                                                    }
                                                }
                                                catch (Exception e)
                                                {
                                                    erreursList.Add(new ProcessResult()
                                                    {
                                                        Controles = erreursList.Count() + 1,
                                                        Description = "Champs Invalide : La nature des fonds doit être de type numérique sur une position",
                                                        Detail = "Champ : " + currentRow[i] + "\n" + "  " + e.Message,
                                                        Resultat = false
                                                    });
                                                }
                                            }
                                            else if (csInUse.ElementAt(i).TagIndex == 2)
                                            {
                                                virementDetail.tag_32B_1 = devise;
                                                // Formater le montant décimale
                                                decimal montant;
                                                string valeur = currentRow[i].Substring(0, 13) + "," + currentRow[i].Substring(13, 2);
                                                if (Decimal.TryParse(valeur, out montant))
                                                    virementDetail.tag_32B_2 = montant.ToString();
                                                else
                                                {
                                                    erreursList.Add(new ProcessResult()
                                                    {
                                                        Controles = erreursList.Count() + 1,
                                                        Description = "Champs Invalide : Le montant doit être de type numérique sur 15 positions (dont les 2 dernières pour les décimales)",
                                                        Detail = "Champ : " + currentRow[i],
                                                        Resultat = false
                                                    });
                                                    virementDetail.tag_32B_2 = "0";
                                                }
                                            }
                                            break;
                                        case "50H":
                                            if (csInUse.ElementAt(i).TagIndex == 1)
                                            {
                                                virement.tag_50H_1 = "/" + currentRow[i];
                                            }
                                            else if (csInUse.ElementAt(i).TagIndex == 2)
                                            {
                                                // Formater le texte sur  plusieurs lignes
                                                virement.tag_50H_2 = !string.IsNullOrEmpty(currentRow[i]) ? currentRow[i].Trim() : string.Empty;
                                            }
                                            break;
                                        case "59":
                                            if (csInUse.ElementAt(i).TagIndex == 1)
                                            {
                                                // vérification du RIB
                                                virementDetail.tag_59_1 = "/" + currentRow[i];
                                            }
                                            else if (csInUse.ElementAt(i).TagIndex == 2)
                                            {
                                                // Formater le texte sur  plusieurs lignes
                                                virementDetail.tag_59_2 = !string.IsNullOrEmpty(currentRow[i]) ? currentRow[i].Trim() : string.Empty;
                                            }
                                            break;
                                        case "70":
                                            if (string.IsNullOrEmpty(currentRow[i]))
                                            {
                                                erreursList.Add(new ProcessResult()
                                                {
                                                    Controles = erreursList.Count() + 1,
                                                    Description = "Champs Invalide : La référence de la télé-déclaration ne doit pas être vide",
                                                    Detail = "Champ : " + currentRow[i],
                                                    Resultat = false
                                                });
                                            }
                                            else {
                                                virementDetail.tag_70 = !string.IsNullOrEmpty(currentRow[i]) ? currentRow[i].Trim() : string.Empty;
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }

                            if (isBody)
                            {
                                virementDetail.tag_57A = ip.BicRecepteur;
                                virementDetail.tag_23E = ip.Tag23E;
                                virementDetail.tag_21 = virement.tag_21R_1 + virement.tag_21R_2;
                                virement.Details.Add(virementDetail);
                            }
                        }
                        else
                        {
                            isDGI = false;
                            break;
                        }

                        if (firstPass)
                        {
                            firstPass = false;
                        }
                    }
                    catch (Microsoft.VisualBasic.FileIO.MalformedLineException ex)
                    {
                        erreursList.Add(new ProcessResult()
                        {
                            Controles = erreursList.Count() + 1,
                            Description = "Une erreur est survenu lors du traitement du fichier " + Path.GetFileName(fileName),
                            Detail = ex.Message,
                            Resultat = false
                        });
                    }
                }
            }

            string fileNameDestination = "TELP" + DateTime.Now.ToString("yyyyMMddHHmmffff") + ".SWF";

            if (isDGI)
            {
                if (erreursList.Count == 0)
                {

                    List<ProcessResult> erreurExport = virement.export(outputDirectory, fileNameDestination);
                    if (erreurExport.Count > 0)
                    {
                        erreursList.AddRange(erreurExport);
                    }
                    else
                    {
                        try
                        {
                            File.Copy(fileName, archiveDGIDirectory + "\\" + Path.GetFileName(fileName));
                        }
                        catch (Exception)
                        {
                            // Log warning impossible d'archiver
                        }
                    }
                }
            }
            else {
                erreursList.Add(new ProcessResult()
                {
                    Controles = erreursList.Count() + 1,
                    Description = "Format de fichier NON DGI (A ignorer) ",
                    Detail = "Le fichier " + Path.GetFileName(fileName) + " n'est pas au format DGI ",
                    Resultat = false
                });
            }

            if (erreursList.Count == 0)
            {
                fileOutput = fileNameDestination;
            }
            else fileOutput = String.Empty;

            return erreursList;
        }

        private static IList<ColumnSpecs> getColumnSpecsToUse(ref int[] FieldWidths, InPutParser ip, string rowType, ref bool isBody)
        {
            if (string.Compare(rowType, ip.HeaderKey) == 0)
            {
                FieldWidths = ip.HeaderFormat;
                return ip.HeaderSpecs;
            }
            else if (ip.UseFooter && (string.Compare(rowType, ip.FooterKey) == 0))
            {
                FieldWidths = ip.FooterFormat;
                return ip.FooterSpecs;
            }
            else
            {
                isBody = true;
                FieldWidths = ip.BodyFormat;
                return ip.BodySpecs;
            }
        }
   }
}
