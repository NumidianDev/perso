﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FP_TO_MT101
{
    class MT101_DETAIL
    {
        public string tag_21 { get; set; }
        public string tag_23E { get; set; }
        public string tag_32B_1 { get; set; }
        public string tag_32B_2 { get; set; }
        public string tag_57A { get; set; }
        public string tag_59_1 { get; set; }
        public string tag_59_2 { get; set; }
        public string tag_70 { get; set; }
        public string tag_71A { get { return "OUR"; } }
    }
}
