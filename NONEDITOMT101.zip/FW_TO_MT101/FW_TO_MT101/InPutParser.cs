﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace FP_TO_MT101
{
    class InPutParser
    {

        private const string XML_ROOT_NODE = "DGEParser";
        private const string XML_COLUMN_WIDTH = "ColumnWidth";
        private const string XML_HEADER_COLUMN_WIDTHS = "HeadColumnWidths";
        private const string XML_BODY_COLUMN_WIDTHS = "BodyColumnWidths";
        private const string XML_FOOTER_COLUMN_WIDTHS = "FooterColumnWidths";
        private const string XML_TRIM_WHITE_SPACE = "TrimWhiteSpace";
        private const string XML_HEADER_KEY = "HeaderKey";
        private const string XML_FOOTER_KEY = "FooterKey";
        private const string XML_USE_FOOTER = "UseFooter";
        
        private const string XML_TEXT_FIELD_TYPE = "TextFieldType";

        private const string XML_SAFE_STRING_DELIMITER = ",";

        private const string XML_BIC_EMETTEUR = "BicEmetteur";
        private const string XML_BIC_RECEPTEUR = "BicRecepteur";
        private const string XML_TAG23E = "Tag23E";

        int[] _bodyFormat;
        int[] _enteteFormat;
        int[] _footerFormat;
        bool _trimWhiteSpaces = false;
        bool _useFooter = false;
        
        string _headerKey = String.Empty;
        string _footerKey = String.Empty;
        string _bicEmetteur = String.Empty;
        string _bicRecepteur = String.Empty;
        string _tag23E = String.Empty;

        IList<ColumnSpecs> headerSpecs = new List<ColumnSpecs>();
        IList<ColumnSpecs> bodySpecs = new List<ColumnSpecs>();
        IList<ColumnSpecs> footerSpecs = new List<ColumnSpecs>();

        public InPutParser() {

            string schemaXmlFile = ConfigurationManager.AppSettings["SchemaFile"];

            if (String.IsNullOrEmpty(schemaXmlFile) || !File.Exists(schemaXmlFile))
            {
                throw new Exception("Le Fichier de mapping Schema.xml n'existe pas");
            }
            else {
                Load(schemaXmlFile);
            }
        }

        public int[] BodyFormat
        {
            get {
                return _bodyFormat;            
            }
        }

        public int[] HeaderFormat
        {
            get
            {
                return _enteteFormat;
            }
        }

        public int[] FooterFormat
        {
            get
            {
                return _footerFormat;
            }
        }

        

        public bool TrimWhiteSpaces {
            get {
                return _trimWhiteSpaces;
            }
        }

        public bool UseFooter
        {
            get
            {
                return _useFooter;
            }
        }

        public string HeaderKey
        {
            get
            {
                return _headerKey;
            }
        }

        public string FooterKey
        {
            get
            {
                return _footerKey;
            }
        }

        public string BicEmetteur
        {
            get
            {
                return _bicEmetteur;
            }
        }

        public string BicRecepteur
        {
            get
            {
                return _bicRecepteur;
            }
        }

        public string Tag23E
        {
            get
            {
                return _tag23E;
            }
        }

        public IList<ColumnSpecs> BodySpecs
        {
            get
            {
                return bodySpecs;
            }
        }

        public IList<ColumnSpecs> HeaderSpecs
        {
            get
            {
                return headerSpecs;
            }
        }

        public IList<ColumnSpecs> FooterSpecs
        {
            get
            {
                return footerSpecs;
            }
        }

        private void Load(String sConfigXmlFile)
        {
            XmlDocument xmlConfig = new XmlDocument();

            xmlConfig.Load(sConfigXmlFile);

            Load(xmlConfig);
        }

        private void Load(XmlDocument xmlConfig)
        {
            XmlElement xmlElement;

            ////////////////////////////////////////////////////////////////////
            // Access each element and load the contents of the configuration //
            // into the current GenericParser object.                         //
            ////////////////////////////////////////////////////////////////////

            xmlElement = xmlConfig.DocumentElement[XML_HEADER_COLUMN_WIDTHS];

            if ((xmlElement != null) && (xmlElement.ChildNodes.Count > 0))
            {
                List<int> lstColumnWidths = new List<int>(xmlElement.ChildNodes.Count);

                int index = 0;

                foreach (XmlElement xmlColumnWidth in xmlElement.ChildNodes){
                    if (xmlColumnWidth.Name == XML_COLUMN_WIDTH)
                    {
                        lstColumnWidths.Add(Convert.ToInt32(xmlColumnWidth.InnerText));
                        headerSpecs.Add(new ColumnSpecs { 
                            Index = index,
                            Position = "Header",
                            Size = Convert.ToInt32(xmlColumnWidth.InnerText),
                            Type = xmlColumnWidth.Attributes["Type"].Value,
                            Tag = (null != xmlColumnWidth.Attributes["Tag"]) ? xmlColumnWidth.Attributes["Tag"].Value : string.Empty,
                            TagIndex = (null != xmlColumnWidth.Attributes["TagIndex"]) ? Convert.ToInt32(xmlColumnWidth.Attributes["TagIndex"].Value) : 0
                        });
                    }
                    index++;
                }

                if (lstColumnWidths.Count > 0)
                    _enteteFormat = lstColumnWidths.ToArray();
            }

            /////////////////////////////////////////////////////////////

            xmlElement = xmlConfig.DocumentElement[XML_BODY_COLUMN_WIDTHS];

            if ((xmlElement != null) && (xmlElement.ChildNodes.Count > 0))
            {
                List<int> lstColumnWidths = new List<int>(xmlElement.ChildNodes.Count);

                int index = 0;

                foreach (XmlElement xmlColumnWidth in xmlElement.ChildNodes)
                {
                    if (xmlColumnWidth.Name == XML_COLUMN_WIDTH)
                    {
                        lstColumnWidths.Add(Convert.ToInt32(xmlColumnWidth.InnerText));
                        bodySpecs.Add(new ColumnSpecs
                        {
                            Index = index,
                            Position = "Body",
                            Size = Convert.ToInt32(xmlColumnWidth.InnerText),
                            Type = xmlColumnWidth.Attributes["Type"].Value,
                            Tag = (null != xmlColumnWidth.Attributes["Tag"]) ? xmlColumnWidth.Attributes["Tag"].Value : string.Empty,
                            TagIndex = (null != xmlColumnWidth.Attributes["TagIndex"]) ? Convert.ToInt32(xmlColumnWidth.Attributes["TagIndex"].Value) : 0
                        });
                    }
                    index++;
                }

                if (lstColumnWidths.Count > 0)
                    _bodyFormat = lstColumnWidths.ToArray();
            }

            /////////////////////////////////////////////////////////////

            xmlElement = xmlConfig.DocumentElement[XML_FOOTER_COLUMN_WIDTHS];

            if ((xmlElement != null) && (xmlElement.ChildNodes.Count > 0))
            {
                List<int> lstColumnWidths = new List<int>(xmlElement.ChildNodes.Count);

                int index = 0;

                foreach (XmlElement xmlColumnWidth in xmlElement.ChildNodes)
                {
                    if (xmlColumnWidth.Name == XML_COLUMN_WIDTH)
                    {
                        lstColumnWidths.Add(Convert.ToInt32(xmlColumnWidth.InnerText));
                        footerSpecs.Add(new ColumnSpecs
                        {
                            Index = index,
                            Position = "Footer",
                            Size = Convert.ToInt32(xmlColumnWidth.InnerText),
                            Type = xmlColumnWidth.Attributes["Type"].Value
                        });
                    }
                    index++;
                }

                if (lstColumnWidths.Count > 0)
                    _footerFormat = lstColumnWidths.ToArray();
            }

            xmlElement = xmlConfig.DocumentElement[XML_TRIM_WHITE_SPACE];

            if ((xmlElement != null) && (!String.IsNullOrEmpty(xmlElement.InnerText)))
            {
                _trimWhiteSpaces = Convert.ToBoolean(xmlElement.InnerText);
            }

            xmlElement = xmlConfig.DocumentElement[XML_USE_FOOTER];

            if ((xmlElement != null) && (!String.IsNullOrEmpty(xmlElement.InnerText)))
            {
                _useFooter = Convert.ToBoolean(xmlElement.InnerText);
            }

            xmlElement = xmlConfig.DocumentElement[XML_HEADER_KEY];

            if ((xmlElement != null) && (!String.IsNullOrEmpty(xmlElement.InnerText)))
            {
                _headerKey = xmlElement.InnerText;
            }

            xmlElement = xmlConfig.DocumentElement[XML_FOOTER_KEY];

            if ((xmlElement != null) && (!String.IsNullOrEmpty(xmlElement.InnerText)))
            {
                _footerKey = xmlElement.InnerText;
            }

            xmlElement = xmlConfig.DocumentElement[XML_BIC_EMETTEUR];

            if ((xmlElement != null) && (!String.IsNullOrEmpty(xmlElement.InnerText)))
            {
                _bicEmetteur = xmlElement.InnerText;
            }

            xmlElement = xmlConfig.DocumentElement[XML_BIC_RECEPTEUR];

            if ((xmlElement != null) && (!String.IsNullOrEmpty(xmlElement.InnerText)))
            {
                _bicRecepteur = xmlElement.InnerText;
            }

            xmlElement = xmlConfig.DocumentElement[XML_TAG23E];

            if ((xmlElement != null) && (!String.IsNullOrEmpty(xmlElement.InnerText)))
            {
                _tag23E = xmlElement.InnerText;
            }
            
        }
    }
}
