﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FP_TO_MT101
{
    class ProcessResult
    {

        public int Controles{get; set;}

        public string Description{get; set;}

        public bool Resultat{get; set;}

        public string Detail{get; set;}

    }
}
