﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace FP_TO_MT101
{
    class MT101
    {
        public MT101(){
            _details = new List<MT101_DETAIL>();
        }

        private IList<MT101_DETAIL> _details;

        public IList<MT101_DETAIL> Details { get { return _details; } }

        public string tag_20 { get; set; }
        public string tag_21R_1 { get; set; }
        public string tag_21R_2 { get; set; }
        public string tag_28D { get { return "1/1"; } }
        public string tag_50H_1 { get; set; }
        public string tag_50H_2 { get; set; }
        public string tag_52A { get; set; }
        public string tag_30 { get; set; }

        public List<ProcessResult> export(string fileDir, string fileName)
        {
            List<ProcessResult> erreursList = new List<ProcessResult>();

            try
            {
                if (!Directory.Exists(fileDir))
                {
                    Directory.CreateDirectory(fileDir);
                }
                else {

                    string yyMMddHHmmDate = DateTime.Now.ToString("yyMMddHHmm");

                    string HHmyyMMddmDate = DateTime.Now.ToString("HHmmyyMMdd");

                    string tag20Ref = DateTime.Now.ToString("yyMMddHHmm") + tag_20;

                    

                    using (StreamWriter writer = new StreamWriter(new FileStream(fileDir + "\\" + fileName  , FileMode.Create)))
                    {

                        //writer.WriteLine("{1:F01" + tag_52A + "XXXX0000000000}{2:I101" + tag_52A + "AXXXXN          " + DateTime.Now.ToString("yyMMddHHmm") + "N}{3:{113:XXXX}}{4:");
                        writer.WriteLine((char)1 + "{1:F01" + tag_52A + "XXXX0000000000}{2:0101" + HHmyyMMddmDate + tag_52A + "AXXX          " + DateTime.Now.ToString("yyMMddHHmm") + "N}{3:{113:XXXX}}{4:");
                        writer.WriteLine(":20:" + tag20Ref);
                        writer.WriteLine(":21R:" + tag_21R_1 + tag_21R_2);
                        writer.WriteLine(":28D:" + tag_28D);
                        writer.WriteLine(":50H:" + tag_50H_1);
                        writer.WriteLine(tag_50H_2);
                        writer.WriteLine(":52A:" + tag_52A);
                        writer.WriteLine(":30:" + tag_30);

                        foreach (MT101_DETAIL detailVirement in Details)
                        {

                            writer.WriteLine(":21:" + detailVirement.tag_21);
                            if (!string.IsNullOrEmpty(detailVirement.tag_23E)) {
                                writer.WriteLine(":23E:" + detailVirement.tag_23E);
                            }
                            writer.WriteLine(":32B:" + detailVirement.tag_32B_1 + detailVirement.tag_32B_2);
                            writer.WriteLine(":57A:" + detailVirement.tag_57A);
                            writer.WriteLine(":59:" + detailVirement.tag_59_1);
                            writer.WriteLine(detailVirement.tag_59_2);
                            writer.WriteLine(":70:" + detailVirement.tag_70);
                            writer.WriteLine(":71A:" + detailVirement.tag_71A);
                        }

                        writer.Write("-}" + (char) 3);
                    }
                }
            }
            catch (Exception ex)
            {
                erreursList.Add(new ProcessResult()
                {
                    Controles = erreursList.Count + 1,
                    Description = "Une erreur est survenue lors de la génération du MT101",
                    Detail = ex.Message,
                    Resultat = false
                });
            }

            Thread.Sleep(1);

            return erreursList;
        }

    }
}
