﻿Imports log4net.Config
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Configuration

Module Module1

    Dim Resultat As DataTable = New DataTable
    Private ReadOnly log As log4net.ILog = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)
    Sub Main()

        '' Configuration
        Dim path = My.Application.Info.DirectoryPath
        Dim configFile = path + "\log4net.config"
        XmlConfigurator.Configure(New FileInfo(configFile))


        '' ecrire log
        log.Debug("Démarrage CA_Annul : " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"))

        Init()

        '1) traitement de la requette sql pour recuperr tout les resultats
        '2) remplire le datatable resultat
        '       2.1 recuperer tout les pie avec GetPie()
        '       2.2 pour chaque Pie appler Get_Cells() (existe dans le module calcul cols) 
        '                   2.2.1 calculer les columns pour chaque pie
        '                   2.2.2 Inserer la ligne dans le datatable resultats
        '
        '
        Remplissage(Traiter_reqs())

        '' exporter le Data table principale vers un fichier Excel
        exportExcel(Resultat)
        log.Debug("Fin CAT : " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"))

    End Sub

    Public Sub Init()

        Resultat.Columns.Add("Piece", GetType(String))
        Resultat.Columns.Add("Opération", GetType(String))
        Resultat.Columns.Add("CA_Annulée", GetType(Decimal))
        Resultat.Columns.Add("Produits Constatés d'Avances Annulée", GetType(Decimal))
        Resultat.Columns.Add("Capital leasing Annulée", GetType(Decimal))
        Resultat.Columns.Add("TVA_340201_17", GetType(Decimal))
        Resultat.Columns.Add("TVA_340201_19", GetType(Decimal))
        Resultat.Columns.Add("Commentaire", GetType(String))
    End Sub

    Public Sub Remplissage(dt1 As DataTable)
        For Each pie In GetPies(dt1)
            Dim ligne_temp = GetCells(dt1.Select("pie='" + pie + "'"), pie)
            Resultat.Rows.Add(ligne_temp.piece, ligne_temp.operation, ligne_temp.CAA, ligne_temp.PCAA, ligne_temp.CALA, ligne_temp.TVA_Annul_17, ligne_temp.TVA_Annul_19, ligne_temp.Commentaire)
        Next
    End Sub

    '''''''''' Recupere toutes les piece comptable d'un datatable dans un list
    Public Function GetPies(dt As DataTable) As List(Of String)
        Dim list As New List(Of String)
        '' recuer
       
        Dim s As String = Getparam_Etat_TVA_Annul()
        Dim Alllignes As DataRow() = dt.Select("cha in (" + s + ")")

        Try
            dt = Alllignes.CopyToDataTable
        Catch ex As Exception
            log.Debug("Aucune Pie Taxable Trouvé")
        End Try

        Dim l1 = (From row In dt.AsEnumerable()
                   Select row.Field(Of String)("Pie") Distinct)

        list = l1.ToList()
        Return list
    End Function

    ''''''''''''' Recuperation de toute les resultat avant filtration
    Public Function Traiter_reqs() As DataTable

        'Dim dirInfo As DirectoryInfo = New DirectoryInfo(scriptDirectory)

        ''
        Dim sqlFile As String

        Dim jour_semaine As Integer = Integer.Parse(DateTime.Now.DayOfWeek)


        '' Dimanche = 0 (j-3) Samedi = 6 (j-2) sinon executer le script de j-1 
        If (jour_semaine = 0) Then
            'dimanche
            sqlFile = "Get_J_3.sql"
        ElseIf (jour_semaine = 6) Then
            'samedi
            sqlFile = "Get_J_2.sql"
        Else
            'Autre
            sqlFile = "Get_J_1.sql"
        End If


        '''''' recuperer la requette du fichier texte
        Dim path = My.Application.Info.DirectoryPath
        Dim file_req As FileInfo = New FileInfo(path + "\" + sqlFile)
        Dim script As String = file_req.OpenText().ReadToEnd()

        Dim dtemp As DataTable = New DataTable
        Dim Connexion As New OleDbConnection(GetConStrDelta)
        Connexion.Open()


        Dim reqs As String() = script.Split(";")
        Dim command As OleDbCommand = Connexion.CreateCommand()
        command.CommandTimeout = 1000000000
        command.CommandType = CommandType.Text
        For Each req In reqs
            command.CommandText = req
            command.ExecuteNonQuery()
        Next

        Dim Adapter As New OleDbDataAdapter(command)
        Adapter.Fill(dtemp)
        Return dtemp
    End Function

    Sub Envoi_Partage(nom_fichier As String)

        Dim chemin As String = ConfigurationManager.AppSettings("OutputF").ToString
        Dim fich1 = nom_fichier.Split("/")
        nom_fichier = fich1(fich1.Count - 1)

        Dim path_partage As String = ConfigurationManager.AppSettings("path_partage").Replace("\", "/") + nom_fichier
        Dim path_local As String = ConfigurationManager.AppSettings("OutputF") + nom_fichier

        Try
            log.Debug("Fichier generé : " + fichier_excel)
            File.Copy(path_local, path_partage)
            log.Debug("Fichier envoyé vers le partage :" + path_partage)
        Catch e As Exception
            log.Error("Erreur : Fichier Non copier vers le partage " & e.Message)
        End Try

    End Sub

End Module
