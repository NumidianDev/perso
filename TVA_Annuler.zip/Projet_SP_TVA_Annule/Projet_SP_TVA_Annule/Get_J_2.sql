﻿select a.dag, a.dco,a.age,a.ncp,a.dev,a.pie,a.rlet, a.mon, a.sen, a.ope
from bkhis a
where a.dco = today-2
--and
--(a.ncp like '7%' or a.ncp like'3%')
into temp tab_his
;
Select h.*,c.cha 
from tab_his h
left join  bkcom c 
on	h.age = c.age 
	and h.dev = c.dev 
	and h.ncp = c.ncp 
where  
(c.cha in('340201','365000','365001','365002','365003','341795','204002'))
or
(h.ncp in('3402010000','3402010005'))
or
(h.ncp like'7%')
or
(c.cha like'7%')