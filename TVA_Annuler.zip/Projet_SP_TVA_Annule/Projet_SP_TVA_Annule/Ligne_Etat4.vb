﻿Public Class Ligne_Etat4

    Public piece As String
    Public operation As String
    Public CAA As Decimal
    Public PCAA As Decimal
    Public CALA As Decimal
    Public TVA_Annul_17 As Decimal
    Public TVA_Annul_19 As Decimal
    Public Commentaire As String

End Class
