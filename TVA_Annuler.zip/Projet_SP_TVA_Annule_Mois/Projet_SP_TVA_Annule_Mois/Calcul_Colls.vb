﻿Module Calcul_Colls


    ''''''''''''''' Calcul d'une ligne d'une pie donnée
    Public Function GetCells(Alllignes As DataRow(), pie As String) As Ligne_Etat4
        Dim ligne_temp As Ligne_Etat4 = New Ligne_Etat4
        ligne_temp.piece = pie
        ligne_temp.operation = Getoperation(Alllignes)
        ligne_temp.CAA = calc_CAA(Alllignes)
        ligne_temp.PCAA = calc_PCAA(Alllignes)
        ligne_temp.CALA = calc_CALA(Alllignes)
        ligne_temp.TVA_Annul_17 = Calc_TVA_Annul_17(Alllignes)
        ligne_temp.TVA_Annul_19 = Calc_TVA_Annul_19(Alllignes)
        ligne_temp.Commentaire = Get_Commentaire(ligne_temp)
        Return ligne_temp
    End Function

    Public Function Get_Commentaire(ligne_temp As Ligne_Etat4) As String
        If Math.Abs(ligne_temp.CAA + ligne_temp.PCAA + ligne_temp.CALA) <> 0 Then
            Return "Annulation TVA"
        End If
        Return "Restitution TVA "
    End Function

    Public Function Getoperation(Alllignes As DataRow()) As String
        Dim ope As String = Alllignes(0).Item("ope").ToString
        For Each ligne As DataRow In Alllignes
            If (ligne.Item("ope") <> ope) Then
                Return ("XXX")
            End If
        Next
        Return ope
    End Function


    Public Function calc_CAA(Alllignes As DataRow()) As Double
        Dim dt As DataTable = Alllignes.CopyToDataTable()
        Dim s As String = Getparam_CAA()
        Alllignes = dt.Select("(cha like '7%') or (ncp in (" + s + ")) ")
        Dim CATt As Double
        For Each ligne As DataRow In Alllignes
            If (ligne.Item("sen") = "D") Then
                CATt = CATt - ligne.Item("mon")
            ElseIf (ligne.Item("sen") = "C") Then
                CATt = CATt + ligne.Item("mon")
            End If
        Next
        Return CATt
    End Function


    Public Function calc_PCAA(Alllignes As DataRow()) As Double
        Dim dt As DataTable = Alllignes.CopyToDataTable()
        Dim s As String = Getparam_PCAA()
        Alllignes = dt.Select("cha in (" + s + ") ")
        Dim PCAA As Double
        For Each ligne As DataRow In Alllignes
            If (ligne.Item("sen") = "D") Then
                PCAA = PCAA - ligne.Item("mon")
            ElseIf (ligne.Item("sen") = "C") Then
                PCAA = PCAA + ligne.Item("mon")
            End If
        Next
        Return PCAA
    End Function

    Public Function calc_CALA(Alllignes As DataRow()) As Double
        Dim dt As DataTable = Alllignes.CopyToDataTable()
        Dim s As String = Getparam_CALA()
        Alllignes = dt.Select("cha in (" + s + ")")
        Dim CATt As Double
        For Each ligne As DataRow In Alllignes
            If (ligne.Item("sen") = "D") Then
                CATt = CATt - ligne.Item("mon")
            ElseIf (ligne.Item("sen") = "C") Then
                CATt = CATt + ligne.Item("mon")
            End If
        Next
        Return CATt
    End Function

    Public Function Calc_TVA_Annul_17(Alllignes As DataRow()) As Double
        Dim dt As DataTable = Alllignes.CopyToDataTable()
        Dim s As String = Getparam_TVA_Annul_17()
        Alllignes = dt.Select("ncp in (" + s + ")")
        Dim TVA340201 As Double
        For Each ligne As DataRow In Alllignes
            If (ligne.Item("sen") = "D") Then
                TVA340201 = TVA340201 - ligne.Item("mon")
            ElseIf (ligne.Item("sen") = "C") Then
                TVA340201 = TVA340201 + ligne.Item("mon")
            End If
        Next
        Return TVA340201
    End Function

    Public Function Calc_TVA_Annul_19(Alllignes As DataRow()) As Double
        Dim dt As DataTable = Alllignes.CopyToDataTable()
        Dim s As String = Getparam_TVA_Annul_19()
        Alllignes = dt.Select("ncp in (" + s + ")")
        Dim TVA340201 As Double
        For Each ligne As DataRow In Alllignes
            If (ligne.Item("sen") = "D") Then
                TVA340201 = TVA340201 - ligne.Item("mon")
            ElseIf (ligne.Item("sen") = "C") Then
                TVA340201 = TVA340201 + ligne.Item("mon")
            End If
        Next
        Return TVA340201
    End Function


End Module
