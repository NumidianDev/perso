﻿Imports OfficeOpenXml
Imports System.IO
Imports System.Configuration
Imports System.Data.SqlClient

Module Utils

    Public fichier_excel As String
    Public Sub exportExcel(result As DataTable)

        Dim chemin As String = ConfigurationManager.AppSettings("OutputF").ToString
        Dim nom As String = ConfigurationManager.AppSettings("nomf").ToString


        Dim ladate As String
        Dim mois As Integer
        Dim year As Integer
        '''' Si Janvier on ramene l'annnée passé
        If (DateTime.Now.Month <> 1) Then
            mois = DateTime.Now.Month - 1
            year = DateTime.Now.Year
        Else
            mois = 12
            year = DateTime.Now.Year - 1
        End If

        Dim mlettre As String = ""


        Select Case mois
            Case 1
                mlettre = "Janvier"
            Case 2
                mlettre = "Fevrier"
            Case 3
                mlettre = "Mars"
            Case 4
                mlettre = "Avril"
            Case 5
                mlettre = "Mai"
            Case 6
                mlettre = "Juin"
            Case 7
                mlettre = "Juillet"
            Case 8
                mlettre = "aout"
            Case 8
                mlettre = "Septembre"
            Case 10
                mlettre = "Octobre"
            Case 11
                mlettre = "Novembre"
            Case 12
                mlettre = "Decembre"
            Case Else

        End Select


        ladate = "_Mois_" + mlettre + "_Annee_" + year.ToString + "_Le_" + CStr(DateTime.Now.Day) + "-" + CStr(mois + 1) + "-" + CStr(year)

        Dim nom_fichier As String = chemin + nom + ladate + ".xlsx"


        IO.File.Delete(nom_fichier)
        Dim pck As ExcelPackage = New ExcelPackage(New FileInfo(nom_fichier))
        Dim ws = pck.Workbook.Worksheets.Add("Results")
        ws.Cells("A1").LoadFromDataTable(result, True, Table.TableStyles.None)


        ws.Column(7).Style.Numberformat.Format = "0.00"
        ws.Column(6).Style.Numberformat.Format = "0.00"
        ws.Column(5).Style.Numberformat.Format = "0.00"
        ws.Column(4).Style.Numberformat.Format = "0.00"
        ws.Column(3).Style.Numberformat.Format = "0.00"



        ws.Column(8).AutoFit()
        ws.Column(7).AutoFit()
        ws.Column(6).AutoFit()
        ws.Column(5).AutoFit()
        ws.Column(4).AutoFit()
        ws.Column(3).AutoFit()
        ws.Column(2).AutoFit()
        ws.Column(1).AutoFit()


        ws.Column(8).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ws.Column(7).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ws.Column(6).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ws.Column(5).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ws.Column(4).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ws.Column(3).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ws.Column(2).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ws.Column(1).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Center
        ' ws.Column(12).Style.Font.Bold = True
        pck.Save()

        fichier_excel = nom_fichier

        Envoi_Partage(nom_fichier)


    End Sub

    Public Function GetConStrDelta() As String
        Return ConfigurationManager.ConnectionStrings("Delta").ConnectionString
    End Function

    Public Function GetConStrDev() As String
        Return ConfigurationManager.ConnectionStrings("Dev").ConnectionString
    End Function

    Public Function Getparam_Etat_TVA_Annul() As String

        Dim con As SqlConnection = New SqlConnection(GetConStrDev)
        Dim command As New SqlCommand("Select * from SP_Parametres where Nom_param ='Etat_TVA_Annul'", con)
        con.Open()
        Dim read As SqlDataReader = command.ExecuteReader


        Try
            read.Read()
        Catch ex As Exception
            Return ""
        End Try

        Dim final = read.Item("Valeur_param").ToString
        con.Close()
        Return final


    End Function


    Public Function Getparam_CAA() As String

        Dim con As SqlConnection = New SqlConnection(GetConStrDev)
        Dim command As New SqlCommand("Select * from SP_Parametres where Nom_param ='CA_Annul'", con)
        con.Open()
        Dim read As SqlDataReader = command.ExecuteReader

        Try
            read.Read()
        Catch ex As Exception
            Return ""
        End Try

        Dim final = read.Item("Valeur_param").ToString
        con.Close()
        Return final
    End Function

   
    '''' recuperation des paramaetres de PCA Annulée
    Public Function Getparam_PCAA() As String

        Dim con As SqlConnection = New SqlConnection(GetConStrDev)
        Dim command As New SqlCommand("Select * from SP_Parametres where Nom_param ='PCA_Annul'", con)
        con.Open()
        Dim read As SqlDataReader = command.ExecuteReader

        Try
            read.Read()
        Catch ex As Exception
            Return ""
        End Try

        Dim final = read.Item("Valeur_param").ToString
        con.Close()
        Return final
    End Function

    Public Function Getparam_CALA() As String

        Dim con As SqlConnection = New SqlConnection(GetConStrDev)
        Dim command As New SqlCommand("Select * from SP_Parametres where Nom_param ='CALA_Annul'", con)
        con.Open()
        Dim read As SqlDataReader = command.ExecuteReader

        Try
            read.Read()
        Catch ex As Exception
            Return ""
        End Try

        Dim final = read.Item("Valeur_param").ToString
        con.Close()
        Return final
    End Function
   
    '''' recuperation des paramaetres de TVA_Annul_17
    Public Function Getparam_TVA_Annul_17() As String

        Dim con As SqlConnection = New SqlConnection(GetConStrDev)
        Dim command As New SqlCommand("Select * from SP_Parametres where Nom_param ='TVA_Annul_17'", con)
        con.Open()
        Dim read As SqlDataReader = command.ExecuteReader

        Try
            read.Read()
        Catch ex As Exception
            Return ""
        End Try

        Dim final = read.Item("Valeur_param").ToString
        con.Close()
        Return final


    End Function



    '''' recuperation des paramaetres de TVA_Annul_19
    Public Function Getparam_TVA_Annul_19() As String

        Dim con As SqlConnection = New SqlConnection(GetConStrDev)
        Dim command As New SqlCommand("Select * from SP_Parametres where Nom_param ='TVA_Annul_19'", con)
        con.Open()
        Dim read As SqlDataReader = command.ExecuteReader

        Try
            read.Read()
        Catch ex As Exception
            Return ""
        End Try

        Dim final = read.Item("Valeur_param").ToString
        con.Close()
        Return final


    End Function


End Module
