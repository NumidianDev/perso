﻿Imports System.ComponentModel.DataAnnotations.Schema
Imports System.ComponentModel.DataAnnotations
Imports Newtonsoft.Json

<Table("PreDom_Td")>
Partial Public Class PreDom_Td
    <Key()>
    Public Property Id() As Int32
        Get
            Return m_id
        End Get
        Set(ByVal value As Int32)
            m_id = value
        End Set
    End Property
    Private m_id As Int32

    Public Property Position() As String
        Get
            Return _Position
        End Get
        Set(ByVal value As String)
            _Position = value
        End Set
    End Property
    Private _Position As String

    Public Property Description() As String
        Get
            Return _Description
        End Get
        Set(ByVal value As String)
            _Description = value
        End Set
    End Property
    Private _Description As String

    Public Property Origine() As String
        Get
            Return _Origine
        End Get
        Set(ByVal value As String)
            _Origine = value
        End Set
    End Property
    Private _Origine As String

    Public Property Id_PreDom_Dossier() As Int32
        Get
            Return m_Id_PreDom_Dossier
        End Get
        Set(value As Int32)
            m_Id_PreDom_Dossier = value
        End Set
    End Property
    Private m_Id_PreDom_Dossier As Int32

    <JsonIgnore>
    <ForeignKey("Id_PreDom_Dossier")>
    Public Overridable Property PreDom_Dossier() As PreDom_Dossier
        Get
            Return m_PreDom_Dossier
        End Get
        Set(value As PreDom_Dossier)
            m_PreDom_Dossier = value
        End Set
    End Property
    Private m_PreDom_Dossier As PreDom_Dossier


End Class
