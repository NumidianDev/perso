import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SgaFileUploadComponent } from './sga-file-upload.component';
import { DndDirective } from '../directives/dnd.directive';
import { ProgressComponent } from '../progress/progress.component';



@NgModule({
  declarations: [SgaFileUploadComponent, DndDirective, ProgressComponent],
  imports: [
    CommonModule
  ],
  exports: [SgaFileUploadComponent]
})
export class SgaFileUploadModule { }
