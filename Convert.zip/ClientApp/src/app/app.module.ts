import { LayoutModule } from '@angular/cdk/layout'
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './modules/material/material.module';
import { SgaToolbarComponent } from './sga-toolbar/sga-toolbar.component';
import { SgaFileUploadModule } from './sga-file-upload/sga-file-upload.module';


@NgModule({
  declarations: [
    AppComponent,
    SgaToolbarComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    LayoutModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([]),
    BrowserAnimationsModule,
    MaterialModule,
    SgaFileUploadModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
