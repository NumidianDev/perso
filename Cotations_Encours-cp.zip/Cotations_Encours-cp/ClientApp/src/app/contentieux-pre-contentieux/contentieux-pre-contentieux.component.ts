import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-contentieux-pre-contentieux',
  templateUrl: './contentieux-pre-contentieux.component.html',
  styleUrls: ['./contentieux-pre-contentieux.component.scss']
})
export class ContentieuxPreContentieuxComponent implements OnInit {

  constructor(private route: ActivatedRoute) {
    console.log(route);
  }

  ngOnInit(): void {
  }

}
