import { Component, OnInit } from '@angular/core';
import { periods } from '../app.module';

@Component({
  selector: 'app-engagements-groupes',
  templateUrl: './engagements-groupes.component.html',
  styleUrls: ['./engagements-groupes.component.scss']
})
export class EngagementsGroupesComponent implements OnInit {

  periods = periods;

  selectedPeriod: string;

  constructor() { }

  ngOnInit(): void {
  }

}
