import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-encours-impayes',
  templateUrl: './encours-impayes.component.html',
  styleUrls: ['./encours-impayes.component.scss']
})
export class EncoursImpayesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
