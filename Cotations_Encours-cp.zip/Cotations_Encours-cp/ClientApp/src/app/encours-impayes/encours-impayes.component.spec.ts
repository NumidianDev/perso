import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EncoursImpayesComponent } from './encours-impayes.component';

describe('EncoursImpayesComponent', () => {
  let component: EncoursImpayesComponent;
  let fixture: ComponentFixture<EncoursImpayesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EncoursImpayesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EncoursImpayesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
