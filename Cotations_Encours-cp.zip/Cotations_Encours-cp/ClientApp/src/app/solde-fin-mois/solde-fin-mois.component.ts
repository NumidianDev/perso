import { Component, OnInit } from '@angular/core';
import { periods } from '../app.module';

@Component({
  selector: 'app-solde-fin-mois',
  templateUrl: './solde-fin-mois.component.html',
  styleUrls: ['./solde-fin-mois.component.scss']
})
export class SoldeFinMoisComponent implements OnInit {

  periods = periods;

  selectedPeriod: string;

  constructor() { }

  ngOnInit(): void {
  }

}
