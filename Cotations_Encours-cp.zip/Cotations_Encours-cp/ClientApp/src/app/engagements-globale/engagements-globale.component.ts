import { Component, OnInit } from '@angular/core';
import { periods } from '../app.module';

@Component({
  selector: 'app-engagements-globale',
  templateUrl: './engagements-globale.component.html',
  styleUrls: ['./engagements-globale.component.scss']
})
export class EngagementsGlobaleComponent implements OnInit {

  periods = periods;

  selectedPeriod: string;

  constructor() { }

  ngOnInit(): void {
  }

}
