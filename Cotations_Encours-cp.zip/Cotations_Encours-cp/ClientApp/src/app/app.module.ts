import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMaterialModule } from './angular-material/angular-material.module';
import { EncoursImpayesComponent } from './encours-impayes/encours-impayes.component';
import { ContentieuxPreContentieuxComponent } from './contentieux-pre-contentieux/contentieux-pre-contentieux.component';
import { CotesMouvementsComponent } from './cotes-mouvements/cotes-mouvements.component';
import { DotationsRepriseComponent } from './dotations-reprise/dotations-reprise.component';
import { EngagementsComponent } from './engagements/engagements.component';
import { EngagementsGlobaleComponent } from './engagements-globale/engagements-globale.component';
import { EngagementsGroupesComponent } from './engagements-groupes/engagements-groupes.component';
import { DefaultClientComponent } from './default-client/default-client.component';
import { ClientsComponent } from './clients/clients.component';
import { PpiMarhabaComponent } from './ppi-marhaba/ppi-marhaba.component';
import { ImpRecAmiCtxComponent } from './imp-rec-ami-ctx/imp-rec-ami-ctx.component';
import { EtatDebiteursComponent } from './etat-debiteurs/etat-debiteurs.component';
import { SoldeFinMoisComponent } from './solde-fin-mois/solde-fin-mois.component';
import { RouterModule , Routes} from '@angular/router';

export const routes =  [
  { path: 'CotationsEnCours', component: EncoursImpayesComponent, label: 'Encours et Impayés' },
  { path: 'CotationsImp', component: ContentieuxPreContentieuxComponent, label: 'Clients non cotés' },
  { path: 'CotationMouvment', component: CotesMouvementsComponent, label: 'Clients cotés avec compte mouvementé' },
  { path: 'SoldeDotationReprise', component: DotationsRepriseComponent, label: 'Soldes dotations & reprise' },
  { path: 'Engagements', component: EngagementsComponent, label: 'Engagements' },
  { path: 'EngagementsGlobale', component: EngagementsGlobaleComponent, label: 'Engagements global' },
  { path: 'EngagementsGroupe', component: EngagementsGroupesComponent, label: 'Engagements Groupés' },
  { path: 'DefautClient', component: DefaultClientComponent, label: 'Defaut' },
  { path: 'Clients', component: ClientsComponent, label: 'Liste des clients' },
  { path: 'Ppi', component: PpiMarhabaComponent, label: 'PPI MARHABA' },
  { path: 'Imp_deb', component: ImpRecAmiCtxComponent, label: 'IMP_REC/AMI/CTX' },
  { path: 'debiteurs', component: EtatDebiteursComponent, label: 'Etat des débiteurs' },
  { path: 'soldesFinMois', component: SoldeFinMoisComponent, label: 'Soldes fin du mois' }
 ];

export const periods = ['Etat mensuel', 'Etat journalier'];

@NgModule({
  declarations: [
    AppComponent,
    EncoursImpayesComponent,
    ContentieuxPreContentieuxComponent,
    CotesMouvementsComponent,
    DotationsRepriseComponent,
    EngagementsComponent,
    EngagementsGlobaleComponent,
    EngagementsGroupesComponent,
    DefaultClientComponent,
    ClientsComponent,
    PpiMarhabaComponent,
    ImpRecAmiCtxComponent,
    EtatDebiteursComponent,
    SoldeFinMoisComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
