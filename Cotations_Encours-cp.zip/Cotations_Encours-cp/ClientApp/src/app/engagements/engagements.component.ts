import { Component, OnInit } from '@angular/core';
import { periods } from '../app.module';

@Component({
  selector: 'app-engagements',
  templateUrl: './engagements.component.html',
  styleUrls: ['./engagements.component.scss']
})
export class EngagementsComponent implements OnInit {

  periods = periods;

  selectedPeriod: string;

  constructor() { }

  ngOnInit(): void {
  }

}
