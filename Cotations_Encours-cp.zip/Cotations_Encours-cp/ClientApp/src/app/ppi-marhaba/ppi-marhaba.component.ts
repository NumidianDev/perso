import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppi-marhaba',
  templateUrl: './ppi-marhaba.component.html',
  styleUrls: ['./ppi-marhaba.component.scss']
})
export class PpiMarhabaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
