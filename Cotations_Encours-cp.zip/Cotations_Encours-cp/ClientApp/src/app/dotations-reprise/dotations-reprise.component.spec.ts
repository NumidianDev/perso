import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DotationsRepriseComponent } from './dotations-reprise.component';

describe('DotationsRepriseComponent', () => {
  let component: DotationsRepriseComponent;
  let fixture: ComponentFixture<DotationsRepriseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DotationsRepriseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DotationsRepriseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
