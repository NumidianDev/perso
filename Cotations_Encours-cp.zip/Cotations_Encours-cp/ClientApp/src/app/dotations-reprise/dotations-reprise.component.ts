import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dotations-reprise',
  templateUrl: './dotations-reprise.component.html',
  styleUrls: ['./dotations-reprise.component.scss']
})
export class DotationsRepriseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
