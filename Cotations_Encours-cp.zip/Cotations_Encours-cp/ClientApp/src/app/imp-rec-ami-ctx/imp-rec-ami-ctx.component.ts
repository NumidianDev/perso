import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imp-rec-ami-ctx',
  templateUrl: './imp-rec-ami-ctx.component.html',
  styleUrls: ['./imp-rec-ami-ctx.component.scss']
})
export class ImpRecAmiCtxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
