import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-client',
  templateUrl: './default-client.component.html',
  styleUrls: ['./default-client.component.scss']
})
export class DefaultClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
