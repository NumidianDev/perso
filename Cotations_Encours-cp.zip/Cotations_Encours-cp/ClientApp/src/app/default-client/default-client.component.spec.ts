import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultClientComponent } from './default-client.component';

describe('DefaultClientComponent', () => {
  let component: DefaultClientComponent;
  let fixture: ComponentFixture<DefaultClientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultClientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
