import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CotesMouvementsComponent } from './cotes-mouvements.component';

describe('CotesMouvementsComponent', () => {
  let component: CotesMouvementsComponent;
  let fixture: ComponentFixture<CotesMouvementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CotesMouvementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CotesMouvementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
