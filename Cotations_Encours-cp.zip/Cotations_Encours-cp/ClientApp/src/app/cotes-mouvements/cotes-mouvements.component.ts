import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cotes-mouvements',
  templateUrl: './cotes-mouvements.component.html',
  styleUrls: ['./cotes-mouvements.component.scss']
})
export class CotesMouvementsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
