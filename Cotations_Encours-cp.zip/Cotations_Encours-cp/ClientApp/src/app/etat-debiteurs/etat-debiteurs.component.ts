import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etat-debiteurs',
  templateUrl: './etat-debiteurs.component.html',
  styleUrls: ['./etat-debiteurs.component.scss']
})
export class EtatDebiteursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
