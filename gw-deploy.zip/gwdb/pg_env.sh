#!/bin/sh
# The script sets environment variables helpful for PostgreSQL

export PATH=/appli/PostgreSQL/10/bin:$PATH
export PGDATA=/data
export PGDATABASE=postgres
export PGUSER=postgres
export PGPORT=5432
export PGLOCALEDIR=/appli/PostgreSQL/10/share/locale
export MANPATH=$MANPATH:/appli/PostgreSQL/10/share/man

                            